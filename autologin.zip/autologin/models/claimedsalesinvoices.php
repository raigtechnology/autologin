<?php
  class Claimedsalesinvoices {
   
  }
?>