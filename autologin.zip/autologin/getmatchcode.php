<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		 
		
	$purchasecodematch = $db->query("select MatchCode from purchasecodematch where PurTaxCode = '".$_GET['value1']."' and supplyType = '".$_SESSION['type']."'  ");	
	?>	
	<select name="data[<?php echo $_GET['value2']; ?>][matchcode]" id="matchcode<?php echo $_GET['value2'];?>"  class="selectbox_small" required="required">
		<option>-- Choose --</option>
		<?php
		foreach($purchasecodematch->fetchAll() as $pcm) {
		
			if($pcm['MatchCode']=="IM"){
				$tax = "IMS";
			} else if($pcm['MatchCode']=="IS"){
				$tax = "ISS";
			} else {
				$tax = $pcm['MatchCode'];
			}
		
		
		?>
		<option value="<?php echo $tax; ?>"><?php echo $tax; ?></option>			
		<?php
		}
		?>
	</select>

