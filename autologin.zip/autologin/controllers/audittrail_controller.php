<?php
  class AudittrailController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
		$cid = $_GET['cid']; // company id
		
		
		$windownamelist =  array();		
		$windows = $db->query("select distinct(Window_name) as Window_name from audittrial where system_name='Auto Accounts' order by Window_name desc ");	
		foreach($windows->fetchAll() as $wd) {
			$windownamelist[] = $wd;
		}  
					
		
		$userslist =  array();		
		$usersl = $db->query(" select distinct(User_name) as User_name from audittrial where company_id='".$cid."' order by User_name desc ");	
		foreach($usersl->fetchAll() as $ul) {
			$userslist[] = $ul;
		}  
		
		
		
		$fromdate = date("Y-01-01");
		$todate = date("Y-m-t");
		
		$cont="where company_id='".$cid."'";
		$action_taken="";
		$user="";
		$window_name="";
					
				
		if(isset($_POST['submit'])){
				
			$fromdate 			= date("Y-m-d", strtotime($_POST['from_date']));
			$todate 			= date("Y-m-d", strtotime($_POST['to_date']));		
			$action_taken 		= $_POST['action_taken'];		
			$user		 		= $_POST['user'];	
			$window_name 		= $_POST['window_name'];					
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-d");
				$todate = date("Y-m-t");
			}				
		
			if($fromdate!="1970-01-01" && $todate!="1970-01-01" && $action_taken!="" && $user!="" && $window_name!="" ){
			
				$cont = " where company_id='".$cid."' and  rec_date >= '".$fromdate."' AND rec_date <= '".$todate."' and Action_taken='".$action_taken."' and User_name='".$user."' and Window_name='".$window_name."' ";
			
			} else if($fromdate!="1970-01-01" && $todate!="1970-01-01" && $action_taken!="" && $user!="" && $window_name=="" ){
			
				$cont = " where company_id='".$cid."' and rec_date >= '".$fromdate."' AND rec_date <= '".$todate."' and Action_taken='".$action_taken."' and User_name='".$user."'  ";
			
			} else if($fromdate!="1970-01-01" && $todate!="1970-01-01" && $action_taken!="" && $user=="" && $window_name!="" ){
			
				$cont = " where company_id='".$cid."' and rec_date >= '".$fromdate."' AND rec_date <= '".$todate."' and Action_taken='".$action_taken."' and Window_name='".$window_name."' ";
			
			} else if($fromdate!="1970-01-01" && $todate!="1970-01-01" && $action_taken=="" && $user!="" && $window_name!="" ){
			
				$cont = " where company_id='".$cid."' and rec_date >= '".$fromdate."' AND rec_date <= '".$todate."' and User_name='".$user."' and Window_name='".$window_name."' ";
			
			} else if($fromdate=="1970-01-01" && $todate=="1970-01-01" && $action_taken!="" && $user!="" && $window_name!="" ){
			
				$cont = " where company_id='".$cid."' and Action_taken='".$action_taken."' and User_name='".$user."' and Window_name='".$window_name."' ";
			
			} else if($fromdate=="1970-01-01" && $todate=="1970-01-01" && $action_taken=="" && $user!="" && $window_name!="" ){
			
				$cont = " where User_name='".$user."' and Window_name='".$window_name."' ";
			
			} else if($fromdate=="1970-01-01" && $todate=="1970-01-01" && $action_taken!="" && $user=="" && $window_name!="" ){
			
				$cont = " where company_id='".$cid."' and Action_taken='".$action_taken."' and Window_name='".$window_name."' ";
			
			} else if($fromdate=="1970-01-01" && $todate=="1970-01-01" && $action_taken!="" && $user!="" && $window_name=="" ){
			
				$cont = " where company_id='".$cid."' and Action_taken='".$action_taken."' and User_name='".$user."'  ";
			
			} else if($fromdate=="1970-01-01" && $todate=="1970-01-01" && $action_taken=="" && $user=="" && $window_name!="" ){
			
				$cont = " where company_id='".$cid."' and Window_name='".$window_name."' ";
			
			} else if($fromdate=="1970-01-01" && $todate=="1970-01-01" && $action_taken=="" && $user!="" && $window_name=="" ){
			
				$cont = " where company_id='".$cid."' and User_name='".$user."' ";
			
			} else if($fromdate=="1970-01-01" && $todate=="1970-01-01" && $action_taken!="" && $user=="" && $window_name=="" ){
			
				$cont = " where company_id='".$cid."' and Action_taken='".$action_taken."'  ";
			
			} else if($fromdate!="1970-01-01" && $todate!="1970-01-01" && $action_taken=="" && $user=="" && $window_name=="" ){
			
				$cont = " where company_id='".$cid."' and rec_date >= '".$fromdate."' AND rec_date <= '".$todate."'  ";
							
			} else if($fromdate!="1970-01-01" && $todate!="1970-01-01" && $action_taken!="" && $user=="" && $window_name=="" ){
			
				$cont = " where company_id='".$cid."' and rec_date >= '".$fromdate."' AND rec_date <= '".$todate."' and Action_taken='".$action_taken."'  ";
			
			} else if($fromdate!="1970-01-01" && $todate!="1970-01-01" && $action_taken=="" && $user=="" && $window_name!="" ){
			
				$cont = " where company_id='".$cid."' and rec_date >= '".$fromdate."' AND rec_date <= '".$todate."' and Window_name='".$window_name."' ";
			
			} else if($fromdate!="1970-01-01" && $todate!="1970-01-01" && $action_taken=="" && $user!="" && $window_name=="" ){
			
				$cont = " where company_id='".$cid."' and rec_date >= '".$fromdate."' AND rec_date <= '".$todate."' and User_name='".$user."'  ";
			
			} 
		
		}
				
		
		$auditlist =  array();		
		$audits = $db->query(" select * from audittrial ".$cont." and system_name='Auto Accounts'  order by rec_date desc ");	
		foreach($audits->fetchAll() as $ad) {
			$auditlist[] = $ad;
		}  		
						  
	  require_once('views/audittrail/index.php'); 
	  
    }	
	
	
		

    public function error() {
      require_once('views/profitcenters/error.php');
    }
  }
?>