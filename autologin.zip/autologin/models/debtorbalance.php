<?php
  class debtorbalance {
   
  }
?>