<?php
  class AudittrailController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
		$cid = $_GET['cid']; // company id
		
		$fromdate = date("Y-01-01");
		$todate = date("Y-m-t");
		
		$cont="";
		if(isset($_POST['submit'])){
				
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));				
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-d");
				$todate = date("Y-m-t");
			}				
		
			$cont = " and (created >= '".$fromdate."' AND created <= '".$todate."') or (modified >= '".$fromdate."' AND modified <= '".$todate."') ";
			$cont1 = " where (created >= '".$fromdate."' AND created <= '".$todate."') or (modified >= '".$fromdate."' AND modified <= '".$todate."') ";
		
		}
		
				
		
		$auditlist =  array();		
		$audits = $db->query("
					select created, created_by, modified, modified_by, 'Accounting Year' as window_name from accounting_year where company_id='".$cid."' ".$cont."
				union select created, created_by, modified, modified_by, 'Code Descriptions' as window_name from code_descriptions ".$cont1."	
				union select created, created_by, modified, modified_by, 'Currency' as window_name from currency where company_id='".$cid."' ".$cont."	
				union select created, created_by, modified, modified_by, 'Gift Rules' as window_name from gift_rules where company_id='".$cid."' ".$cont."	
				union select created, created_by, modified, modified_by, 'GST' as window_name from gst5b6b where company_id='".$cid."' ".$cont."	
				union select created, created_by, modified, modified_by, 'GST Bad Debt' as window_name from gstbaddebt where company_id='".$cid."' ".$cont."	
				union select created, created_by, modified, modified_by, 'General Ledger' as window_name from journal_entries where company_id='".$cid."' ".$cont."	
				union select created, created_by, modified, modified_by, 'Master Account Codes' as window_name from master_account_codes where company_id='".$cid."' ".$cont."	
				union select created, created_by, modified, modified_by, 'Opening Balance' as window_name from opening_balance where company_id='".$cid."' ".$cont."	
				union select created, created_by, modified, modified_by, 'Profit Centers' as window_name from profit_centers where company_id='".$cid."' ".$cont."	
				union select created, created_by, modified, modified_by, 'Subcodes' as window_name from subcodes where company_id='".$cid."' ".$cont."
				order by created					
					");	
		foreach($audits->fetchAll() as $ad) {
			$auditlist[] = $ad;
		}  		
						  
	  require_once('views/audittrail/index.php'); 
	  
    }	
	
	
		

    public function error() {
      require_once('views/profitcenters/error.php');
    }
  }
?>