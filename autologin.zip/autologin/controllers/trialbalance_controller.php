<?php
  class TrialbalanceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	    
		
		$company = $db->query('SELECT id,company_name,address,state,pincode,company_image  FROM companies where id ="'.$cid.'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
			$company_image = $com['company_image'];
		
		if($company_name=="" || $company_name=="NULL"){	$company_name=""; }	
			if($company_address=="" || $company_address=="NULL"){ $company_address=""; }	
			if($company_state=="" || $company_state=="NULL"){ $company_state=""; }
			if($company_pincode=="" || $company_pincode=="NULL"){	$company_pincode=""; }	
		}
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  
		
		
		
		$todate = date("Y-m-d");	
		
		$monthfromdate = date("Y-m-01");	
		$monthtodate = date("Y-m-t");	
		
		$yearfromdate = date("1111-11-11");	
		$yeartodate = date("Y-m-t");	
		
		$currentyeardate1 = date("Y-m");
			
		$lastmonthfromdate = date('Y-m-d', strtotime($currentyeardate1." -1 month"));
		$lastmonthtodate = date('Y-m-t', strtotime($currentyeardate1." -1 month"));
		
		$profitcenter ="";
		$gsttaxcode ="";
		$profit_center_id=0;
		
		if(isset($_POST['submit'])){
		
			$todate = date("Y-m-d");	
		
			$monthfromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$monthtodate = date("Y-m-d", strtotime($_POST['to_date']));;	
			$profit_center_id = $_POST['profit_center_id']; 
			$year = date("Y", strtotime($_POST['from_date']));
			
			//$yearfromdate = date($year."-01-01");	
			$yearfromdate = date($monthfromdate);	
			$yeartodate = date($monthtodate);	
			
			
			$currentyeardate = date("Y-m-d", strtotime($_POST['from_date']));
			$lastyear = date("Y",strtotime("-1 year"));
			$lastyeardate = date($lastyear.'-m-d');			
			
			$currentyeardate1 = date("Y-m", strtotime($_POST['from_date']));
			
			$lastmonthfromdate = date('Y-m-d', strtotime($currentyeardate1." -1 month"));
		    $lastmonthtodate = date('Y-m-t', strtotime($currentyeardate1." -1 month"));
						
		//	$profitcenter = " AND je.profit_center_id=".$profit_center_id." ";
		$profitcenter = " ";
		
		}
		
			
		$trialbalancesubcodesList = array();		
		$trialbalancesubcodes = $db->query("SELECT sc.id, sc.description, sc.code FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY sc.code ASC");		
		foreach($trialbalancesubcodes->fetchAll() as $tbsl) {
			$trialbalancesubcodesList[] = $tbsl;
		} 
		
					
		
		$trialbalanceArray = array();		
		$csi=0;
	
	    $trialbalance_yeardebitbalance=0;
		$trialbalance_yearcreditbalance=0;
		$trialbalance_monthdebitbalance=0;
		$trialbalance_monthcreditbalance=0;
		$trialbalance_yeardebitop_balance=0;
		$trialbalance_yearcreditop_balance=0;
		$trialbalance_monthdebitop_balance=0;
		$trialbalance_monthcreditop_balance=0;
		
		foreach($trialbalancesubcodesList as $cscl){
						
			$description = $cscl['description'];	
			$code = $cscl['code'];					
			
			// opening balance
			$trialbalance_yeardebitopeningbalance = $db->query("SELECT sum(op.debit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE op.company_id = ".$cid." and sc.id = '".$cscl['id']."' AND date(op.opening_date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($trialbalance_yeardebitopeningbalance->fetchAll() as $ydcsop) {
				$trialbalance_yeardebitop_balance = $ydcsop['balance'];
			} 
			
			$trialbalance_yearcreditopeningbalance = $db->query("SELECT sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE op.company_id = ".$cid." and sc.id = '".$cscl['id']."' AND date(op.opening_date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($trialbalance_yearcreditopeningbalance->fetchAll() as $yccsop) {
				$trialbalance_yearcreditop_balance = $yccsop['balance'];
			} 
			
			$trialbalance_monthdebitopeningbalance = $db->query("SELECT sum(op.debit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE op.company_id = ".$cid." and sc.id = '".$cscl['id']."' AND date(op.opening_date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($trialbalance_monthdebitopeningbalance->fetchAll() as $mdcsop) {
				$trialbalance_monthdebitop_balance = $mdcsop['balance'];
			} 
			
			$trialbalance_monthcreditopeningbalance = $db->query("SELECT sum(op.debit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE op.company_id = ".$cid." and sc.id = '".$cscl['id']."' AND date(op.opening_date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($trialbalance_monthcreditopeningbalance->fetchAll() as $mccsop) {
				$trialbalance_monthcreditop_balance = $mccsop['balance'];
			} 
			
			
			// opening balance end
			
			//echo "<pre>";print_r("SELECT sum(je.debit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");
			
			$trialbalance_yeardebitgibalance = $db->query("SELECT sum(je.debit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($trialbalance_yeardebitgibalance->fetchAll() as $csygi) {
				$trialbalance_yeardebitbalance = $csygi['balance'];
			}
			
			$trialbalance_yearcreditgibalance = $db->query("SELECT sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($trialbalance_yearcreditgibalance->fetchAll() as $csygi) {
				$trialbalance_yearcreditbalance = $csygi['balance'];
			}
			
	
			
			$trialbalance_monthdebitgibalance = $db->query("SELECT sum(je.debit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($trialbalance_monthdebitgibalance->fetchAll() as $csmgi) {
				 $trialbalance_monthdebitbalance = $csmgi['balance'];				
			}
			
			$trialbalance_monthcreditgibalance = $db->query("SELECT sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($trialbalance_monthcreditgibalance->fetchAll() as $csmgi) {
				$trialbalance_monthcreditbalance = $csmgi['balance'];				
			}
			
					
				
			$trialbalanceArray[$csi]['description'] = $description;
			$trialbalanceArray[$csi]['code'] = $code;
			$trialbalanceArray[$csi]['yeardebitbalance'] = $trialbalance_yeardebitop_balance + $trialbalance_yeardebitbalance;
			$trialbalanceArray[$csi]['yearcreditbalance'] = $trialbalance_yearcreditop_balance + $trialbalance_yearcreditbalance;
			$trialbalanceArray[$csi]['monthdebitbalance'] = $trialbalance_monthdebitop_balance + $trialbalance_monthdebitbalance;
			$trialbalanceArray[$csi]['monthcreditbalance'] = $trialbalance_monthcreditop_balance + $trialbalance_monthcreditbalance;
							
			$csi++;
		}	
		
				
						  
	  require_once('views/trialbalance/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/trialbalance/error.php');
    }
  }
  

?>