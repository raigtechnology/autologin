<?php session_start();
	
	require_once("connection.php");
	$db = Db::getInstance();		
	
	$accountname = $_GET['value1']; 
	$cid = $_GET['cid']; 
	$rate = $_GET['rate_value']; 
	
	if($rate=="normal"){
	$pomaster = $db->query("select pms.AutoPurchaseID, pms.CustPORef, pms.CurrencyCode, pms.Currencyrate, qms.CustomerID from tblpomaster_sales as pms left join tblquotemaster_sales as qms on qms.AutoQuoationID = pms.QuoteRef where pms.company_id ='".$cid."' and qms.company_id ='".$cid."' and pms.CustPORef = '".$_GET['value1']."' and pms.flag!=1");
	
	
// for currency

		$session_id = $_SESSION['company_id'];		

		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end				

	
	
	$currencylist = array();
	$currency = $db->query("select * from currency where company_id='".$com_id."' ");	
	foreach($currency->fetchAll() as $cy) {
		$currencylist[] = $cy;
	}  	
	
	
	$Totalamt =0;
	$Gstamt =0;
	$TaxCode="";
	?>
		<table style="border:hidden;" id="salesinvoice_panel">
		<tr>				
			<th width="10%" align="right">TOTAL AMOUNT</th>
			<th width="10%" align="right">TOTAL GST</th>
			<th width="10%" align="right">CURRENCY CODE</th>
			<th width="10%" align="right">CURRENCY RATE</th>					
			<th width="10%" align="right">DEPOSIT AMOUNT</th>
		</tr>		
	<?php
	$it=0;
	$pom_sales = array();
	foreach($pomaster as $po){	
		
		$CurrencyCode = $po['CurrencyCode'];
		$Currencyrate = $po['Currencyrate'];
		$customid = $po['CustomerID'];							
		
		$depositlist =  $db->query("select AutoPurchaseID, Productcode, sum(deposit_gst) as deposit_gst, sum(TotalAmount) as TotalAmount, sum(GSTAmount) as GSTAmount, TaxCode from deposit_sales where PoNumber='".$_GET['value1']."' and companyID=".$cid." group by PoNumber order by AutoDepositID asc");
	
					
		$in=0;							
		foreach($depositlist->fetchAll() as $dp){	
			$proid			= $dp['AutoPurchaseID'];	
			$procode 		= $dp['Productcode'];					
			$Totalamt		= $dp['TotalAmount'];				
			$Gstamt 		= $dp['GSTAmount'];	
			$TaxCode		= $dp['TaxCode'];	
			
			?>
			
			<tr>					
			<td align="right">
			<input type="hidden" name="data[<?php echo $in; ?>][procode]" id="procode" class="textbox_small" value="<?php echo $procode; ?>" style="text-align:right;"  required="required" />
			<input type="hidden" name="data[<?php echo $in; ?>][proid]" id="proid" class="textbox_small" value="<?php echo $proid; ?>" style="text-align:right;"  required="required" />
			<input type="text" name="data[<?php echo $in; ?>][amount]" id="amount" class="textbox_small" value="<?php echo $Totalamt; ?>" style="text-align:right;"  required="required" />
			</td>	
						
			<td align="right">
				<input type="text" name="data[<?php echo $in; ?>][gst]" id="gst" class="textbox_small" value="<?php echo $Gstamt; ?>" style="text-align:right;"  required="required" />
			</td>
			<td align="right">
				<select name="data[<?php echo $in; ?>][currency_code]" id="currency_code" class="selectbox_small" required="required" onchange="showexchangerate(this.value,<?php echo $_SESSION['company_id']; ?>)">
						<?php
						foreach($currencylist as $cl){
						?>
							<option value="<?php echo $cl['currency_code'];?>" <?php if($cl['currency_code']==$CurrencyCode){?> selected="selected" <?php } ?>><?php echo $cl['currency_code'];?></option>
						<?php
						}
						?>
					</select>				
				
			</td>
			
			<td align="right">
			<input type="text" ame="data[<?php echo $in; ?>][currecny_rate]"  id="currecny_rate" class="textbox_small" value="<?php echo $Currencyrate; ?>" style="text-align:right;" required="required"/>
			</td>					
			<td align="right">
			<input type="text" name="data[<?php echo $in; ?>][deposit_amount]" id="deposit_amount" class="textbox_small"  value="0.00" style="text-align:right;"  required="required" />
			</td>					
		</tr>			
	
	<input type="hidden" name="data[<?php echo $in; ?>][pototal]" id="pototal" value="<?php echo $Totalamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $in; ?>][pogst]" id="pogst" value="<?php echo $Gstamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $in; ?>][TaxCode]" id="TaxCode" value="<?php echo $TaxCode; ?>" class="textbox_small" style="text-align:right;"  required="required" />
		<input type="hidden" name="data[<?php echo $in; ?>][flg]" id="flg" value="1" class="textbox_small" style="text-align:right;"   />
			
			<?php	
		$in++;
		}	
				
		if($in==0){
							
				
												
			$pop_sales = $db->query("select AutoPurchaseID, Productcode, Totalamt, Gstamt, TaxCode from tblpoproduct_sales where company_id='".$cid."' and AutoPurchaseID = '".$po['AutoPurchaseID']."' ");		
						
			$ir=0;
			foreach($pop_sales as $pos){					
				$procode 		= $pos['Productcode'];		
				$proid 		= $pos['AutoPurchaseID'];			
				$Totalamt 		= $pos['Totalamt'];
				$Gstamt 		= $pos['Gstamt'];
				$TaxCode 		= $pos['TaxCode'];
			?>
			
		<tr>					
			<td align="right">
			<input type="hidden" name="data[<?php echo $ir; ?>][procode]" id="procode" class="textbox_small" value="<?php echo $procode; ?>" style="text-align:right;"  required="required" />
			<input type="hidden" name="data[<?php echo $ir; ?>][proid]" id="proid" class="textbox_small" value="<?php echo $proid; ?>" style="text-align:right;"  required="required" />
			<input type="hidden" name="data[<?php echo $ir; ?>][customerid]" id="customerid" class="textbox_small" value="<?php echo $customid; ?>" style="text-align:right;"   />
			<input type="text" name="data[<?php echo $ir; ?>][amount]" id="amount" class="textbox_small" value="<?php echo $Totalamt; ?>" style="text-align:right;"  required="required" />
			</td>	
						
			<td align="right">
				<input type="text" name="data[<?php echo $ir; ?>][gst]" id="gst" class="textbox_small" value="<?php echo $Gstamt; ?>" style="text-align:right;"  required="required" />
			</td>
			<td align="right">				
				<select name="data[<?php echo $ir; ?>][currency_code]" id="currency_code" class="selectbox_small" required="required" >
						<?php
						foreach($currencylist as $cl){
						?>
							<option value="<?php echo $cl['currency_code'];?>" <?php if($cl['currency_code']==$CurrencyCode){?> selected="selected" <?php } ?>><?php echo $cl['currency_code'];?></option>
						<?php
						}
						?>
					</select>	
			</td>
			
			<td align="right">
			<input type="text" name="data[<?php echo $ir; ?>][currecny_rate]" id="currecny_rate" class="textbox_small" value="<?php echo $Currencyrate; ?>" style="text-align:right;"  required="required" />
			</td>					
			<td align="right">
			<input type="text" name="data[<?php echo $ir; ?>][deposit_amount]" id="deposit_amount" class="textbox_small" style="text-align:right;" value="0.00"  required="required" />
			</td>					
		</tr>			
	
	<input type="hidden" name="data[<?php echo $ir; ?>][pototal]" id="pototal" value="<?php echo $Totalamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $ir; ?>][pogst]" id="pogst" value="<?php echo $Gstamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $ir; ?>][TaxCode]" id="TaxCode" value="<?php echo $TaxCode; ?>" class="textbox_small" style="text-align:right;"  required="required" />
		<input type="hidden" name="data[<?php echo $ir; ?>][flg]" id="flg" value="0" class="textbox_small" style="text-align:right;"   />
			<?php
			$ir++;
			}		
		}
			
				
	$it++;
	}
	
	
	?>	
	</table>
	<?php	
	}else if($rate=="quotation"){
		
		$pomaster = $db->query("select qms.AutoQuoationID,qms.currencycode, qms.Currencyrate,qms.CustomerID from tblquotemaster_sales  as qms where qms.AutoQuoationID = '".$accountname."' and qms.company_id ='".$_GET['cid']."'");
	
	
// for currency

		$session_id = $_SESSION['company_id'];		

		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end				

		$currencylist = array();
		$currency = $db->query("select * from currency where company_id='".$com_id."' ");	
		foreach($currency->fetchAll() as $cy) {
			$currencylist[] = $cy;
		}  	
		
		
		$Totalamt =0;
		$Gstamt =0;
		$TaxCode="";
		?>
		<table style="border:hidden;" id="salesinvoice_panel">
		<tr>				
			<th width="10%" align="right">TOTAL AMOUNT</th>
			<th width="10%" align="right">TOTAL GST</th>
			<th width="10%" align="right">CURRENCY CODE</th>
			<th width="10%" align="right">CURRENCY RATE</th>					
			<th width="10%" align="right">DEPOSIT AMOUNT</th>
		</tr>		
		<?php
		$it=0;
	$pom_sales = array();
	foreach($pomaster as $po){	
		
		$CurrencyCode = $po['currencycode'];
		$Currencyrate = $po['Currencyrate'];
		$customid = $po['CustomerID'];							
		
		$depositlist =  $db->query("select QuoteID, Productcode, sum(deposit_gst) as deposit_gst, sum(TotalAmount) as TotalAmount, sum(GSTAmount) as GSTAmount, TaxCode from deposit_sales where QuoteID='".$_GET['value1']."' and companyID=".$cid." group by QuoteID order by QuoteID asc");
	
					
		$in=0;							
		foreach($depositlist->fetchAll() as $dp){	
			$proid			= $dp['AutoPurchaseID'];	
			$procode 		= $dp['Productcode'];					
			$Totalamt		= $dp['TotalAmount'];				
			$Gstamt 		= $dp['GSTAmount'];	
			$TaxCode		= $dp['TaxCode'];	
			
			?>
			
			<tr>					
			<td align="right">
			<input type="hidden" name="data[<?php echo $in; ?>][procode]" id="procode" class="textbox_small" value="<?php echo $procode; ?>" style="text-align:right;"  required="required" />
			<input type="hidden" name="data[<?php echo $in; ?>][proid]" id="proid" class="textbox_small" value="<?php echo $proid; ?>" style="text-align:right;"  required="required" />
			<input type="text" name="data[<?php echo $in; ?>][amount]" id="amount" class="textbox_small" value="<?php echo $Totalamt; ?>" style="text-align:right;"  required="required" />
			</td>	
						
			<td align="right">
				<input type="text" name="data[<?php echo $in; ?>][gst]" id="gst" class="textbox_small" value="<?php echo $Gstamt; ?>" style="text-align:right;"  required="required" />
			</td>
			<td align="right">
				<select name="data[<?php echo $in; ?>][currency_code]" id="currency_code" class="selectbox_small" required="required" onchange="showexchangerate(this.value,<?php echo $_SESSION['company_id']; ?>)">
						<?php
						foreach($currencylist as $cl){
						?>
							<option value="<?php echo $cl['currency_code'];?>" <?php if($cl['currency_code']==$CurrencyCode){?> selected="selected" <?php } ?>><?php echo $cl['currency_code'];?></option>
						<?php
						}
						?>
					</select>				
				
			</td>
			
			<td align="right">
			<input type="text" ame="data[<?php echo $in; ?>][currecny_rate]"  id="currecny_rate" class="textbox_small" value="<?php echo $Currencyrate; ?>" style="text-align:right;" required="required"/>
			</td>					
			<td align="right">
			<input type="text" name="data[<?php echo $in; ?>][deposit_amount]" id="deposit_amount" class="textbox_small"  value="0.00" style="text-align:right;"  required="required" />
			</td>					
		</tr>			
	
	<input type="hidden" name="data[<?php echo $in; ?>][pototal]" id="pototal" value="<?php echo $Totalamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $in; ?>][pogst]" id="pogst" value="<?php echo $Gstamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $in; ?>][TaxCode]" id="TaxCode" value="<?php echo $TaxCode; ?>" class="textbox_small" style="text-align:right;"  required="required" />
		<input type="hidden" name="data[<?php echo $in; ?>][flg]" id="flg" value="1" class="textbox_small" style="text-align:right;"   />
			
			<?php	
		$in++;
		}	
		if($in==0){
							
				//echo "select AutoQuoationID, ProductID, Totalamt, Gstamt, TaxCode from tblquoteproduct_sales where company_id='".$cid."' and AutoQuoationID = '".$po['AutoQuoationID']."' ";						
			$pop_sales = $db->query("select AutoQuoationID, ProductID, Totalamt, Gstamt, TaxCode from tblquoteproduct_sales where  AutoQuoationID = '".$po['AutoQuoationID']."' ");		
						
			$ir=0;
			foreach($pop_sales as $pos){					
				$procode 		= $pos['ProductID'];		
				$proid 		    = $pos['AutoQuoationID'];			
				$Totalamt 		= $pos['Totalamt'];
				$Gstamt 		= $pos['Gstamt'];
				$TaxCode 		= $pos['TaxCode'];
			?>
			
		<tr>					
			<td align="right">
			<input type="hidden" name="data[<?php echo $ir; ?>][procode]" id="procode" class="textbox_small" value="<?php echo $procode; ?>" style="text-align:right;"  required="required" />
			<input type="hidden" name="data[<?php echo $ir; ?>][proid]" id="proid" class="textbox_small" value="<?php echo $proid; ?>" style="text-align:right;"  required="required" />
			<input type="hidden" name="data[<?php echo $ir; ?>][customerid]" id="customerid" class="textbox_small" value="<?php echo $customid; ?>" style="text-align:right;"   />
			<input type="text" name="data[<?php echo $ir; ?>][amount]" id="amount" class="textbox_small" value="<?php echo $Totalamt; ?>" style="text-align:right;"  required="required" />
			</td>	
						
			<td align="right">
				<input type="text" name="data[<?php echo $ir; ?>][gst]" id="gst" class="textbox_small" value="<?php echo $Gstamt; ?>" style="text-align:right;"  required="required" />
			</td>
			<td align="right">				
				<select name="data[<?php echo $ir; ?>][currency_code]" id="currency_code" class="selectbox_small" required="required" >
						<?php
						foreach($currencylist as $cl){
						?>
							<option value="<?php echo $cl['currency_code'];?>" <?php if($cl['currency_code']==$CurrencyCode){?> selected="selected" <?php } ?>><?php echo $cl['currency_code'];?></option>
						<?php
						}
						?>
					</select>	
			</td>
			
			<td align="right">
			<input type="text" name="data[<?php echo $ir; ?>][currecny_rate]" id="currecny_rate" class="textbox_small" value="<?php echo $Currencyrate; ?>" style="text-align:right;"  required="required" />
			</td>					
			<td align="right">
			<input type="text" name="data[<?php echo $ir; ?>][deposit_amount]" id="deposit_amount" class="textbox_small" style="text-align:right;" value="0.00"  required="required" />
			</td>					
		</tr>			
	
	<input type="hidden" name="data[<?php echo $ir; ?>][pototal]" id="pototal" value="<?php echo $Totalamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $ir; ?>][pogst]" id="pogst" value="<?php echo $Gstamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $ir; ?>][TaxCode]" id="TaxCode" value="<?php echo $TaxCode; ?>" class="textbox_small" style="text-align:right;"  required="required" />
		<input type="hidden" name="data[<?php echo $ir; ?>][flg]" id="flg" value="0" class="textbox_small" style="text-align:right;"   />
			<?php
			$ir++;
			}		
		}
			
				
	$it++;
		
		
		}
		}
	