<?php
  class SalestaxcodemasterController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
								
		$salestaxcodemaster = $db->query("select TaxCode, TaxRate, SupplType from salestaxcodemaster order by TaxCode asc");	
		foreach($salestaxcodemaster->fetchAll() as $scm) {
			$salestaxcodemasterlist[] = $scm;
		}	
								  
		require_once('views/salestaxcodemaster/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/salestaxcodemaster/error.php');
    }
  }
?>
