<?php
  class DebtorbalanceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();	// db connection	
		$cid = $_GET['cid'];		// company id		    
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$date = date("Y-m-t");
		
		if(isset($_POST['submit'])){
				
			$date = date("Y-m-d", strtotime($_POST['date']));			
				
			if(empty($date)){
				$date = date("Y-m-d");			
			}				
		
		}	
		
		$debtorsbalancelist = array();	
		$debtorsbalance = $db->query("CALL balance('".$cid."', '' ,'debitor', '', '', '".$date."')");		
		foreach($debtorsbalance->fetchAll() as $dod) {
			$debtorsbalancelist[] = $dod;
		}  		
		
		$count = count($debtorsbalancelist);						
								  
	  require_once('views/debtorbalance/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/debtorbalance/error.php');
    }
  }
  

?>