<?php session_start();
	
	require_once("connection.php");
	
	$contract_id = $_GET['contract_id']; 
	
	if($contract_id == '1'){
	
	?>	

              <td>Commence Date</td>
              <td colspan="2">:
              <input name="commence_date" type="text" id="datepicker7" style="width:95%;"/></td>
              <td>Complete Date </td>
              <td>:
              <input name="complete_date" type="text" id="datepicker8" style="width:91%;"/></td>
            
	<?php
	} else {
	}
	?>		
		