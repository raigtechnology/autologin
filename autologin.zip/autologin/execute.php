<?php
require_once("connection.php");
$db = Db::getInstance();

$earning = $db->query("SELECT memo FROM `journal_entries` WHERE `created` = '2018-04-10 07:11:59' and company_id='1237' group by `memo`");
	
	foreach($earning->fetchAll() as $er) {
	
	$inv=$er['memo'];
	
	  $SQL_Query = $db->query("UPDATE unattended_gl SET 
status = 0 WHERE company_id='1237' and description='".$inv."'");
	 
	  }
	


?>