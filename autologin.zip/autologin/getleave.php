<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}	
	
	$empid = $_GET['empid']; 
	?>			
		
		 
		<option value="">--Select--</option>   
		<?php
		
		$leavebalance = $db->query("select sum(lo.leaved), lm.id, em.full_name, em.employee_code, lm.leave_name, lm.leave_code, lm.paid_unpaid from leave_opening as lo left join employee_master as em on em.id = lo.employee_id left join leave_master as lm on lm.id = lo.leavemaster_id where lo.employee_id = '".$empid."' group by lo.leavemaster_id, lo.employee_id  ");							
		foreach($leavebalance->fetchAll() as $lb) {
			if($lb['sum(lo.leaved)']>0){
		?>
		    <option value="<?php echo $lb['id']; ?>"><?php echo $lb['leave_name']; ?></option>
        <?php
			}
		}	
		?>	
	
