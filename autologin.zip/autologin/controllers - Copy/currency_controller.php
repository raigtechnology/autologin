<?php
  class CurrencyController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
								
		$currency = $db->query("select currency_code, currency_name from currency order by currency_code asc");	
		foreach($currency->fetchAll() as $scm) {
			$currencylist[] = $scm;
		}	
								  
		require_once('views/currency/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/currency/error.php');
    }
  }
?>