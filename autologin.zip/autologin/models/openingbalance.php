<?php
  class openingbalance {
   
  }
?>