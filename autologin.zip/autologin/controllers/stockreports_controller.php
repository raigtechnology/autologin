<?php
  class StockreportsController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
				
		$cid = $_GET['cid']; // companyid
		
		$stockproducts = array();				
		$stkproduct = $db->query("select Productdesc,Porductprice,purchaseqty,Subcode,Productcode from tblproduct where company_id='".$cid."' and isstock='Y'");	
		foreach($stkproduct->fetchAll() as $sp) {
			$stockproducts[] = $sp;
		}  		
					
						  
	  require_once('views/stockreports/index.php'); 
	  
    }	
	
	public function view() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
				
		$cid = $_GET['cid']; // companyid
		$pid = $_GET['id']; // companyid
		
		$stockproducts = array();				
		$stkproduct = $db->query("select ts.ProductDesc,ts.Quantity,ts.UnitPrice,tp.Subcode from tblinvproduct_sales as ts left join tblproduct as tp on tp.Productcode=ts.Productcode where ts.company_id='".$cid."' and ts.Productcode='".$pid."' order by ts.id asc");	
		foreach($stkproduct->fetchAll() as $sp) {
			$stockproducts[] = $sp;
		}  		
					
						  
	  require_once('views/stockreports/view.php'); 
	  
    }
		

    public function error() {
      require_once('views/stockreports/error.php');
    }
  }
?>