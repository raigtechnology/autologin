<?php
  class Creditorsledger {
   
  }
?>