<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		
	
	$year = $_GET['year']; 
	$cid = $_GET['company_id']; 
	$account_type_id = $_GET['account_type_id'];

	$budgets = $db->query("select sum(budget_value) as total from budgets where company_id='".$cid."' and subcode_id in ( select subcodes.id from subcodes left join master_account_codes on master_account_codes.id = subcodes.master_account_code_id where master_account_codes.account_type_id = '".$account_type_id."') and YEAR(to_date)='".$year."' ");	
	foreach($budgets->fetchAll() as $tb) {
		$total_budget = $tb['total'];
	}  
	
	
	$uptocurrentmonthdate = date($year."-m-d");
	

$total_expenditure=0;
$budget_balance=0;
	
if($account_type_id==4){

		$total_fixed_assets=0;	

		$fixedassets_subcodesList = array();		
		$fixedassets_subcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 4 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($fixedassets_subcodes->fetchAll() as $fasc) {
			$fixedassets_subcodesList[] = $fasc;
		} 		
		
		$fixedassets_Array = array();		
		$si=0;
		foreach($fixedassets_subcodesList as $fascl){									
								
			$fixedassets_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$fascl['id']."' and mac.account_type_id = 4 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('2016-01-01') AND date('2016-12-31') ORDER BY je.subcode_id ASC");		
			foreach($fixedassets_currentyeargibalance->fetchAll() as $faygi) {
				$fixedassets_currentyearbalance = $faygi['balance'];				
			}
								
			$total_fixed_assets +=  $fixedassets_currentyearbalance;	
						
			$si++;	
		}
		
		$total_expenditure = $total_fixed_assets;		
		
		
} else if($account_type_id==7){
// cost of sales
		$total_cost_of_sales=0;
		
		$costofsalessubcodesList = array();		
		$costofsalessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($costofsalessubcodes->fetchAll() as $cssc) {
			$costofsalessubcodesList[] = $cssc;
		} 		
		
		$costofsalesArray = array();		
		$csi=0;
		foreach($costofsalessubcodesList as $cscl){	
			
			$costofsales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('2016-01-01') AND date('2016-12-31') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_yeargibalance->fetchAll() as $csygi) {
				$costofsales_yearbalance = $csygi['balance'];
			}
						
			$total_cost_of_sales +=  $costofsales_yearbalance;		
		
			
			$csi++;
		}			
	
		$total_expenditure = $total_cost_of_sales;		

} else if($account_type_id==12){
		
		$total_expenses=0;
		

		$expensessubcodesList = array();		
		$expensessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($expensessubcodes->fetchAll() as $esc) {
			$expensessubcodesList[] = $esc;
		}				 		
		
		$expensesArray = array();		
		$csi=0;
		foreach($expensessubcodesList as $ecl){
			
			$expenses_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('2016-01-01') AND date('2016-12-31') ORDER BY je.subcode_id ASC");		
			foreach($expenses_yeargibalance->fetchAll() as $eygi) {
				$expenses_yearbalance = $eygi['balance'];
			}
				
			$total_expenses +=  $expenses_yearbalance;		
								
			$csi++;
		}		
		
		$total_expenditure = $total_expenses;		

}
	
	
$budget_balance = $total_budget - $total_expenditure;	
	
?>
	<table cellpadding="0" cellspacing="0" id="purchaseinvoice_panel">		
		<tr>					
			<td width="85%" align="left">Total Budget (RM)</td>	
			<td width="15%" align="right"><strong><?php echo number_format($total_budget, 2, '.', ''); ?></strong></td>	
							
		</tr>
		<tr>					
			<td align="left">Total expenditure to date (RM)</td>	
			<td align="right"><strong><?php echo number_format($total_expenditure, 2, '.', ''); ?></strong></td>	
		</tr>
		<tr>					
			<td align="left">Budget balance not utilized (RM)</td>	
			<td align="right"><strong><?php echo number_format($budget_balance, 2, '.', ''); ?></strong></td>	
					
		</tr>		
	</table>	
