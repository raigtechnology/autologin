<?php
class InstallController {

	public function index() { 
		
		if(isset($_POST['save'])){

			$dbhost		= $_POST['dbhost'];
			$dbuser 	= $_POST['dbuser'];
			$dbpassword = '@)!%@9179';
			//$dbname 	= $_POST['dbname'];					
			$dbname 	= 'chqdb';				
			
												
			$link = mysql_connect($dbhost, $dbuser, $dbpassword);
						
			if (!$link) {
									
				$links = mysql_connect("localhost", "root", "");
				mysql_query("SET PASSWORD FOR 'root'@'localhost' = PASSWORD('".$dbpassword."')",$links);
				//mysql_query("CREATE USER 'root'@'localhost' IDENTIFIED BY '12345678'",$links);
			   // mysql_query("GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION ", $links);  		
									
				//$this->Session->setFlash(mysql_error(), 'default', array('class' => 'failed'));
				//return false;
				mysql_close($links);
			} else {
				 mysql_query("DROP DATABASE $dbname", $link) ;			
			}
			
			
// for chqdb insertion start			
			
				$sql = "CREATE DATABASE $dbname";
		
		   		// if (mysql_query($sql, $link)  && mysql_select_db($database) && mysql_query($aa_sql, $link) ) 		   		 	
		   		 if (mysql_query($sql, $link)  && mysql_select_db($dbname)) {		   		 	
			   		 //	$this->executeSchema($host, $login, $password,$database);
					$path = "";
					$sql_filename = 'db/chqdb.sql';
					$sql_contents = file_get_contents($path.$sql_filename);
					$sql_contents = explode(";", $sql_contents);
					    
					$connection = mysql_connect($dbhost, $dbuser, $dbpassword) or die(mysql_error());
					mysql_select_db($dbname, $connection) or die(mysql_error());
					
					foreach($sql_contents as $query){
					   $result = mysql_query($query);					     
					}
				
				
					// for  stored procedure
					$path1 = "";
					$sql_filename1 = 'db/procedure.sql';
					$sql_contents1 = file_get_contents($path1.$sql_filename1);
					$sql_contents1 = explode("$$", $sql_contents1);
					    
					$connection = mysql_connect($dbhost, $dbuser, $dbpassword) or die(mysql_error());
					mysql_select_db($dbname, $connection) or die(mysql_error());
					
					foreach($sql_contents1 as $query1){
					   $result1 = mysql_query($query1);					     
					}
					
					
					// for  views
					$path2 = "";
					$sql_filename2 = 'db/views.sql';
					$sql_contents2 = file_get_contents($path2.$sql_filename2);
					$sql_contents2 = explode("$$", $sql_contents2);
					    
					$connection = mysql_connect($dbhost, $dbuser, $dbpassword) or die(mysql_error());
					mysql_select_db($dbname, $connection) or die(mysql_error());
					
					foreach($sql_contents2 as $query2){
					   $result2 = mysql_query($query2);					     
					}
					
				
					
				 } 		
			
			
// for chqdb insertion end			
			
			
			mysql_close($link);
					
			header("Location: ?controller=users&action=index");			
					
			
		} else {	 
			require_once('views/install/index.php'); 	   
		}  
			
	}


	private function isValidDatabase($link, $database){
		
		$sql    = "SHOW DATABASES LIKE '$database';";
		$result = mysql_query($sql, $link);
		$row = mysql_fetch_assoc($result);
		
		return $row;
		
	}


	// logout
	public function logout() {	
		session_destroy();	
		header("Location: ?controller=users&action=index");	
	}

	public function error() {
		require_once('views/users/error.php');	
	}
}
?>