<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}	
	
	$emp_id		= $_GET['emp_id']; 	
	$cid		= $_GET['cid']; 	

	$earning = $db->query("SELECT em.description, em.id FROM earning as er left join earning_master as em on em.id = er.eid where er.employee_id = '".$emp_id."' and em.company_id='".$cid."' and er.company_id='".$cid."'  ");		
		
	?>			
	<table width="70%" border="0" cellspacing="0" cellpadding="0" id="search_panel">
		 		
		<?php 
		$i=0;
		foreach($earning->fetchAll() as $er) {
		?>
		<tr>
			<td width="26%"><?php echo $er['description']; ?></td>
            <td width="28%">: 
          <input type="text" name="data[<?php echo $i; ?>][amount]" class="txtbox"/><input type="hidden" name="data[<?php echo $i; ?>][eid]" value="<?php echo $er['id']; ?>" /></td>
            <td width="15%"><input type="checkbox" name="data[<?php echo $i; ?>][epf]" value="1" />
          EPF</td>
            <td width="16%"><input type="checkbox" name="data[<?php echo $i; ?>][socso]" value="1" />
          SOCSO</td>
            <td width="15%"><input type="checkbox" name="data[<?php echo $i; ?>][pcb]" value="1" />
          PCB</td>				
		<?php
		$i++;
		}
		
		
		?>				
		</tr>
			
	</table>
	<?php
	if($i>0){
	?>
	
	<table width="70%" border="0" cellspacing="0" cellpadding="0" id="search_panel">
		
		<tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input type="submit" name="Submit" value="Save" class="ibtn" /></td>
          </tr>
		 </table> 
	<?php
	}
	?>	 
