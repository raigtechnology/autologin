<?php
  class BackupController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
				
		$cid = $_GET['cid']; // companyid
		
		$backuplist = array();				
		$backup = $db->query("select * from backup where company_id='".$cid."' ");	
		foreach($backup->fetchAll() as $bk) {
			$backuplist[] = $bk;
		}  			
			
		
		if(isset($_POST['create'])){
	
				$para = array(
					'db_host'=> 'localhost',  //mysql host
					'db_uname' => 'root',  //user
					'db_password' => '@)!%@9179', //pass
					'db_to_backup' => 'chqdb', //database name
					'db_backup_path' => 'backup', //where to backup
					'db_exclude_tables' => array('general_ledgers','chart_of_accounts','balance_sheets','view_cheque') //tables to exclude
				);


				//$compression_type = $_POST['compression_type'];
				$comments = $_POST['comments'];				
				$backup_date = date("Y-m-d");
				$backup_file_name = "sql-backup-".date( "d-m-Y--h-i-s").".sql";
				
				
				$this->__backup_mysql_database($para,$backup_file_name);
				
				$created_by = $_SESSION['username'];
				$created_ip = $_SERVER['REMOTE_ADDR'];
				$created    = date("Y-m-d H:i:s"); 				
				
				$result = $db->query("insert into backup(company_id, filename, comments, backup_date, created_by, created_ip, created) values ('".$cid."', '".$backup_file_name."', '".$comments."', '".$backup_date."', '".$created_by."', '".$created_ip."', '".$created."') ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}
				
				$created_date    = date("Y-m-d"); 
				$created_time    = date("h:i:s"); 
				$system_name     = "Auto Accounts";
				$action_taken    = "Delete";
				$window_name     = "Database Backup";
				
				$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");	
				
				
				header("Location: ?controller=backup&action=index&cid=".$cid."");
				
				
		}
						
						  
	  require_once('views/backup/index.php'); 
	  
    }	
	
//  database backup  script	
public function __backup_mysql_database($params,$backup_file_name)
{
    $mtables = array(); //$contents = "-- Database: `".$params['db_to_backup']."` --\n";
 
    $contents = "";
	
	/*$contents .="
	

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `balance`(IN `company_id` INT, IN `profitCenterID` INT, IN `debtorCreditor` VARCHAR(10), IN `accountTypeCode` CHAR(1), IN `subcodeID` INT, IN `toDate` DATE)
BEGIN

SET @company_id = company_id;


SET @debtorCreditor = debtorCreditor;
IF(@debtorCreditor = '') THEN
SET @debtorCreditor  = NULL;
END if;

SET @accountTypeCode = accountTypeCode;
IF(@accountTypeCode = '') THEN
SET @accountTypeCode  = NULL;
END if;

SET @toDate =toDate;

SET @profitCenterID =profitCenterID;
IF(@profitCenterID = '') THEN
SET @profitCenterID  = NULL;
END if;

SET @subcodeID =subcodeID;
IF(@subcodeID = '') THEN
SET @subcodeID  = NULL;
END if;


SET @whereStmtMonth = ' `ChartOfAccount`.`company_id` = @company_id 
	AND MONTH(GL.date) = MONTH(@toDate)
 	AND YEAR(GL.date) = YEAR(@toDate)';


SET @whereStmtYear = ' `ChartOfAccount`.`company_id` = @company_id
	AND YEAR(GL.date) = YEAR(@toDate)';

SET @balanceStmt = 'ROUND(SUM(monthDebit) - SUM(monthCredit),2) as monthBalance,
	ROUND(SUM(yearDebit) - SUM(yearCredit),2) as yearBalance
';

CALL codeDeclaration('debtorCreditor');

SET @balanceWhereStmt = ' `ChartOfAccount`.`company_id` = @company_id AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeDebtor) AND MasterAccountCode.company_id = @company_id) ';



IF(@debtorCreditor = 'debitor') THEN
SET @whereStmtMonth = CONCAT(@whereStmtMonth,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeDebtor) AND MasterAccountCode.company_id = @company_id)');

SET @whereStmtYear = CONCAT(@whereStmtYear,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeDebtor) AND MasterAccountCode.company_id = @company_id)');

SET @balanceStmt = 'ROUND(SUM(monthDebit) - SUM(monthCredit),2) as monthBalance,
	ROUND(SUM(yearDebit) - SUM(yearCredit),2) as yearBalance
';

SET @balanceWhereStmt = ' `ChartOfAccount`.`company_id` = @company_id AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeDebtor) AND MasterAccountCode.company_id = @company_id) ';


END IF;

IF (@debtorCreditor = 'creditor')
THEN
SET @whereStmtMonth = CONCAT(@whereStmtMonth,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeCreditor)  AND MasterAccountCode.company_id = @company_id)');

SET @whereStmtYear = CONCAT(@whereStmtYear,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeCreditor)  AND MasterAccountCode.company_id = @company_id)');

SET @balanceStmt = 'ROUND(SUM(monthCredit) - SUM(monthDebit),2) as monthBalance,
	ROUND(SUM(yearCredit) - SUM(yearDebit),2) as yearBalance
';

SET @balanceWhereStmt = ' `ChartOfAccount`.`company_id` = @company_id AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeCreditor)  AND MasterAccountCode.company_id = @company_id) ';

END IF;



IF(@accountTypeCode IS NOT NULL) THEN
SET @whereStmtMonth = concat(@whereStmtMonth, ' AND `ChartOfAccount`.`code` = @accountTypeCode ');
SET @whereStmtYear = concat(@whereStmtYear, ' AND `ChartOfAccount`.`code` = @accountTypeCode ');
END if;

IF(@subcodeID IS NOT NULL) THEN
SET @whereStmtMonth = concat(@whereStmtMonth, ' AND `ChartOfAccount`.`subcode_id` = @subcodeID ');
SET @whereStmtYear = concat(@whereStmtYear, ' AND `ChartOfAccount`.`subcode_id` = @subcodeID ');
END if;



IF(@profitCenterID IS NOT NULL) THEN
 SET @whereStmtMonth = concat(@whereStmtMonth, ' AND `GL`.`profit_center_id`= @profitCenterID');
 SET @whereStmtYear = concat(@whereStmtYear, ' AND `GL`.`profit_center_id`= @profitCenterID');
END if;

  CALL balanceGeneric(@whereStmtMonth, @whereStmtYear,@balanceWhereStmt, @debtorCreditor, @company_id, @profitCenterID,NULL);


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `balanceGeneric`(IN `whereStmtMonth` TEXT, IN `whereStmtYear` TEXT, IN `balanceWhereStmt` TEXT, IN `debtorCreditor` VARCHAR(10), IN `company_id` INT, IN `profitCenterID` INT, IN `projectID` INT)
BEGIN

SET @whereStmtMonth = whereStmtMonth;
SET @whereStmtYear = whereStmtYear;

SET @company_id = company_id;
SET @profitCenterID = profitCenterID;
SET @projectID = projectID;

SET @balanceStmt = 'ROUND(SUM(monthCredit) - SUM(monthDebit),2) as monthBalance,
	ROUND(SUM(yearCredit) - SUM(yearDebit),2) as yearBalance';


IF(@debtorCreditor = 'debitor') THEN
SET @balanceStmt = 'ROUND(SUM(monthDebit) - SUM(monthCredit),2) as monthBalance,
	ROUND(SUM(yearDebit) - SUM(yearCredit),2) as yearBalance
';

END IF;

IF (@debtorCreditor = 'creditor')
THEN
SET @balanceStmt = 'ROUND(SUM(monthCredit) - SUM(monthDebit),2) as monthBalance,
	ROUND(SUM(yearCredit) - SUM(yearDebit),2) as yearBalance
';
END IF;

SET @balanceWhereStmt = balanceWhereStmt;
IF(@balanceWhereStmt = '' OR ISNULL(@balanceWhereStmt)) THEN
SET @balanceWhereStmt  = ' ChartOfAccount.company_id = @company_id ';
END if;



SET @stmt = CONCAT('
SELECT `date`,
	`ref`,
	`description`,
	`code`,
    `code_desc`,
    `special_acc`, 
	`subcode_id`,
    `subcode`,
    `subcode_desc`,Debit  as Debit,Credit,
IFNULL(getOpeningBalance(@company_id,subcode_id,@profitCenterID,@projectID,B,1111-11-11,now()),0)  as openingBalance, 
  ROUND(SUM(IFNULL(yearDebit,0)),2) as yearDebit,
  ROUND(SUM(IFNULL(yearCredit,0)),2) as yearCredit,
  ROUND(SUM(IFNULL(monthDebit,0)),2) as monthDebit, 
  ROUND(SUM(IFNULL(monthCredit,0)),2) as monthCredit,
  ROUND(SUM(IFNULL(monthCredit,0)),2) as monthBalance,
  ROUND(SUM(IFNULL(monthCredit,0)),2) as yearBalance

 FROM(

SELECT   
	`date`,
	`ref`,
	`description`,
	`code`,
    `code_desc`,
    `special_acc`, 
	`subcode_id`,
    `subcode`,
    `subcode_desc`,
 ROUND(SUM(IFNULL(yearDebit,0)),2) as Debit,
 ROUND(SUM(IFNULL(yearCredit,0)),2) as Credit,


IF(ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2) >0,ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2),0)
as yearDebit ,


IF(ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2) <0,ABS(ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2)),0)
as yearCredit ,

-- ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2) >0,ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2),0) as yearDebit , 
-- IF(ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2) <0,ABS(ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2)),0) as yearCredit , 

IF(ROUND(SUM(IFNULL(monthDebit,0) - IFNULL(monthCredit,0)),2) >0,ROUND(SUM(IFNULL(monthDebit,0) - IFNULL(monthCredit,0)),2),0) as monthDebit , 
IF(ROUND(SUM(IFNULL(monthDebit,0) - IFNULL(monthCredit,0)),2) <0,ABS(ROUND(SUM(IFNULL(monthDebit,0) - IFNULL(monthCredit,0)),2)),0)as monthCredit,

-- ROUND(SUM(IFNULL(yearDebit,0)),2) as yearDebit,
-- ROUND(SUM(IFNULL(yearCredit,0)),2) as yearCredit,
-- ROUND(SUM(IFNULL(monthDebit,0)),2) as monthDebit,
-- ROUND(SUM(IFNULL(monthCredit,0)),2) as monthCredit,
',@balanceStmt,'

FROM (

SELECT 
    -- `ChartOfAccount`.`company_id`,
    -- `ChartOfAccount`.`account_code_id`,
	`GL`.`date`,
    `GL`.`ref`,
`GL`.`description`,
    `ChartOfAccount`.`code`,
    `ChartOfAccount`.`code_desc`,
    `ChartOfAccount`.`special_acc`,
    -- `ChartOfAccount`.`account_code`,
    -- `ChartOfAccount`.`account_desc`,
     `ChartOfAccount`.`subcode_id`,
    -- `ChartOfAccount`.`parent`,
    -- `ChartOfAccount`.`subcode_of`,
    `ChartOfAccount`.`subcode`,
    `ChartOfAccount`.`subcode_desc`,
	0 as yearDebit,
	0 as yearCredit,
	ROUND(SUM( IFNULL(debit,0)),2)*count(DISTINCT GL.id)/count(*) as monthDebit , 
	ROUND(SUM( IFNULL(credit,0)),2)*count(DISTINCT GL.id)/count(*) as monthCredit

FROM
    `chart_of_accounts` AS `ChartOfAccount`
	LEFT JOIN subcodes as Subcode ON Subcode.id = `ChartOfAccount`.`subcode_id` 
	LEFT JOIN `general_ledgers` as GL ON `GL`.`subcode_id` = `ChartOfAccount`.`subcode_id` 
WHERE 
   ', @whereStmtMonth ,'

GROUP BY ChartOfAccount.subcode 

UNION SELECT 
    -- `ChartOfAccount`.`company_id`,
    -- `ChartOfAccount`.`account_code_id`,
`GL`.`date`,
    `GL`.`ref`,
`GL`.`description`,
    `ChartOfAccount`.`code`,
    `ChartOfAccount`.`code_desc`,
    `ChartOfAccount`.`special_acc`,
    -- `ChartOfAccount`.`account_code`,
    -- `ChartOfAccount`.`account_desc`,
     `ChartOfAccount`.`subcode_id`,
    -- `ChartOfAccount`.`parent`,
    -- `ChartOfAccount`.`subcode_of`,
    `ChartOfAccount`.`subcode`,
    `ChartOfAccount`.`subcode_desc`,
	-- ROUND(SUM(Distinct IFNULL(debit,0)),2) + IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,@projectID,D,1111-11-11,now()),0) as yearDebit, 
	-- ROUND(SUM(Distinct IFNULL(credit,0)),2)+ IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,@projectID,C,1111-11-11,now()),0) as yearCredit,
	 ROUND(SUM( IFNULL(debit,0)),2)*count(DISTINCT GL.id)/count(*)  as yearDebit, 
	 ROUND(SUM( IFNULL(credit,0)),2)*count(DISTINCT GL.id)/count(*) as yearCredit,
	0 as monthDebit,
	0 as monthCredit
FROM
    `chart_of_accounts` AS `ChartOfAccount`
	LEFT JOIN subcodes as Subcode ON Subcode.id = `ChartOfAccount`.`subcode_id` 
	LEFT JOIN `general_ledgers` as GL ON `GL`.`subcode_id` = `ChartOfAccount`.`subcode_id` 
WHERE
   ', @whereStmtYear ,'
GROUP BY ChartOfAccount.subcode 


UNION SELECT 
    -- `ChartOfAccount`.`company_id`,
    -- `ChartOfAccount`.`account_code_id`,
`GL`.`date`,
    `GL`.`ref`,
`GL`.`description`,
    `ChartOfAccount`.`code`,
    `ChartOfAccount`.`code_desc`,
    `ChartOfAccount`.`special_acc`,
    -- `ChartOfAccount`.`account_code`,
    -- `ChartOfAccount`.`account_desc`,
     `ChartOfAccount`.`subcode_id`,
    -- `ChartOfAccount`.`parent`,
    -- `ChartOfAccount`.`subcode_of`,
    `ChartOfAccount`.`subcode`,
    `ChartOfAccount`.`subcode_desc`,
	-- IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,@projectID,D,1111-11-11,now()),0) as yearDebit, 
	-- IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,@projectID,C,1111-11-11,now()),0) as yearCredit,

	-- IF (`ChartOfAccount`.`subcode_id` IN (SELECT subcode_id FROM Banks WHERE subcode_id ),0,IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,@projectID,B,1111-11-11,now()),0))  as yearDebit,

	-- IF (`ChartOfAccount`.`subcode_id` IN (SELECT subcode_id FROM Banks WHERE subcode_id ),IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,@projectID,B,1111-11-11,now()),0),0)  as yearCredit, 
	IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,@projectID,B,1111-11-11,now()),0) as yearDebit,
	0 as yearCredit,
	0 as monthDebit,
	0 as monthCredit
FROM
    `chart_of_accounts` AS `ChartOfAccount`
	LEFT JOIN subcodes as Subcode ON Subcode.id = `ChartOfAccount`.`subcode_id` 
	LEFT JOIN `general_ledgers` as GL ON `GL`.`subcode_id` = `ChartOfAccount`.`subcode_id` 
WHERE
   ', @balanceWhereStmt  ,'
GROUP BY ChartOfAccount.subcode 

) balanc 

GROUP BY subcode
)balance
WHERE (yearDebit OR yearCredit OR monthDebit OR  monthCredit )

GROUP BY subcode WITH ROLLUP

 ');


PREPARE executeStmt FROM @stmt;

EXECUTE executeStmt;

DEALLOCATE PREPARE executeStmt;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `codeDeclaration`(IN `declareType` VARCHAR(15))
BEGIN

SET @declareType = declareType;
IF(@declareType = '' || isNull(@declareType)) THEN
SET @declareType  = 'code';
END if;

IF(@declareType = 'code')
THEN
SET @salesAdjestment = 'E';
SET @otherIncomes = 'K';
SET @sales = 'E';
SET @costOfGoodsSold = 'N';
SET @expenses = 'I';

SET @fixedAsset = 'B';
SET @currentLiabilities = 'D';
SET @currentAssets = 'M';
SET @costOfSales = 'F';
SET @equity = 'L'; 

END if;

IF(@declareType = 'id')
THEN

SET @capital = 2;
SET @longTermLiabilities = 3;
SET @fixedAsset = 4;
SET @currentLiabilities = 5;
SET @sales = 6;
SET @costOfSales = 7;
SET @otherIncome = 11;
SET @expenses = 12;
SET @currentAssets = 13;
SET @otherAsset = 16;
SET @otherLiabilities = 18;

SET @costOfGoodsSold = 14;
SET @manufacturingAccount = 8;
SET @salesAdjestments = 17;

END if;

IF(@declareType = 'debtorCreditor')
THEN

SET @tradeDebtor = 1;
SET @tradeCreditor = 4;

END if;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `duePayment`(IN `company_id` INT, IN `profitCenterID` INT, IN `debtorCreditor` VARCHAR(10), IN `toDate` DATE, IN `cid` INT)
BEGIN
SET @company_id = company_id;
SET @profitCenterID = profitCenterID;
SET @debtorCreditor = debtorCreditor;
SET @toDate = toDate;

SET @profitCenterID =profitCenterID;
IF(@profitCenterID = '') THEN
SET @profitCenterID  = NULL;
END if;


CALL codeDeclaration('debtorCreditor');

SET @groupStmt = ' GROUP BY ChartOfAccount.subcode_id WITH rollup';

 SET @whereStmt = ' ChartOfAccount.company_id = @company_id
 	AND `GL`.`date` <= DATE(@toDate) ';


IF(@debtorCreditor = 'debitor') THEN
SET @whereStmt = CONCAT(@whereStmt,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeDebtor) AND MasterAccountCode.company_id = @company_id)');

SET @balanceStmt = ' SUM(IFNULL(debit,0)) + IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,NULL,D,1111-11-11,now()),0) 
-  ROUND(SUM(IFNULL(credit,0)) + IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,NULL,C,1111-11-11,now()),0),2)';

END IF;

IF (@debtorCreditor = 'creditor')
THEN
SET @whereStmt = CONCAT(@whereStmt,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE CodeDesc.id in (@tradeCreditor)  AND MasterAccountCode.company_id = @company_id)');

SET @balanceStmt = ' ROUND(SUM(IFNULL(credit,0)) + IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,NULL,C,1111-11-11,now()),0)
-SUM(IFNULL(debit,0)) + IFNULL(getOpeningBalance(@company_id,ChartOfAccount.subcode_id,@profitCenterID,NULL,D,1111-11-11,now()),0) 
,2)';

END IF;

IF(@profitCenterID IS NOT NULL) THEN
SET @whereStmt = CONCAT(@whereStmt,' AND GL.profit_center_id = @profitCenterID ');
END IF;



SET @stmt = CONCAT(' SELECT 
     -- `ChartOfAccount`.`company_id`,
    -- `ChartOfAccount`.`account_code_id`,
    `ChartOfAccount`.`code`,
    -- `ChartOfAccount`.`account_code`,
    -- `ChartOfAccount`.`account_desc`,
     `ChartOfAccount`.`subcode_id`,
    -- `ChartOfAccount`.`parent`,
    -- `ChartOfAccount`.`subcode_of`,
    `ChartOfAccount`.`subcode`,
    `ChartOfAccount`.`subcode_desc`,
    `GL`.`date` as inv_date,
    `GL`.`ref`,
	DATEDIFF(@toDate,`GL`.`date`) as oDueDays,
-- 	ROUND(SUM(IFNULL(debit,0)),2) as debit, 
-- 	ROUND(SUM(IFNULL(credit,0)),2) as credit,
',@balanceStmt,'as balance

FROM
    `chart_of_accounts` AS `ChartOfAccount`
	LEFT JOIN `general_ledgers` as GL ON `GL`.`subcode_id` = `ChartOfAccount`.`subcode_id` 
 WHERE ',@whereStmt, @groupStmt ,' 
-- ORDER BY inv_date ');

PREPARE executeStmt FROM @stmt;

EXECUTE executeStmt;

DEALLOCATE PREPARE executeStmt;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `trialBalance`(IN `company_id` INT, IN `profitCenterID` INT, IN `projectID` INT, IN `toDate` DATE)
BEGIN

SET @company_id = company_id;

SET @toDate =toDate;

SET @profitCenterID = profitCenterID;
IF(@profitCenterID = '') THEN
SET @profitCenterID  = NULL;
END if;

SET @projectID = projectID;
IF(@projectID = '') THEN
SET @projectID  = NULL;
END if;

SET @whereStmtMonth = ' ChartOfAccount.company_id = @company_id  -- AND `Subcode`.`subcode_of`=  0  
	-- AND MONTH(GL.date) = MONTH(@toDate)
 	-- AND YEAR(GL.date) = YEAR(@toDate)
	AND DATE(GL.date) BETWEEN FIRST_DAY(@toDate) AND LAST_DAY(@toDate) 
';

SET @whereStmtYear = '    ChartOfAccount.company_id = @company_id  
-- AND `Subcode`.`subcode_of`= 0 AND YEAR(GL.date) = YEAR(@toDate)
AND DATE(GL.date) <= LAST_DAY(@toDate) 
';

IF(@profitCenterID IS NOT NULL) THEN
SET @whereStmtMonth = concat(@whereStmtMonth, ' AND `GL`.`profit_center_id`= @profitCenterID');
SET @whereStmtYear = concat(@whereStmtYear, ' AND `GL`.`profit_center_id`= @profitCenterID');
END if;

IF(@projectID IS NOT NULL) THEN
SET @whereStmtMonth = concat(@whereStmtMonth, ' AND `GL`.`project_id`= @projectID');
SET @whereStmtYear = concat(@whereStmtYear, ' AND `GL`.`project_id`= @projectID');
END if;

CALL balanceGeneric(@whereStmtMonth, @whereStmtYear,NULL,NULL, @company_id, @profitCenterID,@projectID );

END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `FIRST_DAY`(`day` DATE) RETURNS date
BEGIN
  RETURN ADDDATE(LAST_DAY(SUBDATE(day, INTERVAL 1 MONTH)), 1);
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `getOpeningBalance`(`company_id` INT, `subcodeID` INT, `profitCenterID` INT, `projectID` INT, `type` CHAR(1), `fromDate` DATE, `toDate` DATE) RETURNS float
BEGIN  

SET @balance = 0;
SET @debit = 0;
SET @credit = 0;

SET @profitCenterID =  profitCenterID;
SET @fromDate =  fromDate;
SET @toDate =  toDate;

IF(@profitCenterID = '') THEN
SET @profitCenterID  = NULL;
END if;

SET @projectID =  projectID;
IF(@projectID = '') THEN
SET @projectID  = NULL;
END if;


IF(@projectID IS NULL) THEN

IF(@profitCenterID IS NULL) THEN
	SELECT SUM((COALESCE(debit,0) - COALESCE(credit,0))),
	COALESCE(IFNULL(debit,0),0),
	COALESCE(IFNULL(credit,0),0)
	INTO @balance, @debit, @credit
			FROM  opening_balance
			WHERE `opening_balance`.`subcode_id` = subcodeID
			AND `opening_balance`.`company_id` = company_id
			AND `opening_balance`.`opening_date` BETWEEN DATE(fromDate) AND DATE(toDate)		
			;

ELSE
	SELECT SUM((COALESCE(debit,0) - COALESCE(credit,0))),
	COALESCE(IFNULL(debit,0),0),
	COALESCE(IFNULL(credit,0),0)
	INTO @balance, @debit, @credit
			FROM  opening_balance
			WHERE `opening_balance`.`subcode_id` = subcodeID
			AND  `opening_balance`.`profit_center_id` = profitCenterID
			AND `opening_balance`.`company_id` = company_id
			AND `opening_balance`.`opening_date` BETWEEN DATE(fromDate) AND DATE(toDate);
END if;

END if;

if (type = 'D') THEN
RETURN @debit;
END IF;

if (type = 'C') THEN
RETURN @credit;
END IF;

RETURN @balance;

END$$

DELIMITER ;
	
	
	
	
	";
			*/
	
	
    $mysqli = new mysqli($params['db_host'], $params['db_uname'], $params['db_password'], $params['db_to_backup']);
    if ($mysqli->connect_error) {
        die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
    }
    
    $results = $mysqli->query("SHOW TABLES");
    
    while($row = $results->fetch_array()){
        if (!in_array($row[0], $params['db_exclude_tables'])){
            $mtables[] = $row[0];
        }
    }

    foreach($mtables as $table){
       // $contents .= "-- Table `".$table."` --\n";
        
        $results = $mysqli->query("SHOW CREATE TABLE ".$table);
        while($row = $results->fetch_array()){
            $contents .= $row[1].";\n\n";
        }

        $results = $mysqli->query("SELECT * FROM ".$table);
        $row_count = $results->num_rows;
        $fields = $results->fetch_fields();
        $fields_count = count($fields);
        
        $insert_head = "INSERT INTO `".$table."` (";
        for($i=0; $i < $fields_count; $i++){
          		  
				$insert_head  .= "`".$fields[$i]->name."`";
				
				if($i < $fields_count-1){
                        $insert_head  .= ', ';
                    }
        }
        $insert_head .=  ")";
        $insert_head .= " VALUES\n";        
                
        if($row_count>0){
            $r = 0;
            while($row = $results->fetch_array()){
                if(($r % 400)  == 0){
                    $contents .= $insert_head;
                }
                $contents .= "(";
                for($i=0; $i < $fields_count; $i++){
				
					if($row[$i]==NULL){
						$row[$i] = "NULL";
					}
				
                    $row_content =  str_replace("\n","\\n",$mysqli->real_escape_string($row[$i]));
                    
                    switch($fields[$i]->type){
                        case 8: case 3:
                            $contents .=  $row_content;
                            break;
                        default:
                            $contents .= "'". $row_content ."'";
                    }
                    if($i < $fields_count-1){
                            $contents  .= ', ';
                        }
                }
                if(($r+1) == $row_count || ($r % 400) == 399){
                    $contents .= ");\n\n";
                }else{
                    $contents .= "),\n";
                }
                $r++;
            }						
        }
    }
	
	
	/*$contents .="
	
	--
-- Stand-in structure for view `balance_sheets`
--
CREATE TABLE IF NOT EXISTS `balance_sheets` (
`id` int(11)
,`company_id` int(11)
,`profit_center_id` int(11)
,`account_code_id` int(11)
,`account_code` varchar(9)
,`account_desc` varchar(255)
,`subcode_id` int(11)
,`subcode` varchar(10)
,`subcode_desc` varchar(255)
,`debit` decimal(18,2)
,`credit` decimal(18,2)
,`created` datetime
);


--
-- Stand-in structure for view `chart_of_accounts`
--
CREATE TABLE IF NOT EXISTS `chart_of_accounts` (
`company_id` int(11)
,`account_code_id` int(11)
,`account_type_id` int(11)
,`code` char(1)
,`code_desc` varchar(45)
,`special_acc` varchar(45)
,`account_code` varchar(9)
,`account_desc` varchar(255)
,`subcode_id` bigint(20)
,`parent` bigint(20)
,`subcode_of` int(11)
,`subcode` varchar(10)
,`subcode_desc` varchar(255)
);

--
-- Stand-in structure for view `general_ledgers`
--
CREATE TABLE IF NOT EXISTS `general_ledgers` (
`id` varchar(259)
,`subcode_id` int(255)
,`profit_center_id` int(255)
,`company_id` int(255)
,`totalamount` double
,`currencycode` varchar(11)
,`currencyrate` varchar(20)
,`unattended_gl_id` bigint(255)
,`project_id` bigint(255)
,`date` date
,`ref` varchar(45)
,`description` varchar(255)
,`debit` decimal(18,2)
,`credit` decimal(18,2)
,`gst` varchar(20)
,`taxcode` varchar(10)
,`status` tinyint(4)
,`created_ip` varchar(20)
,`created` datetime
,`created_by` int(11)
,`modified_ip` varchar(20)
,`modified` datetime
,`modified_by` int(11)
);


--
-- Table structure for table `view_cheque`
--

CREATE TABLE IF NOT EXISTS `view_cheque` (
  `CheqDate` date DEFAULT NULL,
  `CheqNO` varchar(20) DEFAULT NULL,
  `Payee` varchar(250) DEFAULT NULL,
  `Amount` decimal(18,2) DEFAULT NULL,
  `PVNO` varchar(20) DEFAULT NULL,
  `Description` text,
  `Company_Name` varchar(100) DEFAULT NULL,
  `Bank_Name` varchar(45) DEFAULT NULL,
  `Bank_Branch` varchar(45) DEFAULT NULL,
  `Account_Number` varchar(50) DEFAULT NULL,
  `CheqType` varchar(10) DEFAULT NULL,
  `company_id` int(255) DEFAULT NULL,
  `BankID` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Structure for view `balance_sheets`
--
DROP TABLE IF EXISTS `balance_sheets`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `balance_sheets` AS select `opening_balance`.`id` AS `id`,`opening_balance`.`company_id` AS `company_id`,`opening_balance`.`profit_center_id` AS `profit_center_id`,`master_account_codes`.`id` AS `account_code_id`,`master_account_codes`.`account_code` AS `account_code`,`master_account_codes`.`account_desc` AS `account_desc`,`opening_balance`.`subcode_id` AS `subcode_id`,`subcodes`.`code` AS `subcode`,`subcodes`.`description` AS `subcode_desc`,`opening_balance`.`debit` AS `debit`,`opening_balance`.`credit` AS `credit`,`opening_balance`.`created` AS `created` from ((`opening_balance` left join `subcodes` on((`subcodes`.`id` = `opening_balance`.`subcode_id`))) left join `master_account_codes` on((`master_account_codes`.`id` = `subcodes`.`master_account_code_id`)));

-- --------------------------------------------------------

--
-- Structure for view `chart_of_accounts`
--
DROP TABLE IF EXISTS `chart_of_accounts`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `chart_of_accounts` AS select `master_account_codes`.`company_id` AS `company_id`,`master_account_codes`.`id` AS `account_code_id`,`accounttype`.`id` AS `account_type_id`,`accounttype`.`code` AS `code`,`accounttype`.`code_desc` AS `code_desc`,`master_account_codes`.`special_acc` AS `special_acc`,`master_account_codes`.`account_code` AS `account_code`,`master_account_codes`.`account_desc` AS `account_desc`,ifnull(`subcodes`.`id`,0) AS `subcode_id`,ifnull(`subcodes`.`subcode_of`,0) AS `parent`,if(((`subcodes`.`subcode_of` = NULL) or (`subcodes`.`subcode_of` = 0)),`subcodes`.`id`,`subcodes`.`subcode_of`) AS `subcode_of`,`subcodes`.`code` AS `subcode`,`subcodes`.`description` AS `subcode_desc` from (((((`master_account_codes` left join `account_types` `accounttype` on((`accounttype`.`id` = `master_account_codes`.`account_type_id`))) left join `subcodes` on((`master_account_codes`.`id` = `subcodes`.`master_account_code_id`))) left join `subcodes` `s1` on((`s1`.`id` = `subcodes`.`subcode_of`))) left join `subcodes` `s2` on((`s2`.`id` = `s1`.`subcode_of`))) left join `subcodes` `s3` on((`s3`.`id` = `s2`.`subcode_of`))) union select `master_account_codes`.`company_id` AS `company_id`,`master_account_codes`.`id` AS `account_code_id`,`accounttype`.`id` AS `account_type_id`,`accounttype`.`code` AS `code`,`accounttype`.`code_desc` AS `code_desc`,`master_account_codes`.`special_acc` AS `special_acc`,`master_account_codes`.`account_code` AS `account_code`,`master_account_codes`.`account_desc` AS `account_desc`,ifnull(`subcodes`.`id`,0) AS `subcode_id`,ifnull(`subcodes`.`subcode_of`,0) AS `parent`,if((`s2`.`id` = 0),`subcodes`.`id`,ifnull(`s2`.`id`,`subcodes`.`id`)) AS `subcode_of`,`subcodes`.`code` AS `subcode`,`subcodes`.`description` AS `subcode_desc` from (((((`master_account_codes` left join `account_types` `accounttype` on((`accounttype`.`id` = `master_account_codes`.`account_type_id`))) left join `subcodes` on((`master_account_codes`.`id` = `subcodes`.`master_account_code_id`))) left join `subcodes` `s1` on((`s1`.`id` = `subcodes`.`subcode_of`))) left join `subcodes` `s2` on((`s2`.`id` = `s1`.`subcode_of`))) left join `subcodes` `s3` on((`s3`.`id` = `s2`.`subcode_of`))) union select `master_account_codes`.`company_id` AS `company_id`,`master_account_codes`.`id` AS `account_code_id`,`accounttype`.`id` AS `account_type_id`,`accounttype`.`code` AS `code`,`accounttype`.`code_desc` AS `code_desc`,`master_account_codes`.`special_acc` AS `special_acc`,`master_account_codes`.`account_code` AS `account_code`,`master_account_codes`.`account_desc` AS `account_desc`,ifnull(`subcodes`.`id`,0) AS `subcode_id`,ifnull(`subcodes`.`subcode_of`,0) AS `parent`,if((`s1`.`id` = 0),`subcodes`.`id`,ifnull(`s1`.`id`,`subcodes`.`id`)) AS `subcode_of`,`subcodes`.`code` AS `subcode`,`subcodes`.`description` AS `subcode_desc` from (((((`master_account_codes` left join `account_types` `accounttype` on((`accounttype`.`id` = `master_account_codes`.`account_type_id`))) left join `subcodes` on((`master_account_codes`.`id` = `subcodes`.`master_account_code_id`))) left join `subcodes` `s1` on((`s1`.`id` = `subcodes`.`subcode_of`))) left join `subcodes` `s2` on((`s2`.`id` = `s1`.`subcode_of`))) left join `subcodes` `s3` on((`s3`.`id` = `s2`.`subcode_of`)));

-- --------------------------------------------------------

--
-- Structure for view `general_ledgers`
--
DROP TABLE IF EXISTS `general_ledgers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `general_ledgers` AS select concat('agl',`auto_general_ledgers`.`id`) AS `id`,`auto_general_ledgers`.`subcode_id` AS `subcode_id`,`auto_general_ledgers`.`profit_center_id` AS `profit_center_id`,`auto_general_ledgers`.`company_id` AS `company_id`,`auto_general_ledgers`.`totalamount` AS `totalamount`,`auto_general_ledgers`.`currencycode` AS `currencycode`,`auto_general_ledgers`.`currencyrate` AS `currencyrate`,`auto_general_ledgers`.`unattended_gl_id` AS `unattended_gl_id`,`auto_general_ledgers`.`project_id` AS `project_id`,`auto_general_ledgers`.`date` AS `date`,`auto_general_ledgers`.`ref` AS `ref`,`auto_general_ledgers`.`description` AS `description`,`auto_general_ledgers`.`debit` AS `debit`,`auto_general_ledgers`.`credit` AS `credit`,`auto_general_ledgers`.`gst` AS `gst`,`auto_general_ledgers`.`taxcode` AS `taxcode`,`auto_general_ledgers`.`status` AS `status`,`auto_general_ledgers`.`created_ip` AS `created_ip`,`auto_general_ledgers`.`created` AS `created`,`auto_general_ledgers`.`created_by` AS `created_by`,`auto_general_ledgers`.`modified_ip` AS `modified_ip`,`auto_general_ledgers`.`modified` AS `modified`,`auto_general_ledgers`.`modified_by` AS `modified_by` from `auto_general_ledgers` union select concat('je',`journal_entries`.`id`) AS `id`,`journal_entries`.`subcode_id` AS `subcode_id`,`journal_entries`.`profit_center_id` AS `profit_center_id`,`journal_entries`.`company_id` AS `company_id`,`journal_entries`.`totalamount` AS `totalamount`,`journal_entries`.`currencycode` AS `currencycode`,`journal_entries`.`currencyrate` AS `currencyrate`,0 AS `unattended_gl_id`,0 AS `project_id`,`journal_entries`.`date` AS `date`,`journal_entries`.`ref` AS `ref`,`journal_entries`.`memo` AS `description`,`journal_entries`.`debit` AS `debit`,`journal_entries`.`credit` AS `credit`,`journal_entries`.`gst` AS `gst`,`journal_entries`.`taxcode` AS `taxcode`,`journal_entries`.`status` AS `status`,`journal_entries`.`created_ip` AS `created_ip`,`journal_entries`.`created` AS `created`,`journal_entries`.`created_by` AS `created_by`,`journal_entries`.`modified_ip` AS `modified_ip`,`journal_entries`.`modified` AS `modified`,`journal_entries`.`modified_by` AS `modified_by` from `journal_entries` union select concat('fagl',`fixed_asset_gl`.`id`) AS `id`,`fixed_asset_gl`.`subcode_id` AS `subcode_id`,`fixed_asset_gl`.`profit_center_id` AS `profit_center_id`,`fixed_asset_gl`.`company_id` AS `company_id`,`fixed_asset_gl`.`totalamount` AS `totalamount`,`fixed_asset_gl`.`currencycode` AS `currencycode`,`fixed_asset_gl`.`currencyrate` AS `currencyrate`,0 AS `unattended_gl_id`,`fixed_asset_gl`.`project_id` AS `project_id`,`fixed_asset_gl`.`date` AS `date`,`fixed_asset_gl`.`ref` AS `ref`,`fixed_asset_gl`.`description` AS `description`,`fixed_asset_gl`.`debit` AS `debit`,`fixed_asset_gl`.`credit` AS `credit`,`fixed_asset_gl`.`gst` AS `gst`,`fixed_asset_gl`.`taxcode` AS `taxcode`,`fixed_asset_gl`.`status` AS `status`,`fixed_asset_gl`.`created_ip` AS `created_ip`,`fixed_asset_gl`.`created` AS `created`,`fixed_asset_gl`.`created_by` AS `created_by`,`fixed_asset_gl`.`modified_ip` AS `modified_ip`,`fixed_asset_gl`.`modified` AS `modified`,`fixed_asset_gl`.`modified_by` AS `modified_by` from `fixed_asset_gl`;
	
	";*/
	
    
		
    if (!is_dir ( $params['db_backup_path'] )) {
            mkdir ( $params['db_backup_path'], 0777, true );
     }
    
    
         
    $fp = fopen($backup_file_name ,'w+');
    if (($result = fwrite($fp, $contents))) {
        echo "Backup file created '--$backup_file_name' ($result)"; 
    }
    fclose($fp);
}
	
	



    public function error() {
      require_once('views/backup/error.php');
    }
  }
?>