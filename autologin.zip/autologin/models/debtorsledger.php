<?php
  class Debtorsledger {
   
  }
?>