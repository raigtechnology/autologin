<?php
  class OpeningbalanceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // company_id
				    
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 	
				
		$openingbalancelist = array();
		$opening_balance = $db->query("select op.opening_date, op.id, sc.code, op.debit, op.credit, sc.description, pc.profit_center from opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join profit_centers as pc on pc.id = op.profit_center_id where op.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		foreach($opening_balance->fetchAll() as $pc) {
			$openingbalancelist[] = $pc;
		}  		
						  
	  require_once('views/openingbalance/index.php'); 
	  
    }	
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // company_id
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_desc in('CURRENT LIABILITIES','CURRENT ASSETS','EQUITY','CAPITAL','LONG TERM LIABILITIES','OTHER ASSETS','OTHER LIABILITIES','FIXED ASSETS') order by account_desc asc ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  	
		
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
		
	
		$accountingyear = $db->query("select ls_yr_closing_date from accounting_year where company_id='".$cid."' ");	
		foreach($accountingyear->fetchAll() as $ay) {
			$last_yr_closing_date = $ay['ls_yr_closing_date'];
		}  	
		
		
		
		if(isset($_POST['save'])){			
												
			$data = $_POST['data'];
			
			foreach($data as $dt){
									
				$subcode_id 		= $dt['subcode_id'];	
				$profit_center_id	= $dt['profit_center_id'];	
				$debit				= $dt['debit'];	
				$credit				= $dt['credit'];	
								
				$created_by = $_SESSION['username'];
				$created_ip = $_SERVER['REMOTE_ADDR'];
				$created    = date("Y-m-d H:i:s"); 
							
				// insert query
				$result = $db->query("insert into opening_balance(opening_date, company_id, subcode_id, profit_center_id, debit, credit, created_by, created_ip, created) values ('".$last_yr_closing_date."', '".$cid."', '".$subcode_id."', '".$profit_center_id."', '".$debit."', '".$credit."', '".$created_by."', '".$created_ip."', '".$created."') ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}				
			}
			
			header("Location: ?controller=openingbalance&action=index&cid=".$cid."");						
					
		} else {	 
		   require_once('views/openingbalance/create.php'); 	   
		}  
	  
    }		
	
	// edit
	public function edit() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // company_id
		
		$openingbalancelist = array();
		$opening_balance = $db->query("select sc.code, op.id, op.debit, op.credit, op.profit_center_id, op.subcode_id from opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join profit_centers as pc on pc.id = op.profit_center_id where op.company_id='".$cid."' and sc.company_id='".$cid."' and op.id = '".$_GET['id']."' ");	
		foreach($opening_balance->fetchAll() as $pc) {
			$openingbalancelist[] = $pc;
		}  	
		
		
		// account types
		$subcodeslist = array();
		$subcodes = $db->query("select id, description from subcodes where company_id='".$cid."' ");	
		foreach($subcodes->fetchAll() as $sc) {
			$subcodeslist[] = $sc;
		}  	
		
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
		$accountingyear = $db->query("select ls_yr_closing_date from accounting_year where company_id='".$cid."' ");	
		foreach($accountingyear->fetchAll() as $ay) {
			$last_yr_closing_date = $ay['ls_yr_closing_date'];
		}  
		
		
		if(isset($_POST['save'])){			
			
			
			$db->query("update opening_balance set opening_date = '".$last_yr_closing_date."' where company_id = '".$cid."' ");		
			
			
			$data = $_POST['data'];
			
			foreach($data as $dt){
			
				$debit				= $dt['debit'];	
				$credit				= $dt['credit'];		
				
				$modified_by = $_SESSION['username'];
				$modified_ip = $_SERVER['REMOTE_ADDR'];
				$modified    = date("Y-m-d H:i:s"); 
											
				// update query
				$result = $db->query("update opening_balance set debit = '".$debit."', credit = '".$credit."', modified_by='".$modified_by."', modified_ip='".$modified_ip."', modified='".$modified."' where company_id = '".$cid."' and id = '".$_GET['id']."' ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}				
			}
			
			header("Location: ?controller=openingbalance&action=index&cid=".$cid."");						
					
		} else {	 
		   require_once('views/openingbalance/edit.php'); 	   
		}  
	  
    }		
	
		
	// delete
	public function delete() {
	
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // company_id
		
		$id = $_GET['id'];	
		$result = $db->query("delete from opening_balance where company_id = '".$cid."' and id ='".$id."' ");		
							
		if(!$result){
			die('Invalid query: ' . mysql_error());
		}	
		
      header("Location: ?controller=openingbalance&action=index&cid=".$cid."");		
    }
		

    public function error() {
      require_once('views/openingbalance/error.php');
    }
  }
?>