<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		
	
	$accountname = $_GET['value1']; 
	$cid = $_GET['cid']; 

	$pomaster = $db->query("select pmp.AutoPurchaseID, pmp.QuoteRef, pmp.CurrencyCode, pmp.Currencyrate, pmp.vendorID from tblpomaster_purchase as pmp where pmp.company_id ='".$cid."' and pmp.QuoteRef = '".$_GET['value1']."' and pmp.flag!=1 ");
	
	$Totalamt =0;
	$Gstamt =0;
	$TaxCode="";
	?>
		<table style="border:hidden;" id="salesinvoice_panel">
		<tr>				
			<th width="10%" align="right">TOTAL AMOUNT</th>
			<th width="10%" align="right">TOTAL GST</th>
			<th width="10%" align="right">CURRENCY CODE</th>
			<th width="10%" align="right">CURRENCY RATE</th>					
			<th width="10%" align="right">DEPOSIT AMOUNT</th>
		</tr>			
	
	<?php
	$it=0;
	$pom_sales = array();
	foreach($pomaster as $po){	
		
		$CurrencyCode = $po['CurrencyCode'];
		$Currencyrate = $po['Currencyrate'];							
		
		$depositlist =  $db->query("select amount, deposit_amount, deposit_gst, TotalAmount, GSTAmount, TaxCode, Currencyrate from deposit_purchase where PoNumber='".$_GET['value1']."' and companyID=".$cid." order by AutoDepositID desc limit 1 ");
		
		$in=0;							
		foreach($depositlist->fetchAll() as $dp){				
			$Totalamt		= $dp['TotalAmount'];		
			$Gstamt 		= $dp['GSTAmount'] - $dp['deposit_gst'];	
			$TaxCode		= $dp['TaxCode'];			
		?>	
			<tr>					
			<td align="right">
			<input type="text" name="data[<?php echo $in; ?>][amount]" id="amount" class="textbox_small" value="<?php echo $Totalamt; ?>" style="text-align:right;"  required="required" />
			</td>	
						
			<td align="right">
				<input type="text" name="data[<?php echo $in; ?>][gst]" id="gst" class="textbox_small" value="<?php echo $Gstamt; ?>" style="text-align:right;"  required="required" />
			</td>
			<td align="right">
				<select name="data[<?php echo $in; ?>][currency_code]" id="currency_code" class="selectbox_small">
					<option value="EUR" <?php if($CurrencyCode=="EUR"){?> selected="selected" <?php } ?>>EUR</option>			
					<option value="USD" <?php if($CurrencyCode=="USD"){?> selected="selected" <?php } ?>>USD</option>			
					<option value="RM" <?php if($CurrencyCode=="RM"){?> selected="selected" <?php } ?>>RM</option>			
				</select>
			</td>
			
			<td align="right">
			<input type="text" name="data[<?php echo $in; ?>][currecny_rate]" id="currecny_rate" class="textbox_small" value="<?php echo $Currencyrate; ?>" style="text-align:right;" value="1.00"  required="required" />
			</td>					
			<td align="right">
			<input type="text" name="data[<?php echo $in; ?>][deposit_amount]" id="deposit_amount" class="textbox_small" style="text-align:right;"  required="required" />
			</td>					
		</tr>			

	<input type="hidden" name="data[<?php echo $in; ?>][pototal]" id="pototal" value="<?php echo $Totalamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $in; ?>][pogst]" id="pogst" value="<?php echo $Gstamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $in; ?>][TaxCode]" id="TaxCode" value="<?php echo $TaxCode; ?>" class="textbox_small" style="text-align:right;"  required="required" />
		
		
		<?php
		$in++;
		}	
				
		if($in==0){
												
			$pop_purchase = $db->query("select AutoPurchaseID, Totalamt, GSTamt, TaxCode from tblpoproduct_purchase where company_id='".$cid."' and AutoPurchaseID = '".$po['AutoPurchaseID']."' ");					
		
			$ir=0;
			foreach($pop_purchase as $pop){					
				$Totalamt 		= $pop['Totalamt'];
				$Gstamt 		= $pop['GSTamt'];
				$TaxCode 		= $pop['TaxCode'];
			?>
			
		<tr>					
			<td align="right">
			<input type="text" name="data[<?php echo $r; ?>][amount]" id="amount" class="textbox_small" value="<?php echo $Totalamt; ?>" style="text-align:right;"  required="required" />
			</td>	
						
			<td align="right">
				<input type="text" name="data[<?php echo $r; ?>][gst]" id="gst" class="textbox_small" value="<?php echo $Gstamt; ?>" style="text-align:right;"  required="required" />
			</td>
			<td align="right">
				<select name="data[<?php echo $r; ?>]currency_code" id="currency_code" class="selectbox_small">
					<option value="EUR" <?php if($CurrencyCode=="EUR"){?> selected="selected" <?php } ?>>EUR</option>			
					<option value="USD" <?php if($CurrencyCode=="USD"){?> selected="selected" <?php } ?>>USD</option>			
					<option value="RM" <?php if($CurrencyCode=="RM"){?> selected="selected" <?php } ?>>RM</option>			
				</select>
			</td>
			
			<td align="right">
			<input type="text" name="data[<?php echo $r; ?>][currecny_rate]" id="currecny_rate" class="textbox_small" value="<?php echo $Currencyrate; ?>" style="text-align:right;" value="1.00"  required="required" />
			</td>					
			<td align="right">
			<input type="text" name="data[<?php echo $r; ?>][deposit_amount]" id="deposit_amount" class="textbox_small" style="text-align:right;"  required="required" />
			</td>					
		</tr>			

	<input type="hidden" name="data[<?php echo $r; ?>][pototal]" id="pototal" value="<?php echo $Totalamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $r; ?>][pogst]" id="pogst" value="<?php echo $Gstamt; ?>" class="textbox_small" style="text-align:right;"  required="required" />
	<input type="hidden" name="data[<?php echo $r; ?>][TaxCode]" id="TaxCode" value="<?php echo $TaxCode; ?>" class="textbox_small" style="text-align:right;"  required="required" />
			
			<?php	
			$ir++;	
			}		
		}
			
				
	$it++;
	}
	
	
	?>	
		</table>	
