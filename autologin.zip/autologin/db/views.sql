
CREATE TABLE IF NOT EXISTS `balance_sheets` (
`id` int(11)
,`company_id` int(11)
,`profit_center_id` int(11)
,`account_code_id` int(11)
,`account_code` varchar(9)
,`account_desc` varchar(255)
,`subcode_id` int(11)
,`subcode` varchar(10)
,`subcode_desc` varchar(255)
,`debit` decimal(18,2)
,`credit` decimal(18,2)
,`created` datetime
);



CREATE TABLE IF NOT EXISTS `chart_of_accounts` (
`company_id` int(11)
,`account_code_id` int(11)
,`account_type_id` int(11)
,`code` char(1)
,`code_desc` varchar(45)
,`special_acc` varchar(45)
,`account_code` varchar(9)
,`account_desc` varchar(255)
,`subcode_id` bigint(20)
,`parent` bigint(20)
,`subcode_of` int(11)
,`subcode` varchar(10)
,`subcode_desc` varchar(255)
);


CREATE TABLE IF NOT EXISTS `general_ledgers` (
`id` varchar(259)
,`subcode_id` int(255)
,`profit_center_id` int(255)
,`company_id` int(255)
,`totalamount` double
,`currencycode` varchar(11)
,`currencyrate` varchar(20)
,`unattended_gl_id` bigint(255)
,`project_id` bigint(255)
,`date` date
,`ref` varchar(45)
,`description` varchar(255)
,`debit` decimal(18,2)
,`credit` decimal(18,2)
,`gst` varchar(20)
,`taxcode` varchar(10)
,`status` tinyint(4)
,`created_ip` varchar(20)
,`created` datetime
,`created_by` int(11)
,`modified_ip` varchar(20)
,`modified` datetime
,`modified_by` int(11)
);



CREATE TABLE IF NOT EXISTS `view_cheque` (
  `CheqDate` date DEFAULT NULL,
  `CheqNO` varchar(20) DEFAULT NULL,
  `Payee` varchar(250) DEFAULT NULL,
  `Amount` decimal(18,2) DEFAULT NULL,
  `PVNO` varchar(20) DEFAULT NULL,
  `Description` text,
  `Company_Name` varchar(100) DEFAULT NULL,
  `Bank_Name` varchar(45) DEFAULT NULL,
  `Bank_Branch` varchar(45) DEFAULT NULL,
  `Account_Number` varchar(50) DEFAULT NULL,
  `CheqType` varchar(10) DEFAULT NULL,
  `CompanyID` int(255) DEFAULT NULL,
  `BankID` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `balance_sheets` AS select `opening_balance`.`id` AS `id`,`opening_balance`.`company_id` AS `company_id`,`opening_balance`.`profit_center_id` AS `profit_center_id`,`master_account_codes`.`id` AS `account_code_id`,`master_account_codes`.`account_code` AS `account_code`,`master_account_codes`.`account_desc` AS `account_desc`,`opening_balance`.`subcode_id` AS `subcode_id`,`subcodes`.`code` AS `subcode`,`subcodes`.`description` AS `subcode_desc`,`opening_balance`.`debit` AS `debit`,`opening_balance`.`credit` AS `credit`,`opening_balance`.`created` AS `created` from ((`opening_balance` left join `subcodes` on((`subcodes`.`id` = `opening_balance`.`subcode_id`))) left join `master_account_codes` on((`master_account_codes`.`id` = `subcodes`.`master_account_code_id`)));


CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `chart_of_accounts` AS select `master_account_codes`.`company_id` AS `company_id`,`master_account_codes`.`id` AS `account_code_id`,`accounttype`.`id` AS `account_type_id`,`accounttype`.`code` AS `code`,`accounttype`.`code_desc` AS `code_desc`,`master_account_codes`.`special_acc` AS `special_acc`,`master_account_codes`.`account_code` AS `account_code`,`master_account_codes`.`account_desc` AS `account_desc`,ifnull(`subcodes`.`id`,0) AS `subcode_id`,ifnull(`subcodes`.`subcode_of`,0) AS `parent`,if(((`subcodes`.`subcode_of` = NULL) or (`subcodes`.`subcode_of` = 0)),`subcodes`.`id`,`subcodes`.`subcode_of`) AS `subcode_of`,`subcodes`.`code` AS `subcode`,`subcodes`.`description` AS `subcode_desc` from (((((`master_account_codes` left join `account_types` `accounttype` on((`accounttype`.`id` = `master_account_codes`.`account_type_id`))) left join `subcodes` on((`master_account_codes`.`id` = `subcodes`.`master_account_code_id`))) left join `subcodes` `s1` on((`s1`.`id` = `subcodes`.`subcode_of`))) left join `subcodes` `s2` on((`s2`.`id` = `s1`.`subcode_of`))) left join `subcodes` `s3` on((`s3`.`id` = `s2`.`subcode_of`))) union select `master_account_codes`.`company_id` AS `company_id`,`master_account_codes`.`id` AS `account_code_id`,`accounttype`.`id` AS `account_type_id`,`accounttype`.`code` AS `code`,`accounttype`.`code_desc` AS `code_desc`,`master_account_codes`.`special_acc` AS `special_acc`,`master_account_codes`.`account_code` AS `account_code`,`master_account_codes`.`account_desc` AS `account_desc`,ifnull(`subcodes`.`id`,0) AS `subcode_id`,ifnull(`subcodes`.`subcode_of`,0) AS `parent`,if((`s2`.`id` = 0),`subcodes`.`id`,ifnull(`s2`.`id`,`subcodes`.`id`)) AS `subcode_of`,`subcodes`.`code` AS `subcode`,`subcodes`.`description` AS `subcode_desc` from (((((`master_account_codes` left join `account_types` `accounttype` on((`accounttype`.`id` = `master_account_codes`.`account_type_id`))) left join `subcodes` on((`master_account_codes`.`id` = `subcodes`.`master_account_code_id`))) left join `subcodes` `s1` on((`s1`.`id` = `subcodes`.`subcode_of`))) left join `subcodes` `s2` on((`s2`.`id` = `s1`.`subcode_of`))) left join `subcodes` `s3` on((`s3`.`id` = `s2`.`subcode_of`))) union select `master_account_codes`.`company_id` AS `company_id`,`master_account_codes`.`id` AS `account_code_id`,`accounttype`.`id` AS `account_type_id`,`accounttype`.`code` AS `code`,`accounttype`.`code_desc` AS `code_desc`,`master_account_codes`.`special_acc` AS `special_acc`,`master_account_codes`.`account_code` AS `account_code`,`master_account_codes`.`account_desc` AS `account_desc`,ifnull(`subcodes`.`id`,0) AS `subcode_id`,ifnull(`subcodes`.`subcode_of`,0) AS `parent`,if((`s1`.`id` = 0),`subcodes`.`id`,ifnull(`s1`.`id`,`subcodes`.`id`)) AS `subcode_of`,`subcodes`.`code` AS `subcode`,`subcodes`.`description` AS `subcode_desc` from (((((`master_account_codes` left join `account_types` `accounttype` on((`accounttype`.`id` = `master_account_codes`.`account_type_id`))) left join `subcodes` on((`master_account_codes`.`id` = `subcodes`.`master_account_code_id`))) left join `subcodes` `s1` on((`s1`.`id` = `subcodes`.`subcode_of`))) left join `subcodes` `s2` on((`s2`.`id` = `s1`.`subcode_of`))) left join `subcodes` `s3` on((`s3`.`id` = `s2`.`subcode_of`)));



CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `general_ledgers` AS select concat('agl',`auto_general_ledgers`.`id`) AS `id`,`auto_general_ledgers`.`subcode_id` AS `subcode_id`,`auto_general_ledgers`.`profit_center_id` AS `profit_center_id`,`auto_general_ledgers`.`company_id` AS `company_id`,`auto_general_ledgers`.`totalamount` AS `totalamount`,`auto_general_ledgers`.`currencycode` AS `currencycode`,`auto_general_ledgers`.`currencyrate` AS `currencyrate`,`auto_general_ledgers`.`unattended_gl_id` AS `unattended_gl_id`,`auto_general_ledgers`.`project_id` AS `project_id`,`auto_general_ledgers`.`date` AS `date`,`auto_general_ledgers`.`ref` AS `ref`,`auto_general_ledgers`.`description` AS `description`,`auto_general_ledgers`.`debit` AS `debit`,`auto_general_ledgers`.`credit` AS `credit`,`auto_general_ledgers`.`gst` AS `gst`,`auto_general_ledgers`.`taxcode` AS `taxcode`,`auto_general_ledgers`.`status` AS `status`,`auto_general_ledgers`.`created_ip` AS `created_ip`,`auto_general_ledgers`.`created` AS `created`,`auto_general_ledgers`.`created_by` AS `created_by`,`auto_general_ledgers`.`modified_ip` AS `modified_ip`,`auto_general_ledgers`.`modified` AS `modified`,`auto_general_ledgers`.`modified_by` AS `modified_by` from `auto_general_ledgers` union select concat('je',`journal_entries`.`id`) AS `id`,`journal_entries`.`subcode_id` AS `subcode_id`,`journal_entries`.`profit_center_id` AS `profit_center_id`,`journal_entries`.`company_id` AS `company_id`,`journal_entries`.`totalamount` AS `totalamount`,`journal_entries`.`currencycode` AS `currencycode`,`journal_entries`.`currencyrate` AS `currencyrate`,0 AS `unattended_gl_id`,0 AS `project_id`,`journal_entries`.`date` AS `date`,`journal_entries`.`ref` AS `ref`,`journal_entries`.`memo` AS `description`,`journal_entries`.`debit` AS `debit`,`journal_entries`.`credit` AS `credit`,`journal_entries`.`gst` AS `gst`,`journal_entries`.`taxcode` AS `taxcode`,`journal_entries`.`status` AS `status`,`journal_entries`.`created_ip` AS `created_ip`,`journal_entries`.`created` AS `created`,`journal_entries`.`created_by` AS `created_by`,`journal_entries`.`modified_ip` AS `modified_ip`,`journal_entries`.`modified` AS `modified`,`journal_entries`.`modified_by` AS `modified_by` from `journal_entries` union select concat('fagl',`fixed_asset_gl`.`id`) AS `id`,`fixed_asset_gl`.`subcode_id` AS `subcode_id`,`fixed_asset_gl`.`profit_center_id` AS `profit_center_id`,`fixed_asset_gl`.`company_id` AS `company_id`,`fixed_asset_gl`.`totalamount` AS `totalamount`,`fixed_asset_gl`.`currencycode` AS `currencycode`,`fixed_asset_gl`.`currencyrate` AS `currencyrate`,0 AS `unattended_gl_id`,`fixed_asset_gl`.`project_id` AS `project_id`,`fixed_asset_gl`.`date` AS `date`,`fixed_asset_gl`.`ref` AS `ref`,`fixed_asset_gl`.`description` AS `description`,`fixed_asset_gl`.`debit` AS `debit`,`fixed_asset_gl`.`credit` AS `credit`,`fixed_asset_gl`.`gst` AS `gst`,`fixed_asset_gl`.`taxcode` AS `taxcode`,`fixed_asset_gl`.`status` AS `status`,`fixed_asset_gl`.`created_ip` AS `created_ip`,`fixed_asset_gl`.`created` AS `created`,`fixed_asset_gl`.`created_by` AS `created_by`,`fixed_asset_gl`.`modified_ip` AS `modified_ip`,`fixed_asset_gl`.`modified` AS `modified`,`fixed_asset_gl`.`modified_by` AS `modified_by` from `fixed_asset_gl`;
	
	