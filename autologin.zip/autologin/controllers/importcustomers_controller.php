<?php
  class ImportcustomersController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid']; // company id		
		
						  
	  require_once('views/importcustomers/index.php'); 
	  
    }	
	
	public function create() {    
	  
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
				
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$_GET['cid']."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
	
		if(isset($_POST['submit'])){
		
			$cid 				= 1414; 		
			$created_by 		= $_SESSION['username'];
			$created_ip 		= $_SERVER['REMOTE_ADDR'];
			$created    		= date("Y-m-d H:i:s"); 
			$date 				= date("Y-m-d H:i:s");		
			$currentdate 		= date("Y-m-d");
		
				
																					
			if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
				/*echo "<h1>" . "File ". $_FILES['filename']['name'] ." uploaded successfully." . "</h1>";
				echo "<h2>Displaying contents:</h2>";*/
				readfile($_FILES['filename']['tmp_name']);
			}
			
			
				
																						
			$handle = fopen($_FILES['filename']['tmp_name'], "r");
			
			$subcode_of = 0;
			
			$master_account_codes 	= "";
			$subcodes				= "";
			$account_types			= "";
			
				
			while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
				$str[]                    = $data;								
			}	
			fclose($handle);
		
					//echo "<pre>";print_r($str);	exit;													
			foreach($str as $key=>$val) {
				foreach($val as $kk=>$v) {
				    $ss=explode('~',$v);
					//$master_account_codes 	= $ss[0];
					
					
					
					$date					= $ss[0];
					$str11					= explode('/',$date);
					$day					= $str11[0];
					$month					= $str11[1];
					$year					= $str11[2];
					$sdate					= $year."-".$month."-".$day;
					
					$reference_no			= $ss[1];
					$invno					= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[2]));
					$description			= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[3]));
					$debit					= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[4]));
					$credit					= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[5]));
					$master_account_codes	= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[6]));
					$describe               = addslashes($description);
					$des					= "import";
					if($invno!=''){
						$subtitle = $db->query("select id from subcodes where company_id = '".$cid."' and description ='".$master_account_codes."'");	
						foreach($subtitle->fetchAll() as $sc) {
							/*$sub_account_code = $sc['code'];					
							$sub_description = $sc['description'];		*/	
							$subcodeid   = $sc['id'];
						}
						
						$result_qry = $db->query("insert into journal_entries(subcode_id,company_id,date,deb_crt_date,memo,debit,credit,Gstinvdate,entry_mode,remarks) values ('".$subcodeid."', '".$cid."', '".$sdate."', '".$sdate."', '".$reference_no."', '".$debit."', '".$credit."','".$sdate."','".$des."','".$description."') ");										
						if(!$result_qry){
								die('Invalid query: ' . mysql_error());
						}
						
					}
					
					/*if($subcodes=='Trade Debtors'){
						$master_account_codes = "CURRENT ASSETS";
					}else if($subcodes=='Trade Creditors'){
						$master_account_codes = "CURRENT LIABILITIES";
					}
					
					$mac_id_for_title = 10989;
					$getid  		  = 62223;*/
					
					/*$subtitle = $db->query("select code, description from subcodes where company_id = '".$cid."' and id ='".$getid."'");	
					foreach($subtitle->fetchAll() as $sc) {
						$sub_account_code = $sc['code'];					
						$sub_description = $sc['description'];			
					}	*/
			
			
					/*$char = substr($vendor_name, 0, 1); // first letter from a string	
					
					$acode = substr($sub_account_code, 0, 4);
	  				$acode = "$acode/$char";					
					
					$subcode_foraccount_code = $db->query("select Vendor_account_code from vendor where company_id = '".$cid."' and Vendor_account_code like '%$acode%'  order by Vendor_ID desc limit 1 ");	
					foreach($subcode_foraccount_code->fetchAll() as $sac) {							
						$code_for_vendor = $sac['Vendor_account_code'];		
					}	
						
					if($code_for_vendor!=""){
						$code2 = substr($code_for_vendor, 6, 8);
					  	$code2++;
					 	$code2 = str_pad($code2, 3, '0', STR_PAD_LEFT);
					  	$acc_code = "$acode$code2";
       				} else {
               			$acc_code = "$acode"."001";   	
					}			
								
					$acc_code = strtoupper($acc_code);	*/					
					
					
					//echo "insert into vendor(Vendor_Name, Vendor_account_code, company_id, Business_Regno, GSTRNo, Country_Code, CustTradeTYpe,suppliertype) values ('".$vendor_name."', '".$acc_code."', '".$cid."', '".$business_reg_no."', '".$gst_reg_no."', '".$country."', '".$country_type."','TC') ";exit;
					/*$result = $db->query("insert into vendor(Vendor_Name, Vendor_account_code, company_id, Business_Regno, GSTRNo, Country_Code, CustTradeTYpe,suppliertype) values ('".$vendor_name."', '".$acc_code."', '".$cid."', '".$business_reg_no."', '".$gst_reg_no."', '".$country."', '".$country_type."','TC') ");										
						if(!$result){
								die('Invalid query: ' . mysql_error());
						} 
						
						// insert subcodes 
						$result_qry = $db->query("insert into subcodes(master_account_code_id, code, description, subcode_of, company_id,created_by,created_ip,created,flag) values ('".$mac_id_for_title."', '".$acc_code."', '".$vendor_name."', '".$getid."', '".$cid."', '".$created_by."', '".$created_ip."', '".$created."','1') ");										
						if(!$result_qry){
								die('Invalid query: ' . mysql_error());
						} */
					
							
							
							
							
								/************************ other part end ****************************************/
					} // first step end	
				}
			//}	
			require_once('views/importcustomers/index.php');
			//header("Location:?controller=importcustomers&action=index&cid=".$cid."");	
	
		}	
			
		header("Location: ?controller=importcustomers&action=index&cid=".$cid."");	 
	  
    }		
			

    public function error() {
      require_once('views/importcustomers/error.php');
    }
  }
?>