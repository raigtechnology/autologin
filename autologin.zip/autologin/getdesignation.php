<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		
	
	$department_id = $_GET['department_id']; 
	$branch_id = $_GET['branch_id'];
	$cid = $_GET['cid'];
	?>			
		
		 <select name="designation_id" class="selectbox"  onchange="showemployees(<?php echo $cid; ?>,<?php echo $branch_id; ?>,<?php echo $department_id; ?>,this.value)" >	 
		<option value="">--Select--</option>   
		<?php
		
		$designation = $db->query("SELECT * FROM designation_master where department_id = '".$department_id."' ");							
		foreach($designation->fetchAll() as $dp) {
		
		?>
		    <option value="<?php echo $dp['id']; ?>"><?php echo $dp['designation_name']; ?></option>
        <?php
		
		}	
		?>	
	
