<?php
  class PurchaseinvoiceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    	    
		
		$fromdate = date("Y-m-01");
		$todate = date("Y-m-d");
		$cond ="";
		$invoice_no ="";
		if(isset($_POST['submit'])){		
			
			$invoice_no = $_POST['invoice_no'];
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));				
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-01");
				$todate = date("Y-m-d");
			}					
			
			
			
			if($invoice_no!="" && $fromdate!="1970-01-01" && $todate!="1970-01-01"){
				$cond = " and je.memo = '".$invoice_no."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' "; 			
			} else if($invoice_no=="" && $fromdate!="1970-01-01" && $todate!="1970-01-01"){
				$cond = " and je.date >= '".$fromdate."' AND je.date <= '".$todate."' "; 			
			} else if($invoice_no!="" && $fromdate=="1970-01-01" && $todate=="1970-01-01"){
				$cond = " and je.memo = '".$invoice_no."'  "; 			
			} else {
				$cond ="";
			}
			
		}
		
		
		$journallist = array();
		$journals = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.entry_mode in('Purchase')  group by je.memo  order by je.date,je.memo ");	
		foreach($journals->fetchAll() as $jl) {
			$journallist[] = $jl;
		}  	
						
		$purchaseinvoicelistgroup = array();
		$purchaseinvoicegroup = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.entry_mode = 'Purchase' ".$cond." group by je.memo ");	
		foreach($purchaseinvoicegroup->fetchAll() as $jel) {
			$purchaseinvoicelistgroup[] = $jel;
		}  		
		
		$purchaseinvoicelist = array();
		$purchaseinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code, je.trade_type from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode = 'Purchase' ".$cond." order by je.date, je.memo  ");	
		foreach($purchaseinvoice->fetchAll() as $je) {
			$purchaseinvoicelist[] = $je;
		}  	
						  
	  	require_once('views/purchaseinvoice/index.php'); 
	  
    }		
	
	
	// edit
	public function edit() {   			
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		
		$id = $_GET['id'];
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
				
		$purchaseinvoicelist = array();
		$purchaseinvoice = $db->query("select je.id, je.profit_center_id, je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode = 'Purchase' and je.memo = '".$id."'  ");	
		foreach($purchaseinvoice->fetchAll() as $je) {
			$purchaseinvoicelist[] = $je;
		}  	
						  
		if(isset($_POST['save'])){			
			
			$data = $_POST['data'];		
							
			foreach($data as $dt){	
								
				$profit_center_id	= $dt['profit_center_id'];	
				$debit	= $dt['debit'];
				$credit	= $dt['credit'];
				$jeid	= $dt['id'];
				// update query
				$result = $db->query("update journal_entries set profit_center_id = '".$profit_center_id."', debit = '".$debit."', credit = '".$credit."' where company_id = '".$cid."' and memo = '".$id."' and id = '".$jeid."' ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}				
			}
			
			header("Location: ?controller=purchaseinvoice&action=index&cid=".$cid."");						
					
		} else {	 
		   require_once('views/purchaseinvoice/edit.php'); 	   
		}  
	  
    }		
	
	
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		
		$company = $db->query("select MixedSupply, inv_prefix from companies where id='".$cid."'  ");	
		foreach($company->fetchAll() as $cm) {
			$supply_type = $cm['MixedSupply'];
			$inv_prefix = $cm['inv_prefix'];
		}  	
		
		if($supply_type=="Y"){
			$type = 'MIX';
			$stype = "Mixed";
		} else if($supply_type=="N"){
			$type = 'TAXABLE';
			$stype = "Standard";
		} 
		
		$_SESSION['type'] = $type;
		
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id != '6' order by account_desc asc ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// vendor
		$vendorslist = array();
		$vendors = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='5' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors') order by sc.description asc");	
		foreach($vendors->fetchAll() as $ct) {
			$vendorslist[] = $ct;
		}  	
		
		// sales taxcode master		
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select distinct(MatchCode) from purchasecodematch where supplyType = '".$type."' order by MatchCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		// purchase taxcode master		
		$purchasetaxcodemasterlist = array();
		$purchasetaxcodemaster = $db->query("select TaxCode,TaxRate,id from purtaxcodemaster order by TaxCode");	
		foreach($purchasetaxcodemaster->fetchAll() as $pm) {
			$purchasetaxcodemasterlist[] = $pm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	
		
		
// for currency

		$session_id = $_SESSION['company_id'];		

		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end				
		
		
		// currency
		$currencylist = array();
		$currency = $db->query("select * from currency where company_id='".$com_id."' ");	
		foreach($currency->fetchAll() as $cy) {
			$currencylist[] = $cy;
		}  	
		
					
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
			
		
		if(isset($_POST['save'])){			
						
			$date  				= date("Y-m-d", strtotime($_POST['date']));
			$ref  				= $_POST['ref'];
			//$profit_center_id  	= $_POST['profit_center_id'];
			$vendor_id  		= $_POST['vendor_id'];
			$invoice_no  		= $_POST['invoice_no'];
			$currency_code  	= $_POST['currency_code'];
			$exchange_rate  	= $_POST['exchange_rate'];			
			$totalamount 		= $_POST['totalamt'];	// including gst
			$gst 	 			= $_POST['totalgst'];	
			$invflag 	 		= $_POST['invflag'];	
			$gstinvdate         = $date; 
			
			if($invflag==1){
				$invtype = "REV";
				$purchase_order_no  = "REV";	
				$gstinvdate="";	
			} else {
				$invtype = "Purchase";
				$purchase_order_no  = $_POST['purchase_order_no'];	
			}			
					
			$tblinvmasterpurchase = $db->query("select * from tblinvmaster_purchase order by AutoInvoiceID desc limit 1 ");										
			foreach($tblinvmasterpurchase->fetchAll() as $timp) {			
				$AutoInvoiceID = $timp['AutoInvoiceID'];
			}
									
			if($AutoInvoiceID==""){
				$new_autoinvoice_id= $inv_prefix.'/'.date("d/M/Y").'/'.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);			
			} else {
				$old_autoinvoice_id = $AutoInvoiceID;									
				$currentlastsixdigit = substr($old_autoinvoice_id, -6);		 // last six digit							
				$prefixstring = substr($old_autoinvoice_id, 0, -6);			 // prefix string						
				$newlastsixdigit = str_pad($currentlastsixdigit + 1, 6, 0, STR_PAD_LEFT);						 // new last six digit			
				$new_autoinvoice_id = $prefixstring.''.$newlastsixdigit;	 // new invoice id																																							
			}	
				
			$tblinvmasterpurchase1 = $db->query("select count(*) as total from tblinvmaster_purchase where InvRef='".$new_autoinvoice_id."' ");										
			foreach($tblinvmasterpurchase1->fetchAll() as $timp1) {			
				$total = $timp1['total'];
			}	
				
			if($total>0){
				$new_invoice_no = $inv_prefix.'/'.date("d/M/Y").'/'.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);	
			} else {
				$new_invoice_no = $invoice_no;
			}	
				
					
			// master purchase data start
			$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$vendor_id."' ");
			foreach($subcodes->fetchAll() as $scs){
				$vendorname 	= $scs['description'];
				$subcode_of 	= $scs['subcode_of'];	
				$account_code 	= $scs['code'];			
			}
			
			$newAutoInvoiceID   = $new_autoinvoice_id;
			$InvRef 			= $new_invoice_no;
			$PORef 				= "DIN";
			$InvDate 			= date("d/m/Y", strtotime($date));
			$company_id 		= $cid;			
			$VendorName 		= $vendorname;
			$vendorID 			= $vendor_id;
			$Currencycode 		= $currency_code;
			$Currencyrate 		= $exchange_rate;		
			
			
			// for op taxcode
			$TaxCode			= $_POST['data'][0]['matchcode'];
				
			if($TaxCode=="OP"){
				$gstdate = $InvDate;
				//$gstdate ="";
				//$entry = "Reverse Charge";
				$entry = "Purchase";
				$status = '';
			//	$gstinvdate="";
				
			} else if($TaxCode=="IMS" || $TaxCode=="ISS"){
				$gstdate ="";
				$entry = "Imported Goods";
				$status = 'im';
				$gstinvdate="";
				
				if($TaxCode=="IMS"){
					$TaxCode=="IMS";
				} else if($TaxCode=="ISS"){
					$TaxCode=="ISS";
				}
				
								
				
			} else {
				$gstdate = $InvDate;
				$entry = "Purchase";
				$status = '';
				$gstinvdate = $date;
			}	
				
			
					
			$masterpurchasedata = $db->query("insert into  tblinvmaster_purchase(`AutoInvoiceID`,`InvRef`,`PORef`,`InvDate`,`company_id`,`VendorName`,`Currencycode`,`Currencyrate`,`vendorID`,`TaxCode`,`Gstinvdate`) values('".$newAutoInvoiceID."','".$InvRef."','".$PORef."','".$InvDate."','".$company_id."','".$VendorName."','".$Currencycode."','".$Currencyrate."','".$vendorID."','".$TaxCode."','".$gstdate."')");	
						
			if(!$masterpurchasedata){
				die('Invalid query: ' . mysql_error());
			}		
			
			
			// PROFIT CENTER CODE
			$pcenter = $db->query("select profit_center_code from profit_centers where company_id ='".$cid."' ");
			foreach($pcenter->fetchAll() as $pc){
				$profit_center_code 	= $pc['profit_center_code'];				
			}	
					
			// master purchase data end
			
			// journal entries start
			
			$subcode_id   			= $vendor_id;
			//$profit_center_id 		= $profit_center_id;
			$company_id 			= $cid;
			$date 					= date("Y-m-d", strtotime($date));
			$ref 					= $ref;			
			//$memo 					= $invoice_no;			
			$credit 				= $totalamount;		
			$gst 					= $gst;		
			$subcode_of 			= $subcode_of;	
			$entry_mode 			= $entry;		
		
			/*if($TaxCode=="IM" || $TaxCode=="IS"){
				$taxcode = "IM";
			} else {
				$taxocde = "";
			}*/
			$taxocde = "";			
			// taxcode	
			$price=0;
			
			foreach($_POST['data'] as $rdt){
				$price += $rdt['quantity'] * $rdt['unit_price'];
			}
			
	//if($invflag==0){		
					
			$pfcenter = $db->query("select id from profit_centers where flag='1' and company_id ='".$cid."' ");
			foreach($pfcenter->fetchAll() as $pf){
				$pfid 	= $pf['id'];				
			}			
				
			if($entry=="Reverse Charge"){
				$taxcode = "OP";
			}		
								
			$purchasemasterjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`subcode_of`,`entry_mode`,`totalamount`,`currencycode`,`currencyrate`,`taxcode`,`trade_type`,`status`,`Gstinvdate`) values('".$subcode_id."','".$pfid."','".$company_id."','".$date."','".$ref."','".$InvRef."','".$credit."','".$gst."','".$subcode_of."','".$entry_mode."','".$price."','".$Currencycode."','".$Currencyrate."','".$taxocde."','Trade Creditors','".$status."','".$gstinvdate."')");
			
			if(!$purchasemasterjournaldata){
				die('Invalid query: ' . mysql_error());
			}	
	//}		
			
			// for vendor id
			$tblvendor = $db->query("select Vendor_ID from vendor where Vendor_Name = (select description from subcodes where company_id ='".$cid."' and id='".$vendor_id."' ) and company_id = '".$cid."' ");
			foreach($tblvendor->fetchAll() as $vd){
				$CustID 	= $vd['Vendor_ID'];				
			}			
						
			// for cheqwriter
			$tblinvoiceinoutdata = $db->query("insert into tblinvoiceinout(`InvType`,`CustID`,`InvNo`,`InvAmt`,`InvDate`,`DueDate`,`company_id`,`Acc_description`) values('".$invtype."','".$CustID."','".$new_invoice_no."','".$credit."','".$date."','".$date."','".$company_id."','Invoicein')");
			
			if(!$tblinvoiceinoutdata){
				die('Invalid query: ' . mysql_error());
			}	
			
			
			// journal entries end
			
			// gst bad debt entries start
			
			$account_code  			= $account_code;	
			$gstdate 				= date("Y-m-d", strtotime($date));		
			//$description 			= $invoice_no;			
			$ref 					= $ref;			
			$credit 				= $totalamount;		
			$credit_gst 			= $gst;		
			$trade_type 			= "Trade Creditors";	
			$company_id 			= $cid;
			
			$gstbaddebtdata = $db->query("insert into gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`credit`,`credit_gst`,`trade_type`,`company_id`) values('".$account_code."','".$gstdate."','".$new_invoice_no."','".$ref."','".$credit."','".$credit_gst."','".$trade_type."','".$company_id."')");
			
			if(!$gstbaddebtdata){
				die('Invalid query: ' . mysql_error());
			}	
			// gst bad debt entries end		
					
					
			$data = $_POST['data'];
				
			foreach($data as $dt){
										
				$productdescription = $db->query("select description, subcode_of from subcodes where id = '".$dt['subcode_id']."' and company_id='".$cid."' ");
				foreach($productdescription->fetchAll() as $pds){
					$product_desc 			= $pds['description'];
					$product_subcode_of 	= $pds['subcode_of'];						
				}
				
							
				//$autoinvoiceid 			= $newAutoInvoiceID;
				$subcode_id				= $dt['subcode_id'];
				$product_desc 			= $product_desc;
				$quanity 				= $dt['quantity'];
				$unit_price 			= $dt['unit_price'];
				$total_amount 			= $dt['total_amount'];
				//$taxcode_purchased 		= $dt['taxcode'];
				$taxcode_purchased 		= 0;
				$taxcode_matched 		= $dt['matchcode'];
				$gst_amount 			= $dt['gst'];
				$gst_eer 				= $dt['gst_err'];	// gst exclude exchange rate
				$entry_mode 			= "Purchase";			
				$company_id 			= $cid;	
										
				$totalunitprice			= $quanity * $unit_price;
				
				if($taxcode_matched=="IMS"){
					$taxcode_matched = "IMS";
					$taxcode_matched2 = "IM";
				} else if($taxcode_matched=="ISS"){
					$taxcode_matched = "ISS";			
					$taxcode_matched2 = "IS";				
				}
								
											
				if($totalunitprice>0){
				
					//$totamt = $total_amount - $gst_eer;
				
					$productpurchasedata = $db->query("insert into  tblinvproduct_purchase(`AutoInvoiceID`,`ProductDesc`,`Quantity`,`UnitPrice`,`totalunitprice`,`Totalamt`,`TaxCodePurchase`,`TaxCodeMatched`,`GSTamt`,`entry_mode`,`company_id`,`subcode_id`) values('".$newAutoInvoiceID."','".$product_desc."','".$quanity."','".$unit_price."','".$totalunitprice."','".$total_amount."','".$taxcode_purchased."','".$taxcode_matched."','".$gst_eer."','".$entry_mode."','".$company_id."','".$subcode_id."')");
					
					if(!$productpurchasedata){
						die('Invalid query: ' . mysql_error());
					}	
					
					// journal entries start
			
					$pd_subcode_id   			= $subcode_id;
					$pd_profit_center_id 		= $dt['profit_center_id'];
					$pd_company_id 				= $cid;
					$pd_date 					= date("Y-m-d", strtotime($date));
					$pd_ref 					= $ref;			
					//$pd_memo 					= $invoice_no;			
					$pd_debit 					= $total_amount - $gst_amount;		
					$pd_gst 					= $gst_amount;		
					$pd_subcode_of 				= $product_subcode_of;	
					$pd_entry_mode 				= $entry;		
		
			//if($invflag==0){		
					
					$productpurchasejournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`subcode_of`,`entry_mode`,`taxcode`,`status`,`Gstinvdate`) values('".$pd_subcode_id."','".$pd_profit_center_id."','".$pd_company_id."','".$pd_date."','".$pd_ref."','".$InvRef."','".$pd_debit."','".$pd_gst."','".$pd_subcode_of."','".$pd_entry_mode."','".$taxcode_matched2."','".$status."','".$gstinvdate."')");
					
					if(!$productpurchasejournaldata){
						die('Invalid query: ' . mysql_error());
					}	
					
					
					// PROFIT CENTER CODE
					$paccountno = $db->query("select code from subcodes where company_id ='".$cid."' and id='".$pd_subcode_id."' ");
					foreach($paccountno->fetchAll() as $acc){
						$pd_account_code 	= $acc['code'];				
					}	
					
					// for profit center list
					$profitcenterlist = $db->query("insert into profit_centers_list(`company_id`,`pf_center_code`,`pf_invoiceno`,`Pf_amount`,`pf_ispaid`,`Pf_AccNo`) values('".$company_id."','".$profit_center_code."','".$new_autoinvoice_id."','".$pd_debit."','N','".$pd_account_code."')");	
								
					if(!$profitcenterlist){
						die('Invalid query: ' . mysql_error());
					}		
			
			
					
					
					
		//	}		
					// journal entries end
				}
											
			}
			
			// gst output tax
			
			if($gst>0){
			
				$inputtaxdata = $db->query("select id from subcodes where description = 'GST-INPUT-TAX' and company_id='".$cid."' ");
				foreach($inputtaxdata->fetchAll() as $ot){
					$inputtax_id 			= $ot['id'];									
				}			
				
				$outputtaxjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`entry_mode`,`Gstinvdate`) values('".$inputtax_id."','".$pd_profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_invoice_no."','".$gst."','".$gst."','".$entry_mode."','".$date."')");
				
				if(!$outputtaxjournaldata){
					die('Invalid query: ' . mysql_error());
				}		
			
			}	
						
			header("Location: ?controller=purchaseinvoice&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/purchaseinvoice/create.php'); 	   
		}  
	  
    }		
	

    public function error() {
      require_once('views/purchaseinvoice/error.php');
    }
  }
?>