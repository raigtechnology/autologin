<?php
  class gstbaddebtpurchaseadjustment {
   
  }
?>