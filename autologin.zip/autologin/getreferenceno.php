<?php session_start();	?>	
<input type="text" name="reference_no" id="reference_no" value="" required="required" />
							