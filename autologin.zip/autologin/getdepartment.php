<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		
	
	$branch_id = $_GET['branch_id']; 
	$cid = $_GET['cid']; 
	
	$departments = $db->query("SELECT * FROM department_master where branch_id = '".$branch_id."' and company_id='".$cid."' ");				
	?>			
		
		<select name="department_id" class="selectbox"  onchange="showdesignation(this.value,<?php echo $branch_id; ?>,<?php echo $cid; ?>)">
		<option value="">--Select--</option>   
		<?php		
					
		foreach($departments->fetchAll() as $dp) {
		
		?>
		    <option value="<?php echo $dp['id']; ?>"><?php echo $dp['department_name']; ?></option>
        <?php
		
		}	
		?>	
		</select>
	
