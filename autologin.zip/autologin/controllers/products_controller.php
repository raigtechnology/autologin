<?php
  class ProductsController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		
		require_once('views/products/index.php'); 
	  
    }		
		

    public function error() {
      require_once('views/products/error.php');
    }
  }
?>