<?php
  class ListofexpensesController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$date = date("Y-m-t");
		
		if(isset($_POST['submit'])){
				
			$date = date("Y-m-d", strtotime($_POST['date']));			
				
			if(empty($date)){
				$date = date("Y-m-d");			
			}				
		
		}	
		
		$listofexpenseslist = array();		
		$listofexpenses = $db->query("select 
											sc.id,
											sc.code,
											sc.description,
											sc.subcode_of											
										from subcodes as sc
											left join master_account_codes as mac on mac.id = sc.master_account_code_id
										where mac.account_type_id = 12 and mac.company_id = '".$cid."' and sc.company_id='".$cid."'
											group by sc.id 
										");		
		foreach($listofexpenses->fetchAll() as $loe) {
			$listofexpenseslist[] = $loe;
		}  		
			
		
					
						  
	  require_once('views/listofexpenses/index.php'); 
	  
    }	
	
	
	public function view() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		$id = $_GET['id']; 
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$fromdate = $_GET['fromdate']; 
		$todate   = $_GET['todate']; 
		
		$listofexpenseslist = array();
		
		$listofexpenses = $db->query("select 
											sc.id,
											sc.code,
											sc.description,
											sc.subcode_of											
										from subcodes as sc
											left join master_account_codes as mac on mac.id = sc.master_account_code_id
										where mac.account_type_id = 12 and sc.id='".$id."' and mac.company_id = '".$cid."' and sc.company_id='".$cid."'
											group by sc.id 
										");		
		foreach($listofexpenses->fetchAll() as $loe) {
			$listofexpenseslist[] = $loe;
		}  		
			
		
					
						  
	  require_once('views/listofexpenses/view.php'); 
	  
    }	
		

    public function error() {
      require_once('views/listofexpenses/error.php');
    }
  }
  

?>