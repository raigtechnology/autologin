<?php
  class gafreport {
   
  }
?>