<?php
  class simplifiedinvoice {
   
  }
?>