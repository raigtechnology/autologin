<?php
  class GstgeneralledgerController {
  
  
  
	public function index() {      
		
		error_reporting(E_ALL ^ E_NOTICE);
		
			
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$fromdate = date("Y-01-01");
		$todate = date("Y-m-t");
		
		if(isset($_POST['submit'])){
				
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));				
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-d");
				$todate = date("Y-m-t");
			}				
		
		}	    
						
		
		$subcodesList1 = $db->query("select id, description, code, master_account_code_id, subcode_of from subcodes where company_id=".$cid." order by code ");				
		foreach($subcodesList1->fetchAll() as $sclist) {
				
			if($sclist['description']=="Trade Debtors"){
				$debtor_id = $sclist['id'];
			} 
			if($sclist['description']=="Trade Creditors"){
				$creditor_id = $sclist['id'];
			} 
		}		
				
		
		$master_account_codes1 = $db->query("select id as mid, account_desc from master_account_codes where company_id=".$cid." order by account_code");				
		
		foreach($master_account_codes1->fetchAll() as $maclist) {
			
			if($maclist['account_desc']=="CURRENT ASSETS"){
				$currentassetid = $maclist['mid'];
			} 
			if($maclist['account_desc']=="CURRENT LIABILITIES"){
				$currentliabilitiesid = $maclist['mid'];
			} 
			
		}		
		
		
		$subcodesList = array();		
		$subcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$currentliabilitiesid."'
									and sc.subcode_of in (select id from subcodes where description ='GST-OUTPUT-TAX')
								order by sc.code asc");	
									
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		}	
		
		
		// for purchase
		$psubcodesList = array();		
		$psubcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$currentliabilitiesid."'
									and sc.subcode_of in (select id from subcodes where description ='GST-INPUT-TAX')
								order by sc.code asc");	
									
		foreach($psubcodes->fetchAll() as $psc) {
			$psubcodesList[] = $psc;
		}	
		
						
		// for sales tax codes
		$salestaxlist = array();
		$salestax = $db->query("select je.memo, je.debit, je.credit, je.gst, je.taxcode, je.date from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." and je.taxcode!='' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' order by je.memo,je.date ");
		
		foreach($salestax->fetchAll() as $st) {
			$salestaxlist[] = $st;
		}	
		
	
		
		// for purchase tax codes
		$purchasetaxlist = array();
		$purchasetax = $db->query("select je.memo, je.debit, je.credit, je.gst, je.taxcode, je.date from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." and je.date >= '".$fromdate."' AND je.date <= '".$todate."' order by je.memo,je.date ");
		
		foreach($purchasetax->fetchAll() as $pt) {
			$purchasetaxlist[] = $pt;
		}	
		
		
	
				
		
		// end	
		
					  
	  require_once('views/gstgeneralledger/index.php'); 
	  
    }		
	
	public function searchItemsByKey($array, $key)
	{
	
	   $results = array();
	
	  if (is_array($array))
	  {
		if (isset($array[$key]) && key($array)==$key)
			$results[] = $array[$key];
	
		foreach ($array as $sub_array)
			$results = array_merge($results, $this->searchItemsByKey($sub_array, $key));
	  }	  
	
	 return  $results;
	}
	

    public function error() {
      require_once('views/gstgeneralledger/error.php');
    }
  }
?>
