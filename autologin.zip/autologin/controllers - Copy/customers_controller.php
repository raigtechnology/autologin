<?php
  class CustomersController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){			
			header("Location: ?controller=users&action=index");		
		}		
		
		if($_SESSION['username']!="krishnaveni"){
		
			header("Location: ?controller=users&action=index");		
		
		} else {
		
			$db = Db::getInstance();		    
					
			$cid = $_GET['cid']; // companyid
			
			$customerslist = array();				
			$customers = $db->query("select * from registrations order by registered_date desc");	
			foreach($customers->fetchAll() as $cl) {
				$customerslist[] = $cl;
			}  		
						  
			require_once('views/customers/index.php'); 
		
		} 
	  
    }	
	
	

    public function error() {
      require_once('views/customers/error.php');
    }
  }
?>