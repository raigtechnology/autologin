<?php
  class Consolidatedledgerbalance{
   
  }
?>