<?php
  class ImportcustomersController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid']; // company id		
		
						  
	  require_once('views/importcustomers/index.php'); 
	  
    }	
	
	public function create() {    
	  
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
				
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$_GET['cid']."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
	
		if(isset($_POST['submit'])){
		
			$cid 				= $_POST['cid']; 		
			$created_by 		= $_SESSION['username'];
			$created_ip 		= $_SERVER['REMOTE_ADDR'];
			$created    		= date("Y-m-d H:i:s"); 
			$date 				= date("Y-m-d H:i:s");		
			$currentdate 		= date("Y-m-d");
		
				
																					
			if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
				/*echo "<h1>" . "File ". $_FILES['filename']['name'] ." uploaded successfully." . "</h1>";
				echo "<h2>Displaying contents:</h2>";*/
				readfile($_FILES['filename']['tmp_name']);
			}
			
			
				
																						
			$handle = fopen($_FILES['filename']['tmp_name'], "r");
			
			$subcode_of = 0;
			
			$master_account_codes 	= "";
			$subcodes				= "";
			$account_types			= "";
			
				
			while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
				$str[]                    = $data;								
			}	
			fclose($handle);
		
																			
			foreach($str as $key=>$val) {
				foreach($val as $kk=>$v) {
				    $ss=explode('~',$v);
					//$master_account_codes 	= $ss[0];
					
					$account_types			= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[0]));
					/*$gst_reg_no				= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[1]));
					$country				= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[2]));
					$business_reg_no		= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[3]));*/
					$address11				= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[1]));
					$address22				= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[2]));
					$address3				= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[3]));
					$address4				= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[4]));
					/*$email					= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[6]));*/
					$telephone				= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[5]));
					$faxno				    = preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[6]));	
					$subcodes				= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[7]));
					
					$address1 = $address11.','.$address22.','.$address3.','.$address4;
					$address2 = $address11.','.$address22.','.$address3.','.$address4;
					if($subcodes=='Trade Debtors'){
						$master_account_codes = "CURRENT ASSETS";
					}else if($subcodes=='Trade Creditors'){
						$master_account_codes = "CURRENT LIABILITIES";
					}
					if($account_types!=""){	 // first step start
						
						$master_account_types = $db->query("select id, account_code from master_account_codes where company_id='".$cid."' and account_desc LIKE '".$master_account_codes."' ");		
						foreach($master_account_types->fetchAll() as $mac) {						
							$master_account_code_id 	= $mac['id'];
						 	$master_account_code 		= $mac['account_code'];	
						}		
											
					if($subcodes=="Trade Debtors"){    // customers
								
									$subcode_of=0;
									$debtorscodes = $db->query("select id from subcodes where company_id='".$cid."' and description='Trade Debtors'");	
									foreach($debtorscodes->fetchAll() as $dt) {																	
										$subcode_of = $dt['id'];
									} 
							
									$subtitle = $db->query("select code, description from subcodes where company_id = '".$cid."' and id ='".$subcode_of."'");	
									foreach($subtitle->fetchAll() as $sc) {															
										$sub_account_code 	= $sc['code'];					

										$sub_description 	= $sc['description'];	
									} 
								
									$customer_name				= $account_types;		
									$char = substr($customer_name, 0, 1); // first letter from a string						
															
									// generating autocustomer id
									$subcode_for_autocustomerid = $db->query("select AutoCustomerID from tblcustomer order by id desc limit 1 ");	
									foreach($subcode_for_autocustomerid->fetchAll() as $aui) {															
										$tblcustomer_autocustomerid = $aui['AutoCustomerID'];
									} 
															
									if($tblcustomer_autocustomerid!=""){
										$customercode = substr($tblcustomer_autocustomerid, 1, 7);
										$customercode++;
										$customercode = str_pad($customercode, 7, '0', STR_PAD_LEFT);
										$customercode = "C".$customercode;
									  
									} else {
										$customercode = "C0000001";   	
									}			
												
									$customercode = strtoupper($customercode);	
							
									// generating autocustomer id end
								
								
									// generating account code for vendor from vendor name					
									$acode = substr($sub_account_code, 0, 4);
									$acode = "$acode/$char";					
																	
									$subcode_foraccount_code = $db->query("select Customer_account_code from tblcustomer where company_id = '".$cid."' and Customer_account_code like '%$acode%'  order by AutoCustomerID desc limit 1 ");	
									foreach($subcode_foraccount_code->fetchAll() as $sac) {														
										$code_for_customer = $sac['Customer_account_code'];
									} 
															
									if($code_for_customer!=""){
										$code2 = substr($code_for_customer, 6, 8);
										$code2++;
										$code2 = str_pad($code2, 3, '0', STR_PAD_LEFT);
										$acc_code = "$acode$code2";
									} else {
										$acc_code = "$acode"."001";   	
									}			
												
									$acc_code = strtoupper($acc_code);						
									// end of generating account code for vendor from vendor name
												
									
									if($country=="MALAYSIA"){
										$country_type = "LOCAL";
									} else {
										$country_type = "FOREIGN";
									}
									
																		
									$db->query("insert into tblcustomer(AutoCustomerID, Customercode, CompanyName, Customer_account_code, company_id, Business_Regno, GSTRNo, Country_code, Status, CustTradeTYpe,AddressLine1,AddressLine2,Emailaddress,Telno,Faxno) values ('".$customercode."', '".$customercode."', '".$customer_name."', '".$acc_code."', '".$cid."', '".$business_reg_no."', '".$gst_reg_no."', '".$country."', 'A', '".$country_type."','".$address1."','".$address2."','".$email."','".$telephone."','".$faxno."') ");						
																
														
									$db->query("insert into subcodes(company_id, code, description, master_account_code_id, subcode_of, created_by, created_ip, created) values ('".$cid."', '".$acc_code."', '".$account_types."', '".$master_account_code_id."', '".$subcode_of."', '".$created_by."', '".$created_ip."', '".$created."') ");	
																
							
							}else if($subcodes=="Trade Creditors"){  //     vendor table
								
																
								$subcode_of=0;
								$creditorscodes = $db->query("select id from subcodes where company_id='".$cid."' and description='Trade Creditors' and master_account_code_id='".$master_account_code_id."' ");	
								foreach($creditorscodes->fetchAll() as $ct) {																
									$subcode_of = $ct['id'];
								} 
								
									
								$subtitle = $db->query("select code, description from subcodes where company_id = '".$cid."' and id ='".$subcode_of."'");	
								foreach($subtitle->fetchAll() as $sc) {																
									$sub_account_code 	= $sc['code'];					
									$sub_description 	= $sc['description'];	
								} 
										
								$vendor_name	= $account_types;
								$char 			= substr($vendor_name, 0, 1); // first letter from a string						
														
								// generating account code for vendor from vendor name
									
								$acode = substr($sub_account_code, 0, 4);
								$acode = "$acode/$char";					
									
								$subcode_foraccount_code = $db->query("select Vendor_account_code from vendor where company_id = '".$cid."' and Vendor_account_code like '%$acode%'  order by Vendor_ID desc limit 1 ");	
								foreach($subcode_foraccount_code->fetchAll() as $sac) {																			
									$code_for_vendor = $sac['Vendor_account_code'];	
								} 
										
								if($code_for_vendor!=""){
									$code2 = substr($code_for_vendor, 6, 8);
									$code2++;
									$code2 = str_pad($code2, 3, '0', STR_PAD_LEFT);
									$acc_code = "$acode$code2";
								} else {
									$acc_code = "$acode"."001";   	
								}			
												
								$acc_code = strtoupper($acc_code);						
								// end of generating account code for vendor from vendor name
														
								if($country=="MALAYSIA"){
									$country_type = "LOCAL";
								} else {
									$country_type = "FOREIGN";
								}
									
								$db->query("insert into vendor(Vendor_Name, Vendor_account_code, company_id, Business_Regno, GSTRNo, Country_Code, CustTradeTYpe,AddressLine1,AddressLine2,Emailaddress,Telno,Faxno) values ('".$vendor_name."', '".$acc_code."', '".$cid."', '".$business_reg_no."', '".$gst_reg_no."', '".$country."', '".$country_type."','".$address1."','".$address2."','".$email."','".$telephone."','".$faxno."') ");										
																
								$db->query("insert into subcodes(company_id, code, description, master_account_code_id, subcode_of, created_by, created_ip, created) values ('".$cid."', '".$acc_code."', '".$account_types."', '".$master_account_code_id."', '".$subcode_of."', '".$created_by."', '".$created_ip."', '".$created."') ");	
								
							
							}
							
							
							
							
								/************************ other part end ****************************************/
					} // first step end	
				}
			}	
			require_once('views/importcustomers/index.php');
			//header("Location:?controller=importcustomers&action=index&cid=".$cid."");	
	
		}	
			
		header("Location: ?controller=importcustomers&action=index&cid=".$cid."");	 
	  
    }		
			

    public function error() {
      require_once('views/importcustomers/error.php');
    }
  }
?>