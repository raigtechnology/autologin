<?php
  class Fixedassetopeningbalance {
   
  }
?>