<?php
  class importedgoods {
   
  }
?>