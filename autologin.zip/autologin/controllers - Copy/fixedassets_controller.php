<?php
  class FixedassetsController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    	    
						
		$fixedassetslist = array();
		$fixedassets = $db->query("select fa.id, fa.date_of_purchase, fa.disposed, fa.depriciation_value, fa.no_of_years,fa.fixed_asset_value, fa.deposit_paid, fa.total_outstanding_amount, fa.interest, fa.total_payable, fa.depriciation, sc.code, pc.profit_center_code from fixed_assets as fa left join subcodes as sc on sc.id = fa.subcode_id  left join profit_centers as pc on pc.id = fa.profit_center_id where fa.company_id='".$cid."' and sc.company_id='".$cid."' order by fa.date_of_purchase");	
		foreach($fixedassets->fetchAll() as $fa) {
			$fixedassetslist[] = $fa;
		}  	
	
	  require_once('views/fixedassets/index.php'); 
	  
    }		
	
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id = '6' order by account_desc asc ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// fixed assets
		$fixedassetlist = array();
		$fixedasset = $db->query("select sc.id, sc.description from subcodes as sc left join master_account_codes as mac on mac.id=sc.master_account_code_id  where sc.company_id='".$cid."' and mac.account_type_id='4' order by sc.description asc ");	
		foreach($fixedasset->fetchAll() as $fa) {
			$fixedassetlist[] = $fa;
		}  
		
		// current assets
		$currentassetlist = array();
		$currentasset = $db->query("select sc.id, sc.description from subcodes as sc left join master_account_codes as mac on mac.id=sc.master_account_code_id  where sc.company_id='".$cid."' and mac.account_type_id='13' order by sc.description asc ");	
		foreach($currentasset->fetchAll() as $ca) {
			$currentassetlist[] = $ca;
		}  
		
		// long term liabilities
		$longtermliabilitieslist = array();
		$longtermliabilities = $db->query("select sc.id, sc.description from subcodes as sc left join master_account_codes as mac on mac.id=sc.master_account_code_id  where sc.company_id='".$cid."' and mac.account_type_id='3' order by sc.description asc ");	
		foreach($longtermliabilities->fetchAll() as $ltl) {
			$longtermliabilitieslist[] = $ltl;
		}  
		
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		// sales taxcode master		
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select TaxCode,TaxRate,id from salestaxcodemaster order by TaxCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		
		
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	
					
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
					
		
		if(isset($_POST['save'])){			
						
			$date_of_purchase			= date("Y-m-d", strtotime($_POST['date']));			
			$profit_center_id  			= $_POST['profit_center_id'];
			$document_no  				= $_POST['document_no'];
			$no_of_years  				= $_POST['no_of_years'];
			$fixed_asset_id		  		= $_POST['fixed_asset_id'];
			$current_asset_id  			= $_POST['current_asset_id'];
			$long_term_liabilities_id  	= $_POST['long_term_liabilities_id'];
			$fixed_asset_value  		= $_POST['fixed_asset_value'];	
			$deposit_paid 				= $_POST['deposit_paid'];	// including gst
			$total_outstanding_amount 	= $_POST['total_outstanding_amount'];	
			$interest_percent 	 		= $_POST['interest_percent'];
			$interest 	 				= $_POST['interest'];
			$total_payable 	 			= $_POST['total_payable'];
			$depriciation 	 			= $_POST['depriciation'];
			$depriciation_value 	 	= $_POST['depriciation_value'];
			
														
			$fixedassets = $db->query("insert into  fixed_assets(`company_id`,`date_of_purchase`,`profit_center_id`,`subcode_id`,`fixed_asset_value`,`deposit_paid`,`total_outstanding_amount`,`interest_percent`,`interest`,`total_payable`,`depriciation`,`no_of_years`) values('".$cid."','".$date_of_purchase."','".$profit_center_id."','".$fixed_asset_id."','".$fixed_asset_value."','".$deposit_paid."','".$total_outstanding_amount."','".$interest_percent."','".$interest."','".$total_payable."','".$depriciation."','".$no_of_years."')");
			
			if(!$fixedassets){
				die('Invalid query: ' . mysql_error());
			}		
			
						
	/*********************** DEPOSIT *****************************/		
			
			$depositdata_debit = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`) values('".$fixed_asset_id."','".$profit_center_id."','".$cid."','".$date_of_purchase."','fixed asset deposit','".$document_no."','".$fixed_asset_value."','fixed asset deposit')");
			
			if(!$depositdata_debit){
				die('Invalid query: ' . mysql_error());
			}	
			
			$depositdata_credit1 = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`) values('".$current_asset_id."','".$profit_center_id."','".$cid."','".$date_of_purchase."','fixed asset deposit debit','".$document_no."','".$deposit_paid."','fixed asset deposit')");
			
			if(!$depositdata_credit1){
				die('Invalid query: ' . mysql_error());
			}	
			
			$depositdata_credit2 = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`) values('".$long_term_liabilities_id."','".$profit_center_id."','".$cid."','".$date_of_purchase."','fixed asset deposit credit','".$document_no."','".$total_outstanding_amount."','fixed asset deposit')");
			
			if(!$depositdata_credit2){
				die('Invalid query: ' . mysql_error());
			}	
			
		/*********************** INTEREST *****************************/
		
			$intersetsuspense = $db->query("select id from subcodes where company_id='".$cid."' and description='interest in suspense' ");	
			foreach($intersetsuspense->fetchAll() as $is) {
				$interest_suspense_id = $is['id'];
			}  			
		
			$interestdata_debit = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`) values('".$interest_suspense_id."','".$profit_center_id."','".$cid."','".$date_of_purchase."','fixed asset interest debit','".$document_no."','".$interest."','fixed asset interest')");
			
			if(!$interestdata_debit){
				die('Invalid query: ' . mysql_error());
			}	
			
			$interestdata_credit = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`) values('".$long_term_liabilities_id."','".$profit_center_id."','".$cid."','".$date_of_purchase."','fixed asset interest credit','".$document_no."','".$interest."','fixed asset interest')");
			
			if(!$interestdata_credit){
				die('Invalid query: ' . mysql_error());
			}	
		
		/*********************** DEPRECIATION *****************************/
		
			$expenses = $db->query("select id from subcodes where company_id='".$cid."' and description='Depreciation' ");	
			foreach($expenses->fetchAll() as $is) {
				$expense_id = $is['id'];
			}  
			
			$fixedasset_depreciation = $db->query("select id from subcodes where company_id='".$cid."' and subcode_of='".$fixed_asset_id."' ");	
			foreach($fixedasset_depreciation->fetchAll() as $fad) {
				$pd_depreciation_id = $fad['id'];
			}  
						
		
			$depreciationdata_debit = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`) values('".$expense_id."','".$profit_center_id."','".$cid."','".$date_of_purchase."','fixed asset depreciation debit','".$document_no."','".$depriciation_value."','fixed asset depreciation')");
			
			if(!$depreciationdata_debit){
				die('Invalid query: ' . mysql_error());
			}	
			
			$depreciationdata_credit = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`) values('".$pd_depreciation_id."','".$profit_center_id."','".$cid."','".$date_of_purchase."','fixed asset depreciation credit','".$document_no."','".$depriciation_value."','fixed asset depreciation')");
			
			if(!$depreciationdata_credit){
				die('Invalid query: ' . mysql_error());
			}	
		
			
						
			header("Location: ?controller=fixedassets&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/fixedassets/create.php'); 	   
		}  
	  
    }		
	
	
	// FIXED asset disposal
	public function dispose() {
	
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		$id = $_GET['id']; // fixed asset id
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id = '4' ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		// sales taxcode master		
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select TaxCode,TaxRate,id from salestaxcodemaster order by TaxCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		
		
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	
					
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
		
		// profit center
		
		$fixedassets = $db->query("select profit_center_id from fixed_assets where company_id='".$cid."' and id='".$id."' ");	
		foreach($fixedassets->fetchAll() as $fa) {
			$profit_center_id = $fa['profit_center_id'];
		}  	
		
				
		if(isset($_POST['save'])){			
						
			$date  				= date("Y-m-d", strtotime($_POST['date']));
			$ref  				= 'dispose';
			$profit_center_id  	= $profit_center_id;
			$customer_id  		= $_POST['customer_id'];
			$currency_code  	= 'RM';
			$exchange_rate  	= 1;
			$purchase_order_no  = 'Fixed Assets';	
			$amount 			= $_POST['amount'];	// without gst
			$totalamount 		= $_POST['total_amount'];	// including gst
			$gst 	 			= $_POST['gst'];	
			$subcode_id  		= $_POST['subcode_id'];
					
			
			$tblinvmastersales = $db->query("select * from tblinvmaster_sales order by AutoInvoiceID desc limit 1 ");										
			foreach($tblinvmastersales->fetchAll() as $tims) {
				$AutoInvoiceID = $tims['AutoInvoiceID'];
			}						
						
			if($AutoInvoiceID==""){
				$new_autoinvoice_id= $inv_prefix.''.date("MM/yy").''.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);			
			} else {
				$old_autoinvoice_id = $AutoInvoiceID;									
				$currentlastsixdigit = substr($old_autoinvoice_id, -6);		 // last six digit							
				$prefixstring = substr($old_autoinvoice_id, 0, -6);			 // prefix string						
				$newlastsixdigit = str_pad($currentlastsixdigit + 1, 6, 0, STR_PAD_LEFT);						 // new last six digit			
				$new_autoinvoice_id = $prefixstring.''.$newlastsixdigit;	 // new invoice id																																							
			}	
									
			// master sales data start
			$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$customer_id."' and company_id='".$cid."' ");
			foreach($subcodes->fetchAll() as $scs){
				$customername 	= $scs['description'];
				$subcode_of 	= $scs['subcode_of'];	
				$account_code 	= $scs['code'];			
			}
			
			
			// customer code
			$customers = $db->query("select AutoCustomerID from tblcustomer where CompanyName = '".$customername."' and company_id='".$cid."' ");
			foreach($customers->fetchAll() as $ct){
				$customerid 	= $ct['AutoCustomerID'];					
			}
			
			
			//$newAutoInvoiceID   = $new_autoinvoice_id;
			$CustPORef			= $purchase_order_no;			
			$InvDate			= date("d/m/Y", strtotime($date));			
			$company_id			= $cid;		
			$VendorName			= $customername;
			$CurrencyCode		= $currency_code;
			$Currencyrate		= $exchange_rate;			
							
			$invmastersales = $db->query("insert into tblinvmaster_sales(`AutoInvoiceID`,`CustPORef`,`InvDate`,`company_id`,`CurrencyCode`,`Currencyrate`,`VendorName`,`Gstinvdate`,`customerID`) values('".$new_autoinvoice_id."','".$CustPORef."','".$InvDate."','".$company_id."','".$CurrencyCode."','".$Currencyrate."','".$VendorName."','".$InvDate."','".$customerid."')");	
			
			if(!$invmastersales){
				die('Invalid query: ' . mysql_error());
			}	
			
			
			
						
			// master purchase data end
			
			// journal entries start
			
			$customer_id   			= $customer_id;
			$profit_center_id 		= $profit_center_id;
			$company_id 			= $cid;
			$date 					= $date;
			$ref 					= $ref;			
			$memo 					= $new_autoinvoice_id;			
			$debit	 				= $totalamount;		
			$gst 					= $gst;		
			$subcode_of 			= $subcode_of;	
			$entry_mode 			= "Sales";		
						
					
			$mastersalesjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`subcode_of`,`entry_mode`,`totalamount`,`currencycode`,`currencyrate`,`trade_type`,`Gstinvdate`,`fixed_asset_id`) values('".$customer_id."','".$profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_autoinvoice_id."','".$debit."','".$gst."','".$subcode_of."','".$entry_mode."','".$amount."','".$CurrencyCode."','".$Currencyrate."','Trade Debtors','".$date."','".$id."')");
			
			if(!$mastersalesjournaldata){
				die('Invalid query: ' . mysql_error());
			}		
					
			
			// for customer id
			$tblcustomer = $db->query("select AutoCustomerID from tblcustomer where CompanyName = (select description from subcodes where company_id ='".$cid."' and id='".$customer_id."' ) and company_id = '".$cid."' ");
			foreach($tblcustomer->fetchAll() as $vd){
				$CustID 	= $vd['AutoCustomerID'];				
			}		
			
			// for cheqwriter
			$tblinvoiceinoutdata = $db->query("insert into tblinvoiceinout(`InvType`,`CustID`,`InvNo`,`InvAmt`,`InvDate`,`DueDate`,`company_id`,`Acc_description`) values('Sales','".$CustID."','".$new_autoinvoice_id."','".$debit."','".$date."','".$date."','".$company_id."','Invoiceout')");
			
			if(!$tblinvoiceinoutdata){
				die('Invalid query: ' . mysql_error());
			}	
			
			// journal entries end
			
			// gst bad debt entries start
			
			$account_code  			= $account_code;	
			$gstdate 				= $date;		
			$description 			= $new_autoinvoice_id;			
			$ref 					= $ref;			
			$debit	 				= $totalamount;		
			$debit_gst	 			= $gst;		
			$trade_type 			= "Trade Debtors";	
			$company_id 			= $cid;
			$taxcode 				= 'SR';
			
			$gstbaddebtdata = $db->query("insert into  gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`debit`,`debit_gst`,`trade_type`,`company_id`) values('".$account_code."','".$gstdate."','".$new_autoinvoice_id."','".$ref."','".$debit."','".$debit_gst."','".$trade_type."','".$company_id."')");
			
			if(!$gstbaddebtdata){
				die('Invalid query: ' . mysql_error());
			}	
			
						
			
			// gst bad debt entries end							
												
				$productdescription = $db->query("select description, subcode_of from subcodes where id = '".$subcode_id."' and company_id='".$cid."' ");
				foreach($productdescription->fetchAll() as $pds){
					$product_desc 			= $pds['description'];
					$product_subcode_of 	= $pds['subcode_of'];						
				}
				
							
				//$autoinvoiceid 			= $newAutoInvoiceID;
				$subcode_id				= $subcode_id;
				$product_desc 			= $product_desc;				
				
				$productdescription_pro = $db->query("select Productcode, Misc_code from tblproduct where Productdesc = '".$product_desc."' and company_id='".$cid."' ");
				foreach($productdescription_pro->fetchAll() as $pr){
					$productcode 		= $pr['Productcode'];		
					$Misc_code 			= $pr['Misc_code'];								
				}
						
					
					$productsalesdata = $db->query("insert into  tblinvproduct_sales(`AutoInvoiceID`,`Productcode`,`ProductDesc`,`Quantity`,`UnitPrice`,`totalunitprice`,`Totalamt`,`TaxCode`,`GSTAmt`,`company_id`,`Misc_code`) values('".$new_autoinvoice_id."','".$productcode."','".$product_desc."','1','".$amount."','".$total_amount."','".$total_amount."','".$taxcode."','".$gst."','".$company_id."','".$Misc_code."')");
					
					if(!$productsalesdata){
						die('Invalid query: ' . mysql_error());
					}	
					
					// journal entries start
			
					$pd_subcode_id   			= $subcode_id;
					$pd_profit_center_id 		= $profit_center_id;
					$pd_company_id 				= $cid;
					$pd_date 					= date("Y-m-d", strtotime($date));
					$pd_ref 					= $ref;			
					//$pd_memo 					= $new_autoinvoice_id;		
					$pd_credit 					= $amount;		
					$pd_gst 					= $gst;		
					$pd_subcode_of 				= $product_subcode_of;	
					$pd_entry_mode 				= "Sales";		
					
					$productsalesjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`subcode_of`,`entry_mode`,`taxcode`,`Gstinvdate`,`fixed_asset_id`) values('".$pd_subcode_id."','".$pd_profit_center_id."','".$pd_company_id."','".$pd_date."','".$pd_ref."','".$new_autoinvoice_id."','".$pd_credit."','".$pd_gst."','".$pd_subcode_of."','".$pd_entry_mode."','".$taxcode."','".$date."','".$id."')");
					
					if(!$productsalesjournaldata){
						die('Invalid query: ' . mysql_error());
					}	
					// journal entries end
					
					
					// PROFIT CENTER CODE
					$pcenter = $db->query("select profit_center_code from profit_centers where company_id ='".$cid."' and id='".$profit_center_id."' ");
					foreach($pcenter->fetchAll() as $pc){
						$profit_center_code 	= $pc['profit_center_code'];				
					}		
					
					
					// PROFIT CENTER CODE
					$paccountno = $db->query("select code from subcodes where company_id ='".$cid."' and id='".$pd_subcode_id."' ");
					foreach($paccountno->fetchAll() as $acc){
						$pd_account_code 	= $acc['code'];				
					}	
					
					// for profit center list
					//$profitcenterlist = $db->query("insert into profit_centers_list(`company_id`,`pf_center_code`,`pf_invoiceno`,`pf_ispaid`,`Pf_AccNo`) values('".$company_id."','".$profit_center_code."','".$new_autoinvoice_id."','N','".$pd_account_code."')");	
								
					//if(!$profitcenterlist){
				//		die('Invalid query: ' . mysql_error());
				//	}		
			
			
				
			// gst output tax
			
			$outputtaxdata = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX' and company_id='".$cid."' ");
			foreach($outputtaxdata->fetchAll() as $ot){
				$outputtax_id 			= $ot['id'];									
			}
			
			
			$outputtaxjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`entry_mode`,`Gstinvdate`,`fixed_asset_id`) values('".$outputtax_id."','".$profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_autoinvoice_id."','".$gst."','".$gst."','".$entry_mode."','".$date."','".$id."')");
			
			if(!$outputtaxjournaldata){
				die('Invalid query: ' . mysql_error());
			}	
			
			
			// update fixed asset table status
			$db->query("update fixed_assets set disposed='1' where company_id='".$cid."' and id='".$id."'");
								
						
			header("Location: ?controller=disposal&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/fixedassets/dispose.php'); 	   
		}  
	  
	
	}		
	
	
	

    public function error() {
      require_once('views/fixedassets/error.php');
    }
  }
?>