<?php
  class BudgetController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
		$cid = $_GET['cid']; // company id
		
		$budgetlist =  array();		
		$budgets = $db->query("select sc.code, pc.profit_center, sc.description, bl.subcode_id, bl.from_date, bl.budget_value from budgets as bl left join subcodes as sc on sc.id = bl.subcode_id left join profit_centers as pc on pc.id = bl.profit_center_id where bl.company_id='".$cid."' and sc.company_id ='".$cid."' ");	
		foreach($budgets->fetchAll() as $bd) {
			$budgetlist[] = $bd;
		}  		
			
		$monthlist =  array();		
		$months = $db->query("select distinct(MONTH(from_date)) as month from budgets where company_id='".$cid."' order by month  ");	
		foreach($months->fetchAll() as $ms) {
			$month = $ms['month'];
			$dateObj   = DateTime::createFromFormat('!m', $month);
			$monthName = $dateObj->format('F'); // March
			$monthlist[] = $monthName;
		}  		
		
		$budgetlist1 =  array();		
		$budgets1 = $db->query("select bl.budget_value, bl.subcode_id from budgets as bl where bl.company_id='".$cid."' ");	
		foreach($budgets1->fetchAll() as $bd1) {
			$budgetlist1[] = $bd1;
		}  	
		
		
						  
	  require_once('views/budget/index.php'); 
	  
    }	
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // company id
			
		
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
		$subcodeslist = array();
		$subcodes = $db->query("select * from subcodes where company_id='".$cid."' and master_account_code_id in (select id from master_account_codes where account_type_id in ('6','7','9','12')) ");	
		foreach($subcodes->fetchAll() as $sc) {
			$subcodeslist[] = $sc;
		}  	
		
		
		$fromdate = "";
		$todate="";
		$profit_center_id="";
		
		
		$months = array();
		if(isset($_POST['submit'])){
		
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
		
		
			$fromdate = $_POST['from_date']; 
			$todate = $_POST['to_date']; 
			$profit_center_id = $_POST['profit_center_id']; 
		
			$startDate = new DateTime($fromdate);
			$endDate = new DateTime($todate);
			
			$dateInterval = new DateInterval('P1M');
			$datePeriod   = new DatePeriod($startDate, $dateInterval, $endDate);
			
			$monthCount = 0;
			
			foreach ($datePeriod as $date) {
				$months[] = $date->format('F');			
				$monthCount++;
			}
			
		}	
		
		
		if(isset($_POST['create'])){
			
			$fromdate = $_POST['from_date']; 
			$todate = $_POST['to_date']; 
			$profit_center_id = $_POST['profit_center_id']; 
		
			$startDate = new DateTime($fromdate);
			$endDate = new DateTime($todate);
			
			$dateInterval = new DateInterval('P1M');
			$datePeriod   = new DatePeriod($startDate, $dateInterval, $endDate);
			
			$monthCount = 0;
			
			foreach ($datePeriod as $date) {
				$months[] = $date->format('F');			
				$monthCount++;
			}
		
		
			$data = $_POST['data'];
			
			
			foreach($data as $dt){
				
				foreach($dt as $d){
				
					$subcode_id = $d['subcode_id'];
					$budget_value = $d['amount'];
					$from_date = $d['month']; 
					$to_date = $d['month']; 
				
					if($budget_value>0){
				
						$result = $db->query("insert into budgets(company_id, profit_center_id, subcode_id, budget_value, from_date, to_date, created_by, created_ip, created) values ('".$cid."', '".$profit_center_id."', '".$subcode_id."', '".$budget_value."', '".$from_date."', '".$to_date."', '".$created_by."', '".$created_ip."', '".$created."') ");		
							
						if(!$result){
							die('Invalid query: ' . mysql_error());
						}
					
					}
					
					
				}
				
			}
		
			header("Location: ?controller=budget&action=index&cid=".$cid."");	
		
		}
					
				
		require_once('views/budget/create.php'); 	 
	  
    }		
			

    public function error() {
      require_once('views/profitcenters/error.php');
    }
  }
?>