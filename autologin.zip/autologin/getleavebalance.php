<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		
	
	$empid = $_GET['empid']; 
	?>			
		<table cellpadding="0" cellspacing="0" id="salesinvoice_panel">
		<tr bgcolor="#2E4270" style="color:#FFFFFF;">			
			<td colspan="3">Employee Leave Balance</td>
		</tr>
		<tr>
			<th>Year</th>			
			<th>Leave</th>
			<th>Balance</th>		
		</tr>
		<?php
		
	$leaveopen = $db->query("select distinct YEAR(opening_date) as opening_date from leave_opening where employee_id = '".$empid."'  ");							
		
	foreach($leaveopen->fetchAll() as $lo) {	
			
		$dateformat = $lo['opening_date'];	
				
		$i=1;
		$leavebalance = $db->query("select sum(lo.leaved), lo.opening_date, em.full_name, em.employee_code, lm.leave_name, lm.leave_code, lm.paid_unpaid from leave_opening as lo left join employee_master as em on em.id = lo.employee_id left join leave_master as lm on lm.id = lo.leavemaster_id where lo.employee_id = '".$empid."' and lo.opening_date LIKE '%".$dateformat."%' group by lo.leavemaster_id, lo.employee_id ");							
		foreach($leavebalance->fetchAll() as $lb) {
		?>
		<tr>
			<td align="left"><?php echo date("Y", strtotime($lb['opening_date'])); ?></td>
			<td align="left"><?php echo $lb['leave_name']; ?></td>
			<td align="left"><?php echo $lb['sum(lo.leaved)']; ?> day(s)</td>				
		</tr>
		<?php
		$i++;
		}	
		
	}	
		?>	
		</table>

