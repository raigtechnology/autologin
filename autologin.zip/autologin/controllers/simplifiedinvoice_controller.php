<?php
  class SimplifiedinvoiceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
						
		$purchaseinvoicelistgroup = array();
		$purchaseinvoicegroup = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.entry_mode in ('Simplified','SimplifiedTX','SimplifiedBL') group by je.memo ");	
		foreach($purchaseinvoicegroup->fetchAll() as $jel) {
			$purchaseinvoicelistgroup[] = $jel;
		}  		
		
		$purchaseinvoicelist = array();
		$purchaseinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode in ('Simplified','SimplifiedTX','SimplifiedBL')  ");	
		foreach($purchaseinvoice->fetchAll() as $je) {
			$purchaseinvoicelist[] = $je;
		}  	
						  
	  require_once('views/simplifiedinvoice/index.php'); 
	  
    }		
	
	
	// edit
	public function edit() {   			
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		
		$id = $_GET['id'];
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
		
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
				
		$purchaseinvoicelist = array();
		$purchaseinvoice = $db->query("select je.id, je.profit_center_id, je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode = 'Purchase' and je.memo = '".$id."'  ");	
		foreach($purchaseinvoice->fetchAll() as $je) {
			$purchaseinvoicelist[] = $je;
		}  	
						  
		if(isset($_POST['save'])){			
			
			
			
			$data = $_POST['data'];		
							
			foreach($data as $dt){	
								
				$profit_center_id	= $dt['profit_center_id'];	
				$debit	= $dt['debit'];
				$credit	= $dt['credit'];
				$jeid	= $dt['id'];
				// update query
				$result = $db->query("update journal_entries set profit_center_id = '".$profit_center_id."', debit = '".$debit."', credit = '".$credit."' where company_id = '".$cid."' and memo = '".$id."' and id = '".$jeid."' ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}				
			}
			
			header("Location: ?controller=simplifiedinvoice&action=index&cid=".$cid."");						
					
		} else {	 
		   require_once('views/simplifiedinvoice/edit.php'); 	   
		}  
	  
    }		
	
	
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
		
		
		$company = $db->query("select MixedSupply, inv_prefix from companies where id='".$cid."'  ");	
		foreach($company->fetchAll() as $cm) {
			$supply_type = $cm['MixedSupply'];
			$inv_prefix = $cm['inv_prefix'];
		}  	
		
		if($supply_type=="Y"){
			$type = 'MIX';
			$stype = "Mixed";
		} else if($supply_type=="N"){
			$type = 'TAXABLE';
			$stype = "Standard";
		} 
		
		$_SESSION['type'] = $type;
		
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id in ('4','7','12') order by account_desc asc ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// banks
		$bankslist = array();
		$banks = $db->query("select bl.bank_name, bk.subcode_id from banks as bk left join bank_lists as bl on bl.id = bk.bank_list_id left join subcodes as sc on sc.id = bk.subcode_id where bk.company_id=".$cid." and bk.subcode_id>0 order by bl.bank_name");	
		foreach($banks->fetchAll() as $bk) {
			$bankslist[] = $bk;
		}  
		
		// vendor
		$vendorslist = array();
		$vendors = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='5' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors') order by sc.description asc");	
		foreach($vendors->fetchAll() as $ct) {
			$vendorslist[] = $ct;
		}  	
		
		// sales taxcode master		
		 	
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select distinct(MatchCode) from purchasecodematch where supplyType = '".$type."' and MatchCode in ('TX','ZP') order by MatchCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		
		// purchase taxcode master		
		$purchasetaxcodemasterlist = array();
		$purchasetaxcodemaster = $db->query("select TaxCode,TaxRate,id from purtaxcodemaster order by TaxCode");	
		foreach($purchasetaxcodemaster->fetchAll() as $pm) {
			$purchasetaxcodemasterlist[] = $pm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	
			
// for currency

		$session_id = $_SESSION['company_id'];		

		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end				
		
		// currency
		$currencylist = array();
		$currency = $db->query("select * from currency where company_id='".$com_id."' ");	
		foreach($currency->fetchAll() as $cy) {
			$currencylist[] = $cy;
		}  		
			
					
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
			
		
		if(isset($_POST['save'])){			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
			
									
			$date  				= date("Y-m-d", strtotime($_POST['date']));
			$ref  				= $_POST['ref'];
			//$profit_center_id  	= $_POST['profit_center_id'];
			$vendor_id  		= $_POST['vendor_id'];
			$invoice_no  		= $_POST['invoice_no'];
			$currency_code  	= $_POST['currency_code'];
			$exchange_rate  	= $_POST['exchange_rate'];			
			$totalamount 		= $_POST['totalamt'];	// including gst
			$gst 	 			= $_POST['totalgst'];			
			$bank_id  			= $_POST['bank_id'];
					
			$tblinvmasterpurchase = $db->query("select * from tblinvmaster_purchase order by AutoInvoiceID desc limit 1 ");										
			foreach($tblinvmasterpurchase->fetchAll() as $timp) {			
				$AutoInvoiceID = $timp['AutoInvoiceID'];
			}
									
			if($AutoInvoiceID==""){
				$new_autoinvoice_id= $inv_prefix.''.date("MM/yy").''.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);			
			} else {
				$old_autoinvoice_id = $AutoInvoiceID;									
				$currentlastsixdigit = substr($old_autoinvoice_id, -6);		 // last six digit							
				$prefixstring = substr($old_autoinvoice_id, 0, -6);			 // prefix string						
				$newlastsixdigit = str_pad($currentlastsixdigit + 1, 6, 0, STR_PAD_LEFT);						 // new last six digit			
				$new_autoinvoice_id = $prefixstring.''.$newlastsixdigit;	 // new invoice id																																							
			}	
			
			$tblinvmasterpurchase1 = $db->query("select count(*) as total from tblinvmaster_purchase where InvRef='".$new_autoinvoice_id."' ");										
			foreach($tblinvmasterpurchase1->fetchAll() as $timp1) {			
				$total = $timp1['total'];
			}	
				
			if($total>0){
				$new_invoice_no = $inv_prefix.'/'.date("d/M/Y").'/'.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);	
			} else {
				$new_invoice_no = $invoice_no;
			}	
						
			// master purchase data start
			$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$vendor_id."' ");
			foreach($subcodes->fetchAll() as $scs){
				$vendorname 	= $scs['description'];
				$subcode_of 	= $scs['subcode_of'];	
				$account_code 	= $scs['code'];			
			}
			
			$newAutoInvoiceID   = $new_autoinvoice_id;
			$InvRef 			= $new_invoice_no;			
			$InvDate 			= date("d/m/Y", strtotime($date));
			$company_id 		= $cid;			
			$VendorName 		= $vendorname;
			$vendorID 			= $vendor_id;
			$Currencycode 		= $currency_code;
			$Currencyrate 		= $exchange_rate;		
			
			
			// for op taxcode
			$TaxCode			= $_POST['data'][0]['matchcode'];
					
			$masterpurchasedata = $db->query("insert into  tblinvmaster_purchase(`AutoInvoiceID`,`InvRef`,`PORef`,`InvDate`,`company_id`,`VendorName`,`Currencycode`,`Currencyrate`,`vendorID`,`TaxCode`,`Gstinvdate`) values('".$newAutoInvoiceID."','".$InvRef."','DIN','".$InvDate."','".$company_id."','".$VendorName."','".$Currencycode."','".$Currencyrate."','".$vendorID."','".$TaxCode."','".$InvDate."')");	
						
			if(!$masterpurchasedata){
				die('Invalid query: ' . mysql_error());
			}				
			// master purchase data end
			
			// journal entries start
			
			$subcode_id   			= $vendor_id;
			//$profit_center_id 		= $profit_center_id;
			$company_id 			= $cid;
			$date 					= date("Y-m-d", strtotime($date));
			$ref 					= $ref;			
			$memo 					= $new_invoice_no;			
			$credit 				= $totalamount;		
			$gst 					= $gst;		
			$subcode_of 			= $subcode_of;	
			$entry_mode 			= "Simplified";		
		
									
			// taxcode	
			
			foreach($_POST['data'] as $rdt){
				$price += $rdt['quantity'] * $rdt['unit_price'];
			}
								
			$purchasemasterjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`subcode_of`,`entry_mode`,`totalamount`,`currencycode`,`currencyrate`,`trade_type`,`Gstinvdate`,`created_by`,`created_ip`,`created`) values('".$subcode_id."','','".$company_id."','".$date."','".$ref."','".$memo."','".$credit."','".$gst."','".$subcode_of."','".$entry_mode."','".$price."','".$Currencycode."','".$Currencyrate."','Trade Creditors','".$InvDate."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$purchasemasterjournaldata){
				die('Invalid query: ' . mysql_error());
			}	
		
			// journal entries end
			
			// gst bad debt entries start
			
			$account_code  			= $account_code;	
			$gstdate 				= date("Y-m-d", strtotime($date));		
			$description 			= $new_invoice_no;			
			$ref 					= $ref;			
			$credit 				= $totalamount;		
			$credit_gst 			= $gst;		
			$trade_type 			= "Trade Creditors";	
			$company_id 			= $cid;
			
			$gstbaddebtdata = $db->query("insert into gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`credit`,`credit_gst`,`trade_type`,`company_id`,`created_by`,`created_ip`,`created`) values('".$account_code."','".$gstdate."','".$description."','".$ref."','".$credit."','".$credit_gst."','".$trade_type."','".$company_id."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$gstbaddebtdata){
				die('Invalid query: ' . mysql_error());
			}	
			
			// for tally
			$gstbaddebtdata1 = $db->query("insert into gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`debit`,`debit_gst`,`trade_type`,`company_id`,`created_by`,`created_ip`,`created`) values('".$account_code."','".$gstdate."','".$description."','".$ref."','".$credit."','".$credit_gst."','".$trade_type."','".$company_id."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$gstbaddebtdata1){
				die('Invalid query: ' . mysql_error());
			}	
			// gst bad debt entries end		
					
					
			$data = $_POST['data'];
			
			$i=0;
			$_SESSION['tac']=0;	
			foreach($data as $dt){
										
				$productdescription = $db->query("select description, subcode_of from subcodes where id = '".$dt['subcode_id']."' and company_id='".$cid."' ");
				foreach($productdescription->fetchAll() as $pds){
					$product_desc 			= $pds['description'];
					$product_subcode_of 	= $pds['subcode_of'];						
				}
				
							
				$autoinvoiceid 			= $newAutoInvoiceID;
				$subcode_id				= $dt['subcode_id'];
				$product_desc 			= $product_desc;
				$quantity 				= $dt['quantity'];
				$unit_price 			= $dt['unit_price'];
				$total_amount 			= $dt['total_amount'];
				//$taxcode_purchased 		= $dt['taxcode'];
				$taxcode_purchased 		= 0;
				$taxcode_matched 		= $dt['matchcode'];
				$gst_amount 			= $dt['gst'];	
				$gst_eer 				= $dt['gst_err'];	// gst exclude exchange rate
				$entry_mode 			= "Simplified";			
				$company_id 			= $cid;	
										
				$totalunitprice			= $quantity * $unit_price;
						
				
				if($total_amount>0){
				
					
					if($taxcode_matched=="TX"){
						
						// tax entries - tx & bl
						$inputtaxdata = $db->query("select id from subcodes where description = 'GST-INPUT-TAX' and company_id='".$cid."' ");
						foreach($inputtaxdata->fetchAll() as $ot){
							$inputtax_id 			= $ot['id'];									
						}
												
						$tot += $totalunitprice;
						$gst_tot += $gst_amount;							
						
					// for zp 													
					} else {
						
						// bl product purchase			
							$productpurchasedata1 = $db->query("insert into  tblinvproduct_purchase(`AutoInvoiceID`,`ProductDesc`,`Quantity`,`UnitPrice`,`totalunitprice`,`Totalamt`,`TaxCodePurchase`,`TaxCodeMatched`,`entry_mode`,`company_id`,`subcode_id`) values('".$autoinvoiceid."','".$product_desc."','".$quantity."','".$unit_price."','".$totalunitprice."','".$total_amount."','".$taxcode_purchased."','".$taxcode_matched."','".$entry_mode."','".$company_id."','".$subcode_id."')");
					
							if(!$productpurchasedata1){
								die('Invalid query: ' . mysql_error());
							}	
					
					}
								
					
					
					
					// journal entries start
			
					$pd_subcode_id   			= $subcode_id;
					$pd_profit_center_id 		= $dt['profit_center_id'];
					$pd_company_id 				= $cid;
					$pd_date 					= date("Y-m-d", strtotime($date));
					$pd_ref 					= $ref;			
					$pd_memo 					= $new_invoice_no;			
					$pd_debit 					= $total_amount - $gst_amount;		
					$pd_gst 					= $gst_amount;		
					$pd_subcode_of 				= $product_subcode_of;	
					$pd_entry_mode 				= "Simplified";		
					
					$productpurchasejournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`subcode_of`,`entry_mode`,`taxcode`,`Gstinvdate`,`created_by`,`created_ip`,`created`) values('".$pd_subcode_id."','".$pd_profit_center_id."','".$pd_company_id."','".$pd_date."','".$pd_ref."','".$pd_memo."','".$pd_debit."','".$pd_gst."','".$pd_subcode_of."','".$pd_entry_mode."','".$taxcode_matched."','".$InvDate."','".$created_by."','".$created_ip."','".$created."')");
					
					if(!$productpurchasejournaldata){
						die('Invalid query: ' . mysql_error());
					}	
					// journal entries end
				}
					
					
			$i++;								
			}
/****************************************************************************/
			
					if($tot>500){
							
							$tx_amount 	= 500; 
							$tx_gst	 	= 30;
							
							$bl_amount 	= $tot - $tx_amount;
							$bl_gst		= $gst_tot - $tx_gst;	
								
								
							$db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`subcode_of`,`entry_mode`,`taxcode`,`Gstinvdate`,`created_by`,`created_ip`,`created`) values('".$inputtax_id."','','".$company_id."','".$date."','".$ref."','".$memo."','".$tx_gst."','".$tx_gst."','".$product_subcode_of."','SimplifiedTX','TX','".$InvDate."','".$created_by."','".$created_ip."','".$created."')");	
								
							
							$tx_amount_gst = $tx_amount + $tx_gst;							
						
							// product purchase				
							$db->query("insert into  tblinvproduct_purchase(`AutoInvoiceID`,`ProductDesc`,`Quantity`,`UnitPrice`,`totalunitprice`,`Totalamt`,`TaxCodePurchase`,`TaxCodeMatched`,`GSTamt`,`entry_mode`,`company_id`,`subcode_id`) values('".$autoinvoiceid."','".$product_desc."','".$quantity."','".$tx_amount."','".$tx_amount."','".$tx_amount_gst."','".$taxcode_purchased."','TX','".$tx_gst."','".$entry_mode."','".$company_id."','".$subcode_id."')");	
							
						
							
							if($bl_amount>0){
						
								$db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`subcode_of`,`entry_mode`,`taxcode`,`Gstinvdate`,`created_by`,`created_ip`,`created`) values('".$inputtax_id."','".$profit_center_id."','".$company_id."','".$date."','".$ref."','".$memo."','".$bl_gst."','".$bl_gst."','".$product_subcode_of."','SimplifiedBL','BL','".$InvDate."','".$created_by."','".$created_ip."','".$created."')");	
															
												
								$bl_amount_gst = $bl_amount + $bl_gst;
								
								// bl product purchase			
								$db->query("insert into  tblinvproduct_purchase(`AutoInvoiceID`,`ProductDesc`,`Quantity`,`UnitPrice`,`totalunitprice`,`Totalamt`,`TaxCodePurchase`,`TaxCodeMatched`,`GSTamt`,`entry_mode`,`company_id`,`subcode_id`) values('".$autoinvoiceid."','".$product_desc."','1','".$bl_amount."','".$bl_amount."','".$bl_amount_gst."','".$taxcode_purchased."','BL','".$bl_gst."','".$entry_mode."','".$company_id."','".$subcode_id."')");
													
							}
											
												
					} else {
							
							$tx_amount 	= $tot; 
							$tx_gst	 	= $gst_tot;							
							
							$db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`subcode_of`,`entry_mode`,`taxcode`,`Gstinvdate`,`created_by`,`created_ip`,`created`) values('".$inputtax_id."','','".$company_id."','".$date."','".$ref."','".$memo."','".$tx_gst."','".$tx_gst."','".$product_subcode_of."','SimplifiedTX','TX','".$InvDate."','".$created_by."','".$created_ip."','".$created."')");										
							
					}	
			
			
			
			
			
/**************************************************************************************/			
			
			
			
			// for tally purpose only ------------------------------	
			// for vendor payment
			$journaldatasimplified1 = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`subcode_of`,`entry_mode`,`totalamount`,`currencycode`,`currencyrate`,`trade_type`,`Gstinvdate`,`created_by`,`created_ip`,`created`) values('".$vendor_id."','','".$company_id."','".$date."','".$ref."','".$memo."','".$credit."','".$gst."','".$subcode_of."','".$entry_mode."','".-abs($price)."','".$Currencycode."','".$Currencyrate."','Trade Creditors','".$InvDate."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$journaldatasimplified1){
				die('Invalid query: ' . mysql_error());
			}	
			// release payment from bank
			$bankdescription = $db->query("select subcode_of from subcodes where id = '".$bank_id."' and company_id='".$cid."' ");
			foreach($bankdescription->fetchAll() as $bds){				
				$bank_subcode_of 	= $bds['subcode_of'];						
			}			
			
			$journaldatasimplified2 = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`subcode_of`,`entry_mode`,`Gstinvdate`,`created_by`,`created_ip`,`created`) values('".$bank_id."','','".$company_id."','".$date."','".$ref."','".$memo."','".$credit."','".$gst."','".$bank_subcode_of."','".$entry_mode."','".$InvDate."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$journaldatasimplified2){
				die('Invalid query: ' . mysql_error());
			}	
			// tally purpose end ----------------------------------------
			
			// gst output tax
			
			
			/*$outputtaxjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`entry_mode`,`Gstinvdate`) values('".$inputtax_id."','".$pd_profit_center_id."','".$company_id."','".$date."','".$ref."','".$memo."','".$gst."','".$gst."','".$entry_mode."','".$InvDate."')");
			
			if(!$outputtaxjournaldata){
				die('Invalid query: ' . mysql_error());
			}		*/	
			
			
			$created_by 	 = $_SESSION['username'];
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Add";
			$window_name     = "Simplied Invoice";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
						
			header("Location: ?controller=simplifiedinvoice&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/simplifiedinvoice/create.php'); 	   
		}  
	  
    }		
	

    public function error() {
      require_once('views/simplifiedinvoice/error.php');
    }
  }
?>
