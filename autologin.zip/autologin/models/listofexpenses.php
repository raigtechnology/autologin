<?php
  class listofexpenses {
   
  }
?>