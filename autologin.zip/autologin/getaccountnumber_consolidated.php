<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		 
		

		$userflag = $db->query("select flag from tbllogin where company_id='".$_GET['cid']."' and username = '".$_SESSION['username']."' ");	
		foreach($userflag->fetchAll() as $uf) {
			$flag = $uf['flag'];
		}  		
		
				
		if($flag==1){					
			$usergroup = $db->query("select id from user_group where company_id='".$_GET['cid']."' ");	
			foreach($usergroup->fetchAll() as $ug) {
				$user_group_id = $ug['id'];
			}  	
			
			$clists = array();
			$clist = $db->query("select id from companies where user_group_id in ('".$user_group_id."')");	
			foreach($clist->fetchAll() as $cl) {
				$clists[] 	= $cl['id'];					
			}				
					
			$id_nums = $clists;
			$cid1 = implode("','", $id_nums);																		
			
		} else {
			$cid1 = $cid;			
		}

		
	$accountnumbers = $db->query("select id, account_number from banks where bank_list_id = '".$_GET['value1']."' and company_id in( '".$cid1."') ");		
	$accountnumbers1 = $db->query("select id, account_number from banks where bank_list_id = '".$_GET['value1']."' and company_id in( '".$cid1."') ");	
	
	$it=0;
	foreach($accountnumbers1->fetchAll() as $ans) {
		$it++;
	}		
	?>	
	<select name="bank_list_id" id="bank_list_id"  class="selectbox_small" required="required">
		<?php 
			if($it>1){
		?>
			<option value="0">-- Choose --</option>
		<?php
		}
		?>
		
		<?php
		foreach($accountnumbers->fetchAll() as $an) {
		?>
		<option value="<?php echo $an['id']; ?>"><?php echo $an['account_number']; ?></option>			
		<?php
		}
		?>
	</select>
