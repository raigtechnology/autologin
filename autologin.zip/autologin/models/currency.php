<?php
  class Currency {
   
  }
?>