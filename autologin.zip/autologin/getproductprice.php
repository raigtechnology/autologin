<?php session_start();
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}	
	
	$products = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where sc.id = '".$_GET['value1']."' and tp.company_id = '".$_GET['company_id']."' and sc.company_id = '".$_GET['company_id']."' ");	
		
	foreach($products->fetchAll() as $pc) {
		$price = number_format($pc['Porductprice'], 2, '.', '');
	}	
	
	$_SESSION['price'] = $price;
	
	
?>	

<input type="text" value="<?php echo $price; ?>" name="data[<?php echo $_GET['value2']; ?>][unit_price]" id="unit_price<?php echo $_GET['value2']; ?>" class="textbox_small" style="text-align:right;" />




