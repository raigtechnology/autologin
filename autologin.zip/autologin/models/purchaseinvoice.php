<?php
  class purchaseinvoice {
   
  }
?>