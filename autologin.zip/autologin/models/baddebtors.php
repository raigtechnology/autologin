<?php
  class baddebtors {
   
  }
?>