<?php
  class Remittanceadvice {
   
  }
?>