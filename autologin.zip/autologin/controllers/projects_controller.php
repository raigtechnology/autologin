<?php
  class ProjectsController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$todate = date("Y-m-d");		
		
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code from subcodes as sc  where sc.company_id=".$cid." order by sc.description asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 	
		
		// project reference no list
		$projectreferencelist = array();		
		$projectreference = $db->query("select jr.job_refno from tbljobrefno as jr where jr.company_id=".$cid." and jr.parent_id = 0 order by jr.job_refno asc");		
		foreach($projectreference->fetchAll() as $pc) {
			$projectreferencelist[] = $pc;
		} 
		
		$monthfromdate = date("Y-m-01");	
		$monthtodate = date("Y-m-t");	
		
		$refno="";
		if(isset($_POST['submit'])){
			
			$refno 		= $_POST['refno'];	
			$from_date	= $_POST['from_date'];	
			$to_date 	= $_POST['to_date'];
			
			$monthfromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$monthtodate = date("Y-m-d", strtotime($_POST['to_date']));;	
			
			// journal entries
			$journallist = array();		
			$journals = $db->query("select 
										sc.description,
										sc.id,
										sc.code,
										je.debit,
										je.credit,
										je.date,
										je.memo,
										jr.job_description
									from 
										subcodes as sc
										left join journal_entries as je on je.subcode_id = sc.id
										left join tbljobrefno as jr on jr.job_refno = je.jobrefno										
									where 
										je.company_id=".$cid." and je.jobrefno like '%".$refno."%' and (sc.code LIKE '%300%' OR sc.code LIKE '%400%') date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') order by je.date asc");		
			foreach($journals->fetchAll() as $je) {
				$journallist[] = $je;
			} 	
			
				
		} else {
			
			// journal entries
			$journallist = array();		
			$journals = $db->query("select 
										sc.description,
										sc.id,
										sc.code,
										je.debit,
										je.credit,
										je.date,
										je.memo,
										jr.job_description
									from 
										subcodes as sc
										left join journal_entries as je on je.subcode_id = sc.id
										left join tbljobrefno as jr on jr.job_refno = je.jobrefno						
									where 
										je.company_id=".$cid." and je.jobrefno!=0 and (sc.code LIKE '%300%' OR sc.code LIKE '%400%') order by je.date asc");		
			foreach($journals->fetchAll() as $je) {
				$journallist[] = $je;
			} 	
			
				
		}	
		
		
						  
	  require_once('views/projects/index.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/projects/error.php');
    }
  }
?>