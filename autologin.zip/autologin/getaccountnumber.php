<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		 
		
	$accountnumbers = $db->query("select id, account_number from banks where bank_list_id = '".$_GET['value1']."' and company_id = '".$_GET['cid']."' ");	
	$accountnumbers1 = $db->query("select id, account_number from banks where bank_list_id = '".$_GET['value1']."' and company_id = '".$_GET['cid']."' ");	
	
	$it=0;
	foreach($accountnumbers1->fetchAll() as $ans) {
		$it++;
	}		
	?>	
	<select name="bank_list_id" id="bank_list_id"  class="selectbox_small" required="required">
		<?php 
			if($it>1){
		?>
			<option value="0">-- Choose --</option>
		<?php
		}
		?>
		
		<?php
		foreach($accountnumbers->fetchAll() as $an) {
		?>
		<option value="<?php echo $an['id']; ?>"><?php echo $an['account_number']; ?></option>			
		<?php
		}
		?>
	</select>

