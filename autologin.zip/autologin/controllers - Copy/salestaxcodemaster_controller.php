<?php
  class SalestaxcodemasterController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
								
		$salestaxcodemaster = $db->query("select TaxCode, TaxRate, SupplType from salestaxcodemaster order by TaxCode asc");	
		foreach($salestaxcodemaster->fetchAll() as $scm) {
			$salestaxcodemasterlist[] = $scm;
		}	
								  
		require_once('views/salestaxcodemaster/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/salestaxcodemaster/error.php');
    }
  }
?>