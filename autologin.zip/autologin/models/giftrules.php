<?php
  class Giftrules {
   
  }
?>