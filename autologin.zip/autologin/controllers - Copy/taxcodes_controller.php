<?php
  class TaxcodesController {
  
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
								
		$taxcodes = $db->query("select taxcode, taxrate, description from taxcodes order by taxcode asc");	
		foreach($taxcodes->fetchAll() as $scm) {
			$taxcodeslist[] = $scm;
		}	
								  
		require_once('views/taxcodes/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/taxcodes/error.php');
    }
  }
?>