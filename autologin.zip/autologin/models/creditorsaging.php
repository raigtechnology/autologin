<?php
  class creditorsaging {
   
  }
?>