<?php
  class ProfitandlosssummaryController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();	// db connection	
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
				
		
		$todate = date("Y-m-d");	
		
		$monthfromdate = date("Y-m-01");	
		$monthtodate = date("Y-m-t");	
		
		$yearfromdate = date("Y-01-01");	
		$yeartodate = date("Y-m-t");	
		
		$currentyeardate1 = date("Y-m");
			
		$lastmonthfromdate = date('Y-m-d', strtotime($currentyeardate1." -1 month"));
		$lastmonthtodate = date('Y-m-t', strtotime($currentyeardate1." -1 month"));
		
		$profitcenter ="";
		$gsttaxcode ="";
		$profit_center_id=0;
		
		if(isset($_POST['submit'])){
		
			$todate = date("Y-m-d");	
		
			$monthfromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$monthtodate = date("Y-m-d", strtotime($_POST['to_date']));;	
			$profit_center_id = $_POST['profit_center_id']; 
			$year = date("Y", strtotime($_POST['from_date']));
			
			$yearfromdate = date($year."-01-01");	
			$yeartodate = date($monthtodate);	
			
			
			$currentyeardate = date("Y-m-d", strtotime($_POST['from_date']));
			$lastyear = date("Y",strtotime("-1 year"));
			$lastyeardate = date($lastyear.'-m-d');			
			
			$currentyeardate1 = date("Y-m", strtotime($_POST['from_date']));
			
			$lastmonthfromdate = date('Y-m-d', strtotime($currentyeardate1." -1 month"));
		    $lastmonthtodate = date('Y-m-t', strtotime($currentyeardate1." -1 month"));
						
		//	$profitcenter = " AND je.profit_center_id=".$profit_center_id." ";
		$profitcenter = " ";
		
		}
	
		
			$previousdate = date('Y-m-d', strtotime('-1 day', strtotime($monthfromdate)));  
					
					
					// for gst 					
					$gstbalance = $db->query("SELECT aa.AdjustmentRecovered as balance, aa.TaxCode FROM annualadjustment as aa WHERE aa.company_id = ".$cid." AND STR_TO_DATE(aa.PeriodTo,'%d/%m/%Y') BETWEEN '1111-11-11' AND '".$previousdate."' ");								
								
					foreach($gstbalance->fetchAll() as $gs) {
						 
						 if($gs['TaxCode']=="AJS"){
						 	 $gst_balance1 = -abs($gs['balance']);				
						 } else  if($gs['TaxCode']=="AJP"){
						 	 $gst_balance2 = $gs['balance'];				
						 } 
						 
						 $gsttaxcode = $gs['TaxCode'];
					}	
		
		
				
		
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code from subcodes as sc  where sc.company_id=".$cid." order by sc.description asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 
		
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
		/******************* SALES START  ****/
		
		$salessubcodesList = array();		
		$salessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($salessubcodes->fetchAll() as $ssc) {
			$salessubcodesList[] = $ssc;
		} 		
		
		$salesArray = array();		
		$si=0;
		foreach($salessubcodesList as $scl){
						
			$description = $scl['description'];						
						
			$openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and op.company_id = ".$cid." and sc.id = '".$scl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($openingbalance->fetchAll() as $op) {
				$op_balance = $op['balance'];
			} 		
						
			$sales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_yeargibalance->fetchAll() as $sygi) {
				$sales_yearbalance = $sygi['balance'];				
			}
			
			$sales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_monthgibalance->fetchAll() as $smgi) {
				$sales_monthbalance = $smgi['balance'];				
			}								
			
			$salesArray[$si]['description'] = $description;
			$salesArray[$si]['yearbalance'] = $op_balance + $sales_yearbalance;
			$salesArray[$si]['monthbalance'] = $op_balance + $sales_monthbalance;
						
			$si++;	
		}
		
				
		
				
		/******************* SALES END  ****/	
		
		/******************* SALES ADJUSTMENT START  ****/
		
		$salesadjustmentsubcodesList = array();		
		$salesadjustmentsubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 17 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($salesadjustmentsubcodes->fetchAll() as $sasc) {
			$salesadjustmentsubcodesList[] = $sasc;
		} 		
		
		$salesadjustmentArray = array();		
		$sai=0;
		foreach($salesadjustmentsubcodesList as $sacl){
						
			$description = $sacl['description'];						
						
			$salesadjustmentopeningbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 17 and op.company_id = ".$cid." and sc.id = '".$sacl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($salesadjustmentopeningbalance->fetchAll() as $saop) {
				$salesadjustmentop_balance = $saop['balance'];
			} 		
						
			$salesadjustment_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$sacl['id']."' and mac.account_type_id = 17 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($salesadjustment_yeargibalance->fetchAll() as $saygi) {
				$salesadjustment_yearbalance = $saygi['balance'];				
			}
			
			$salesadjustment_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$sacl['id']."' and mac.account_type_id = 17 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($salesadjustment_monthgibalance->fetchAll() as $samgi) {
				$salesadjustment_monthbalance = $samgi['balance'];				
			}								
			
			$salesadjustmentArray[$sai]['description'] = $description;
			$salesadjustmentArray[$sai]['yearbalance'] = $op_balance + $salesadjustment_yearbalance;
			$salesadjustmentArray[$sai]['monthbalance'] = $op_balance + $salesadjustment_monthbalance;
						
			$sai++;	
		}
				
		/******************* SALES ADJUSTMENT END  ****/
			
				
		/******************* COST OF SALES START  ****/
		
		$costofsalessubcodesList = array();		
		$costofsalessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($costofsalessubcodes->fetchAll() as $cssc) {
			$costofsalessubcodesList[] = $cssc;
		} 
		
					
		
		$costofsalesArray = array();		
		$csi=0;
		foreach($costofsalessubcodesList as $cscl){
						
			$description = $cscl['description'];					
			
			// opening balance
			$costofsales_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and op.company_id = ".$cid." and sc.id = '".$cscl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($costofsales_openingbalance->fetchAll() as $csop) {
				$costofsales_op_balance = $csop['balance'];
			} 
			
			$costofsales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_yeargibalance->fetchAll() as $csygi) {
				$costofsales_yearbalance = $csygi['balance'];
			}
			
			$costofsales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_monthgibalance->fetchAll() as $csmgi) {
				$costofsales_monthbalance = $csmgi['balance'];				
			}
				
			$costofsalesArray[$csi]['description'] = $description;
			$costofsalesArray[$csi]['yearbalance'] = $costofsales_op_balance + $costofsales_yearbalance;
			$costofsalesArray[$csi]['monthbalance'] = $costofsales_op_balance + $costofsales_monthbalance;
							
			$csi++;
		}		
				
		/******************* COST OF SALES END  ****/		
				
		
		/******************* OTHER INCOMES START  ****/
		
		$otherincomessubcodesList = array();		
		$otherincomessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 11 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($otherincomessubcodes->fetchAll() as $oisc) {
			$otherincomessubcodesList[] = $oisc;
		} 
		
					
		
		$otherincomesArray = array();		
		$oii=0;
		foreach($otherincomessubcodesList as $oicl){
						
			$description = $oicl['description'];					
			
			// opening balance
			$otherincomes_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 11 and op.company_id = ".$cid." and sc.id = '".$oicl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($otherincomes_openingbalance->fetchAll() as $oiop) {
				$otherincomes_op_balance = $oiop['balance'];
			} 
			
			$otherincomes_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$oicl['id']."' and mac.account_type_id = 11 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($otherincomes_yeargibalance->fetchAll() as $oiygi) {
				$otherincomes_yearbalance = $oiygi['balance'];
			}
			
			$otherincomes_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$oicl['id']."' and mac.account_type_id = 11 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($otherincomes_monthgibalance->fetchAll() as $oimgi) {
				$otherincomes_monthbalance = $oimgi['balance'];				
			}
				
			$otherincomesArray[$oii]['description'] = $description;
			$otherincomesArray[$oii]['yearbalance'] = $otherincomes_op_balance + $otherincomes_yearbalance;
			$otherincomesArray[$oii]['monthbalance'] = $otherincomes_op_balance + $otherincomes_monthbalance;
							
			$oii++;
		}		
				
		/******************* OTHER INCOMES END  ****/		
				
				
		/******************* EXPENSES START  ****/
		
		$expensessubcodesList = array();		
		$expensessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($expensessubcodes->fetchAll() as $esc) {
			$expensessubcodesList[] = $esc;
		}				 		
		
		$expensesArray = array();		
		$csi=0;
		foreach($expensessubcodesList as $ecl){
						
			$description = $ecl['description'];					
			
			// opening balance
			$expenses_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and op.company_id = ".$cid." and sc.id = '".$ecl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($expenses_openingbalance->fetchAll() as $eop) {
				$expenses_op_balance = $eop['balance'];
			} 	
			
			
			$expenses_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_yeargibalance->fetchAll() as $eygi) {
				$expenses_yearbalance = $eygi['balance'];
			}
				
			
			
			$expenses_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_monthgibalance->fetchAll() as $emgi) {			
				$expenses_monthbalance = $emgi['balance'];				
			}							
						
			$expensesArray[$csi]['description'] = $description;
			$expensesArray[$csi]['yearbalance'] = $expenses_op_balance + $expenses_yearbalance;
			$expensesArray[$csi]['monthbalance'] = $expenses_op_balance + $expenses_monthbalance;
			
			$csi++;
		}				
				
		/******************* EXPENSES END  ****/	
		
		/******************* CAPITAL START  ****/
		
	
			// opening balance
			$capital_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE sc.description = 'RETAINED EARNINGS' and mac.account_type_id = 2 and op.company_id = ".$cid." ORDER BY `op`.`subcode_id` ASC");		
			foreach($capital_openingbalance->fetchAll() as $caop) {
				$capital_op_balance = abs($caop['balance']);
			} 	
			
			
			
				
		/******************* CAPITAL END  ****/	
		
					
		
		/******************* Current Assets START  ****/
		$master_account_codes1 = $db->query("select id as mid, account_desc from master_account_codes where company_id=".$cid." order by account_code");				
		
		foreach($master_account_codes1->fetchAll() as $maclist) {
			
			if($maclist['account_desc']=="CURRENT ASSETS"){
				$currentassetid = $maclist['mid'];
			} 
			if($maclist['account_desc']=="CURRENT LIABILITIES"){
				$currentliabilitiesid = $maclist['mid'];
			} 
			
		}		
		
		// for output tax
		$subcodesList = array();		
		$subcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$currentassetid."'
									and sc.subcode_of in (select id from subcodes where description ='GST-OUTPUT-TAX')
								order by sc.code asc");	
									
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		}	
				
		// for sales tax codes
		$outputtaxdata = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX' and company_id='".$cid."' ");
		foreach($outputtaxdata->fetchAll() as $ot){
			$outputtax_id 			= $ot['id'];									
		}
		
				
		// for sales tax codes
				
		$salestax_year = $db->query("select sum(credit) as credit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." ".$profitcenter." and je.subcode_id ='".$outputtax_id."' AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') order by je.memo,je.date ");
				
		foreach($salestax_year->fetchAll() as $st_year) {
			$outputtax_year = $st_year['credit'];
		}	
		
		if($gsttaxcode=="AJS"){
			$outputtax_year = $outputtax_year + $gst_balance1;
		} 
		
				
		// month		
		$salestax_month = $db->query("select sum(credit) as credit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." ".$profitcenter." and je.subcode_id='".$outputtax_id."' AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') order by je.memo,je.date ");
		
		foreach($salestax_month->fetchAll() as $st_month) {
			$outputtax_month = $st_month['credit'];
		}		
		
		
		
		
		
				
		// for input tax		
		$psubcodesList = array();		
		$psubcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$currentliabilitiesid."'
									and sc.subcode_of in (select id from subcodes where description ='GST-INPUT-TAX')
								order by sc.code asc");	
									
		foreach($psubcodes->fetchAll() as $psc) {
			$psubcodesList[] = $psc;
		}	
				
		// for sales tax codes
		$inputtaxdata = $db->query("select id from subcodes where description = 'GST-INPUT-TAX' and company_id='".$cid."' ");
		foreach($inputtaxdata->fetchAll() as $ot){
			$inputtax_id 			= $ot['id'];									
		}
		
		// for purchase tax codes
		$purchasetax_year = $db->query("select sum(debit) as debit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." ".$profitcenter." and je.subcode_id='".$inputtax_id."' AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') order by je.memo,je.date ");
		
		foreach($purchasetax_year->fetchAll() as $pt_year) {
			$inputtax_year = $pt_year['debit'];
		}	
		
		if($gsttaxcode=="AJP"){
			$inputtax_year = $inputtax_year + $gst_balance2;
		} 
		
		
		/*$purchasetax_year_bl = $db->query("select sum(gst) as gst from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." and je.taxcode='BL' and je.date >= '1111-11-11' AND je.date <= '".$yeartodate."' order by je.memo,je.date ");
		
		foreach($purchasetax_year_bl->fetchAll() as $pt_year_bl) {
			$inputtax_year_bl = $pt_year_bl['gst'];
		}	*/
				
		
		// month wise		
		$purchasetax_month = $db->query("select sum(debit) as debit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." ".$profitcenter." and je.subcode_id='".$inputtax_id."' AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') order by je.memo,je.date ");
		
		foreach($purchasetax_month->fetchAll() as $pt_month) {
			$inputtax_month = $pt_month['debit'];
		}		
				
		/*$purchasetax_month_bl = $db->query("select sum(je.gst) as gst from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." and je.taxcode='BL' and je.date >= '".$monthfromdate."' AND je.date <= '".$monthtodate."' order by je.memo,je.date ");
		
		foreach($purchasetax_month_bl->fetchAll() as $pt_month_bl) {
			$inputtax_month_bl = $pt_month_bl['gst'];
		}				
		
		if($inputtax_month>$inputtax_month_bl){
			$inputtax_month = $inputtax_month - $inputtax_month_bl;
		} else {
			$inputtax_month = $inputtax_month_bl - $inputtax_month;
		}
			
		if($inputtax_year>$inputtax_year_bl){
			$inputtax_year = $inputtax_year - $inputtax_year_bl;
		} else {
			$inputtax_year = $inputtax_year_bl - $inputtax_year;
		}*/
	
		
		
				
						
		/******************* current assets END  ****/		
		
		
/******************************************************************************************************************************************************************/	

/******************* SALES START  ****/
		
		$salessubcodesList_retained = array();		
		$salessubcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($salessubcodes_retained->fetchAll() as $ssc_retained) {
			$salessubcodesList_retained[] = $ssc_retained;
		} 		
		
		$salesArray_retained = array();		
		$si_retained=0;
		foreach($salessubcodesList_retained as $scl_retained){
						
			$description_retained = $scl_retained['description'];						
						
			$openingbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and op.company_id = ".$cid." and sc.id = '".$scl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($openingbalance_retained->fetchAll() as $op_retained) {
				$op_balance_retained = $op_retained['balance'];
			} 		
						
			$sales_yeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl_retained['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_yeargibalance_retained->fetchAll() as $sygi_retained) {
				$sales_yearbalance_retained = $sygi_retained['balance'];				
			}
			
			
			$sales_monthgibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl_retained['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_monthgibalance_retained->fetchAll() as $smgi_retained) {
				$sales_monthbalance_retained = $smgi_retained['balance'];				
			}					
									
			$salesArray_retained[$si_retained]['description'] = $description_retained;
			$salesArray_retained[$si_retained]['yearbalance'] = $op_balance_retained + $sales_yearbalance_retained;
			$salesArray_retained[$si_retained]['monthbalance'] = $op_balance_retained + $sales_monthbalance_retained;
						
			$si_retained++;	
		}
				
		/******************* SALES END  ****/	
			
				
		
		/******************* SALES ADJUSTMENT START  ****/
		
		$salesadjustmentsubcodesList_retained = array();		
		$salesadjustmentsubcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 17 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($salesadjustmentsubcodes_retained->fetchAll() as $sasc_retained) {
			$salesadjustmentsubcodesList_retained[] = $sasc_retained;
		} 		
		
		$salesadjustmentArray_retained = array();		
		$sai_retained=0;
		foreach($salesadjustmentsubcodesList_retained as $sacl_retained){
						
			$description_retained = $sacl_retained['description'];						
						
			$salesadjustmentopeningbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 17 and op.company_id = ".$cid." and sc.id = '".$sacl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($salesadjustmentopeningbalance_retained->fetchAll() as $saop_retained) {
				$salesadjustmentop_balance_retained = $saop_retained['balance'];
			} 		
						
			$salesadjustment_yeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$sacl_retained['id']."' and mac.account_type_id = 17 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($salesadjustment_yeargibalance_retained->fetchAll() as $saygi_retained) {
				$salesadjustment_yearbalance_retained = $saygi_retained['balance'];				
			}
			
			$salesadjustment_monthgibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$sacl_retained['id']."' and mac.account_type_id = 17 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($salesadjustment_monthgibalance_retained->fetchAll() as $samgi_retained) {
				$salesadjustment_monthbalance_retained = $samgi_retained['balance'];				
			}								
			
			$salesadjustmentArray_retained[$sai_retained]['description'] = $description_retained;
			$salesadjustmentArray_retained[$sai_retained]['yearbalance'] = $op_balance_retained + $salesadjustment_yearbalance_retained;
			$salesadjustmentArray_retained[$sai_retained]['monthbalance'] = $op_balance_retained + $salesadjustment_monthbalance_retained;
						
			$sai_retained++;	
		}
				
		/******************* SALES ADJUSTMENT END  ****/
			
				
		/******************* COST OF SALES START  ****/
		
		$costofsalessubcodesList_retained = array();		
		$costofsalessubcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($costofsalessubcodes_retained->fetchAll() as $cssc_retained) {
			$costofsalessubcodesList_retained[] = $cssc_retained;
		} 
		
					
		
		$costofsalesArray_retained = array();		
		$csi_retained=0;
		foreach($costofsalessubcodesList_retained as $cscl_retained){
						
			$description_retained = $cscl_retained['description'];					
			
			// opening balance
			$costofsales_openingbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and op.company_id = ".$cid." and sc.id = '".$cscl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($costofsales_openingbalance_retained->fetchAll() as $csop_retained) {
				$costofsales_op_balance_retained = $csop_retained['balance'];
			} 
			
			$costofsales_yeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl_retained['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_yeargibalance_retained->fetchAll() as $csygi_retained) {
				$costofsales_yearbalance_retained = $csygi_retained['balance'];
			}
			
			$costofsales_monthgibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl_retained['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_monthgibalance_retained->fetchAll() as $csmgi_retained) {
				$costofsales_monthbalance_retained = $csmgi_retained['balance'];				
			}
			
							
			$costofsalesArray_retained[$csi_retained]['description'] = $description_retained;
			$costofsalesArray_retained[$csi_retained]['yearbalance'] = $costofsales_op_balance_retained + $costofsales_yearbalance_retained;
			$costofsalesArray_retained[$csi_retained]['monthbalance'] = $costofsales_op_balance_retained + $costofsales_monthbalance_retained;
							
			$csi_retained++;
		}		
				
		/******************* COST OF SALES END  ****/		
				
		
		/******************* OTHER INCOMES START  ****/
		
		$otherincomessubcodesList_retained = array();		
		$otherincomessubcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 11 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($otherincomessubcodes_retained->fetchAll() as $oisc_retained) {
			$otherincomessubcodesList_retained[] = $oisc_retained;
		} 
		
					
		
		$otherincomesArray_retained = array();		
		$oii_retained=0;
		foreach($otherincomessubcodesList_retained as $oicl_retained){
						
			$description_retained = $oicl_retained['description'];					
			
			// opening balance
			$otherincomes_openingbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 11 and op.company_id = ".$cid." and sc.id = '".$oicl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($otherincomes_openingbalance_retained->fetchAll() as $oiop_retained) {
				$otherincomes_op_balance_retained = $oiop_retained['balance'];
			} 
						
			
			$otherincomes_yeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$oicl_retained['id']."' and mac.account_type_id = 11 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($otherincomes_yeargibalance_retained->fetchAll() as $oiygi_retained) {
				$otherincomes_yearbalance_retained = $oiygi_retained['balance'];
			}
				
			
			$otherincomes_monthgibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$oicl_retained['id']."' and mac.account_type_id = 11 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($otherincomes_monthgibalance_retained->fetchAll() as $oimgi_retained) {
				$otherincomes_monthbalance_retained = $oimgi_retained['balance'];				
			}			
						
				
			$otherincomesArray_retained[$oii]['description'] = $description_retained;
			$otherincomesArray_retained[$oii]['yearbalance'] = $otherincomes_op_balance_retained + $otherincomes_yearbalance_retained;
			$otherincomesArray_retained[$oii]['monthbalance'] = $otherincomes_op_balance_retained + $otherincomes_monthbalance_retained;
							
			$oii++;
		}		
				
		/******************* OTHER INCOMES END  ****/		
				
				
		/******************* EXPENSES START  ****/
		
		$expensessubcodesList_retained = array();		
		$expensessubcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($expensessubcodes_retained->fetchAll() as $esc_retained) {
			$expensessubcodesList_retained[] = $esc_retained;
		}				 		
		
		$expensesArray_retained = array();		
		$csi_retained=0;
		foreach($expensessubcodesList_retained as $ecl_retained){
						
			$description_retained = $ecl_retained['description'];					
			
			// opening balance
			$expenses_openingbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and op.company_id = ".$cid." and sc.id = '".$ecl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($expenses_openingbalance_retained->fetchAll() as $eop_retained) {
				$expenses_op_balance_retained = $eop_retained['balance'];
			} 	
			
			
			
			
			$expenses_yeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl_retained['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_yeargibalance_retained->fetchAll() as $eygi_retained) {
				$expenses_yearbalance_retained = $eygi_retained['balance'];
			}
				
			
			
			$expenses_monthgibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl_retained['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_monthgibalance_retained->fetchAll() as $emgi_retained) {			
				$expenses_monthbalance_retained = $emgi_retained['balance'];				
			}							
						
			$expensesArray_retained[$csi_retained]['description'] = $description_retained;
			$expensesArray_retained[$csi_retained]['yearbalance'] = $expenses_op_balance_retained + $expenses_yearbalance_retained;
			$expensesArray_retained[$csi_retained]['monthbalance'] = $expenses_op_balance_retained + $expenses_monthbalance_retained;
			
			$csi_retained++;
		}				
				
				
		$salestax_year_retained = $db->query("select sum(credit) as credit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." ".$profitcenter." and je.subcode_id ='".$outputtax_id."' AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') order by je.memo,je.date ");
				
		foreach($salestax_year_retained->fetchAll() as $st_year_retained) {
			$outputtax_year_retained = $st_year_retained['credit'];
		}	
		
		if($gsttaxcode=="AJS"){
			$outputtax_year_retained = $outputtax_year_retained + $gst_balance1;
		} 
		
				
		// month		
		$salestax_month_retained = $db->query("select sum(credit) as credit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." ".$profitcenter." and je.subcode_id='".$outputtax_id."' AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') order by je.memo,je.date ");
		
		foreach($salestax_month_retained->fetchAll() as $st_month_retained) {
			$outputtax_month_retained = $st_month_retained['credit'];
		}		
		
// purchase tax				
		
		$purchasetax_year_retained = $db->query("select sum(debit) as debit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." ".$profitcenter." and je.subcode_id='".$inputtax_id."' AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') order by je.memo,je.date ");
		
		foreach($purchasetax_year_retained->fetchAll() as $pt_year_retained) {
			$inputtax_year_retained = $pt_year_retained['debit'];
		}	
		
		if($gsttaxcode=="AJP"){
			$inputtax_year_retained = $inputtax_year_retained + $gst_balance2;
		} 
		
		
		/*$purchasetax_year_bl = $db->query("select sum(gst) as gst from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." and je.taxcode='BL' and je.date >= '1111-11-11' AND je.date <= '".$yeartodate."' order by je.memo,je.date ");
		
		foreach($purchasetax_year_bl->fetchAll() as $pt_year_bl) {
			$inputtax_year_bl = $pt_year_bl['gst'];
		}	*/
				
		
		// month wise		
		$purchasetax_month_retained = $db->query("select sum(debit) as debit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." ".$profitcenter." and je.subcode_id='".$inputtax_id."' AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastmonthtodate."') order by je.memo,je.date ");
		
		foreach($purchasetax_month_retained->fetchAll() as $pt_month_retained) {
			$inputtax_month_retained = $pt_month_retained['debit'];
		}		
		
				
				
		/******************* EXPENSES END  ****/	



/******************************************************************************************************************************************************************/	
		
		
		
		
		
		
		
		
		
						  
	  require_once('views/profitandlosssummary/index.php'); 
	  
    }		
	
	
	public function view() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();	// db connection	
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
		} 
		
				
		$monthfromdate = date("Y-m-01", strtotime($_GET['from']));	
		$monthtodate = date("Y-m-t", strtotime($_GET['to']));							
		
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code from subcodes as sc  where sc.company_id=".$cid." order by sc.description asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 
		
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
		/******************* SALES START  ****/
		
		$salessubcodesList = array();		
		$salessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and sc.company_id = ".$cid." and mac.company_id=".$cid." and sc.description not in('Sales') ORDER BY  sc.id ASC");		
		foreach($salessubcodes->fetchAll() as $ssc) {
			$salessubcodesList[] = $ssc;
		} 		
		
		$profitcenter ="";
		$gsttaxcode ="";
		$profit_center_id=0;
		
		
		$salesArray = array();		
		$si=0;
		foreach($salessubcodesList as $scl){
						
			$description = $scl['description'];						
						
			$openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and op.company_id = ".$cid." and sc.id = '".$scl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($openingbalance->fetchAll() as $op) {
				$op_balance = $op['balance'];
			} 							
			
			$sales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_monthgibalance->fetchAll() as $smgi) {
				$sales_monthbalance = $smgi['balance'];				
			}								
			
			$salesArray[$si]['description'] = $description;			
			$salesArray[$si]['monthbalance'] = $op_balance + $sales_monthbalance;
						
			$si++;	
		}
			
/* for grouping start*/
		$salessubcodesList1 = array();		
		$salessubcodes1 = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and sc.company_id = ".$cid." and mac.company_id=".$cid." and sc.description not in('Sales') and sc.subcode_of=0 ORDER BY  sc.id ASC");		
		foreach($salessubcodes1->fetchAll() as $ssc1) {
			$salessubcodesList1[] = $ssc1;
		} 		
		
		$profitcenter1 ="";
		$gsttaxcode1 ="";
		$profit_center_id1=0;
		
		
		$salesArray1 = array();		
		$si1=0;
		foreach($salessubcodesList1 as $scl1){
						
			
			$subcodeoflist =  array();
			$subcodeoflist1 =  array();
			$subcodeoflist2 =  array();
			$subcodeoflist3 =  array();
			$subcodeoflist4 =  array();
			$subcodeoflist5 =  array();
			$subcodeoflist6 =  array();
			$subcodeoflist7 =  array();
			$subcodeoflist8 =  array();
			$subcodeoflist9 =  array();

			$subcodeof = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$scl1['id']."' ");	
			foreach($subcodeof->fetchAll() as $sf) {
				$subcodeoflist[] = $sf['id'];
							
					$subcodeof1 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf['id']."' ");	
					foreach($subcodeof1->fetchAll() as $sf1) {
						$subcodeoflist1[] = $sf1['id'];
						
						$subcodeof2 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf1['id']."' ");	
						foreach($subcodeof2->fetchAll() as $sf2) {
							$subcodeoflist2[] = $sf2['id'];
							
							$subcodeof3 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf2['id']."' ");	
							foreach($subcodeof3->fetchAll() as $sf3) {
								$subcodeoflist3[] = $sf3['id'];
								
								$subcodeof4 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf3['id']."' ");	
								foreach($subcodeof4->fetchAll() as $sf4) {
									$subcodeoflist4[] = $sf4['id'];
									
									$subcodeof5 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf4['id']."' ");	
									foreach($subcodeof5->fetchAll() as $sf5) {
										$subcodeoflist5[] = $sf5['id'];
										
										$subcodeof6 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf5['id']."' ");	
										foreach($subcodeof6->fetchAll() as $sf6) {
											$subcodeoflist6[] = $sf6['id'];
											
											$subcodeof7 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf6['id']."' ");	
											foreach($subcodeof7->fetchAll() as $sf7) {
												$subcodeoflist7[] = $sf7['id'];
												
												$subcodeof8 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf7['id']."' ");	
												foreach($subcodeof8->fetchAll() as $sf8) {
													$subcodeoflist8[] = $sf8['id'];
													
													$subcodeof9 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf8['id']."' ");	
													foreach($subcodeof9->fetchAll() as $sf9) {
														$subcodeoflist9[] = $sf9['id'];
													}
													
												}
												
											}
											
										}
										
									}
									
								}
										
							}
							
						}
						
					}
									
			}  
			
			
			$listofsubcodeof = array_merge($subcodeoflist,$subcodeoflist1,$subcodeoflist2,$subcodeoflist3,$subcodeoflist4,$subcodeoflist5,$subcodeoflist6,$subcodeoflist7,$subcodeoflist8,$subcodeoflist9);						
			
			
			$sf_nums = $listofsubcodeof;
			$sfids = implode("','", $sf_nums);		
			
								
			$id1 = $scl1['id'];		
			$description1 = $scl1['description'];					
						
			$openingbalance1 = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and op.company_id = ".$cid." and sc.id in('".$sfids."')  ORDER BY `op`.`subcode_id` ASC");		
			foreach($openingbalance1->fetchAll() as $op1) {
				$op_balance1 = $op1['balance'];
			} 		
							
			
			$sales_monthgibalance1 = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id in('".$sfids."') and mac.account_type_id = 6 and je.company_id = ".$cid." ".$profitcenter1." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_monthgibalance1->fetchAll() as $smgi1) {
				$sales_monthbalance1 = $smgi1['balance'];				
			}								
			
			$salesArray1[$si1]['id'] = $id1;		
			$salesArray1[$si1]['description'] = $description1;			
			$salesArray1[$si1]['monthbalance'] = $op_balance1 + $sales_monthbalance1;
						
			$si1++;	
		}
		
					
		
/* end of grouping */		
		
						  
	  require_once('views/profitandlosssummary/view.php'); 
	  
    }		
	
	
	public function expand() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();	// db connection	
		$cid = $_GET['cid'];		// company id	
		$id = $_GET['id'];
		
		
		$company = $db->query('SELECT id,company_name FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
		} 
		
				
		$monthfromdate = date("Y-m-d", strtotime($_GET['fromdate']));	
		$monthtodate = date("Y-m-d", strtotime($_GET['todate']));							
		
	
		
		/******************* SALES START  ****/
		
			
/* for grouping start*/
		
		
		$salessubcodesList1 = array();		
		$salessubcodes1 = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and sc.company_id = ".$cid." and mac.company_id=".$cid." and sc.description not in('Sales') and sc.subcode_of='".$id."' ORDER BY  sc.id ASC");		
		foreach($salessubcodes1->fetchAll() as $ssc1) {
			$salessubcodesList1[] = $ssc1;
		} 		
		
		$profitcenter1 ="";
		$gsttaxcode1 ="";
		$profit_center_id1=0;
		
		$sidarray = array();
		$salesArray1 = array();		
		$si1=0;
		
		
		foreach($salessubcodesList1 as $scl1){
	
			$sidarray[] = $scl1['id'];
		
			$subcodeoflist =  array();
			$subcodeoflist1 =  array();
			$subcodeoflist2 =  array();
			$subcodeoflist3 =  array();
			$subcodeoflist4 =  array();
			$subcodeoflist5 =  array();
			$subcodeoflist6 =  array();
			$subcodeoflist7 =  array();
			$subcodeoflist8 =  array();
			$subcodeoflist9 =  array();

			$subcodeof = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$scl1['id']."' ");	
			foreach($subcodeof->fetchAll() as $sf) {
				 $subcodeoflist[] = $sf['id'];
							
					$subcodeof1 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf['id']."' ");	
					foreach($subcodeof1->fetchAll() as $sf1) {
						$subcodeoflist1[] = $sf1['id'];
						
						$subcodeof2 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf1['id']."' ");	
						foreach($subcodeof2->fetchAll() as $sf2) {
							$subcodeoflist2[] = $sf2['id'];
							
							$subcodeof3 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf2['id']."' ");	
							foreach($subcodeof3->fetchAll() as $sf3) {
								$subcodeoflist3[] = $sf3['id'];
								
								$subcodeof4 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf3['id']."' ");	
								foreach($subcodeof4->fetchAll() as $sf4) {
									$subcodeoflist4[] = $sf4['id'];
									
									$subcodeof5 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf4['id']."' ");	
									foreach($subcodeof5->fetchAll() as $sf5) {
										$subcodeoflist5[] = $sf5['id'];
										
										$subcodeof6 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf5['id']."' ");	
										foreach($subcodeof6->fetchAll() as $sf6) {
											$subcodeoflist6[] = $sf6['id'];
											
											$subcodeof7 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf6['id']."' ");	
											foreach($subcodeof7->fetchAll() as $sf7) {
												$subcodeoflist7[] = $sf7['id'];
												
												$subcodeof8 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf7['id']."' ");	
												foreach($subcodeof8->fetchAll() as $sf8) {
													$subcodeoflist8[] = $sf8['id'];
													
													$subcodeof9 = $db->query("select id, subcode_of from subcodes where company_id='".$cid."' and subcode_of='".$sf8['id']."' ");	
													foreach($subcodeof9->fetchAll() as $sf9) {
														$subcodeoflist9[] = $sf9['id'];
													}
													
												}
												
											}
											
										}
										
									}
									
								}
										
							}
							
						}
						
					}
									
			}  
		
			$idarray = array();
			
			$idarray[] = $id;
			
			
			$listofsubcodeof = array_merge($idarray,$sidarray,$subcodeoflist,$subcodeoflist1,$subcodeoflist2,$subcodeoflist3,$subcodeoflist4,$subcodeoflist5,$subcodeoflist6,$subcodeoflist7,$subcodeoflist8,$subcodeoflist9);						
			
			
			
			
			$sf_nums = $listofsubcodeof;
		 	$sfids = implode("','", $sf_nums);	
			
								
			$description1 = $scl1['description'];	
			$id1 = $scl1['id'];											
						
			$openingbalance1 = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and op.company_id = ".$cid." and sc.id in('".$sfids."')  ORDER BY `op`.`subcode_id` ASC");		
			foreach($openingbalance1->fetchAll() as $op1) {
				$op_balance1 = $op1['balance'];
			} 		
							
			$sales_monthbalance1=0;
			$sales_monthgibalance1 = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id in('".$sfids."') and mac.account_type_id = 6 and je.company_id = ".$cid." ".$profitcenter1." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_monthgibalance1->fetchAll() as $smgi1) {
				$sales_monthbalance1 = $smgi1['balance'];				
			}								
			
			$salesArray1[$si1]['id'] = $id1;		
			$salesArray1[$si1]['description'] = $description1;			
			$salesArray1[$si1]['monthbalance'] = $op_balance1 + $sales_monthbalance1;
			
			$si1++;	
			
			$sidarray = array();		
		}
					
		
/* end of grouping */		
		
						  
	  require_once('views/profitandlosssummary/expand.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/profitandlosssummary/error.php');
    }
  }
?>