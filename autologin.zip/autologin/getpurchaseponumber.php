<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}	
	
	$accountname = $_GET['value1']; 

	$pomaster = $db->query("select pmp.AutoPurchaseID, pmp.QuoteRef, pmp.CurrencyCode, pmp.Currencyrate, qmp.VendorName from tblpomaster_purchase as pmp left join tblquotemaster_purchase as qmp on qmp.AutoQuoationID = pmp.QuoteRef where pmp.company_id ='".$_GET['cid']."' and pmp.flag!=1");
	
			
	$it=0;
	$pom_purchase = array();
	foreach($pomaster as $po){	
										
			//$pom_sales[$it]['AutoPurchaseID'] = $po['AutoPurchaseID'];
			$vendorname = $po['VendorName'];
							
		/*	$vendornamelist = $db->query("select Vendor_Name from vendor where company_id='".$_GET['cid']."' and Vendor_ID = '".$vendorID."' ");					
			foreach($vendornamelist as $cl){	
				$vendorname = $cl['Vendor_Name'];
			}	*/		
				
									
			if($accountname==$vendorname){
							
				$pom_purchase[$it]['vendorname'] = $vendorname;
				$pom_purchase[$it]['CurrencyCode'] = $po['CurrencyCode'];
				$pom_purchase[$it]['Currencyrate'] = $po['Currencyrate'];
				$pom_purchase[$it]['QuoteRef'] = $po['QuoteRef'];
			}
			
			
	$it++;
	}
	?>	
		<select name="po_number" id="po_number" class="selectbox_small" onchange="showdeposit(this.value,<?php echo $_GET['cid']; ?>)" required="required">
			<option value="">-- Choose --</option>					
			<?php
		foreach($pom_purchase as $pms) {
		?>
		<option value="<?php echo $pms['QuoteRef']; ?>"><?php echo $pms['QuoteRef']; ?></option>			
		<?php
		}
		?>
		</select>

