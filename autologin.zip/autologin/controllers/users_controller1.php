<?php
  class UsersController {
  
	public function index() {      
	
	if(isset($_GET['uid']) && isset($_GET['pid'])){
		
		$txt_username =  $_GET['uid']; //line 2	
		$txt_password =  base64_decode($_GET['pid']); //line 2	

	} else if(isset($_POST['username']) && isset($_POST['password'])){
		
		$txt_username =  $_POST['username']; //line 2	
		$txt_password =  $_POST['password']; //line 2	

	} else {
		
		 $txt_username =  ""; //line 2	
	 	 $txt_password =  ""; //line 2		
	
	} 
	 /* $myFile = "c:\\login\login.txt";
	  $lines = file($myFile);//file in to an array
	  $txt_username =  trim($lines[0]).''; //line 2	
	  $txt_password =  trim($lines[1]); //line 2	*/
	 
	  if(isset($_SESSION['username'])){
	  	header("Location: ?controller=companies&action=index");	
	  }	else if($txt_username!=="" && $txt_password!=""){
	  
	  	$db = Db::getInstance();
			  
	  	$tbllogin = $db->query('SELECT count(*) as total FROM tbllogin WHERE username ="'.$txt_username.'" and password = "'.$txt_password.'"  ');		
		foreach($tbllogin->fetchAll() as $tbl) {
        	$total = $tbl['total'];
     	}	

		$tbllogin2 = $db->query('SELECT * FROM tbllogin WHERE username ="'.$txt_username.'" and password = "'.$txt_password.'"  ');		
		foreach($tbllogin2->fetchAll() as $tbl2) {
        	$user_group_id = $tbl2['user_group_id'];
			$company_id	   = $tbl2['company_id'];
     	}		  
	
	  	if($total>0){
			
				/*	$tbllog = $db->query("SELECT count(*) as total FROM user_logs WHERE username ='".$txt_username."' and password = '".$txt_password."' and app_type='accounts' ");		
					foreach($tbllog->fetchAll() as $tl) {
						$tl_tot = $tl['total'];
					}	
										
					if($tl_tot>0){		 
												
						 unset($_SESSION['username']);
	 					 unset($_SESSION['password']);							
						 header("Location: ?controller=users&action=view");	
						exit;
					} else {
						$db->query("insert into user_logs(`username`,`password`,`app_type`,`company_id`,`user_group_id`)values('".$txt_username."','".$txt_password."','accounts','".$company_id."','".$user_group_id."')");
					}	

*/		
				
					$_SESSION['username'] = $txt_username;
					$_SESSION['password'] = $txt_password;
$_SESSION['company_id'] = $company_id;
					$_SESSION['user_group_id'] = $user_group_id;
					$_SESSION['timeout'] = time();
		  			header("Location: ?controller=companies&action=index");	
		
		
		} else {
			header("Location: ?controller=users&action=logout");	
		}
	  }	else {
	  	require_once('views/users/login.php');
	  }
	  	  	 	  
    }
		
	// logout
	public function logout() {
	

		/*if(isset($_SESSION['username']) && isset($_SESSION['password'])){			
			$db = Db::getInstance();
	  		$db->query("delete from user_logs where username = '".$_SESSION['username']."' and password = '".$_SESSION['password']."' and app_type='accounts' and user_group_id='".$_SESSION['user_group_id']."' ");		 
		}*/
		
	  unset($_SESSION['username']);
	  unset($_SESSION['password']);	
	  unset($_SESSION['user_group_id']);	
	  unset($_SESSION['company_id']);	
	
	   header("Location: ?controller=users&action=logview");	
    }
	
public function logview() {		 
	  require_once('views/users/logout.php');
    }

	public function view() {			 
	  require_once('views/users/view.php');
    }
	
			
	
    public function error() {
      require_once('views/users/error.php');
    }
	
  }
?>