<?php
  class depositsalesnonrefundable {
   
  }
?>