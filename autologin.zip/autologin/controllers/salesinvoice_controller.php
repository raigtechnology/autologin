<?php
  class SalesinvoiceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    	    
		
		$fromdate = date("Y-m-01");
		$todate = date("Y-m-d");
		$cond ="";
		$invoice_no ="";
		
		if(isset($_POST['submit'])){		
			
			$invoice_no = $_POST['invoice_no'];
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));				
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-01");
				$todate = date("Y-m-d");
			}					
			
			if($invoice_no!="" && $fromdate!="1970-01-01" && $todate!="1970-01-01"){
				$cond = " and je.memo = '".$invoice_no."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' "; 			
			} else if($invoice_no=="" && $fromdate!="1970-01-01" && $todate!="1970-01-01"){
				$cond = " and je.date >= '".$fromdate."' AND je.date <= '".$todate."' "; 			
			} else if($invoice_no!="" && $fromdate=="1970-01-01" && $todate=="1970-01-01"){
				$cond = " and je.memo = '".$invoice_no."'  "; 			
			} else {
				$cond ="";
			}
			
		}
		
			
		
		$journallist = array();
		$journals = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.entry_mode in('Sales','Deposit Sales')  group by je.memo  order by je.date,je.memo ");	
		foreach($journals->fetchAll() as $jl) {
			$journallist[] = $jl;
		}  	
		
		
						
		$salesinvoicelistgroup = array();
		$salesinvoicegroup = $db->query("select je.memo,je.received_entry from journal_entries as je where je.company_id='".$cid."' and je.entry_mode in('Sales','Deposit Sales') ".$cond." group by je.memo  order by je.date,je.memo ");	
		foreach($salesinvoicegroup->fetchAll() as $jel) {
			$salesinvoicelistgroup[] = $jel;
		}  	
		
				
		$salesinvoicelist = array();
		$salesinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code,je.trade_type,je.customremarks from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode in('Sales','Deposit Sales') ".$cond." order by je.date,je.memo");	
		foreach($salesinvoice->fetchAll() as $je) {
			$salesinvoicelist[] = $je;
		}  	
				
						  
	  require_once('views/salesinvoice/index.php'); 
	  
    }		
	
	
	// edit
	public function edit() {   			
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		
		$id = $_GET['id'];
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	   
		
		
		$company = $db->query("select MixedSupply, inv_prefix from companies where id='".$cid."'  ");	
		foreach($company->fetchAll() as $cm) {
			$supply_type = $cm['MixedSupply'];
			$inv_prefix = $cm['inv_prefix'];
		}  	
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id = '6' order by account_desc asc ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		// sales taxcode master		
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select TaxCode,TaxRate,id from salestaxcodemaster order by TaxCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' order by tp.Productdesc asc ");	
		
		
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	

// for currency

		$session_id = $_SESSION['company_id'];		

		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end				

					
		// currency
		$currencylist = array();
		$currency = $db->query("select * from currency where company_id='".$com_id."' ");	
		foreach($currency->fetchAll() as $cy) {
			$currencylist[] = $cy;
		}  	
		
		
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}   
		
			
		/*$invmastersales = $db->query("insert into tblinvmaster_sales(AutoInvoiceID,CustPORef,InvDate,company_id,CurrencyCode,Currencyrate,VendorName,Gstinvdate,customerID) values('".$new_autoinvoice_id."','".$CustPORef."','".$InvDate."','".$company_id."','".$CurrencyCode."','".$Currencyrate."','".$VendorName."','".$InvDate."','".$customerid."')");*/	
		
		
		$customviews = $db->query("select * from tblinvmaster_sales where AutoInvoiceID ='".$id."'");	
		foreach($customviews->fetchAll() as $cv) {
			$date = $cv['InvDate'];
			$cuspono = $cv['CustPORef'];
			$customername = $cv['VendorName'];
		}
		
		
		$salesinvoicee = array();
		$salesinvoices = $db->query("select * from tblinvproduct_sales where AutoInvoiceID ='".$id."'");	
		foreach($salesinvoices->fetchAll() as $ss) {
			$salesinvoicee[] = $ss;
		}
		
		
		$profits = $db->query("select ref,profit_center_id from journal_entries where memo ='".$id."' group by memo");	
		foreach($profits->fetchAll() as $pf) {
			$refer = $pf['ref'];
			$pfid = $pf['profit_center_id'];
		}
				
		$salesinvoicelist = array();
		$salesinvoice = $db->query("select je.id, je.profit_center_id, je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode = 'Sales' and je.memo = '".$id."'  ");	
		foreach($salesinvoice->fetchAll() as $je) {
			$salesinvoicelist[] = $je;
		}  	
						  
		if(isset($_POST['save'])){			
			
			/*$data = $_POST['data'];		
			
			$modified_by = $_SESSION['username'];
			$modified_ip = $_SERVER['REMOTE_ADDR'];
			$modified    = date("Y-m-d H:i:s"); 
			
							
			foreach($data as $dt){	
								
				$profit_center_id	= $dt['profit_center_id'];	
				$debit	= $dt['debit'];
				$credit	= $dt['credit'];
				$jeid	= $dt['id'];
				// update query
				$result = $db->query("update journal_entries set profit_center_id = '".$profit_center_id."', debit = '".$debit."', credit = '".$credit."', modified_by='".$modified_by."', modified_ip='".$modified_ip."', modified='".$modified."' where company_id = '".$cid."' and memo = '".$id."' and id = '".$jeid."' ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}				
			}
			
			header("Location: ?controller=salesinvoice&action=index&cid=".$cid."");	*/	
			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
			
						
			$date  				= date("Y-m-d", strtotime($_POST['date']));
			$ref  				= $_POST['ref'];
			$profit_center_id  	= $_POST['profit_center_id'];
			$customer_id  		= $_POST['customer_id'];
			$currency_code  	= $_POST['currency_code'];
			$exchange_rate  	= $_POST['exchange_rate'];
			$purchase_order_no  = $_POST['purchase_order_no'];	
			$totalamount 		= $_POST['totalamt'];	// including gst
			$gst 	 			= $_POST['totalgst'];
			$invoice_no 	 	= $_POST['invoice_number'];			
			
									
						
								 // new last six digit			
				$new_autoinvoice_id = $invoice_no;	 // new invoice id																																							
				$db->query("DELETE FROM tblinvmaster_sales where AutoInvoiceID='".$new_autoinvoice_id."' ");
				$db->query("DELETE FROM journal_entries where memo='".$new_autoinvoice_id."' ");
				$db->query("DELETE FROM tblinvoiceinout where InvNo='".$new_autoinvoice_id."' ");
				$db->query("DELETE FROM gstbaddebt where description='".$new_autoinvoice_id."' ");
				$db->query("DELETE FROM tblinvproduct_sales where AutoInvoiceID='".$new_autoinvoice_id."' ");
				$db->query("DELETE FROM profit_centers_list where pf_invoiceno='".$new_autoinvoice_id."' ");
					
			// master sales data start
			$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$customer_id."' and company_id='".$cid."' ");
			foreach($subcodes->fetchAll() as $scs){
				$customername 	= $scs['description'];
				$subcode_of 	= $scs['subcode_of'];	
				$account_code 	= $scs['code'];			
			}
			
			
			// customer code
			$customers = $db->query("select AutoCustomerID from tblcustomer where CompanyName = '".$customername."' and company_id='".$cid."' ");
			foreach($customers->fetchAll() as $ct){
				$customerid 	= $ct['AutoCustomerID'];					
			}
			
			
			//$newAutoInvoiceID   = $new_autoinvoice_id;
			$CustPORef			= $purchase_order_no;			
			$InvDate			= date("d/m/Y", strtotime($date));			
			$company_id			= $cid;		
			$VendorName			= $customername;
			$CurrencyCode		= $currency_code;
			$Currencyrate		= $exchange_rate;			
							
			$invmastersales = $db->query("insert into tblinvmaster_sales(AutoInvoiceID,CustPORef,InvDate,company_id,CurrencyCode,Currencyrate,VendorName,Gstinvdate,customerID) values('".$new_autoinvoice_id."','".$CustPORef."','".$InvDate."','".$company_id."','".$CurrencyCode."','".$Currencyrate."','".$VendorName."','".$InvDate."','".$customerid."')");	
			
			if(!$invmastersales){
				die('Invalid query: ' . mysql_error());
			}	
			
			
			
						
			// master purchase data end
			
			// journal entries start
			
			$subcode_id   			= $customer_id;
			$profit_center_id 		= $profit_center_id;
			$company_id 			= $cid;
			$date 					= $date;
			$ref 					= $ref;			
			$memo 					= $new_autoinvoice_id;			
			$debit	 				= $totalamount;		
			$gst 					= $gst;		
			$subcode_of 			= $subcode_of;	
			$entry_mode 			= "Sales";		
			
			$price=0;
			
			foreach($_POST['data'] as $rdt){
				$price += $rdt['quantity'] * $rdt['unit_price'];
			}
			
			$mastersalesjournaldata = $db->query("insert into  journal_entries(subcode_id,profit_center_id,company_id,date,ref,memo,debit,gst,subcode_of,entry_mode,totalamount,currencycode,currencyrate,trade_type,Gstinvdate,created_by,created_ip,created,received_entry) values('".$subcode_id."','".$profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_autoinvoice_id."','".$debit."','".$gst."','".$subcode_of."','".$entry_mode."','".$price."','".$CurrencyCode."','".$Currencyrate."','Trade Debtors','".$date."','".$created_by."','".$created_ip."','".$created."','Manual_sale')");
			
			if(!$mastersalesjournaldata){
				die('Invalid query: ' . mysql_error());
			}		
					
			
			// for customer id
			$tblcustomer = $db->query("select AutoCustomerID from tblcustomer where CompanyName = (select description from subcodes where company_id ='".$cid."' and id='".$customer_id."' ) and company_id = '".$cid."' ");
			foreach($tblcustomer->fetchAll() as $vd){
				$CustID 	= $vd['AutoCustomerID'];				
			}		
			
			// for cheqwriter
			$tblinvoiceinoutdata = $db->query("insert into tblinvoiceinout(InvType,CustID,InvNo,InvAmt,InvDate,DueDate,company_id,Acc_description) values('Sales','".$CustID."','".$new_autoinvoice_id."','".$debit."','".$date."','".$date."','".$company_id."','Invoiceout')");
			
			if(!$tblinvoiceinoutdata){
				die('Invalid query: ' . mysql_error());
			}	
			
			// journal entries end
			
			// gst bad debt entries start
			
			$account_code  			= $account_code;	
			$gstdate 				= $date;		
			$description 			= $new_autoinvoice_id;			
			$ref 					= $ref;			
			$debit	 				= $totalamount;		
			$debit_gst	 			= $gst;		
			$trade_type 			= "Trade Debtors";	
			$company_id 			= $cid;
			
			$gstbaddebtdata = $db->query("insert into  gstbaddebt(account_code,gstdate,description,ref,debit,debit_gst,trade_type,company_id,created_by,created_ip,created) values('".$account_code."','".$gstdate."','".$new_autoinvoice_id."','".$ref."','".$debit."','".$debit_gst."','".$trade_type."','".$company_id."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$gstbaddebtdata){
				die('Invalid query: ' . mysql_error());
			}	
			
						
			
			// gst bad debt entries end					
					
			$data = $_POST['data'];
				
			foreach($data as $dt){
										
				$productdescription = $db->query("select description, subcode_of from subcodes where id = '".$dt['subcode_id']."' and company_id='".$cid."' ");
				foreach($productdescription->fetchAll() as $pds){
					$product_desc 			= $pds['description'];
					$product_subcode_of 	= $pds['subcode_of'];						
				}
				
							
				//$autoinvoiceid 			= $newAutoInvoiceID;
				$subcode_id				= $dt['subcode_id'];
				$product_desc 			= $product_desc;
				$quanity 				= $dt['quantity'];
				$unit_price 			= $dt['unit_price'];
				$total_amount 			= $dt['total_amount'];
				$taxcode		 		= $dt['taxcode'];				
				$gst_amount 			= $dt['gst'];	
				$gst_eer 				= $dt['gst_err'];	// gst exclude exchange rate			
				$company_id 			= $cid;				
				
				$totalunitprice			= $quanity * $unit_price;
				
				
				$productdescription_pro = $db->query("select Productcode, Misc_code from tblproduct where Productdesc = '".$product_desc."' and company_id='".$cid."' ");
				foreach($productdescription_pro->fetchAll() as $pr){
					$productcode 		= $pr['Productcode'];		
					$Misc_code 			= $pr['Misc_code'];								
				}
				
				
				if($total_amount>0){
				
					$totamt = $total_amount - $gst_eer;
				
					$productsalesdata = $db->query("insert into  tblinvproduct_sales(AutoInvoiceID,Productcode,ProductDesc,Quantity,UnitPrice,totalunitprice,Totalamt,TaxCode,GSTAmt,company_id,Misc_code) values('".$new_autoinvoice_id."','".$productcode."','".$product_desc."','".$quanity."','".$unit_price."','".$totalunitprice."','".$total_amount."','".$taxcode."','".$gst_eer."','".$company_id."','".$Misc_code."')");
					
					if(!$productsalesdata){
						die('Invalid query: ' . mysql_error());
					}	
					
					// journal entries start
			
					$pd_subcode_id   			= $dt['subcode_id'];
					$pd_profit_center_id 		= $profit_center_id;
					$pd_company_id 				= $cid;
					$pd_date 					= date("Y-m-d", strtotime($date));
					$pd_ref 					= $ref;			
					//$pd_memo 					= $new_autoinvoice_id;		
					$pd_credit 					= $total_amount - $gst_amount;		
					$pd_gst 					= $gst_amount;		
					$pd_subcode_of 				= $product_subcode_of;	
					$pd_entry_mode 				= "Sales";		
					
					$productsalesjournaldata = $db->query("insert into  journal_entries(subcode_id,profit_center_id,company_id,date,ref,memo,credit,gst,subcode_of,entry_mode,taxcode,Gstinvdate,created_by,created_ip,created,received_entry) values('".$pd_subcode_id."','".$pd_profit_center_id."','".$pd_company_id."','".$pd_date."','".$pd_ref."','".$new_autoinvoice_id."','".$pd_credit."','".$pd_gst."','".$pd_subcode_of."','".$pd_entry_mode."','".$taxcode."','".$date."','".$created_by."','".$created_ip."','".$created."','Manual_sale')");
					
					if(!$productsalesjournaldata){
						die('Invalid query: ' . mysql_error());
					}	
					// journal entries end
					
					
					// PROFIT CENTER CODE
					$pcenter = $db->query("select profit_center_code from profit_centers where company_id ='".$cid."' and id='".$profit_center_id."' ");
					foreach($pcenter->fetchAll() as $pc){
						$profit_center_code 	= $pc['profit_center_code'];				
					}		
					
					
					// PROFIT CENTER CODE
					$paccountno = $db->query("select code from subcodes where company_id ='".$cid."' and id='".$pd_subcode_id."' ");
					foreach($paccountno->fetchAll() as $acc){
						$pd_account_code 	= $acc['code'];				
					}	
					
					// for profit center list
					$profitcenterlist = $db->query("insert into profit_centers_list(company_id,pf_center_code,pf_invoiceno,pf_ispaid,Pf_AccNo) values('".$company_id."','".$profit_center_code."','".$new_autoinvoice_id."','N','".$pd_account_code."')");	
								
					if(!$profitcenterlist){
						die('Invalid query: ' . mysql_error());
					}		
			
					
				}
											
			}
			
				
			// gst output tax
			
			$outputtaxdata = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX' and company_id='".$cid."' ");
			foreach($outputtaxdata->fetchAll() as $ot){
				$outputtax_id 			= $ot['id'];									
			}
			
			
			$outputtaxjournaldata = $db->query("insert into  journal_entries(subcode_id,profit_center_id,company_id,date,ref,memo,credit,gst,entry_mode,Gstinvdate,created_by,created_ip,createdreceived_entry) values('".$outputtax_id."','".$profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_autoinvoice_id."','".$gst."','".$gst."','".$entry_mode."','".$date."','".$created_by."','".$created_ip."','".$created."','Manual_sale')");
			
			if(!$outputtaxjournaldata){
				die('Invalid query: ' . mysql_error());
			}			

						
			header("Location: ?controller=salesinvoice&action=index&cid=".$cid."");					
					
		} else {	 
		   require_once('views/salesinvoice/edit.php'); 	   
		}  
	  
    }		
	
	
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		$company = $db->query("select MixedSupply, inv_prefix from companies where id='".$cid."'  ");	
		foreach($company->fetchAll() as $cm) {
			$supply_type = $cm['MixedSupply'];
			$inv_prefix = $cm['inv_prefix'];
		}  	
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id = '6' order by account_desc asc ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		// sales taxcode master		
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select TaxCode,TaxRate,id from salestaxcodemaster order by TaxCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' order by tp.Productdesc asc ");	
		
		
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	

// for currency

		$session_id = $_SESSION['company_id'];		

		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end				

					
		// currency
		$currencylist = array();
		$currency = $db->query("select * from currency where company_id='".$com_id."' ");	
		foreach($currency->fetchAll() as $cy) {
			$currencylist[] = $cy;
		}  	
		
		
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  
		
			
		
		if(isset($_POST['save'])){			
			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
			
						
			$date  				= date("Y-m-d", strtotime($_POST['date']));
			$ref  				= $_POST['ref'];
			$profit_center_id  	= $_POST['profit_center_id'];
			$customer_id  		= $_POST['customer_id'];
			$currency_code  	= $_POST['currency_code'];
			$exchange_rate  	= $_POST['exchange_rate'];
			$purchase_order_no  = $_POST['purchase_order_no'];	
			$totalamount 		= $_POST['totalamt'];	// including gst
			$gst 	 			= $_POST['totalgst'];	
			
			$remark 	 		= $_POST['remarks'];		
			
			$tblinvmastersales = $db->query("select * from tblinvmaster_sales where company_id='".$cid."' order by AutoInvoiceID desc limit 1 ");										
			foreach($tblinvmastersales->fetchAll() as $tims) {
				$AutoInvoiceID = $tims['AutoInvoiceID'];
			}						
						
			if($AutoInvoiceID==""){
				$new_autoinvoice_id= $inv_prefix.''.date("M/y").''.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);			
			} else {
				$old_autoinvoice_id = $AutoInvoiceID;									
				$currentlastsixdigit = substr($old_autoinvoice_id, -6);		 // last six digit							
				$prefixstring = substr($old_autoinvoice_id, 0, -6);			 // prefix string						
				$newlastsixdigit = str_pad($currentlastsixdigit + 1, 6, 0, STR_PAD_LEFT);						 // new last six digit			
				$new_autoinvoice_id = $prefixstring.''.$newlastsixdigit;	 // new invoice id																																							
			}	
									
			// master sales data start
			$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$customer_id."' and company_id='".$cid."' ");
			foreach($subcodes->fetchAll() as $scs){
				$customername 	= $scs['description'];
				$subcode_of 	= $scs['subcode_of'];	
				$account_code 	= $scs['code'];			
			}
			
			
			// customer code
			$customers = $db->query("select AutoCustomerID from tblcustomer where CompanyName = '".$customername."' and company_id='".$cid."' ");
			foreach($customers->fetchAll() as $ct){
				$customerid 	= $ct['AutoCustomerID'];					
			}
			
			
			//$newAutoInvoiceID   = $new_autoinvoice_id;
			$CustPORef			= $purchase_order_no;			
			$InvDate			= date("d/m/Y", strtotime($date));			
			$company_id			= $cid;		
			$VendorName			= $customername;
			$CurrencyCode		= $currency_code;
			$Currencyrate		= $exchange_rate;			
							
			$invmastersales = $db->query("insert into tblinvmaster_sales(AutoInvoiceID,CustPORef,InvDate,company_id,CurrencyCode,Currencyrate,VendorName,Gstinvdate,customerID) values('".$new_autoinvoice_id."','".$CustPORef."','".$InvDate."','".$company_id."','".$CurrencyCode."','".$Currencyrate."','".$VendorName."','".$InvDate."','".$customerid."')");	
			
			if(!$invmastersales){
				die('Invalid query: ' . mysql_error());
			}	
			
			
			
						
			// master purchase data end
			
			// journal entries start
			
			$subcode_id   			= $customer_id;
			$profit_center_id 		= $profit_center_id;
			$company_id 			= $cid;
			$date 					= $date;
			$ref 					= $ref;			
			$memo 					= $new_autoinvoice_id;			
			$debit	 				= $totalamount;		
			$gst 					= $gst;		
			$subcode_of 			= $subcode_of;	
			$entry_mode 			= "Sales";		
			
			$price=0;
			
			foreach($_POST['data'] as $rdt){
				$price += $rdt['quantity'] * $rdt['unit_price'];
			}
			
			$mastersalesjournaldata = $db->query("insert into  journal_entries(subcode_id,profit_center_id,company_id,date,deb_crt_date,ref,memo,debit,gst,subcode_of,entry_mode,totalamount,currencycode,currencyrate,trade_type,Gstinvdate,created_by,created_ip,created,received_entry,customremarks) values('".$subcode_id."','".$profit_center_id."','".$company_id."','".$date."','".$date."','".$ref."','".$new_autoinvoice_id."','".$debit."','".$gst."','".$subcode_of."','".$entry_mode."','".$price."','".$CurrencyCode."','".$Currencyrate."','Trade Debtors','".$date."','".$created_by."','".$created_ip."','".$created."','Manual_sale','".$remark."')");
			
			if(!$mastersalesjournaldata){
				die('Invalid query: ' . mysql_error());
			}		
					
			
			// for customer id
			$tblcustomer = $db->query("select AutoCustomerID from tblcustomer where CompanyName = (select description from subcodes where company_id ='".$cid."' and id='".$customer_id."' ) and company_id = '".$cid."' ");
			foreach($tblcustomer->fetchAll() as $vd){
				$CustID 	= $vd['AutoCustomerID'];				
			}		
			
			// for cheqwriter
			$tblinvoiceinoutdata = $db->query("insert into tblinvoiceinout(InvType,CustID,InvNo,InvAmt,InvDate,DueDate,company_id,Acc_description) values('Sales','".$CustID."','".$new_autoinvoice_id."','".$debit."','".$date."','".$date."','".$company_id."','Invoiceout')");
			
			if(!$tblinvoiceinoutdata){
				die('Invalid query: ' . mysql_error());
			}	
			
			// journal entries end
			
			// gst bad debt entries start
			
			$account_code  			= $account_code;	
			$gstdate 				= $date;		
			$description 			= $new_autoinvoice_id;			
			$ref 					= $ref;			
			$debit	 				= $totalamount;		
			$debit_gst	 			= $gst;		
			$trade_type 			= "Trade Debtors";	
			$company_id 			= $cid;
			
			$gstbaddebtdata = $db->query("insert into  gstbaddebt(account_code,gstdate,description,ref,debit,debit_gst,trade_type,company_id,created_by,created_ip,created) values('".$account_code."','".$gstdate."','".$new_autoinvoice_id."','".$ref."','".$debit."','".$debit_gst."','".$trade_type."','".$company_id."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$gstbaddebtdata){
				die('Invalid query: ' . mysql_error());
			}	
			
						
			
			// gst bad debt entries end					
					
			$data = $_POST['data'];
				
			foreach($data as $dt){
										
				$productdescription = $db->query("select description, subcode_of from subcodes where id = '".$dt['subcode_id']."' and company_id='".$cid."' ");
				foreach($productdescription->fetchAll() as $pds){
					$product_desc 			= $pds['description'];
					$product_subcode_of 	= $pds['subcode_of'];						
				}
				
							
				//$autoinvoiceid 			= $newAutoInvoiceID;
				$subcode_id				= $dt['subcode_id'];
				$product_desc 			= $product_desc;
				$quanity 				= $dt['quantity'];
				$unit_price 			= $dt['unit_price'];
				$total_amount 			= $dt['total_amount'];
				$taxcode		 		= $dt['taxcode'];				
				$gst_amount 			= $dt['gst'];	
				$gst_eer 				= $dt['gst_err'];	// gst exclude exchange rate			
				$company_id 			= $cid;				
				
				$totalunitprice			= $quanity * $unit_price;
				
				
				$productdescription_pro = $db->query("select Productcode, Misc_code from tblproduct where Productdesc = '".$product_desc."' and company_id='".$cid."' ");
				foreach($productdescription_pro->fetchAll() as $pr){
					$productcode 		= $pr['Productcode'];		
					$Misc_code 			= $pr['Misc_code'];								
				}
				
				
				if($total_amount>0){
				
					$totamt = $total_amount - $gst_eer;
				
					$productsalesdata = $db->query("insert into  tblinvproduct_sales(AutoInvoiceID,Productcode,ProductDesc,Quantity,UnitPrice,totalunitprice,Totalamt,TaxCode,GSTAmt,company_id,Misc_code) values('".$new_autoinvoice_id."','".$productcode."','".$product_desc."','".$quanity."','".$unit_price."','".$totalunitprice."','".$total_amount."','".$taxcode."','".$gst_eer."','".$company_id."','".$Misc_code."')");
					
					if(!$productsalesdata){
						die('Invalid query: ' . mysql_error());
					}	
					
					// journal entries start
			
					$pd_subcode_id   			= $dt['subcode_id'];
					$pd_profit_center_id 		= $profit_center_id;
					$pd_company_id 				= $cid;
					$pd_date 					= date("Y-m-d", strtotime($date));
					$pd_ref 					= $ref;			
					//$pd_memo 					= $new_autoinvoice_id;		
					$pd_credit 					= $total_amount - $gst_amount;		
					$pd_gst 					= $gst_amount;		
					$pd_subcode_of 				= $product_subcode_of;	
					$pd_entry_mode 				= "Sales";		
					
					$productsalesjournaldata = $db->query("insert into  journal_entries(subcode_id,profit_center_id,company_id,date,deb_crt_date,ref,memo,credit,gst,subcode_of,entry_mode,taxcode,Gstinvdate,created_by,created_ip,created,received_entry,customremarks) values('".$pd_subcode_id."','".$pd_profit_center_id."','".$pd_company_id."','".$pd_date."','".$pd_date."','".$pd_ref."','".$new_autoinvoice_id."','".$pd_credit."','".$pd_gst."','".$pd_subcode_of."','".$pd_entry_mode."','".$taxcode."','".$date."','".$created_by."','".$created_ip."','".$created."','Manual_sale','".$remark."')");
					
					if(!$productsalesjournaldata){
						die('Invalid query: ' . mysql_error());
					}	
					// journal entries end
					
					
					// PROFIT CENTER CODE
					$pcenter = $db->query("select profit_center_code from profit_centers where company_id ='".$cid."' and id='".$profit_center_id."' ");
					foreach($pcenter->fetchAll() as $pc){
						$profit_center_code 	= $pc['profit_center_code'];				
					}		
					
					
					// PROFIT CENTER CODE
					$paccountno = $db->query("select code from subcodes where company_id ='".$cid."' and id='".$pd_subcode_id."' ");
					foreach($paccountno->fetchAll() as $acc){
						$pd_account_code 	= $acc['code'];				
					}	
					
					// for profit center list
					$profitcenterlist = $db->query("insert into profit_centers_list(company_id,pf_center_code,pf_invoiceno,pf_ispaid,Pf_AccNo) values('".$company_id."','".$profit_center_code."','".$new_autoinvoice_id."','N','".$pd_account_code."')");	
								
					if(!$profitcenterlist){
						die('Invalid query: ' . mysql_error());
					}		
			
					
					
					
					
				}
											
			}
			
				
			// gst output tax
			
			$outputtaxdata = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX' and company_id='".$cid."' ");
			foreach($outputtaxdata->fetchAll() as $ot){
				$outputtax_id 			= $ot['id'];									
			}
			
			
			$outputtaxjournaldata = $db->query("insert into  journal_entries(subcode_id,profit_center_id,company_id,date,deb_crt_date,ref,memo,credit,gst,entry_mode,Gstinvdate,created_by,created_ip,created,received_entry,customremarks) values('".$outputtax_id."','".$profit_center_id."','".$company_id."','".$date."','".$date."','".$ref."','".$new_autoinvoice_id."','".$gst."','".$gst."','".$entry_mode."','".$date."','".$created_by."','".$created_ip."','".$created."','Manual_sale','".$remark."')");
			
			if(!$outputtaxjournaldata){
				die('Invalid query: ' . mysql_error());
			}			
			
			
			
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Add";
			$window_name     = "Sales";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
			
						

			header("Location: ?controller=salesinvoice&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/salesinvoice/create.php'); 	   
		}  
	  
    }		
	

    public function error() {
      require_once('views/salesinvoice/error.php');
    }
  }
?>