<?php
  class approveduncategorizedgl {
   
  }
?>