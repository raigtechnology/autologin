<?php
  class Companies {
   
  }
?>