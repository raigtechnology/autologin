<?php
  class ProfitcentersController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
		$cid = $_GET['cid']; // company id
		
		$profitcenterslist =  array();		
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  		
						  
	  require_once('views/profitcenters/index.php'); 
	  
    }	
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // company id
			
		
		$pccerror="";		
		$pcerror="";		
		$paerror="";		
		$pserror="";		
		$pperror="";	
		
		$profit_center_code="";	
		$profit_center="";	
		$address="";
		$state="";
		$pincode="";
		$msg="";
		
		if(isset($_POST['create'])){
		
			$profit_center_code		= $_POST['profit_center_code'];
			$profit_center			= $_POST['profit_center'];
			$address				= $_POST['address'];
			$state					= $_POST['state'];
			$pincode				= $_POST['pincode'];	
			$flag					= $_POST['flag'];
			
			if($profit_center_code==""){
				$pccerror = "Please enter profit center code";							 						
			} 
			if($profit_center==""){
				$pcerror = "Please enter profit center ";			 							
			} 
			if($address==""){
				$paerror = "Please enter address";			 					
			} 
			if($state==""){
				$pserror = "Please enter state";			 					
			} 
			if($pincode==""){
				$pperror = "Please enter pincode";			 					
			} 	
			
			if($pccerror!="" || $pcerror!="" || $paerror!="" || $pserror!="" || $pperror!=""){
				require_once('views/profitcenters/create.php'); 	 
			}
			
			
			if($profit_center_code!=""){			
				
				$profitcenterlist = $db->query('SELECT count(*) as total FROM profit_centers WHERE profit_center_code = "'.$profit_center_code.'" and company_id = "'.$cid.'" ');		
				foreach($profitcenterlist->fetchAll() as $pc) {
					$total = $pc['total'];
				}
			
				if($total>0){
					$pccerror = "Profit Center Code already exist!";
					require_once('views/profitcenters/create.php'); 
				}				
			}	
			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
						
			// insert query
			$result = $db->query("insert into profit_centers(company_id, profit_center_code, profit_center, address, state, pincode, flag, created_by, created_ip, created) values ('".$cid."', '".$profit_center_code."', '".$profit_center."', '".$address."', '".$state."', '".$pincode."', '".$flag."', '".$created_by."', '".$created_ip."', '".$created."') ");		
						
			if(!$result){
				die('Invalid query: ' . mysql_error());
			}
			header("Location: ?controller=profitcenters&action=index&cid=".$cid."");		
					
		} else {	 
		   require_once('views/profitcenters/create.php'); 	   
		}  
	  
    }		
	
	public function edit() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();	
		$cid = $_GET['cid']; // company id
		
		$id = $_GET['id'];	    
		
		$profitcenterslist =  array();			
		$profitcenters = $db->query("select * from profit_centers where id ='".$id."' and company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  		
		
		$pccerror="";		
		$pcerror="";		
		$paerror="";		
		$pserror="";		
		$pperror="";	
		
		$profit_center_code="";	
		$profit_center="";	
		$address="";
		$state="";
		$pincode="";
		$msg="";
		
		if(isset($_POST['edit'])){
		
			//$db = Db::getInstance(); // db connection
		
			$profit_center_code		= $_POST['profit_center_code'];
			$profit_center			= $_POST['profit_center'];
			$address				= $_POST['address'];
			$state					= $_POST['state'];
			$pincode				= $_POST['pincode'];	
			$flag  			    	= $_POST['flag'];
			
			if($profit_center_code==""){
				$pccerror = "Please enter profit center code";							 						
			} 
			if($profit_center==""){
				$pcerror = "Please enter profit center ";			 							
			} 
			if($address==""){
				$paerror = "Please enter address";			 					
			} 
			if($state==""){
				$pserror = "Please enter state";			 					
			} 
			if($pincode==""){
				$pperror = "Please enter pincode";			 					
			} 	
			
			if($pccerror!="" || $pcerror!="" || $paerror!="" || $pserror!="" || $pperror!=""){
				require_once('views/profitcenters/edit.php'); 	 
			}
			
			
			/*if($profit_center_code!=""){			
										
				$profitcenterlist = $db->query('SELECT count(*) as total FROM profit_centers WHERE profit_center_code = "'.$profit_center_code.'" and company_id = "'.$_SESSION['company_id'].'" ');		
				foreach($profitcenterlist->fetchAll() as $pc) {
					$total = $pc['total'];
				}
						
				if($total>0){
					$pccerror = "Profit Center Code already exist!";				
					require_once('views/profitcenters/edit.php'); 
				}				
			}	*/
											
			
			if($pccerror==""){
			
				$modified_by = $_SESSION['username'];
			   	$modified_ip = $_SERVER['REMOTE_ADDR'];
				$modified    = date("Y-m-d H:i:s"); 
			
				// update query
				$result = $db->query("update profit_centers set profit_center_code = '".$profit_center_code."',  profit_center = '".$profit_center."', address = '".$address."', state = '".$state."', pincode = '".$pincode."', flag='".$flag."', modified_by='".$modified_by."', modified_ip='".$modified_ip."', modified='".$modified."' where company_id = '".$cid."' and id ='".$id."' ");		
							
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}
				header("Location: ?controller=profitcenters&action=index&cid=".$cid."");		
			}
					
		} else {	 
		   require_once('views/profitcenters/edit.php'); 	   
		}  
	  
    }	
	
	// delete
	public function delete() {
		
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
	
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // company id
		
		
		$id = $_GET['id'];	
		$result = $db->query("delete from profit_centers where company_id = '".$cid."' and id ='".$id."' ");		
							
		if(!$result){
			die('Invalid query: ' . mysql_error());
		}	
		
      header("Location: ?controller=profitcenters&action=index&cid=".$cid."");		
    }
		

    public function error() {
      require_once('views/profitcenters/error.php');
    }
  }
?>