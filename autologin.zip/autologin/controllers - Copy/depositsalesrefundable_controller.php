<?php
  class DepositsalesrefundableController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='13' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		$fromdate = date("01/01/Y");
		$todate = date("d/m/Y");
		
		$cond="";
		$customer_id=0;
		$ponumber=0;
		if(isset($_POST['submit'])){
							
			$customer_id = $_POST['customer_id'];
			$ponumber = $_POST['ponumber'];
			
			$cond=" and ds.subcode_id='".$customer_id." '";			
			
		
		}		
		
			
		//and  STR_TO_DATE(ds.PayDate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."'
							
		$depositsaleslist = array();
		$depositsales = $db->query("select ds.PayDate, ds.PoNumber, ds.deposit_amount from deposit_sales_dummy as ds where ds.companyID='".$cid."'  ".$cond." order by ds.PayDate");	
					
		foreach($depositsales->fetchAll() as $ds) {
			$depositsaleslist[] = $ds;
		}  	
		
				
						  
	  require_once('views/depositsalesrefundable/index.php'); 
	  
    }		
	
		
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
		// BANK LIST
		$banklist = array();
		$banks = $db->query("select b.id, bl.bank_name,b.bank_branch from banks as b left join bank_lists as bl on bl.id = b.bank_list_id where b.company_id='".$cid."' and b.subcode_id>0 ");	
		foreach($banks->fetchAll() as $bl) {
			$banklist[] = $bl;
		}  			
			
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='13' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		
		// currency
		$currencylist = array();
		$currency = $db->query("select * from currency where company_id='".$cid."' ");	
		foreach($currency->fetchAll() as $cy) {
			$currencylist[] = $cy;
		}  	
		
					
		
		if($_POST['submit']=="Save"){			
			
			// subcodes
			$subcodes = $db->query("select id, subcode_of from subcodes where description = '".$_POST['customer_id']."' and company_id='".$cid."' ");
			foreach($subcodes->fetchAll() as $scs){
				$subcode_id 	= $scs['id'];	
				$subcode_of 	= $scs['subcode_of'];			
			}
					
							
			$paydate 				= date("d/m/Y");					
			$memo 				= $_POST['memo'];				
			$Currencyrate		= $_POST['exchange_rate'];			
			$Currencycode		= $_POST['currency_code'];			
			$profit_center_id	= $_POST['profit_center_id'];
			$bank_id			= $_POST['bank_id'];
			$amount				= $_POST['amount'];
			$deposit_amount		= $_POST['deposit_amount'];
			
							
			$depositdata =$db->query("insert into deposit_sales_dummy(`PayDate`,`PoNumber`,`companyID`,`bank_id`,`subcode_id`,`deposit_amount`,`Currencyrate`) values('".$paydate."','".$memo."', '".$cid."', '".$bank_id."', '".$subcode_id."', '".$deposit_amount."', '".$Currencyrate."')"); 
				
			if(!$depositdata){
				die('Invalid query: ' . mysql_error());
			}
						
						
						
			$date = date("Y-m-d");
				
								
			// credit
			$depositcreditdata =$db->query("insert into journal_entries(`subcode_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`,`profit_center_id`,`currencycode`,`currencyrate`,`trade_type`) values('".$subcode_id."', '".$cid."', '".$date."', 'Deposit Sales non refund', '".$memo."', '".$deposit_amount."', 'Deposit Sales', '".$profit_center_id."', '".$Currencycode."', '".$Currencyrate."', 'Trade Debtors')"); 
			
			if(!$depositcreditdata){
				die('Invalid query: ' . mysql_error());
			}
			
			// bank subcode
			$bankssubcodes = $db->query("select subcode_id from banks where id = '".$_POST['bank_id']."' and company_id='".$cid."' ");
			foreach($bankssubcodes->fetchAll() as $bk){
				$bank_subcode_id 	= $bk['subcode_id'];					
			}
			
			
			// debit
			$depositdebitdata =$db->query("insert into journal_entries(`subcode_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`,`profit_center_id`) values('".$bank_subcode_id."', '".$cid."', '".$date."', 'Deposit Sales non refund', '".$memo."', '".$deposit_amount."', 'Deposit Sales', '".$profit_center_id."')"); 
			
			if(!$depositdebitdata){
				die('Invalid query: ' . mysql_error());
			}	
			
			
						
			header("Location: ?controller=depositsalesrefundable&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/depositsalesrefundable/create.php'); 	   
		}  
	  
    }		
	

    public function error() {
      require_once('views/depositsalesrefundable/error.php');
    }
  }
?>