<?php
  class ImportreturnproductController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid']; // company id		
		
						  
	  require_once('views/importreturnproduct/index.php'); 
	  
    }	
	
	
	public function create() {    
	  
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid']; // company id		
				
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$_GET['cid']."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
	
		if(isset($_POST['submit'])){
		
			$cid 				= $_POST['cid']; 		
			$created_by 		= $_SESSION['username'];
			$created_ip 		= $_SERVER['REMOTE_ADDR'];
			$created    		= date("Y-m-d H:i:s"); 
			$date 				= date("Y-m-d H:i:s");		
			$currentdate 		= date("Y-m-d");
		
				
																					
			if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
				
				readfile($_FILES['filename']['tmp_name']);
			}
			
			
				
																						
			$handle = fopen($_FILES['filename']['tmp_name'], "r");
			
			$subcode_of = 0;
			
			$master_account_codes 	= "";
			$subcodes				= "";
			$account_types			= "";
			
				
			while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
				$str[]                    = $data;								
			}	
			fclose($handle);
			
			
			
			foreach($str as $key=>$val) {
				foreach($val as $kk=>$v) {
				    $ss=explode('~',$v);
					//echo "<pre>";print_r($ss);	
					$receivedate			= $ss[0];
					$receiptdate			= explode('/',$receivedate);
					$day					= $receiptdate[0];
					$month					= $receiptdate[1];
					$year					= $receiptdate[2];
					$receivedate1			= $year.'-'.$month.'-'.$day;
					$receiveno				= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[1]));
					$amount				    = $ss[2];
					
					$gst                    = 0.06;
					$gstamt                 = $amount*0.06;
					$creditamt              = $amount-$gstamt;
									
					if($receiveno!=""){    // product and payment
							
							$db->query("insert into unattended_gl(date,company_id,account_code,ref,description,debit,credit,status,Invoice_Mode,gst,taxcode,subcode_of,Gstinvdate,totalamount,trade_type,entry_mode) values ('".$receivedate1."','".$cid."','3001/P003','Sales Return
-Credit','".$receiveno."','0.00','".$amount."','0','Sales Return','0','0','64901','".$receivedate1."','".$amount."','Trade Debtors','POS Sales Return') ");
							
							$db->query("insert into unattended_gl(date,company_id,account_code,ref,description,debit,credit,status,Invoice_Mode,gst,taxcode,subcode_of,Gstinvdate,totalamount,trade_type,entry_mode) values ('".$receivedate1."','".$cid."','5100/0000','Sales Return-Debit','".$receiveno."','".$amount."','0.00','0','Sales Return','0','0','64903','".$receivedate1."','".$amount."','Trade Debtors','POS Sales Return') ");
							
							
							/*$db->query("insert into unattended_gl(date,company_id,account_code,ref,description,debit,credit,status,Invoice_Mode,gst,taxcode,subcode_of,Gstinvdate,totalamount,trade_type,entry_mode) values ('".$receivedate1."','".$cid."','4900/1000','Sales Return-Debit','".$receiveno."','".$gstamt."','0.00','0','Sales Return','".$gstamt."','SR','55375','".$receivedate1."','".$amount."','Trade Debtors','POS Sales') ");
							*/
							
							$db->query("insert into unattended_gl(date,company_id,account_code,ref,description,debit,credit,status,Invoice_Mode,gst,taxcode,subcode_of,Gstinvdate,totalamount,trade_type,entry_mode) values ('".$receivedate1."','".$cid."','3001/P003','Sales Return - Debit','".$receiveno."','".$amount."','0.00','0','Sales Return','0','0','64901','".$receivedate1."','".$amount."','Trade Debtors','POS - Sales Return - Payment') ");
							
							
							$db->query("insert into unattended_gl(date,company_id,account_code,ref,description,debit,credit,status,Invoice_Mode,gst,taxcode,subcode_of,Gstinvdate,totalamount,trade_type,entry_mode) values ('".$receivedate1."','".$cid."','3111/0001','Sales Return - Credit','".$receiveno."','0.00','".$amount."','0','Sales Return','0','0','55841','".$receivedate1."','".$amount."','Trade Debtors','POS - Sales Return - Payment') ");
				}
				}
			}	
			
			require_once('views/importreturnproduct/index.php');
		}	
			require_once('views/importreturnproduct/index.php');
		//header("Location: ?controller=importcustomers&action=index&cid=".$cid."");	 
	  
    }		
	
    public function error() {
      require_once('views/importreturnproduct/error.php');
    }
  }
?>