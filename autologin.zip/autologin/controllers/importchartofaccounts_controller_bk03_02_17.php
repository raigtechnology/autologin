<?php
  class ImportchartofaccountsController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
		$cid = $_GET['cid']; // company id		
		
						  
	  require_once('views/importchartofaccounts/index.php'); 
	  
    }	
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		$db = Db::getInstance(); // db connection
				
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$_GET['cid']."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
	
		if(isset($_POST['submit'])){
		
			$cid 				= $_POST['cid']; 		
			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
			
			
			
			if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
				echo "<h1>" . "File ". $_FILES['filename']['name'] ." uploaded successfully." . "</h1>";
				echo "<h2>Displaying contents:</h2>";
				readfile($_FILES['filename']['tmp_name']);
			}
// default chart of accounts start

	//currency part start
$date 					= date("Y-m-d H:i:s");		
$currentdate 			= date("Y-m-d");	
	
									
$insert_currency_qry = $db->query("INSERT INTO `currency` (`company_id`, `source_id`, `source_date`, `updated_date`, `currency_name`, `currency_code`, `exchange_rate`, `created_by`, `created_ip`, `created`) VALUES
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Australian Dollar', 'AUD', '3.05', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Bahraini Dinar', 'BHD', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Brunei Dollar', 'BND', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Burma Kyat', 'BUK', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Canadian Dollar', 'CAD', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Swiss Franc', 'CHF', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Yuan (Chinese) Renminbi', 'CNY', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Hong Kong Dollar', 'HKD', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Indonesian Rupiah', 'IDR', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Indian Rupee', 'INR', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Japanese Yen', 'JPY', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'North Korean Won', 'KPW', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', '(South) Korean Won', 'KRW', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Kuwaiti Dinar', 'KWD', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Sri Lanka Rupee', 'LKR', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Malaysian Ringgit', 'RM', '1.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Nepalese Rupee', 'NPR', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'New Zealand Dollar', 'NZD', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Philippine Peso', 'PHP', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Pakistan Rupee', 'PKR', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Saudi Arabian Riyal', 'SAR', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Singapore Dollar', 'SGD', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'US Dollar', 'USD', '0.00', '".$created_by."', '".$created_ip."', '".$created."'),
('".$cid."', 1, '".$currentdate."', '".$currentdate."', 'Sweedan Pound', 'GBP', '6.00', '".$created_by."', '".$created_ip."', '".$created."')");

// currency part end



$insert_masteraccountcodes_qry = $db->query("INSERT INTO `master_account_codes` (`company_id`, `account_type_id`, `account_code`, `account_desc`, `special_acc`, `depriciation`, `created_ip`, `created`, `created_by`, `modified_ip`, `modified`, `modified_by`) VALUES
('".$cid."', 6, '5000/0000', 'SALES', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 5, '4000/0000', 'CURRENT LIABILITIES', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 7, '7000/0000', 'COST OF SALES', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 13, '3000/0000', 'CURRENT ASSETS', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 1, '1000/0000', 'EQUITY', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 2, '1010/0000', 'CAPITAL', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 3, '4050/0000', 'LONG TERM LIABILITIES', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 4, '2000/0000', 'FIXED ASSETS', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 11, '5500/0000', 'OTHER INCOME', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 12, '9000/0000', 'EXPENSES', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 16, '2800/0000', 'OTHER ASSETS', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 17, '5800/0000', 'SALES ADJUSTMENTS', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1),
('".$cid."', 18, '4080/0000', 'OTHER LIABILITIES', '', NULL, '::1', '".$date."', 1, '::1', '".$date."', 1)");

$mastercodes = $db->query("select id,account_desc,account_code,account_type_id from master_account_codes where company_id='".$cid."' ");					
foreach($mastercodes->fetchAll() as $ms) {		
	if($ms['account_code']=="3000/0000"){
		$currentassetid = $ms['id'];
	} else if($ms['account_code']=="4000/0000"){
		$currentliabilitiesid = $ms['id'];
	} else if($ms['account_code']=="9000/0000"){
		$expensesid = $ms['id'];
	} 
}

/* expenses hardcoded */
$insert_masteraccountcodes_qry = $db->query("INSERT INTO `subcodes` (`master_account_code_id`, `code`, `description`, `company_id`, `flag`, `created_by`, `created_ip`, `created`) VALUES
('".$expensesid."', '9000/0100', 'Employer EPF', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."'),
('".$expensesid."', '9000/0200', 'Employee EPF', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."'),
('".$expensesid."', '9000/0300', 'Employer SOCSO', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."'),
('".$expensesid."', '9000/0400', 'Employee SOCSO', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."'),
('".$expensesid."', '9000/0500', 'Employee PCB', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."'),
('".$expensesid."', '9000/1515', 'Gift and Promotion', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."'),
('".$expensesid."', '9000/2020', 'GST Expenses (Deemed Supply)', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."'),
('".$expensesid."', '9000/5000', 'Salary and Bonus', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."'),
('".$expensesid."', '9000/0020', 'Depreciation', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."')");


$insert_masteraccountcodes_qry = $db->query("INSERT INTO `subcodes` (`master_account_code_id`, `code`, `description`, `company_id`, `flag`, `created_by`, `created_ip`, `created`) VALUES
('".$currentassetid."', '3000/0100', 'Deposit & Prepayment', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentassetid."', '3000/1000', 'Trade Debtors', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4000/1000', 'Trade Creditors', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."')");




$insert_masteraccountcodes_qry = $db->query("INSERT INTO `subcodes` (`master_account_code_id`, `code`, `description`, `company_id`, `flag`, `created_by`, `created_ip`, `created`) VALUES
('".$currentliabilitiesid."', '4900/0000', 'GST OUTPUT & INPUT TAX', '".$cid."', '1', '".$created_by."', '".$created_ip."', '".$created."')");


$gstoutputinput = $db->query("select id from subcodes where company_id='".$cid."' and code='4900/0000' ");					
foreach($gstoutputinput->fetchAll() as $goi) {		
	$gstoutintaxid = $goi['id'];
}


$insert_masteraccountcodes_qry = $db->query("INSERT INTO `subcodes` (`master_account_code_id`, `code`, `description`, `company_id`, `flag`, `subcode_of`, `created_by`, `created_ip`, `created`) VALUES
('".$currentassetid."', '3111/0000', 'BANKS', '".$cid."', '0', '0', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1000', 'GST-OUTPUT-TAX', '".$cid."', '0', '".$gstoutintaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2000', 'GST-INPUT-TAX', '".$cid."', '0', '".$gstoutintaxid."', '".$created_by."', '".$created_ip."', '".$created."')");

$subcodes_tax = $db->query("select id,code,description from subcodes where company_id='".$cid."' ");					
foreach($subcodes_tax->fetchAll() as $st) {								
	if($st['code']=="4900/1000"){
		$outputtaxid = $st['id'];
	} else if($st['code']=="4900/2000"){
		$inputtaxid = $st['id'];
	} 
}


$insert_masteraccountcodes_qry = $db->query("INSERT INTO `subcodes` (`master_account_code_id`, `code`, `description`, `company_id`, `subcode_of`, `created_by`, `created_ip`, `created`) VALUES ('".$currentliabilitiesid."', '4900/1001', 'GST-OUTPUT-TAX-ES', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1002', 'GST-OUTPUT-TAX-GS', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1003', 'GST-OUTPUT-TAX-OS', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1004', 'GST-OUTPUT-TAX-RS', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1005', 'GST-OUTPUT-TAX-SR', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1006', 'GST-OUTPUT-TAX-ZRE', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1007', 'GST-OUTPUT-TAX-ZRL', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1008', 'GST-OUTPUT-TAX-ES43', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1009', 'GST-OUTPUT-TAX-NR', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1010', 'GST-OUTPUT-TAX-DS', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/1011', 'GST-OUTPUT-TAX-AJS', '".$cid."', '".$outputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2001', 'GST-INPUT-TAX-TX', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2002', 'GST-INPUT-TAX-IM', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2003', 'GST-INPUT-TAX-IS', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2004', 'GST-INPUT-TAX-BL', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2005', 'GST-INPUT-TAX-NR', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2006', 'GST-INPUT-TAX-ZP', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2007', 'GST-INPUT-TAX-EP', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2008', 'GST-INPUT-TAX-OP', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2009', 'GST-INPUT-TAX-GP', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2010', 'GST-INPUT-TAX-TXE43', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2011', 'GST-INPUT-TAX-TXN43', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2012', 'GST-INPUT-TAX-TXRE', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."'),
('".$currentliabilitiesid."', '4900/2013', 'GST-INPUT-TAX-AJP', '".$cid."', '".$inputtaxid."', '".$created_by."', '".$created_ip."', '".$created."')");


// end		
		
		
		
			//Import uploaded file to Database
			$handle = fopen($_FILES['filename']['tmp_name'], "r");
			
			$subcode_of = 0;
			
			$master_account_codes 	= "";
			$subcodes				= "";
			$account_types			= "";
			
					
			while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
						
				$master_account_codes 	= $data[0];
				$subcodes				= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($data[1]));
				$account_types			= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($data[2]));
				$business_reg_no		= "";
				$gst_reg_no				= "";
				$country				= "";		
		 				
				if($account_types!=""){	 // first step start
			
						$master_account_types = $db->query("select id, account_code from master_account_codes where company_id='".$cid."' and account_desc='".$master_account_codes."' ");		
						foreach($master_account_types->fetchAll() as $mac) {						
							$master_account_code_id 	= $mac['id'];
						 	$master_account_code 		= $mac['account_code'];	
						}		
											
													
						if($subcodes==""){
								
																			
							if($master_account_codes=="Current Assets" || $master_account_codes=="Current Liabilities"){
														
								$scodes = $db->query("select id, code from subcodes where subcode_of = '0' and company_id='".$cid."' and master_account_code_id='".$master_account_code_id."' order by id desc limit 1 ");		
															
							
							} else {						
								
								$scodes = $db->query("select id, code from subcodes where company_id='".$cid."' and master_account_code_id='".$master_account_code_id."' order by id desc limit 1 ");		
								
							
								
							}																		
							$arr = array();
							foreach($scodes->fetchAll() as $scd) {						
								$scode_id 	= $scd['id'];
								$scode_code	= $scd['code'];	
								
								$arr[] = $scd;
							}	
														
												
							if(count($arr)==0){								
								$acc_prefix	   = substr($master_account_code,0,5);		
								$acc_postfix   = substr($master_account_code,5,8);
							} else {
								$acc_prefix	   = substr($scode_code,0,5);		
								$acc_postfix   = substr($scode_code,5,8);
							}							
							
							
								
							
							$code2 = $acc_postfix;
							$code2++;	
							$code2 = str_pad($code2, 4, '0', STR_PAD_LEFT);
							$account_code 		= $acc_prefix.''.$code2;
							
				
							if($account_code!=""){	
																		
									$subcodes = $db->query("SELECT count(*) as total FROM subcodes WHERE code = '".$account_code."' and company_id = '".$cid."' ");		
									foreach($subcodes->fetchAll() as $sc) {									
										$total = $sc['total'];
									}
													
									if($total>0){
										$acerror = "Account Code already exist!";
										exit;
									} else {
								
										 $master_account_codes = $db->query("select account_type_id from master_account_codes where company_id='".$cid."' and id='".$master_account_code_id."' order by account_code");			
										foreach($master_account_codes->fetchAll() as $mc) {															
											$account_type_id = $mc['account_type_id'];
										}
										
																
										if($account_type_id=="3" || $account_type_id=="5" || $account_type_id=="4" || $account_type_id=="7" || $account_type_id=="12" || $account_type_id=="13"){				
											$flag = 1;										
										} else {
											$flag = 0;												
										}	
																				
																										
										// insert query
										$db->query("insert into subcodes(company_id, code, description, master_account_code_id, flag, created_by, created_ip, created) values ('".$cid."', '".$account_code."', '".$account_types."', '".$master_account_code_id."', '".$flag."') ");	
									
										
										$subcode_for_depre = $db->query("select id from subcodes order by id desc limit 1 ");	
										foreach($subcode_for_depre->fetchAll() as $dp) {																			
											$dp_subcode_of = $dp['id'];
										} 
																					
										if($master_account_codes=='Fixed Assets'){
																			
											$account_code_dep = $account_code.'A';
											$description_dep = $account_types.' - Depreciation';	
											
											$db->query("insert into subcodes(company_id, code, description, master_account_code_id, subcode_of, flag, created_by, created_ip, created) values ('".$cid."', '".$account_code_dep."', '".$description_dep."', '".$master_account_code_id."', '".$dp_subcode_of."', '".$flag."', '".$created_by."', '".$created_ip."', '".$created."') ");
											
											$account_code_dis = $account_code.'B';
											$description_dis = $account_types.' - Disposal';	
											
											$db->query("insert into subcodes(company_id, code, description, master_account_code_id, subcode_of, flag, created_by, created_ip, created) values ('".$cid."', '".$account_code_dis."', '".$description_dis."', '".$master_account_code_id."', '".$dp_subcode_of."', '".$flag."', '".$created_by."', '".$created_ip."', '".$created."') ");
										
										}
										
										
										
										
										
										//header("Location: ?controller=chartofaccounts&action=index&cid=".$cid."&code=".$getcode."&id=".$getid."");			
									}				
								  }	
							}	else if($subcodes=="Trade Debtors"){    // customers
								
									
									$subcode_of=0;
									$debtorscodes = $db->query("select id from subcodes where company_id='".$cid."' and description='Trade Debtors' and master_account_code_id='".$master_account_code_id."' ");	
									foreach($debtorscodes->fetchAll() as $dt) {																	
										$subcode_of = $dt['id'];
									} 
							
									$subtitle = $db->query("select code, description from subcodes where company_id = '".$cid."' and id ='".$subcode_of."'");	
									foreach($subtitle->fetchAll() as $sc) {															
										$sub_account_code 	= $sc['code'];					
										$sub_description 	= $sc['description'];	
									} 
								
									$customer_name				= $account_types;		
									$char = substr($customer_name, 0, 1); // first letter from a string						
															
									// generating autocustomer id
									$subcode_for_autocustomerid = $db->query("select AutoCustomerID from tblcustomer order by AutoCustomerID desc limit 1 ");	
									foreach($subcode_for_autocustomerid->fetchAll() as $aui) {															
										$tblcustomer_autocustomerid = $aui['AutoCustomerID'];
									} 
															
									if($tblcustomer_autocustomerid!=""){
										$customercode = substr($tblcustomer_autocustomerid, 1, 7);
										$customercode++;
										$customercode = str_pad($customercode, 7, '0', STR_PAD_LEFT);
										$customercode = "C".$customercode;
									  
									} else {
										$customercode = "C0000001";   	
									}			
												
									$customercode = strtoupper($customercode);	
							
									// generating autocustomer id end
								
								
									// generating account code for vendor from vendor name					
									$acode = substr($sub_account_code, 0, 4);
									$acode = "$acode/$char";					
																		
									$subcode_foraccount_code = $db->query("select Customer_account_code from tblcustomer where company_id = '".$cid."' and Customer_account_code like '%$acode%'  order by AutoCustomerID desc limit 1 ");	
									foreach($subcode_foraccount_code->fetchAll() as $sac) {														
										$code_for_customer = $sac['Customer_account_code'];
									} 
															
									if($code_for_customer!=""){
										$code2 = substr($code_for_customer, 6, 8);
										$code2++;
										$code2 = str_pad($code2, 3, '0', STR_PAD_LEFT);
										$acc_code = "$acode$code2";
									} else {
										$acc_code = "$acode"."001";   	
									}			
												
									$acc_code = strtoupper($acc_code);						
									// end of generating account code for vendor from vendor name
												
									
									if($country=="MALAYSIA"){
										$country_type = "LOCAL";
									} else {
										$country_type = "FOREIGN";
									}
																		
									$db->query("insert into tblcustomer(AutoCustomerID, Customercode, CompanyName, Customer_account_code, company_id, Business_Regno, GSTRNo, Country_code, Status, CustTradeTYpe) values ('".$customercode."', '".$customercode."', '".$customer_name."', '".$acc_code."', '".$cid."', '".$business_reg_no."', '".$gst_reg_no."', '".$country."', 'A', '".$country_type."') ");						
																
														
									$db->query("insert into subcodes(company_id, code, description, master_account_code_id, subcode_of, created_by, created_ip, created) values ('".$cid."', '".$acc_code."', '".$account_types."', '".$master_account_code_id."', '".$subcode_of."', '".$created_by."', '".$created_ip."', '".$created."') ");	
								
							
							}	else if($subcodes=="Trade Creditors"){  //     vendor table
								
																
								$subcode_of=0;
								$creditorscodes = $db->query("select id from subcodes where company_id='".$cid."' and description='Trade Creditors' and master_account_code_id='".$master_account_code_id."' ");	
								foreach($creditorscodes->fetchAll() as $ct) {																
									$subcode_of = $ct['id'];
								} 
								
									
								$subtitle = $db->query("select code, description from subcodes where company_id = '".$cid."' and id ='".$subcode_of."'");	
								foreach($subtitle->fetchAll() as $sc) {																
									$sub_account_code 	= $sc['code'];					
									$sub_description 	= $sc['description'];	
								} 
										
								$vendor_name	= $account_types;
								$char 			= substr($vendor_name, 0, 1); // first letter from a string						
														
								// generating account code for vendor from vendor name
									
								$acode = substr($sub_account_code, 0, 4);
								$acode = "$acode/$char";					
									
								$subcode_foraccount_code = $db->query("select Vendor_account_code from vendor where company_id = '".$cid."' and Vendor_account_code like '%$acode%'  order by Vendor_ID desc limit 1 ");	
								foreach($subcode_foraccount_code->fetchAll() as $sac) {																			
									$code_for_vendor = $sac['Vendor_account_code'];	
								} 
										
								if($code_for_vendor!=""){
									$code2 = substr($code_for_vendor, 6, 8);
									$code2++;
									$code2 = str_pad($code2, 3, '0', STR_PAD_LEFT);
									$acc_code = "$acode$code2";
								} else {
									$acc_code = "$acode"."001";   	
								}			
												
								$acc_code = strtoupper($acc_code);						
								// end of generating account code for vendor from vendor name
														
								if($country=="MALAYSIA"){
									$country_type = "LOCAL";
								} else {
									$country_type = "FOREIGN";
								}
									
								$db->query("insert into vendor(Vendor_Name, Vendor_account_code, company_id, Business_Regno, GSTRNo, Country_Code, CustTradeTYpe) values ('".$vendor_name."', '".$acc_code."', '".$cid."', '".$business_reg_no."', '".$gst_reg_no."', '".$country."', '".$country_type."') ");										
																
								$db->query("insert into subcodes(company_id, code, description, master_account_code_id, subcode_of, created_by, created_ip, created) values ('".$cid."', '".$acc_code."', '".$account_types."', '".$master_account_code_id."', '".$subcode_of."', '".$created_by."', '".$created_ip."', '".$created."') ");	
								
							
							}	
								/************************ other part end ****************************************/
					} // first step end		
														
				}	
				
			
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Add";
			$window_name     = "Import Chart of Accounts";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
				
					
		
			fclose($handle);
		
			print "Import done";
		
			//view upload form			
			
			header("Location: ?controller=importchartofaccounts&action=index&cid=".$cid."");	
	
		}	
			
		require_once('views/importchartofaccounts/create.php'); 	 
	  
    }		
			

    public function error() {
      require_once('views/importchartofaccounts/error.php');
    }
  }
?>