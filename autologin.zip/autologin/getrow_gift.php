<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}	 
		
	$master_account_codes = $db->query("select id, description from subcodes where master_account_code_id = '".$_GET['value1']."' and company_id = '".$_GET['company_id']."' and IsCategory='N' order by description asc ");	
	?>	
	<select name="data[<?php echo $_GET['value2']; ?>][subcode_id]" id="subcode_id<?php echo $_GET['value2'];?>"  class="selectbox_small" required="required">
		<option value="">-- Choose --</option>
		<?php
		foreach($master_account_codes->fetchAll() as $mac) {
		?>
		<option value="<?php echo $mac['id']; ?>"><?php echo $mac['description']; ?></option>			
		<?php
		}
		?>
	</select>
