<?php
  class BalancesheetController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode,company_image  FROM companies where id ="'.$cid.'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
			$company_image = $com['company_image'];
		} 
		
		
		
		$currentyear 				= date("Y");
		$currentmonth 				= date("m");
		/*$currentyeardate			= date("Y-12-31");	
		$lastyear 					= date("Y", strtotime($currentyeardate))-1;
		$lastyeardate 				= date($lastyear.'-12-31');
				
		$monthfromdate 				= date("Y-m-01");		
		$yearfromdate 				= date("Y-01-01");	*/
					
		$profitcenter="";		
		$gsttaxcode = "";	
		
		$mas1 = $db->query('SELECT current_yr_from_date,ls_yr_closing_date FROM accounting_year where company_id ="'.$cid.'" and YEAR(current_yr_to_date)>="'.$currentyear.'" ');    	
		foreach($mas1->fetchAll() as $mm1) {
			$lastyeardate    = $mm1['ls_yr_closing_date'];
		    $currentyeardate = $mm1['current_yr_from_date'];
		} 
		
		
		
		
		if(isset($_POST['submit'])){				
		
			$currentyear 				= date("Y", strtotime($_POST['from_date']));
			$currentmonth				= date("m", strtotime($_POST['from_date']));
			/*$currentyeardate1			= date($currentyear."-12-31");	
			$currentyeardate			= date("Y-m-d", strtotime($_POST['from_date']));
			$lastyear 					= date("Y", strtotime($currentyeardate))-1;
			$lastyeardate 				= date($lastyear.'-12-31');*/
			$currentyeardate            = date('Y-m-d',strtotime($_POST['from_date']));	
					
			//echo 'SELECT current_yr_from_date,ls_yr_closing_date  FROM accounting_year where company_id ="'.$cid.'" and YEAR(current_yr_to_date)<="'.$currentyear.'" ';
			$mas1 = $db->query('SELECT current_yr_from_date,ls_yr_closing_date  FROM accounting_year where company_id ="'.$cid.'" and YEAR(current_yr_to_date)>="'.$currentyear.'" ');    
			foreach($mas1->fetchAll() as $mm1) {
				$lastyeardate    = $mm1['ls_yr_closing_date'];
			} 
		
		}
					
					
					$monthfromdate 				= date("Y-m-01", strtotime($_POST['from_date']));		
					$yearfromdate 				= date($currentyear."-01-01", strtotime($_POST['from_date']));	
			
					$previousdate = date('Y-m-d', strtotime('-1 day', strtotime($monthfromdate)));  
					
					
					// for gst 					
					$gstbalance = $db->query("SELECT aa.AdjustmentRecovered as balance, aa.TaxCode FROM annualadjustment as aa WHERE aa.company_id = ".$cid." AND STR_TO_DATE(aa.PeriodTo,'%d/%m/%Y') BETWEEN '1111-11-11' AND '".$previousdate."' ");								
								
					foreach($gstbalance->fetchAll() as $gs) {
						 
						 if($gs['TaxCode']=="AJS"){
						 	 $gst_balance1 = -abs($gs['balance']);				
						 } else  if($gs['TaxCode']=="AJP"){
						 	 $gst_balance2 = $gs['balance'];				
						 } 
						 
						 $gsttaxcode = $gs['TaxCode'];
					}	
		
		
		
		
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code from subcodes as sc  where sc.company_id=".$cid." order by sc.description asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 
		
		/******************* fixed Assets START  ****/
		
		$fixedassets_subcodesList = array();		
		$fixedassets_subcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 4 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($fixedassets_subcodes->fetchAll() as $fasc) {
			$fixedassets_subcodesList[] = $fasc;
		} 		
		
		$fixedassets_Array = array();		
		$si=0;
		foreach($fixedassets_subcodesList as $fascl){
						
			$description = $fascl['description'];						
						
			$fixedassets_openingbalance_currentyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 4 and op.company_id = ".$cid." and sc.id = '".$fascl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($fixedassets_openingbalance_currentyear->fetchAll() as $faop_currentyear) {
				$fixedassets_op_balance_currentyear = $faop_currentyear['balance'];
			} 		
			
			$fixedassets_openingbalance_lastyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 4 and op.company_id = ".$cid." and sc.id = '".$fascl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($fixedassets_openingbalance_lastyear->fetchAll() as $faop_lastyear) {
				$fixedassets_op_balance_lastyear = $faop_lastyear['balance'];
			} 		
			
				
						
			$fixedassets_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$fascl['id']."' and mac.account_type_id = 4 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($fixedassets_currentyeargibalance->fetchAll() as $faygi) {
				$fixedassets_currentyearbalance = $faygi['balance'];				
			}
						
			
			$fixedassets_lastyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$fascl['id']."' and mac.account_type_id = 4 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($fixedassets_lastyeargibalance->fetchAll() as $famgi) {
				$fixedassets_lastyearbalance = $famgi['balance'];				
			}								
			
			$fixedassets_Array[$si]['description'] = $description;
			$fixedassets_Array[$si]['currentyearbalance'] = $fixedassets_op_balance_currentyear + $fixedassets_currentyearbalance;
			$fixedassets_Array[$si]['lastyearbalance'] = $fixedassets_op_balance_lastyear + $fixedassets_lastyearbalance;
						
			$si++;	
		}
				
		/******************* fixed assets END  ****/	
		
		/******************* other Assets START  ****/
		
		$otherassets_subcodesList = array();		
		$otherassets_subcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 16 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($otherassets_subcodes->fetchAll() as $fasc) {
			$otherassets_subcodesList[] = $fasc;
		} 		
		
		$otherassets_Array = array();		
		$si=0;
		foreach($otherassets_subcodesList as $fascl){
						
			$description = $fascl['description'];						
						
			$otherassets_openingbalance_currentyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 16 and op.company_id = ".$cid." and sc.id = '".$fascl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($otherassets_openingbalance_currentyear->fetchAll() as $faop_currentyear) {
				$otherassets_op_balance_currentyear = $faop_currentyear['balance'];
			} 	
			
			$otherassets_openingbalance_lastyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 16 and op.company_id = ".$cid." and sc.id = '".$fascl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($otherassets_openingbalance_lastyear->fetchAll() as $faop_lastyear) {
				$otherassets_op_balance_lastyear = $faop_lastyear['balance'];
			} 	
			
		
						
			$otherassets_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$fascl['id']."' and mac.account_type_id = 16 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($otherassets_currentyeargibalance->fetchAll() as $faygi) {
				$otherassets_currentyearbalance = $faygi['balance'];				
			}
			
			$otherassets_lastyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$fascl['id']."' and mac.account_type_id = 16 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($otherassets_lastyeargibalance->fetchAll() as $famgi) {
				$otherassets_lastyearbalance = $famgi['balance'];				
			}								
			
			$otherassets_Array[$si]['description'] = $description;
			$otherassets_Array[$si]['currentyearbalance'] = $otherassets_op_balance_currentyear + $otherassets_currentyearbalance;
			$otherassets_Array[$si]['lastyearbalance'] = $otherassets_op_balance_lastyear + $otherassets_lastyearbalance;
						
			$si++;	
		}
				
		/******************* other assets END  ****/
		
		/******************* Current Assets START  ****/
		
		$currentassets_subcodesList = array();		
		$currentassets_subcodes = $db->query("SELECT sc.id, sc.description, sc.subcode_of FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 13 and sc.company_id = ".$cid." and sc.subcode_of not in(select id from subcodes where (description='Trade Debtors' OR description='GST-OUTPUT-TAX' OR description='GST-INPUT-TAX') and company_id='".$cid."') and sc.id not in(select id from subcodes where (description='GST-OUTPUT-TAX' OR description='GST-INPUT-TAX') and company_id='".$cid."') and mac.company_id=".$cid." and sc.description not in('Trade Debtors') ORDER BY  sc.id ASC");		
		foreach($currentassets_subcodes->fetchAll() as $casc) {
			$currentassets_subcodesList[] = $casc;
		} 		
		
		$currentassets_Array = array();		
		$si=0;
		foreach($currentassets_subcodesList as $cascl){
						
			$description = $cascl['description'];	
			$subcode_of = $cascl['subcode_of'];						
						
			$currentassets_openingbalance_currentyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 13 and op.company_id = ".$cid." and sc.id = '".$cascl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($currentassets_openingbalance_currentyear->fetchAll() as $caop_currentyear) {
				$currentassets_op_balance_currentyear = $caop_currentyear['balance'];
			} 		
					
			$currentassets_openingbalance_lastyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 13 and op.company_id = ".$cid." and sc.id = '".$cascl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($currentassets_openingbalance_lastyear->fetchAll() as $caop_lastyear) {
				$currentassets_op_balance_lastyear = $caop_lastyear['balance'];
			} 			
									
		
						
			$currentassets_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cascl['id']."' and mac.account_type_id = 13 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($currentassets_currentyeargibalance->fetchAll() as $caygi) {
				$currentassets_currentyearbalance = $caygi['balance'];				
			}
			
			$currentassets_lastyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cascl['id']."' and mac.account_type_id = 13 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($currentassets_lastyeargibalance->fetchAll() as $camgi) {
				$currentassets_lastyearbalance = $camgi['balance'];				
			}								
			
			$currentassets_Array[$si]['description'] = $description;
			$currentassets_Array[$si]['subcode_of'] = $subcode_of;
			$currentassets_Array[$si]['currentyearbalance'] = $currentassets_op_balance_currentyear + $currentassets_currentyearbalance;
			//$currentassets_Array[$si]['currentyearbalance'] = $currentassets_currentyearbalance;
			$currentassets_Array[$si]['lastyearbalance'] = $currentassets_op_balance_lastyear + $currentassets_lastyearbalance;
						
			$si++;	
		}
			
			
// current asset trade debtors list start			
			
			
		$tradedebtors_subcodesList = array();		
		$tradedebtors_subcodes = $db->query("SELECT sc.id, sc.description, sc.subcode_of FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 13 and sc.company_id = ".$cid." and sc.subcode_of in(select id from subcodes where description='Trade Debtors' and company_id='".$cid."') and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($tradedebtors_subcodes->fetchAll() as $tdbt) {
			$tradedebtors_subcodesList[] = $tdbt;
		} 		
		
		$tradedebtors_Array = array();		
		$si=0;
		foreach($tradedebtors_subcodesList as $tdbt1){
						
			$description = $tdbt1['description'];	
			$subcode_of = $tdbt1['subcode_of'];						
						
			$tradedebtors_openingbalance_currentyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 13 and op.company_id = ".$cid." and sc.id = '".$tdbt1['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($tradedebtors_openingbalance_currentyear->fetchAll() as $tdbop_currentyear) {
				$tradedebtors_op_balance_currentyear = $tdbop_currentyear['balance'];
			} 
			
			$tradedebtors_openingbalance_lastyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 13 and op.company_id = ".$cid." and sc.id = '".$tdbt1['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($tradedebtors_openingbalance_lastyear->fetchAll() as $tdbop_lastyear) {
				$tradedebtors_op_balance_lastyear = $tdbop_lastyear['balance'];
			} 
			
						
			$tradedebtors_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$tdbt1['id']."' and mac.account_type_id = 13 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($tradedebtors_currentyeargibalance->fetchAll() as $tdbgi) {
				$tradedebtors_currentyearbalance = $tdbgi['balance'];				
			}
			
				
			
			$tradedebtors_lastyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$tdbt1['id']."' and mac.account_type_id = 13 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($tradedebtors_lastyeargibalance->fetchAll() as $tbdyi) {
				$tradedebtors_lastyearbalance = $tbdyi['balance'];				
			}								
			
			$tradedebtors_Array[$si]['description'] = $description;
			$tradedebtors_Array[$si]['subcode_of'] = $subcode_of;
			$tradedebtors_Array[$si]['currentyearbalance'] = $tradedebtors_op_balance_currentyear + $tradedebtors_currentyearbalance;
			//$tradedebtors_Array[$si]['currentyearbalance'] = $tradedebtors_currentyearbalance;
			$tradedebtors_Array[$si]['lastyearbalance'] = $tradedebtors_op_balance_lastyear + $tradedebtors_lastyearbalance;
						
			$si++;	
		}
					
			
			
// current asset trade debtors list end			
			
			
				
		/******************* current assets END  ****/		
				
		/******************* current liabilities START  ****/
		
		$currentliabilitiessubcodesList = array();		
		$currentliabilitiessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 5 and sc.company_id = ".$cid." and sc.subcode_of not in(select id from subcodes where (description='Trade Creditors' OR description='GST-INPUT-TAX' OR description='GST-OUTPUT-TAX') and company_id='".$cid."') and sc.id not in(select id from subcodes where (description='GST-INPUT-TAX' OR description='GST-OUTPUT-TAX') and company_id='".$cid."') and mac.company_id=".$cid." and sc.description not in('Trade Creditors') ORDER BY  sc.id ASC");		
		foreach($currentliabilitiessubcodes->fetchAll() as $clsc) {
			$currentliabilitiessubcodesList[] = $clsc;
		} 		
		
		$currentliabilitiesArray = array();		
		$csi=0;
		foreach($currentliabilitiessubcodesList as $clcl){
						
			$description = $clcl['description'];					
			
			// opening balance
			$currentliabilities_openingbalance_currentyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 5 and op.company_id = ".$cid." and sc.id = '".$clcl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($currentliabilities_openingbalance_currentyear->fetchAll() as $clop_currentyear) {
				$currentliabilities_op_balance_currentyear = $clop_currentyear['balance'];
			} 
			
			$currentliabilities_openingbalance_lastyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 5 and op.company_id = ".$cid." and sc.id = '".$clcl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($currentliabilities_openingbalance_lastyear->fetchAll() as $clop_lastyear) {
				$currentliabilities_op_balance_lastyear = $clop_lastyear['balance'];
			} 
			
					
			
			$currentliabilities_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$clcl['id']."' and mac.account_type_id = 5 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($currentliabilities_currentyeargibalance->fetchAll() as $clygi) {
				$currentliabilities_currentyearbalance = $clygi['balance'];
			}
			
						
			$currentliabilities_lastyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$clcl['id']."' and mac.account_type_id = 5 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($currentliabilities_lastyeargibalance->fetchAll() as $clmgi) {
				$currentliabilities_lastyearbalance = $clmgi['balance'];				
			}
				
			$currentliabilitiesArray[$csi]['description'] = $description;
			$currentliabilitiesArray[$csi]['currentyearbalance'] = $currentliabilities_op_balance_currentyear + $currentliabilities_currentyearbalance;
			//$currentliabilitiesArray[$csi]['currentyearbalance'] = $currentliabilities_currentyearbalance;
			$currentliabilitiesArray[$csi]['lastyearbalance'] = $currentliabilities_op_balance_lastyear + $currentliabilities_lastyearbalance;
			
										
			$csi++;
		}		
		
		
		
		// current asset trade debtors list start			
			
			
		$tradecreditors_subcodesList = array();		
		$tradecreditors_subcodes = $db->query("SELECT sc.id, sc.description, sc.subcode_of FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 5 and sc.company_id = ".$cid." and sc.subcode_of in(select id from subcodes where description='Trade Creditors' and company_id='".$cid."') and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($tradecreditors_subcodes->fetchAll() as $tcdt) {
			$tradecreditors_subcodesList[] = $tcdt;
		} 		
		
		$tradecreditors_Array = array();		
		$si=0;
		foreach($tradecreditors_subcodesList as $tcdt1){
						
			$description = $tcdt1['description'];	
			$subcode_of = $tcdt1['subcode_of'];						
						
			$tradecreditors_openingbalance_currentyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 5 and op.company_id = ".$cid." and sc.id = '".$tcdt1['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."')  ORDER BY `op`.`subcode_id` ASC");		
			foreach($tradecreditors_openingbalance_currentyear->fetchAll() as $tdbop_currentyear) {
				$tradecreditors_op_balance_currentyear = $tdbop_currentyear['balance'];
			} 
			
			$tradecreditors_openingbalance_lastyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 5 and op.company_id = ".$cid." and sc.id = '".$tcdt1['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($tradecreditors_openingbalance_lastyear->fetchAll() as $tdbop_lastyear) {
				$tradecreditors_op_balance_lastyear = $tdbop_lastyear['balance'];
			} 
			
						
			$tradecreditors_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$tcdt1['id']."' and mac.account_type_id = 5 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($tradecreditors_currentyeargibalance->fetchAll() as $tdbgi) {
				$tradecreditors_currentyearbalance = $tdbgi['balance'];				
			}
			
				
			
			$tradecreditors_lastyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$tcdt1['id']."' and mac.account_type_id = 5 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($tradecreditors_lastyeargibalance->fetchAll() as $tbdyi) {
				$tradecreditors_lastyearbalance = $tbdyi['balance'];				
			}								
			
			$tradecreditors_Array[$si]['description'] = $description;
			$tradecreditors_Array[$si]['subcode_of'] = $subcode_of;
			$tradecreditors_Array[$si]['currentyearbalance'] = $tradecreditors_op_balance_currentyear + $tradecreditors_currentyearbalance;
			//$tradecreditors_Array[$si]['currentyearbalance'] = $tradecreditors_currentyearbalance;
			$tradecreditors_Array[$si]['lastyearbalance'] = $tradecreditors_op_balance_lastyear + $tradecreditors_lastyearbalance;
						
			$si++;	
		}
		
					
		
		
				
		/******************* current liabilities END  ****/		
		
		/******************* capital START  ****/
		
		$capital_subcodesList = array();		
		$capital_subcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 2 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($capital_subcodes->fetchAll() as $csc) {
			$capital_subcodesList[] = $csc;
		}				 		
		
		$capital_Array = array();		
		$csi=0;
		foreach($capital_subcodesList as $ccl){
						
			$description = $ccl['description'];					
			
			// opening balance
			$capital_openingbalance_currentyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 2 and op.company_id = ".$cid." and sc.id = '".$ccl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($capital_openingbalance_currentyear->fetchAll() as $cyop_currentyear) {
				$capital_op_balance_currentyear = $cyop_currentyear['balance'];
			} 	
			
			$capital_openingbalance_lastyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 2 and op.company_id = ".$cid." and sc.id = '".$ccl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($capital_openingbalance_lastyear->fetchAll() as $cyop_lastyear) {
				$capital_op_balance_lastyear = $cyop_lastyear['balance'];
			} 	
			
							
			
			$capital_currentyear_gibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ccl['id']."' and mac.account_type_id = 2 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($capital_currentyear_gibalance->fetchAll() as $cygi) {
				$capital_currentyear_balance = $cygi['balance'];
			}
			
			$capital__lastyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ccl['id']."' and mac.account_type_id = 2 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($capital__lastyeargibalance->fetchAll() as $lygi) {			
				$capital_lastyear_balance = $lygi['balance'];				
			}							
				
			
				
						
			$capital_Array[$csi]['description'] = $description;
			$capital_Array[$csi]['currentyearbalance'] = $capital_op_balance_currentyear + $capital_currentyear_balance;
			$capital_Array[$csi]['lastyearbalance'] = $capital_op_balance_lastyear + $capital_lastyear_balance;
			
			$csi++;
		}		
					
		/******************* capital END  ****/	
		
				
				
		/******************* long term liabilities START  ****/
		
		$longtermliabilities_subcodesList = array();		
		$longtermliabilities_subcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 3 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($longtermliabilities_subcodes->fetchAll() as $esc) {
			$longtermliabilities_subcodesList[] = $esc;
		}				 		
		
		$longtermliabilities_Array = array();		
		$csi=0;
		foreach($longtermliabilities_subcodesList as $ecl){
						
			$description = $ecl['description'];					
			
			// opening balance
			$longtermliabilities_openingbalance_currentyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 3 and op.company_id = ".$cid." and sc.id = '".$ecl['id']."'   AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($longtermliabilities_openingbalance_currentyear->fetchAll() as $eop_currentyear) {
				$longtermliabilities_op_balance_currentyear = $eop_currentyear['balance'];
			} 	
			
			$longtermliabilities_openingbalance_lastyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 3 and op.company_id = ".$cid." and sc.id = '".$ecl['id']."'  AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($longtermliabilities_openingbalance_lastyear->fetchAll() as $eop_lastyear) {
				$longtermliabilities_op_balance_lastyear = $eop_lastyear['balance'];
			} 				
					
			
			$longtermliabilities__yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 3 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($longtermliabilities__yeargibalance->fetchAll() as $eygi) {
				$longtermliabilities_yearbalance = $eygi['balance'];
			}
			
			$longtermliabilities__monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 3 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($longtermliabilities__monthgibalance->fetchAll() as $emgi) {			
				$longtermliabilities_monthbalance = $emgi['balance'];				
			}							
						
			$longtermliabilities_Array[$csi]['description'] = $description;
			$longtermliabilities_Array[$csi]['currentyearbalance'] = $longtermliabilities_op_balance_currentyear + $longtermliabilities_yearbalance;
			$longtermliabilities_Array[$csi]['lastyearbalance'] = $longtermliabilities_op_balance_lastyear + $longtermliabilities_monthbalance;
			
			$csi++;
		}		
					
		/******************* long term liabilities END  ****/	
		
		/******************* other liabilities START  ****/
		
		$otherliabilities_subcodesList = array();		
		$otherliabilities_subcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 18 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($otherliabilities_subcodes->fetchAll() as $esc) {
			$otherliabilities_subcodesList[] = $esc;
		}				 		
		
		$otherliabilities_Array = array();		
		$csi=0;
		foreach($otherliabilities_subcodesList as $ecl){
						
			$description = $ecl['description'];					
			
			// opening balance
			$otherliabilities_openingbalance_currentyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 18 and op.company_id = ".$cid." and sc.id = '".$ecl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($otherliabilities_openingbalance_currentyear->fetchAll() as $eop_currentyear) {
				$otherliabilities_op_balance_currentyear = $eop_currentyear['balance'];
			} 	
			
			$otherliabilities_openingbalance_lastyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 18 and op.company_id = ".$cid." and sc.id = '".$ecl['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($otherliabilities_openingbalance_lastyear->fetchAll() as $eop_lastyear) {
				$otherliabilities_op_balance_lastyear = $eop_lastyear['balance'];
			} 	
			
			
			$otherliabilities__yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 18 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($otherliabilities__yeargibalance->fetchAll() as $eygi) {
				$otherliabilities__yearbalance = $eygi['balance'];
			}
			
			$otherliabilities__monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 18 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($otherliabilities__monthgibalance->fetchAll() as $emgi) {			
				$otherliabilities__monthbalance = $emgi['balance'];				
			}							
						
			$otherliabilities_Array[$csi]['description'] = $description;
			$otherliabilities_Array[$csi]['currentyearbalance'] = $otherliabilities_op_balance_currentyear + $otherliabilities__yearbalance;
			$otherliabilities_Array[$csi]['lastyearbalance'] = $otherliabilities_op_balance_lastyear + $otherliabilities__monthbalance;
			
			$csi++;
		}		
					
		/******************* other liabilities END  ****/
		
		
		
		/******************* SALES START  ****/
		
		$salessubcodesList = array();		
		$salessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($salessubcodes->fetchAll() as $ssc) {
			$salessubcodesList[] = $ssc;
		} 		
		
		$salesArray = array();		
		$si=0;
		foreach($salessubcodesList as $scl){
						
			$description = $scl['description'];						
						
			$openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and op.company_id = ".$cid." and sc.id = '".$scl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($openingbalance->fetchAll() as $op) {
				$op_balance = $op['balance'];
			} 		
						
			$sales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_yeargibalance->fetchAll() as $sygi) {
				$sales_yearbalance = $sygi['balance'];				
			}
			
			$sales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_monthgibalance->fetchAll() as $smgi) {
				$sales_monthbalance = $smgi['balance'];				
			}								
			
			$salesArray[$si]['description'] = $description;
			$salesArray[$si]['yearbalance'] = $op_balance + $sales_yearbalance;
			$salesArray[$si]['monthbalance'] = $op_balance + $sales_monthbalance;
						
			$si++;	
		}
					
				
		/******************* SALES END  ****/		
				
		/******************* COST OF SALES START  ****/
		
		$costofsalessubcodesList = array();		
		$costofsalessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($costofsalessubcodes->fetchAll() as $cssc) {
			$costofsalessubcodesList[] = $cssc;
		} 		
		
		$costofsalesArray = array();		
		$csi=0;
		foreach($costofsalessubcodesList as $cscl){
						
			$description = $cscl['description'];					
			
			// opening balance
			$costofsales_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and op.company_id = ".$cid." and sc.id = '".$cscl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($costofsales_openingbalance->fetchAll() as $csop) {
				$costofsales_op_balance = $csop['balance'];
			} 
			
			$costofsales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_yeargibalance->fetchAll() as $csygi) {
				$costofsales_yearbalance = $csygi['balance'];
			}
			
			$costofsales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_monthgibalance->fetchAll() as $csmgi) {
				$costofsales_monthbalance = $csmgi['balance'];				
			}
				
			$costofsalesArray[$csi]['description'] = $description;
			$costofsalesArray[$csi]['yearbalance'] = $costofsales_op_balance + $costofsales_yearbalance;
			$costofsalesArray[$csi]['monthbalance'] = $costofsales_op_balance + $costofsales_monthbalance;
							
			$csi++;
		}		
			
		
				
		/******************* COST OF SALES END  ****/		
				
				
		/******************* EXPENSES START  ****/
		
		$expensessubcodesList = array();		
		$expensessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($expensessubcodes->fetchAll() as $esc) {
			$expensessubcodesList[] = $esc;
		}				 		
		
		$expensesArray = array();		
		$csi=0;
		foreach($expensessubcodesList as $ecl){
						
			$description = $ecl['description'];					
			
			// opening balance
			$expenses_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and op.company_id = ".$cid." and sc.id = '".$ecl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($expenses_openingbalance->fetchAll() as $eop) {
				$expenses_op_balance = $eop['balance'];
			} 	
			
			
			$expenses_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_yeargibalance->fetchAll() as $eygi) {
				$expenses_yearbalance = $eygi['balance'];
			}
			
			$expenses_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_monthgibalance->fetchAll() as $emgi) {			
				$expenses_monthbalance = $emgi['balance'];				
			}							
						
			$expensesArray[$csi]['description'] = $description;
			$expensesArray[$csi]['currentyearbalance'] = $expenses_op_balance + $expenses_yearbalance;
			$expensesArray[$csi]['lastyearbalance'] = $expenses_op_balance + $expenses_monthbalance;
			
			$csi++;
		}		
		
	
				
		/******************* EXPENSES END  ****/
		
	
					
/******************* Current Assets START  ****/
		$master_account_codes1 = $db->query("select id as mid, account_desc from master_account_codes where company_id=".$cid." order by account_code");				
		
		foreach($master_account_codes1->fetchAll() as $maclist) {
			
			if($maclist['account_desc']=="CURRENT ASSETS"){
				$currentassetid = $maclist['mid'];
			} 
			if($maclist['account_desc']=="CURRENT LIABILITIES"){
				$currentliabilitiesid = $maclist['mid'];
			} 
			
		}		
		
		// for output tax
		$subcodesList = array();		
		$subcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$currentassetid."'
									and sc.subcode_of in (select id from subcodes where description ='GST-OUTPUT-TAX')
								order by sc.code asc");	
									
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		}	
		
		$outputtaxdata = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX' and company_id='".$cid."' ");
		foreach($outputtaxdata->fetchAll() as $ot){
			$outputtax_id 			= $ot['id'];									
		}
		
				
		// for sales tax codes
	
		$salestax_year = $db->query("select sum(credit) as credit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." and je.subcode_id ='".$outputtax_id."' and je.date >= '1111-11-11' AND je.date <= '".$currentyeardate."' order by je.memo,je.date ");
		
		foreach($salestax_year->fetchAll() as $st_year) {
			$outputtax_currentyear = $st_year['credit'];
		}		
	
		
		// month		
		$salestax_month = $db->query("select sum(credit) as credit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." and je.subcode_id='".$outputtax_id."' and je.date >= '1111-11-11' AND je.date <= '".$lastyeardate."' order by je.memo,je.date ");
		
		foreach($salestax_month->fetchAll() as $st_month) {
			$outputtax_lastyear = $st_month['credit'];
		}		
		
			
		if($gsttaxcode=="AJS"){				
			 $outputtax_lastyear = $outputtax_lastyear + $gst_balance1;
		} 
					
		
				
		// for input tax		
		$psubcodesList = array();		
		$psubcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$currentliabilitiesid."'
									and sc.subcode_of in (select id from subcodes where description ='GST-INPUT-TAX')
								order by sc.code asc");	
									
		foreach($psubcodes->fetchAll() as $psc) {
			$psubcodesList[] = $psc;
		}	
				
		// for sales tax codes
		$inputtaxdata = $db->query("select id from subcodes where description = 'GST-INPUT-TAX' and company_id='".$cid."' ");
		foreach($inputtaxdata->fetchAll() as $ot){
			$inputtax_id 			= $ot['id'];									
		}
		
		// for purchase tax codes
		$purchasetax_year = $db->query("select sum(debit) as debit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." and je.subcode_id='".$inputtax_id."' and je.date >= '1111-11-11' AND je.date <= '".$currentyeardate."' order by je.memo,je.date ");
		
		foreach($purchasetax_year->fetchAll() as $pt_year) {
			$inputtax_currentyear = $pt_year['debit'];
		}			
		
		// month wise		
		$purchasetax_month = $db->query("select sum(debit) as debit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." and je.subcode_id='".$inputtax_id."' and je.date >= '1111-11-11' AND je.date <= '".$lastyeardate."' order by je.memo,je.date ");
		
		foreach($purchasetax_month->fetchAll() as $pt_month) {
			$inputtax_lastyear = $pt_month['debit'];
		}	
			
		if($gsttaxcode=="AJP"){
			$inputtax_lastyear = $inputtax_lastyear + $gst_balance1;
		} 	
				
		
		/******************************************************************************************************************************************************************/	

/******************* SALES START  ****/
		
		$salessubcodesList_retained = array();		
		$salessubcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($salessubcodes_retained->fetchAll() as $ssc_retained) {
			$salessubcodesList_retained[] = $ssc_retained;
		} 		
		
		
		
				
		$salesArray_retained = array();		
		$si_retained=0;
		foreach($salessubcodesList_retained as $scl_retained){
						
			$description_retained = $scl_retained['description'];						
						
			$openingbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and op.company_id = ".$cid." and sc.id = '".$scl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($openingbalance_retained->fetchAll() as $op_retained) {
				$op_balance_retained = $op_retained['balance'];
			} 
								
		
						
			$sales_currentyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl_retained['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_currentyeargibalance_retained->fetchAll() as $sygi_retained) {
				 $sales_currentyearbalance_retained = $sygi_retained['balance'];				
			}
							
			$sales_lastyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl_retained['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid."  AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_lastyeargibalance_retained->fetchAll() as $smgi_retained) {
				 $sales_lastyearbalance_retained = $smgi_retained['balance'];				
			}					
									
			$salesArray_retained[$si_retained]['description'] = $description_retained;
			$salesArray_retained[$si_retained]['currentyearbalance'] = $op_balance_retained + $sales_currentyearbalance_retained;
			$salesArray_retained[$si_retained]['lastyearbalance'] = $op_balance_retained + $sales_lastyearbalance_retained;
						
			$si_retained++;	
		}
			
								
				
		/******************* SALES END  ****/	
			
				
		
		/******************* SALES ADJUSTMENT START  ****/
		
		$salesadjustmentsubcodesList_retained = array();		
		$salesadjustmentsubcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 17 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($salesadjustmentsubcodes_retained->fetchAll() as $sasc_retained) {
			$salesadjustmentsubcodesList_retained[] = $sasc_retained;
		} 		
		
		$salesadjustmentArray_retained = array();		
		$sai_retained=0;
		foreach($salesadjustmentsubcodesList_retained as $sacl_retained){
						
			$description_retained = $sacl_retained['description'];						
						
			$salesadjustmentopeningbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 17 and op.company_id = ".$cid." and sc.id = '".$sacl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($salesadjustmentopeningbalance_retained->fetchAll() as $saop_retained) {
				$salesadjustmentop_balance_retained = $saop_retained['balance'];
			} 	
									

						
			$salesadjustment_currentyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$sacl_retained['id']."' and mac.account_type_id = 17 and je.company_id = ".$cid."  AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($salesadjustment_currentyeargibalance_retained->fetchAll() as $saygi_retained) {
				$salesadjustment_currentyearbalance_retained = $saygi_retained['balance'];				
			}
			
			$salesadjustment_lastyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$sacl_retained['id']."' and mac.account_type_id = 17 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($salesadjustment_lastyeargibalance_retained->fetchAll() as $samgi_retained) {
				$salesadjustment_lastyearbalance_retained = $samgi_retained['balance'];				
			}								
			
			$salesadjustmentArray_retained[$sai_retained]['description'] = $description_retained;
			$salesadjustmentArray_retained[$sai_retained]['currentyearbalance'] = $salesadjustmentop_balance_retained + $salesadjustment_currentyearbalance_retained;
			$salesadjustmentArray_retained[$sai_retained]['lastyearbalance'] = $salesadjustmentop_balance_retained + $salesadjustment_lastyearbalance_retained;
						
			$sai_retained++;	
		}
				
		/******************* SALES ADJUSTMENT END  ****/
			
				
		/******************* COST OF SALES START  ****/
		
		$costofsalessubcodesList_retained = array();		
		$costofsalessubcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($costofsalessubcodes_retained->fetchAll() as $cssc_retained) {
			$costofsalessubcodesList_retained[] = $cssc_retained;
		} 
		
					
		
		$costofsalesArray_retained = array();		
		$csi_retained=0;
		foreach($costofsalessubcodesList_retained as $cscl_retained){
						
			$description_retained = $cscl_retained['description'];					
			
			// opening balance
			$costofsales_openingbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and op.company_id = ".$cid." and sc.id = '".$cscl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($costofsales_openingbalance_retained->fetchAll() as $csop_retained) {
				$costofsales_op_balance_retained = $csop_retained['balance'];
			} 
			
						
			$costofsales_currentyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl_retained['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_currentyeargibalance_retained->fetchAll() as $csygi_retained) {
				$costofsales_currentyearbalance_retained = $csygi_retained['balance'];
			}
						
			
			$costofsales_lastyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl_retained['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_lastyeargibalance_retained->fetchAll() as $csmgi_retained) {
				$costofsales_lastyearbalance_retained = $csmgi_retained['balance'];				
			}
			
							
			$costofsalesArray_retained[$csi_retained]['description'] = $description_retained;
			$costofsalesArray_retained[$csi_retained]['currentyearbalance'] = $costofsales_op_balance_retained + $costofsales_currentyearbalance_retained;
			$costofsalesArray_retained[$csi_retained]['lastyearbalance'] = $costofsales_op_balance_retained + $costofsales_lastyearbalance_retained;
							
			$csi_retained++;
		}		
				
		/******************* COST OF SALES END  ****/		
				
		/******************* capital START  ****/
		
		$capital_subcodesList_retained = array();		
		$capital_subcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 2 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($capital_subcodes_retained->fetchAll() as $csc_retained) {
			$capital_subcodesList_retained[] = $csc_retained;
		}				 		
		
		$capital_Array_retained = array();		
		$csi=0;
		foreach($capital_subcodesList_retained as $ccl_retained){
						
			$description_retained = $ccl_retained['description'];					
			
			// opening balance
			$capital_openingbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 2 and op.company_id = ".$cid." and sc.id = '".$ccl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($capital_openingbalance_retained->fetchAll() as $cyop_retained) {
				$capital_op_balance_retained = $cyop_retained['balance'];
			} 	
				
			
			$capital_currentyear_gibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ccl_retained['id']."' and mac.account_type_id = 2 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($capital_currentyear_gibalance_retained->fetchAll() as $cygi_retained) {
				$capital_currentyear_balance_retained = $cygi_retained['balance'];
			}
			
			$capital__lastyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ccl_retained['id']."' and mac.account_type_id = 2 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($capital__lastyeargibalance_retained->fetchAll() as $lygi_retained) {			
				$capital_lastyear_balance_retained = $lygi_retained['balance'];				
			}							
						
			$capital_Array_retained[$csi]['description'] = $description_retained;
			$capital_Array_retained[$csi]['currentyearbalance'] = $capital_op_balance_retained + $capital_currentyear_balance_retained;
			$capital_Array_retained[$csi]['lastyearbalance'] = $capital_op_balance_retained + $capital_lastyear_balance_retained;
			
			$csi++;
		}		
					
		/******************* capital END  ****/	
		
		
		
		/******************* OTHER INCOMES START  ****/
		
		$otherincomessubcodesList_retained = array();		
		$otherincomessubcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 11 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($otherincomessubcodes_retained->fetchAll() as $oisc_retained) {
			$otherincomessubcodesList_retained[] = $oisc_retained;
		} 
		
					
		
		$otherincomesArray_retained = array();		
		$oii_retained=0;
		foreach($otherincomessubcodesList_retained as $oicl_retained){
						
			$description_retained = $oicl_retained['description'];					
			
			// opening balance
			$otherincomes_openingbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 11 and op.company_id = ".$cid." and sc.id = '".$oicl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($otherincomes_openingbalance_retained->fetchAll() as $oiop_retained) {
				$otherincomes_op_balance_retained = $oiop_retained['balance'];
			} 
				
			
			$otherincomes_currentyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$oicl_retained['id']."' and mac.account_type_id = 11 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($otherincomes_currentyeargibalance_retained->fetchAll() as $oiygi_retained) {
				$otherincomes_currentyearbalance_retained = $oiygi_retained['balance'];
			}
				
			
			$otherincomes_lastyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$oicl_retained['id']."' and mac.account_type_id = 11 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($otherincomes_lastyeargibalance_retained->fetchAll() as $oimgi_retained) {
				$otherincomes_lastyearbalance_retained = $oimgi_retained['balance'];				
			}			
						
				
			$otherincomesArray_retained[$oii]['description'] = $description_retained;
			$otherincomesArray_retained[$oii]['currentyearbalance'] = $otherincomes_op_balance_retained + $otherincomes_currentyearbalance_retained;
			$otherincomesArray_retained[$oii]['lastyearbalance'] = $otherincomes_op_balance_retained + $otherincomes_lastyearbalance_retained;
							
			$oii++;
		}		
				
		/******************* OTHER INCOMES END  ****/		
				
				
		/******************* EXPENSES START  ****/
		
		$expensessubcodesList_retained = array();		
		$expensessubcodes_retained = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($expensessubcodes_retained->fetchAll() as $esc_retained) {
			$expensessubcodesList_retained[] = $esc_retained;
		}				 		
		
		$expensesArray_retained = array();		
		$csi_retained=0;
		foreach($expensessubcodesList_retained as $ecl_retained){
						
			$description_retained = $ecl_retained['description'];					
			
			// opening balance
			$expenses_openingbalance_retained = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and op.company_id = ".$cid." and sc.id = '".$ecl_retained['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($expenses_openingbalance_retained->fetchAll() as $eop_retained) {
				$expenses_op_balance_retained = $eop_retained['balance'];
			} 	
			
			
			
			$expenses_currentyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl_retained['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_currentyeargibalance_retained->fetchAll() as $eygi_retained) {
				$expenses_currentyearbalance_retained = $eygi_retained['balance'];
			}
				
			
			
			$expenses_lastyeargibalance_retained = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl_retained['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_lastyeargibalance_retained->fetchAll() as $emgi_retained) {			
				$expenses_lastyearbalance_retained = $emgi_retained['balance'];				
			}							
						
			$expensesArray_retained[$csi_retained]['description'] = $description_retained;
			$expensesArray_retained[$csi_retained]['currentyearbalance'] = $expenses_op_balance_retained + $expenses_currentyearbalance_retained;
			$expensesArray_retained[$csi_retained]['lastyearbalance'] = $expenses_op_balance_retained + $expenses_lastyearbalance_retained;
			
			$csi_retained++;
		}				
		
// sales tax 		
		$salestax_year_retained = $db->query("select sum(credit) as credit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." and je.subcode_id ='".$outputtax_id."' and je.date >= '".$yearfromdate."' AND je.date <= '".$currentyeardate."' order by je.memo,je.date ");
		
		foreach($salestax_year_retained->fetchAll() as $st_year_retained) {
			$outputtax_currentyear_retained = $st_year_retained['credit'];
		}		
		
		// month		
		$salestax_month_retained = $db->query("select sum(credit) as credit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." and je.subcode_id='".$outputtax_id."' and je.date >= '1111-11-11' AND je.date <= '".$lastyeardate."' order by je.memo,je.date ");
		
		foreach($salestax_month_retained->fetchAll() as $st_month_retained) {
			$outputtax_lastyear_retained = $st_month_retained['credit'];
		}		
		
			
		if($gsttaxcode=="AJS"){				
			 $outputtax_lastyear_retained = $outputtax_lastyear_retained + $gst_balance1;
		} 

// purchase tax				
		
		// for purchase tax codes
		$purchasetax_year_retained = $db->query("select sum(debit) as debit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." and je.subcode_id='".$inputtax_id."' and je.date >= '".$yearfromdate."' AND je.date <= '".$currentyeardate."' order by je.memo,je.date ");
		
		foreach($purchasetax_year_retained->fetchAll() as $pt_year_retained) {
			$inputtax_currentyear_retained = $pt_year_retained['debit'];
		}			
		
		// month wise		
		$purchasetax_month_retained = $db->query("select sum(debit) as debit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." and je.subcode_id='".$inputtax_id."' and je.date >= '1111-11-11' AND je.date <= '".$lastyeardate."' order by je.memo,je.date ");
		
		foreach($purchasetax_month_retained->fetchAll() as $pt_month_retained) {
			$inputtax_lastyear_retained = $pt_month_retained['debit'];
		}	
			
		if($gsttaxcode=="AJP"){
			$inputtax_lastyear_retained = $inputtax_lastyear_retained + $gst_balance1;
		} 	
		
		
		
				
		/******************* EXPENSES END  ****/	



/******************************************************************************************************************************************************************/	
		
		
		
						  
	  require_once('views/balancesheet/index.php'); 
	  
    }		
	
	
	
	public function tradedebtors() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$cid.'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
				
		$fromdate   = $_GET['fromdate'];
		$todate 	= $_GET['todate'];
				
		if($fromdate=="1111-11-11"){		
			$lastyeardate_new = date($todate);
		} else {
			$lastyeardate_new = date($fromdate);
		}		
		
		$profitcenter="";
		
		$gsttaxcode = "";		
		
		$previousdate = date('Y-m-d', strtotime('-1 day', strtotime($fromdate)));  
					
					
					// for gst 					
					$gstbalance = $db->query("SELECT aa.AdjustmentRecovered as balance, aa.TaxCode FROM annualadjustment as aa WHERE aa.company_id = ".$cid." AND STR_TO_DATE(aa.PeriodTo,'%d/%m/%Y') BETWEEN '1111-11-11' AND '".$previousdate."' ");								
								
					foreach($gstbalance->fetchAll() as $gs) {
						 
						 if($gs['TaxCode']=="AJS"){
						 	 $gst_balance1 = -abs($gs['balance']);				
						 } else  if($gs['TaxCode']=="AJP"){
						 	 $gst_balance2 = $gs['balance'];				
						 } 
						 
						 $gsttaxcode = $gs['TaxCode'];
					}	
		
		
		
			
		
		/******************* Current Assets START  ****/
		
			
// current asset trade debtors list start			
			
			
		$tradedebtors_subcodesList = array();		
		$tradedebtors_subcodes = $db->query("SELECT sc.id, sc.description, sc.subcode_of FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 13 and sc.company_id = ".$cid." and sc.subcode_of in(select id from subcodes where description='Trade Debtors' and company_id='".$cid."') and mac.company_id=".$cid."  ORDER BY  sc.id ASC");		
		foreach($tradedebtors_subcodes->fetchAll() as $tdbt) {
			$tradedebtors_subcodesList[] = $tdbt;
		} 		
		
		$tradedebtors_Array = array();		
		$si=0;
		foreach($tradedebtors_subcodesList as $tdbt1){
			$subcode_id = $tdbt1['id'];				
			$description = $tdbt1['description'];	
			$subcode_of = $tdbt1['subcode_of'];						
					
			
			$tradedebtors_openingbalance_currentyear = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 13 and op.company_id = ".$cid." and sc.id = '".$tdbt1['id']."' AND date(op.opening_date) BETWEEN date('1111-11-11') AND date('".$todate."') ORDER BY `op`.`subcode_id` ASC");		
			foreach($tradedebtors_openingbalance_currentyear->fetchAll() as $tdbop_currentyear) {
				$tradedebtors_op_balance = $tdbop_currentyear['balance'];
			} 
			
			
			
			/*$openbalance = $db->query("SELECT `getOpeningBalance`('".$cid."','".$subcode_id."','0','0',null,'1111-11-11','".$lastyeardate_new."') as openingbalance");					
			foreach($openbalance->fetchAll() as $ybl) {
				echo $tradedebtors_op_balance = $ybl['openingbalance'];
			}	
			*/
			
			$tradedebtors_opbalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$tdbt1['id']."' and mac.account_type_id = 13 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate_new."') ORDER BY je.subcode_id ASC");		
			foreach($tradedebtors_opbalance->fetchAll() as $top) {
				$tradedebtors_balance = $top['balance'];				
			}	
															
						
			$tradedebtors_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$tdbt1['id']."' and mac.account_type_id = 13 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$fromdate."') AND date('".$todate."') ORDER BY je.subcode_id ASC");		
			foreach($tradedebtors_currentyeargibalance->fetchAll() as $tdbgi) {
				$tradedebtors_currentyearbalance = $tdbgi['balance'];				
			}
			
			
			
			$tradedebtors_Array[$si]['subcode_id'] = $subcode_id;
			$tradedebtors_Array[$si]['description'] = $description;
			$tradedebtors_Array[$si]['subcode_of'] = $subcode_of;
			
			
			if($fromdate=="1111-11-11"){		
				$tradedebtors_Array[$si]['currentyearbalance'] = $tradedebtors_op_balance + $tradedebtors_currentyearbalance;
			} else {
				$tradedebtors_Array[$si]['currentyearbalance'] = $tradedebtors_op_balance + $tradedebtors_currentyearbalance + $tradedebtors_balance;
			}	
			
			
			
			
								
			$si++;	
		}
			
			
	
					
						  
	  require_once('views/balancesheet/tradedebtors.php'); 
	  
    }		
	
	
	
	public function tradecreditors() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$cid.'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
				
		$fromdate   = $_GET['fromdate'];
		$todate 	= $_GET['todate'];
		
		if($fromdate=="1111-11-11"){		
			$lastyeardate_new = date($todate.'-12-31');
		} else {
			$lastyeardate_new = date($fromdate.'-12-31');
		}		
		
		$profitcenter="";
		
		$gsttaxcode = "";		
		
		$previousdate = date('Y-m-d', strtotime('-1 day', strtotime($fromdate)));  
					
					
					// for gst 					
					$gstbalance = $db->query("SELECT aa.AdjustmentRecovered as balance, aa.TaxCode FROM annualadjustment as aa WHERE aa.company_id = ".$cid." AND STR_TO_DATE(aa.PeriodTo,'%d/%m/%Y') BETWEEN '1111-11-11' AND '".$previousdate."' ");								
								
					foreach($gstbalance->fetchAll() as $gs) {
						 
						 if($gs['TaxCode']=="AJS"){
						 	 $gst_balance1 = -abs($gs['balance']);				
						 } else  if($gs['TaxCode']=="AJP"){
						 	 $gst_balance2 = $gs['balance'];				
						 } 
						 
						 $gsttaxcode = $gs['TaxCode'];
					}	
		
		
		
			
		
		/******************* Current Assets START  ****/
		
			
// current asset trade debtors list start			
			
			
		$tradecreditors_subcodesList = array();		
		$tradecreditors_subcodes = $db->query("SELECT sc.id, sc.description, sc.subcode_of FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 5 and sc.company_id = ".$cid." and sc.subcode_of in(select id from subcodes where description='Trade Creditors' and company_id='".$cid."') and mac.company_id=".$cid."  ORDER BY  sc.id ASC");		
		foreach($tradecreditors_subcodes->fetchAll() as $tdbt) {
			$tradecreditors_subcodesList[] = $tdbt;
		} 		
		
		$tradecreditors_Array = array();		
		$si=0;
		foreach($tradecreditors_subcodesList as $tdbt1){
			$subcode_id = $tdbt1['id'];				
			$description = $tdbt1['description'];	
			$subcode_of = $tdbt1['subcode_of'];						
		
					
			$tradecreditors_opbalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$tdbt1['id']."' and mac.account_type_id = 5 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate_new."') ORDER BY je.subcode_id ASC");		
			foreach($tradecreditors_opbalance->fetchAll() as $top) {
				$tradecreditors_balance = $top['balance'];				
			}	
						
			$openbalance = $db->query("SELECT `getOpeningBalance`('".$cid."','".$subcode_id."','0','0',null,'1111-11-11','".$lastyeardate_new."') as openingbalance");					
			foreach($openbalance->fetchAll() as $ybl) {
				$tradecreditors_op_balance = $ybl['openingbalance'];
			}			
										
						
			$tradecreditors_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$tdbt1['id']."' and mac.account_type_id = 5 and je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$fromdate."') AND date('".$todate."') ORDER BY je.subcode_id ASC");		
			foreach($tradecreditors_currentyeargibalance->fetchAll() as $tdbgi) {
				$tradecreditors_currentyearbalance = $tdbgi['balance'];				
			}
			
			
			
			$tradecreditors_Array[$si]['subcode_id'] = $subcode_id;
			$tradecreditors_Array[$si]['description'] = $description;

			$tradecreditors_Array[$si]['subcode_of'] = $subcode_of;
			
			
			if($fromdate=="1111-11-11"){		
				$tradecreditors_Array[$si]['currentyearbalance'] = $tradecreditors_op_balance + $tradecreditors_currentyearbalance;
			} else {
				$tradecreditors_Array[$si]['currentyearbalance'] = $tradecreditors_op_balance + $tradecreditors_currentyearbalance + $tradecreditors_balance;
			}	
			
			
			
			
								
			$si++;	
		}
			
			
	
					
						  
	  require_once('views/balancesheet/tradecreditors.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/balancesheet/error.php');
    }
  }
?>