<?php
  class DebtorsagingController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  

		$cid = $_GET['cid'];		// company id	   
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$date = date("Y-m-t");
		
		if(isset($_POST['submit'])){
				
			$date = date("Y-m-d", strtotime($_POST['date']));			
				
			if(empty($date)){
				$date = date("Y-m-d");			
			}				
		
		}	
		
		$debtorslist = array();		
		$debtors = $db->query("select sc.description, sc.id, sc.code from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='13' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");		
		foreach($debtors->fetchAll() as $dt) {
			$debtorslist[] = $dt;
		} 	
		
		$subcodesList1 = $db->query("select id, description from subcodes where company_id=".$cid." order by code ");
		foreach($subcodesList1->fetchAll() as $sl) {
				
			if($sl['description']=="Trade Debtors"){
				$debtor_id = $sl['id'];
			} 
			if($sl['description']=="Trade Creditors"){
				$creditor_id = $sl['id'];
			} 
		
		}  	
					
						  
	  require_once('views/debtorsaging/index.php'); 
	  
    }	
		
public function view() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	   
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$id 		= $_GET['id'];
		$fromdate 	= $_GET['fromdate'];
		$todate 	= $_GET['todate'];
		
			
		$subcodesList = array();		
		$subcodes = $db->query("select description, id, code from subcodes where id='".$id."'");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 	
		
		
			
		$journallist = array();		
		$journals = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									je.debit,
									je.credit,
									je.date,
									je.memo
								from 
									subcodes as sc
									left join journal_entries as je on je.subcode_id = sc.id
								where 
									je.company_id=".$cid." and sc.company_id='".$cid."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' order by je.date asc");		
		foreach($journals->fetchAll() as $je) {
			$journallist[] = $je;
		} 		
			
					
						  
	  require_once('views/debtorsaging/view.php'); 
	  
    }	
	
    public function error() {
      require_once('views/debtorsaging/error.php');
    }
  }
  

?>