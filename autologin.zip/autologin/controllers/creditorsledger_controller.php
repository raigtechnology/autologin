<?php
  class CreditorsledgerController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		$description = $_GET['des'];// Description val	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$codelist = array();
		$codedescriptions = $db->query("select code from subcodes where company_id='".$cid."' and description='Trade Creditors' order by code asc ");	
		foreach($codedescriptions->fetchAll() as $scm) {		
			$codelist[] =$scm['code'];		
		}	
		
		
		$fromdate = date("Y-01-01");
		$todate = date("Y-m-t");
		$account_code="";
		
		$cont="";
		
		if(isset($_POST['submit'])){
				
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));			
			
			$account_code = $_POST['account_code'];				
			$cont=" and sc.code='".$account_code."' ";						
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-d");
				$todate = date("Y-m-t");
			}				
		
		}
		
		$subcodesList = array();		
		
		//parent child query format in creditors and debitors report edited prabhu 11-09-16

		$subcodes = $db->query("SELECT c1.description, c1.id, c1.code FROM subcodes p LEFT JOIN subcodes c1 ON c1.subcode_of = p.id WHERE p.description='Trade Creditors' and      p.company_id='".$cid."' order by c1.code, c1.description asc");	


		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		}		 			
		
		// journal entries
		$journallist = array();		
		
		$journals = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									je.debit,
									je.credit,
									je.date,
									je.memo
								from 
									subcodes as sc
									left join journal_entries as je on je.subcode_id = sc.id
								where 
									je.company_id=".$cid."  and sc.company_id='".$cid."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' order by je.date asc");		
		foreach($journals->fetchAll() as $je) {
			$journallist[] = $je;
		} 	
		
		
		/*********************************/
				
		
		/*********************************/
	
		// journal entries for input output tax
		$journallist1 = array();		
		$journals1 = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									je.debit,
									je.credit,
									je.date,
									je.memo
								from 
									subcodes as sc
									left join journal_entries as je on je.subcode_id = sc.id
								where 
									je.company_id=".$cid."  and sc.company_id='".$cid."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' and Gstinvdate!='' and sc.description in('GST-OUTPUT-TAX','GST-OUTPUT-TAX-AJS','GST-INPUT-TAX-AJP','GST-INPUT-TAX','GST OUTPUT & INPUT TAX') order by je.date asc");	
							
										
		foreach($journals1->fetchAll() as $je1) {
			$journallist1[] = $je1;
		} 	
		
				
				
						  
	  require_once('views/creditorsledger/index.php'); 
	  
    }		
	
    public function error() {
      require_once('views/creditorsledger/error.php');
    }
  }
?>