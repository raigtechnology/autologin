<?php
  class profitandloss {
   
  }
?>