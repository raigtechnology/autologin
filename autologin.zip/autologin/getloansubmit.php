<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}	
	
	$emp_id		= $_GET['emp_id']; 	
	
	?>			
	
	<?php
	if($emp_id>0){
	?>
	
	<table width="70%" border="0" cellspacing="0" cellpadding="0" id="search_panel">
		
		<tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input type="submit" name="Submit" value="Save" class="ibtn" /></td>
            <td>&nbsp;</td>
		</tr>
		 </table> 
	<?php
	}
	?>	
