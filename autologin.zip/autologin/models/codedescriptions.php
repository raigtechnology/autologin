<?php
  class Codedescriptions {
   
  }
?>