<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}
	
    header('Content-Disposition: attachment; filename="'.$_REQUEST['name'].'.xls"');
    header('Content-Type: application/vnd.ms-excel');
   
   $company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
   
  
				
				$data ="<div class='companyhead'>						
							
							<div><span style='font-size:16px; cursor:default; color:#FF0000; text-transform:capitalize;'>".$company_name."</span></div>
							<div><span style='text-transform:capitalize; font-size:10px; cursor:default; color:#000; text-transform:capitalize;'>".$company_address."</span><br>".$company_state." ".$company_pincode."</div>							
							<div>".$_REQUEST['name']."</div>									
					</div>
					<div style='height:25px;'></div>
					";		
   	
	echo $data;
   	   
    echo "<div>".$_REQUEST['data']."</div>";
?>