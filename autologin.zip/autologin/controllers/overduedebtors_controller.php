<?php
  class OverduedebtorsController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$cid.'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$date = date("Y-m-d");
		
		$cond = "";
		
		if(isset($_POST['submit'])){
				
			$date = date("Y-m-d", strtotime($_POST['date']));			
				
			if(empty($date)){
				$date = date("Y-m-d");			
			}
			
			
			$cond = " and STR_TO_DATE(InvDate,'%d/%m/%Y') <= DATE('".$date."')";				
		
		}else{
			$cond = "and STR_TO_DATE(InvDate,'%d/%m/%Y') <= DATE('".$date."')";
		}	
									
				
		$subcodeslist = array();
		$subcodes = $db->query("select sc.id, sc.code as subcode, sc.description as subcode_desc from subcodes as sc where sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') and sc.company_id='".$cid."' order by sc.description asc ");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodeslist[] = $sc;
		} 
		
		$journallistlist = array();
		$journals = $db->query("select * from tblinvoiceinout where company_id='".$cid."' ".$cond." ");		
		foreach($journals->fetchAll() as $jl) {
			$journallistlist[] = $jl;
		} 
					  
	  require_once('views/overduedebtors/index.php'); 
	  
    }	
		
		
	public function view() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		$id = $_GET['id'];
		
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
			
			
			$date = date("Y-m-d", strtotime($_GET['date']));			
		
		$cond = " and STR_TO_DATE(InvDate,'%d/%m/%Y') <= DATE('".$date."')";				
			
			
	/*
		$date = date("Y-m-d", strtotime($_GET['date']));
		$date1 = date("d/m/Y", strtotime($_GET['date']));			
		
		$cond = " and STR_TO_DATE(InvDate,'%d/%m/%Y') <= DATE('".$date1."') OR STR_TO_DATE(InvDate,'%Y-%m-%d') <= DATE('".$date."')";	*/			
		
		//$cond = " and STR_TO_DATE(InvDate,'%d/%m/%Y') BETWEEN '1111-11-11' AND '".$date."' OR  STR_TO_DATE(InvDate,'%d/%m/%Y') BETWEEN '11/11/1111' AND '".$date1."' ";
						
		$subcodeslist = array();
		$subcodes = $db->query("select sc.id, sc.code as subcode, sc.description as subcode_desc from subcodes as sc where sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') and sc.company_id='".$cid."' and sc.id='".$id."' order by sc.description asc ");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodeslist[] = $sc;
		} 
		
		
		$journallist = array();
		$journals = $db->query("select CustID, InvAmt, AmtPaid, InvDate, InvNo from tblinvoiceinout where company_id='".$cid."' ".$cond." ");		
		foreach($journals->fetchAll() as $jl) {
			$journallist[] = $jl;
		} 
		
						  
	  require_once('views/overduedebtors/view.php'); 
	  
    }		
		
		

    public function error() {
      require_once('views/overduedebtors/error.php');
    }
  }
  

?>
