<?php
  class UsersController {
  
	public function index() {      

	
		if(isset($_GET['uid']) && isset($_GET['pid']) && isset($_GET['custid'])){
			
			$txt_username =  $_GET['uid']; //line 2	
			//$txt_password =  $_GET['pid']; //line 2	
			$txt_password =  base64_decode($_GET['pid']); //line 2	
			$txt_usergroup =  $_GET['custid']; //line 2
		
		} else if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['custid'])){
			
			$txt_username =  $_POST['username']; //line 2	
			$txt_password =  $_POST['password']; //line 2	
			$txt_usergroup =  $_POST['custid']; //line 2	
		
		} else {
			
			 $txt_username =  ""; //line 2	
			 $txt_password =  ""; //line 2		
			 $txt_usergroup = ""; //line 2		
		} 

	 
		  if(isset($_SESSION['username'])){	  	
			
				//header("Location: ?controller=companies&action=index");	
		  
		  } else if($txt_username!="" && $txt_password!=""){
		  
			
				$db = Db::getInstance();
				
				$tblcust = $db->query('SELECT id as userid FROM user_group WHERE customer_code="'.$txt_usergroup.'"');		
				foreach($tblcust ->fetchAll() as $tc) {
					  $customer_id = $tc['userid'];
				}	
		
			  
				$tbllogin = $db->query("SELECT count(*) as total FROM tbllogin WHERE username ='".$txt_username."' and password = '".$txt_password."' and Autoaccounts='Y' and user_group_id='".$customer_id."' ");		
				foreach($tbllogin->fetchAll() as $tbl) {
					$total = $tbl['total'];
				}	  	
			 
				$tbllogin2 = $db->query("SELECT * FROM tbllogin WHERE username ='".$txt_username."' and password = '".$txt_password."' and Autoaccounts='Y' and  user_group_id='".$customer_id."'");		
				foreach($tbllogin2->fetchAll() as $tbl2) {
					$user_group_id = $tbl2['user_group_id'];
					$company_id	   = $tbl2['company_id'];
				}	
					
			
				if($total>0){	
				
				    /* Trial Version Check Condition */		
					
					$registrations = $db->query("select * from registrations where user_group_id='".$user_group_id."' ");	
					foreach($registrations->fetchAll() as $rs) {				
						$company_ids = $rs['company_id']; 	
						$product_version = $rs['product_version'];
						$paymentstatus   = $rs['payment_status'];	
						$expiry_date     = $rs['expiry_date'];	 									
					}
					
					if($product_version=='FULL'){
						
						
						
						/* Date difference part is start here */								
							$date1 = strtotime($expiry_date);
							$date2 = date("Y-m-d");
							$date2 = strtotime($date2);
							$dateDiff = $date1 - $date2;
							$total_days = floor($dateDiff/(60*60*24));				
							/* End of date difference part*/		
						if($total_days>=0){
							
						if($paymentstatus=='pending'){
										$msg = 'Your Auto Account Has Expired.';	
										$_SESSION['msg'] = $msg;
																														
										header("Location: ?controller=users&action=logout");					
						}else if($total_days<=15){ 	
									$msg = 'Your  Account will be expire in '.$total_days.' days!';							
									$_SESSION['msg'] = $msg;	
									$_SESSION['username'] = $txt_username;
									$_SESSION['password'] = $txt_password;
									$_SESSION['company_id'] = $company_id;
									$_SESSION['user_group_id'] = $user_group_id;
								
									header("Location: ?controller=companies&action=index");	
								
						}else{
						
										$_SESSION['msg'] = $msg;	
										$_SESSION['username'] = $txt_username;
										$_SESSION['password'] = $txt_password;
										$_SESSION['company_id'] = $company_id;
										$_SESSION['user_group_id'] = $user_group_id;
										$_SESSION['timeout'] = time();
										header("Location: ?controller=companies&action=index");	
					   }
					   }else{
					   					$msg = 'Your Auto Account Has Expired.';	
										$_SESSION['msg'] = $msg;
																														
										header("Location: ?controller=users&action=logout");	
					   }
					}else if($product_version=="TRIAL"){																														
							/* the part is for getting duedate start*/ 			
							$due_res = $db->query("select * from tblduedate where company_id='".$company_ids."' ");
														
							foreach($due_res->fetchAll() as $dr) {					
								$due_date 		= $dr['Duedate']; 
								$install_date 	= $dr['install_date'];
								$expired 		= $dr['Expired'];
								$activated 		= $dr['Activated'];
							}						
							/*end of duedate retrival */	
									
							/* Date difference part is start here */								
							$date1 = strtotime($due_date);
							$date2 = date("Y-m-d");
							$date2 = strtotime($date2);
							$dateDiff = $date1 - $date2;
							$total_days = floor($dateDiff/(60*60*24));				
							/* End of date difference part*/				
													
							
							if($date1==$date2){ // if duedate from the table is equal to current date it will show account will expire today				
								$msg = 'Your Auto Account Trial Version will expire by Today!';					
								$_SESSION['msg'] = $msg;							
								$_SESSION['username'] = $txt_username;
								$_SESSION['password'] = $txt_password;
								$_SESSION['company_id'] = $company_id;
								$_SESSION['user_group_id'] = $user_group_id;
								$_SESSION['timeout'] = time();
								
								
								
									
								header("Location: ?controller=companies&action=index");	
							
							
							
							}else { 														
							
								if($total_days>0){ // if total due days is greater than zero it will show account will expire in the above resultant days										
									//$msg = 'Your Auto Account Trial Version will expire in  '.$total_days.' days!';								$msg = 'Your Auto Account Renewal in  '.$total_days.' days!';								
									$_SESSION['msg'] = $msg;	
									$_SESSION['username'] = $txt_username;
									$_SESSION['password'] = $txt_password;
									$_SESSION['company_id'] = $company_id;
									$_SESSION['user_group_id'] = $user_group_id;
									$_SESSION['timeout'] = time();
									
								
									header("Location: ?controller=companies&action=index");	
								
								} else { // if total due days is less than zero it will show your account expired.						
									
									if($expired=="N" && $activated=="Y"){
										$current_date = date("Y-m-d");
										$Duedate = date("Y-m-d", strtotime($current_date."+45 days"));				
										$db->query("update tblduedate set Expired ='Y', Activated = 'N' where company_id='".$company_ids."' ");
										
									} else {
										$msg = 'Your Account Has Expired.';	
										$_SESSION['msg'] = $msg;
																														
										header("Location: ?controller=users&action=logout");					
									}									
									
								}	
								
								
							}
							
					}else{
							
					$_SESSION['username'] = $txt_username;
					$_SESSION['password'] = $txt_password;
					$_SESSION['company_id'] = $company_id;
					$_SESSION['user_group_id'] = $user_group_id;
					$_SESSION['timeout'] = time();
					header("Location: ?controller=companies&action=index");	
				
				}
				} else {
					header("Location: ?controller=users&action=logout");	
				}
			
		  }	else {
			require_once('views/users/login.php');
		  }
	  	  	 	  
    }
		
	// logout
	public function logout() {
		$db = Db::getInstance();
		session_start();
		error_reporting(0);
		
		 if(isset($_SESSION['username']) && isset($_SESSION['password'])){			
			
			  /* unset($_SESSION['username']);
			  unset($_SESSION['password']);	
			  unset($_SESSION['user_group_id']);	
			  unset($_SESSION['company_id']);
			  session_unset(); */
	  		  session_destroy();
			  header("Location: ?controller=users&action=logout");	
		 }else{
		 
		 	  header("Location: ?controller=users&action=index");	
		 }		
	  
	  /* unset($_SESSION['username']);
	  unset($_SESSION['password']);	
	  unset($_SESSION['user_group_id']);	
	  unset($_SESSION['company_id']);  */	  	
	  //session_destroy();
	  // require_once('views/users/index.php');
	  // 
    }
	
	public function logview() {		 
	  require_once('views/users/logout.php');
    }
	
	public function view() {			 
	  require_once('views/users/view.php');
    }
	
			
	
    public function error() {
      require_once('views/users/error.php');
    }
	
  }
?>