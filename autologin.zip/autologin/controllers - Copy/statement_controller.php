<?php
  class StatementController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();	// db connection	
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name, address, state, pincode FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
	
		
		
		$subcode_id			=	"";		
		$journallist 		= array();	
		
		$cond1				=	"";		
		$accountcode		=	"";
		$customername		=	"";
		
		$lastyear = date("Y", strtotime($_GET['todate']))-1;
	
			if($_GET['fromdate']="1111-11-11"){
				//$from_date = date("Y-m-d", strtotime($_GET['todate']));
				$lastyeardate_new = date($_GET['todate'].'-12-31');
			} else {
				//$from_date = date("Y-m-d", strtotime($_GET['fromdate']));
				$lastyeardate_new = date($lastyear.'-12-31');
			}
		
		
				
			$from_date = date("Y-m-d", strtotime($_GET['fromdate']));
			$to_date = date("Y-m-d", strtotime($_GET['todate']));
			
		
			
			// new validation			
				
			// end		
						
			$subcode_id = $_GET['id'];
		
			
			$customers1 = $db->query("select sc.description, sc.code from subcodes as sc where company_id='".$cid."' and id='".$subcode_id."' ");	
			foreach($customers1->fetchAll() as $ct1) {
				$customername = $ct1['description'];
				$accountcode = $ct1['code'];
			}  	
			
								
			// journal entries			
		
			$cond1 = "and je.date >= '".$from_date."' AND je.date <= '".$to_date."' and sc.id = ".$subcode_id.""; 
			
				
			$journals = $db->query("select 
										sc.description,
										sc.id,
										sc.code,
										je.debit,
										je.credit,
										je.date,
										je.memo
									from 
										subcodes as sc
										left join journal_entries as je on je.subcode_id = sc.id
									where 
										je.company_id=".$cid." and sc.company_id='".$cid."' ".$cond1."  order by je.date asc");		
			
			
			
			
			foreach($journals->fetchAll() as $je) {
				$journallist[] = $je;
			} 	
		
					
			
	
		
		
		/******************************************************************************/	
		$cond = "";
		if($subcode_id!=""){
			$cond = "and sc.id=".$subcode_id." ";
		}
				
		
		$debtorslist = array();		
		$debtors = $db->query("select sc.description, sc.id, sc.code from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='13' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') ".$cond." order by sc.description asc");		
		foreach($debtors->fetchAll() as $dt) {
			$debtorslist[] = $dt;
		} 	
		
		$subcodesList1 = $db->query("select id, description from subcodes where company_id=".$cid." order by code ");
		foreach($subcodesList1->fetchAll() as $sl) {
				
			if($sl['description']=="Trade Debtors"){
				$debtor_id = $sl['id'];
			} 			
		
		}  	
		/*********************************************************************/  	
		
		
		
		///////////////////////////////////////////
			
		
			
							  
	  require_once('views/statement/index.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/statement/error.php');
    }
  }
?>