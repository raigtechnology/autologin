<?php
  class salesinvoice {
   
  }
?>