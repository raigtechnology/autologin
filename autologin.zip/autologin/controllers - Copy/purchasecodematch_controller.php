<?php
  class PurchasecodematchController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
								
		$purchasecodematch = $db->query("select PurTaxCode, MatchCode, supplyType from purchasecodematch order by supplyType asc");	
		foreach($purchasecodematch->fetchAll() as $scm) {
			$purchasecodematchlist[] = $scm;
		}	
								  
		require_once('views/purchasecodematch/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/purchasecodematch/error.php');
    }
  }
?>