<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}	 
	
	$currencycode = $_GET['value1'];
	$companyid = $_GET['company_id'];
		
	$currencycodelist = $db->query("select exchange_rate from currency where currency_code = '".$currencycode."' and company_id ='".$companyid."'  ");	
	foreach($currencycodelist->fetchAll() as $cur) {
		$exchange_rate = $cur['exchange_rate'];		
	}		
	?>	
	<?php echo $exchange_rate; ?><input type="hidden" name="exchange_rate" id="exchange_rate" style="text-align:right;" class="textbox_small" required="required" value="<?php echo $exchange_rate; ?>" />
