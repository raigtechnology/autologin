<?php
  error_reporting(0);
  class ImportjournalentriesController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
		$cid = $_GET['cid']; // company id		
		
						  
	  require_once('views/importjournalentries/index.php'); 
	  
    }	
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		$db = Db::getInstance(); // db connection
			
		$cid = 	$_GET['cid'];
				
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
	
		if(isset($_POST['submit'])){		
			
			if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
			
				readfile($_FILES['filename']['tmp_name']);
			}
		
			$cid 				= $_POST['cid'];
			
			//Import uploaded file to Database
			$handle = fopen($_FILES['filename']['tmp_name'], "r");
			$subcode_of = 0;
			//while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {	
			while(! feof($handle))
  			{
 				 $f[] = fgetcsv($handle);
  			}
			fclose($handle);
			//fclose($file);			
				foreach($f as $sc=>$v) {
					foreach($v as $k=>$t) {
						$str=explode('~',$t);
						if($sc==0){
							foreach($str as $key => $value) {
							$name[] = $value;
							 							
							}
							function trim_value(&$value) 
							{ 
								$value = trim($value); 
							}
						array_walk($name, 'trim_value');
						}
						
						else{
						
						foreach($str as $ky => $va) {
   							$n = $name[$ky];
   							$output[$n]= $va;
   
						}
						}
						/*echo "<pre>";print_r($output);*/
						foreach($output as $ot=>$vs) {
						 	
							 if($ot=='DATE'){
							
								$fld_date = $vs;
								$fld_day = ($fld_date)? date("Y-m-d",strtotime($fld_date)) : date("Y-m-d");
							 }
							 if($ot=='ACCOUNT TYPES'){	
								 $fld_branch = $vs;
								 $codes = $db->query("SELECT code FROM subcodes WHERE description = '".$fld_branch."' and company_id = '".$cid."' ");		
								 foreach($codes->fetchAll() as $sc) {					
								 	$code 		= $sc['code'];					
								 }			
								 $subcode_id=0;
								 $codes1 = $db->query("SELECT id FROM subcodes WHERE description = '".$fld_branch."' ");		
								 foreach($codes1->fetchAll() as $sc1) {				
								 	$subcode_id = $sc1['id'];
				             	 }
							 }
							 if($ot=='Branch Code'){
							 	//echo "testttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt";
							 	$fld_profit_code = $vs;
								$profitcenters2 = $db->query("select id from profit_centers where company_id='".$cid."' and profit_center_code='".$fld_profit_code."' ");	
								foreach($profitcenters2->fetchAll() as $pc2) {
									$profit_centers = $pc2['id'];
								} 
							 }
							  if($ot=='REF'){
								$fld_ref = $vs;
							 }
							 if($ot=='DESCRIPTION'){
								$fld_describe = $vs;
							 }
							 if($ot=='DEBIT'){
								$fld_debit = $vs;
							 }
							 if($ot=='CREDIT'){
								$fld_credit = $vs;
							 }
							 if($ot=='INVOICE  MODE'){
								$fld_invoice = $vs;
							 }
							 if($ot=='GST'){
								$fld_gst = $vs;
							 }
							 if($ot=='TAX CODE'){
								$fld_tax_code = $vs;
							 }
							 if($ot=='TOTAL'){
								$fld_totals = $vs;
							 }
							 if($ot=='CURRENCY CODE'){
								$fld_currency_code = $vs;
							 }
							 if($ot=='CURRENCY RATE'){
								$fld_currency_rate = $vs;
							 }
							 if($ot=='TRADE TYPE'){
								$fld_trade_type = $vs;
							 }
							 if($ot=='ENTRY MODE'){
								$fld_entry_mode = $vs;
							 }
							
  							/* $k.= $ot.',';
   							 $v.= "'".$vs."'".',';	
							 
							if($ot=='jobrefno'){
							 $account_code = $vs;
							 $codes = $db->query("SELECT code FROM subcodes WHERE description = '".$account_code."' and company_id = '".$cid."' ");		
							 foreach($codes->fetchAll() as $sc) {					
					         $code 		= $sc['code'];					
				             }			
				             $subcode_id=0;
				             $codes1 = $db->query("SELECT id FROM subcodes WHERE description = '".$account_code."' ");		
				             foreach($codes1->fetchAll() as $sc1) {				
					         $subcode_id = $sc1['id'];
				             }
							 }*/
							
						} 
						if($sc==0){}else{
							 $valname[] ="'".$fld_day."','".$profit_centers."','".$subcode_id."','".$fld_ref."','".$fld_describe."','".$fld_debit."','".$fld_credit."','".$fld_gst."','".$fld_tax_code."','".$fld_totals."','".$fld_currency_code."','".$fld_currency_rate."','".$fld_trade_type."','".$fld_entry_mode."'";
							/*$kename = trim($k,',');
							$keyname[] = ltrim($kename,'0');
							$vname = trim($v,',');
							$valname[] = ltrim($vname,'Array');*/
							//echo "<pre>";print_r($valname);				
														
			}		
			}
			}
			
				$created_by = $_SESSION['username'];
				$created_ip = $_SERVER['REMOTE_ADDR'];
				$created    = date("Y-m-d H:i:s");
			    foreach($valname as $Keys=>$values) {
				/*$key_name = $keyname[$Keys];*/
				$val_name = $valname[$Keys];
				
				
				$created_by = $_SESSION['username'];
				$created_ip = $_SERVER['REMOTE_ADDR'];
				$created    = date("Y-m-d H:i:s");
				//echo "insert into journal_entries($tbl_date) values ('$fld_date')";
			   $db->query("insert into journal_entries(date,profit_center_id,subcode_id,ref,memo,debit,credit,gst,taxcode,totalamount,currencycode,currencyrate,trade_type,entry_mode,company_id,created_by,created_ip,created) values ($val_name,'$cid','$created_by','$created_ip','$created') ");
			  }
				//exit; 
			
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Add";
			$window_name     = "Import General Ledger";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
			
		
			
		
			print "Import done";
		
			//view upload form			
			
			header("Location: ?controller=importjournalentries&action=index&cid=".$cid."");	
	
		}	
			
		require_once('views/importjournalentries/create.php'); 	 
	  
    }		
			

    public function error() {
      require_once('views/importjournalentries/error.php');
    }
  }
?>