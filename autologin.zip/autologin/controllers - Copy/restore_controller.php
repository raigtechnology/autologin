<?php
  class RestoreController {
  
	public function index() {      
	
				
		$db = Db::getInstance();		    
				
		$cid = $_GET['cid']; // companyid
			
		
		$tabs = $db->query('SELECT COUNT(*) as total FROM information_schema.tables where table_schema = "frombackup" ');
		foreach($tabs->fetchAll() as $tb) {
			$total_tables = $tb['total'];
		} 	
		
			
		if($total_tables>4){
			$backuplist = array();				
			$backup = $db->query("select * from backup");	
		
			$cnt=0;
			foreach($backup->fetchAll() as $bk) {
				$backuplist[] = $bk;
			}  	
			
			$cnt = count($backuplist);
			
		}		
			
								
				
		if(isset($_POST['create'])){
																		
						 
				$db->query("DROP DATABASE ".$_SESSION['dbname']." ");
				
				$sql = $db->query("CREATE DATABASE ".$_SESSION['dbname']." ");
		
		   		// if (mysql_query($sql, $link)  && mysql_select_db($database) && mysql_query($aa_sql, $link) ) 		   		 	
		   		 	
					$sql_filename = $_POST['dbfile2'];	// 'sql-backup-08-04-2016--04-05-24.sql';
							
					$path = "";
					//$sql_filename = 'sql-backup-08-04-2016--04-05-24.sql';
					$sql_contents = file_get_contents($path.$sql_filename);
					$sql_contents = explode(";", $sql_contents);					    
					
					$con= mysql_connect("localhost",$_SESSION['dbusername'],$_SESSION['dbpassword']);					
					mysql_select_db($_SESSION['dbname'], $con);
						
					foreach($sql_contents as $query){
					   $result = mysql_query($query);		     
					}
				
				
					// for  stored procedure
					$path1 = "";
					$sql_filename1 = 'db/procedure.sql';
					$sql_contents1 = file_get_contents($path1.$sql_filename1);
					$sql_contents1 = explode("$$", $sql_contents1);
					
					$con= mysql_connect("localhost",$_SESSION['dbusername'],$_SESSION['dbpassword']);					
					mysql_select_db($_SESSION['dbname'], $con);
					    					
					foreach($sql_contents1 as $query1){
					   $result1 = mysql_query($query1);					     
					}
				
					
					// for views
					$path2 = "";
					$sql_filename2 = 'db/views.sql';
					$sql_contents2 = file_get_contents($path2.$sql_filename2);
					$sql_contents2 = explode(";", $sql_contents2);		
					
					$con= mysql_connect("localhost",$_SESSION['dbusername'],$_SESSION['dbpassword']);					
					mysql_select_db($_SESSION['dbname'], $con);
					    					
					foreach($sql_contents2 as $query2){
					   $result2 = mysql_query($query2);					     
					}
								
				
				header("Location: ?controller=users&action=index");		
		}
		
		
						  
	  require_once('views/restore/index.php'); 
	  
    }		
	
	
	public function restore(){
	
		session_destroy();	
		header("Location: ?controller=restore&action=index");		
		
	}
	

    public function error() {
      require_once('views/restore/error.php');
    }
  }
?>