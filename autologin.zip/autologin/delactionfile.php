<?php session_start();
	
	require_once("connection.php");
	$db = Db::getInstance();		 
		
	$db->query("delete from user_logs where username='".$_SESSION['username']."' and password='".$_SESSION['password']."' and app_type='accounts' and user_group_id='".$_SESSION['user_group_id']."' ");	
	

exit;

	//unset($_SESSION['username']);
	//unset($_SESSION['password']);	
	
	?>