<?php
  class GstbaddebtsalesadjustmentController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];    // company id	    	    
						
		$currentdate = date("Y-m-d");
		
		
		$first_month_start_date = date('Y-m-01', strtotime($currentdate." -1 month"));
		$first_month_end_date = date('Y-m-t', strtotime($currentdate." -1 month"));
				
		$first_month = (strtotime($first_month_end_date) - strtotime($first_month_start_date)) / (60 * 60 * 24);		
		$first_month = $first_month + 1;
			
		$second_month_start_date = date('Y-m-01', strtotime($currentdate." -2 month"));
		$second_month_end_date = date('Y-m-t', strtotime($currentdate." -2 month"));
		
		$second_month = (strtotime($second_month_end_date) - strtotime($second_month_start_date)) / (60 * 60 * 24);		
		$second_month = $second_month + 1;
		
		$third_month_start_date = date('Y-m-01', strtotime($currentdate." -3 month"));
		$third_month_end_date = date('Y-m-t', strtotime($currentdate." -3 month"));
		
		$third_month = (strtotime($third_month_end_date) - strtotime($third_month_start_date)) / (60 * 60 * 24);
		$third_month = $third_month + 1;		
		
		$fourth_month_start_date = date('Y-m-01', strtotime($currentdate." -4 month"));
		$fourth_month_end_date = date('Y-m-t', strtotime($currentdate." -4 month"));
		
		$fourth_month = (strtotime($fourth_month_end_date) - strtotime($fourth_month_start_date)) / (60 * 60 * 24);
		$fourth_month = $fourth_month + 1;	
		
		$fifth_month_start_date = date('Y-m-01', strtotime($currentdate." -5 month"));
		$fifth_month_end_date = date('Y-m-t', strtotime($currentdate." -5 month"));
		
		$fifth_month = (strtotime($fifth_month_end_date) - strtotime($fifth_month_start_date)) / (60 * 60 * 24);
		$fifth_month = $fifth_month + 1;	
		
		$sixth_month_start_date = date('Y-m-01', strtotime($currentdate." -6 month"));
		$sixth_month_end_date = date('Y-m-t', strtotime($currentdate." -6 month"));
		
		$sixth_month = (strtotime($sixth_month_end_date) - strtotime($sixth_month_start_date)) / (60 * 60 * 24);
		$sixth_month = $sixth_month + 1;	
		
		$seventh_month_start_date = date('Y-m-01', strtotime($currentdate." -1 month"));
		$seventh_month_end_date = date('Y-m-t', strtotime($currentdate." -1 month"));
		
		/*echo $first_month.'<br>';
		echo $second_month.'<br>';
		echo $third_month.'<br>';
		echo $fourth_month.'<br>';
		echo $fifth_month.'<br>';
		echo $sixth_month.'<br>';*/
		
		
		$total_days = $first_month + $second_month + $third_month + $fourth_month + $fifth_month + $sixth_month;
		
		/*$baddebtlist = array();
		$baddebt = $db->query("select * from gstbaddebt where trade_type ='Trade Debtors' and company_id ='".$cid."' and  DATEDIFF('".$currentdate."',gstdate) > 180  group by description order by gstdate"); 	
		foreach($baddebt->fetchAll() as $bd) {
			$baddebtlist[] = $bd;
		}	*/					
		
		$appinvoices = array();
		$invs = $db->query("select distinct(invoice_no) from gst5b6b where company_id ='".$cid."' ");	
		foreach($invs->fetchAll() as $inv) {
			$appinvoices[] 	= $inv['invoice_no'];	
		}				
				
		$id_invs = $appinvoices;
		$apinvs = implode("','", $id_invs);		
		
			
		$baddebtlist = array();
		$baddebt = $db->query("select * from gstbaddebt where trade_type ='Trade Debtors' and company_id ='".$cid."' and date(gstdate) BETWEEN date('1111-11-11') and date('".$seventh_month_end_date."') and ref not in ('gift','dispose') and description not in('".$apinvs."') group by description order by gstdate"); 	
		foreach($baddebt->fetchAll() as $bd) {
			$baddebtlist[] = $bd;
		}		
					
				
		$gstbaddebitvalue = array();														
		$in=0;
		foreach($baddebtlist as $key => $value){
				
																	
			$value['flags']=0;
			$value['flag']=1;
						
			$gst5blist = array();			
								
			$gst5b = $db->query("select flag, invoice_no, sum(5b_value) as g5b_value_total, sum(6b_value) as g6b_value_total, sum(5b) as g5btotal, sum(6b) as g6btotal from gst5b6b where invoice_no = '".$value['description']."' and company_id ='".$cid."' "); 												
			foreach($gst5b->fetchAll() as $gbd) {		
								
				if($gbd['g5b_value_total']>0 || $gbd['g6b_value_total']>0){
					$gst5blist[] = $gbd;
				}
				
			}	
			
		
						
															
			$ir=0;
			foreach($gst5blist as $g5b){
				
																								
				if($g5b['flag']==1){					
				
					$b6value 	= $g5b['g5b_value_total'];
					$b6b 		= $g5b['g5btotal'];
					$b5value 	= $g5b['g6b_value_total'];
					$b5b 		= $g5b['g6btotal'];
					$invoice_no = $g5b['invoice_no'];
				
				} else {
										
					$b5value 	= $g5b['g5b_value_total'];
					$b5b 		= $g5b['g5btotal'];
					$b6value 	= $g5b['g6b_value_total'];
					$b6b 		= $g5b['g6btotal'];
					$invoice_no = $g5b['invoice_no'];		
				
				}	
				
				
				
                if($value['description']==$invoice_no){					
					
					$lastflag = $db->query("select flag from gstbaddebt where description = '".$invoice_no."' and company_id ='".$cid."' order by id desc limit 1 "); 						
					foreach($lastflag->fetchAll() as $lf) {																		
							$last_flag = $lf['flag'];				
					}
					
					if($last_flag==1){
						$cont = " and flag=0 "; 
					} else {
						$cont = "";
					}
										
										
					$totalqry = $db->query("select sum(debit-credit) as debitcredittotal, sum(debit_gst-credit_gst) as debitcreditgsttotal from gstbaddebt where company_id ='".$cid."' and description = '".$invoice_no."' ".$cont." "); 		
										
					foreach($totalqry->fetchAll() as $tq) {
						$debitcredittotal = $tq['debitcredittotal'];
						$debitcreditgsttotal = $tq['debitcreditgsttotal'];	
					}
															
					
					$gstlists = array();
					$gstlist = $db->query("select sum(debit-credit)as tot, sum(debit) as debit, sum(credit) as credit, sum(debit_gst) as debit_gst, sum(credit_gst) as credit_gst, flag from gstbaddebt where description = '".$invoice_no."' and company_id ='".$cid."' "); 						
					foreach($gstlist->fetchAll() as $gl) {
						if($gl['debit']>0 || $gl['credit']>0){														
							$gstlists[] = $gl;
						}
						
						$pretotal = $gl['tot']; 
						
					}
					
																																																					
					//$count = count($gstlists);		
				
																										
					if($pretotal>0){ // list only pending records												
					
						$inn=0;																							
						foreach($gstlists as $gst){																																																																																												
							$prev_b5value	= $gst['debit'];		
							$prev_b6value 	= $gst['credit']; 	
							$prev_b5b 		= $gst['debit_gst']; 
							$prev_b6b		= $gst['credit_gst'];		
														
							if($prev_b5b>0 || $prev_b6b>0){											
										
								// for background reference									
								
																																										
								if($b5value>0){				
																															
									if(($b5value==$prev_b6value)) {										
																																	
										$value['debit']			= $prev_b6value;
										$value['credit']	 	= "0.00";//$b6value - $prev_b5value;
										$value['debit_gst'] 	= $prev_b6b;
										$value['credit_gst']	= "0.00"; //$b6b - $prev_b5b;
										
										$value['flags'] 		= 0;     //tmp
																			
									} else {								
																																																																																										
										$value['debit']			= abs($debitcredittotal);
										$value['credit']	 	= "0.00";//$b6value - $prev_b5value;
										$value['debit_gst'] 	= abs($debitcreditgsttotal);
										$value['credit_gst']	= "0.00"; //$b6b - $prev_b5b;
								
										$value['flags'] 		= 1;  //tmp
										$value['slugs'] 		= 0;  //tmp
								
										$value['debits']		= abs($debitcredittotal);                           //tmp
										$value['credits']	 	= "0.00";//$b6value - $prev_b5value;        //tmp
										$value['debit_gsts'] 	= abs($debitcreditgsttotal);                                //tmp
										$value['credit_gsts']	= "0.00"; //$b6b - $prev_b5b;                //tmp
																
									} 
																
																				
								} /*else if($b6value>0){														
									
									if(($b6value==$prev_b5value))	{
																													
										$value['debit']			= "0.00";
										$value['credit']	 	= $prev_b5value; //$b6value - $prev_b5value;
										$value['debit_gst'] 	= "0.00";
										$value['credit_gst']	= $prev_b5b; //$b6b - $prev_b5b;
																					
									} else {											
										
										$value['debit']			= "0.00";
										$value['credit']	 	= abs($debitcredittotal);//$b6value - $prev_b5value;
										$value['debit_gst'] 	= "0.00";
										$value['credit_gst']	= abs($debitcreditgsttotal); //$b6b - $prev_b5b;
										
										$value['flags'] 		= 1;     //tmp
										$value['slugs'] 		= 0;//tmp
										
										$value['debits']		= "0.00";
										$value['credits']	 	= $prev_b5value;//$b6value - $prev_b5value;//tmp
										$value['debit_gsts'] 	= "0.00"; //$b6b - $prev_b5b;//tmp
										$value['credit_gsts']	= $prev_b5b;//tmp
																		
									} 	
																						
								}*/ else {
									unset($value['debit']);
									unset($value['credit']);
									unset($value['debit_gst']);
									unset($value['credit_gst']);
								}							
								
							$inn++;	
							} else {
								
								unset($value['debit']);
								unset($value['credit']);
								unset($value['debit_gst']);
								unset($value['credit_gst']);
							}
						}
							
					} else {
						$value['debit']=0;;
						$value['credit']=0;
						$value['debit_gst']=0;
						$value['credit_gst']=0;
					
					}
				
                } else {
					
					$count=0;
					$count1=0;
					$count2=0;
					
					$newlistarr = array();	
					$newlist = $db->query("select (sum(debit)-sum(credit)) as debit, (sum(credit)-sum(debit)) as credit, (sum(debit_gst)-sum(credit_gst)) as debit_gst, (sum(credit_gst)-sum(debit_gst)) as credit_gst from gstbaddebt where description = '".$value['description']."' and company_id ='".$cid."' and flag=0  "); 
					foreach($newlist->fetchAll() as $nl) {
																		
						$newlistarr[] = $nl;
					}
					
					foreach($newlistarr as $nl){						
							
						if($nl['debit']>$nl['credit']){					
						
							$value['debit']			=	$nl['debit'];
							$value['credit']		=	0;
							$value['debit_gst']		=	$nl['debit_gst'];
							$value['credit_gst']	=	0;
						
						} else if($nl['debit']<$nl['credit']){
							$value['debit']			=	0;
							$value['credit']		=	$nl['credit'];
							$value['debit_gst']		=	0;
							$value['credit_gst']	=	$nl['credit_gst'];
						}		
				
					}
										
					
					$gst5b6binvoicecount = $db->query("select count(*) as total from gst5b6b where invoice_no = '".$value['description']."' and company_id ='".$cid."' "); 		
					foreach($gst5b6binvoicecount->fetchAll() as $gic) {
						$count = $gic['total'];
					}	
				
					$gst5b6binvoicecount1 = $db->query("select count(*) as total1 from gst5b6b where invoice_no = '".$value['description']."' and company_id ='".$cid."' and flag=1"); 		
					foreach($gst5b6binvoicecount1->fetchAll() as $gic1) {
						$count1 = $gic1['total1'];
					}	
				
					$gst5b6binvoicecount2 = $db->query("select count(*) as total2 from gstbaddebt where description = '".$value['description']."' and company_id ='".$cid."' and flag=0"); 											
					foreach($gst5b6binvoicecount2->fetchAll() as $gic2) {
						$count2 = $gic2['total2'];
					}

							
					if($count>0){
						
						if($count==1 && $count1==1 && $count2==0){
							
							unset($value['debit']);
							unset($value['credit']);
							unset($value['debit_gst']);
							unset($value['credit_gst']);
						}	
																																				
						$value['flag']		= 1;		
						$value['flags']		= 0;									
				
					} else {
											
						$value['flags']		= 0;		
						$value['flag']		= 2;				
					}						
														
				}
			$ir++;
			}	
									
									
		$gstbaddebitvalue[] = $value;										
		$in++;
		}
				
										  
	  require_once('views/gstbaddebtsalesadjustment/index.php'); 
	  
    }		

	// filter	
	public function filter() {
     	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance(); // db connection	
		$cid = $_GET['cid'];      // company id	    	 
	   					
		// for filter		
       if(isset($_POST)){		
	   				
			$data = $_POST['data'];					
			
							
			$i=0;
			$addgst=0;
			foreach($data as $da){
																		
		     	$addgst = $da['Gst5b6bTmp']['addgst'];	
				$id = $da['Gst5b6bTmp']['id'];	
				
				
				if($addgst>0){
										
														
						if($da['Gst5b6b_flag']['flag']==2){
						
							$da_5b = number_format($da['Gst5b6bTmp']['credit_gst'], 2, '.', '');
							$da_6b = number_format($da['Gst5b6bTmp']['debit_gst'], 2, '.', '');
																						
							$da['Gst5b6bTmp']['company_id']     = $cid; 	
							$da['Gst5b6bTmp']['customer_id'] 	= $da['Gst5b6bTmp']['account_code'];	
							$da['Gst5b6bTmp']['invoice_no'] 	= $da['Gst5b6bTmp']['description'];	
							$da['Gst5b6bTmp']['invoice_date']   = $da['Gst5b6bTmp']['gstdate'];					
							$da['Gst5b6bTmp']['5b']  			= $da_5b;	
							$da['Gst5b6bTmp']['6b'] 	 		= $da_6b;	
							$da['Gst5b6bTmp']['trade_type'] 	= $da['Gst5b6bTmp']['trade_type'];		
							$da['Gst5b6bTmp']['5b_value'] 		= $da['Gst5b6bTmp']['credit'];		
							$da['Gst5b6bTmp']['6b_value'] 		= $da['Gst5b6bTmp']['debit'];		
										
							if($da_5b>0){
								$datmp['Gst5b6b']['taxcode']  		= "AJS";	
							} else if($da_6b>0){
								$datmp['Gst5b6b']['taxcode']  		= "AJP";	
							}
						
							//$da_5b = $da_6b;
							//$da_6b = $da_5b;	
							//$da['Gst5b6bTmp']['debit'] = $da['Gst5b6bTmp']['credit'];
							//$da['Gst5b6bTmp']['credit'] = $da['Gst5b6bTmp']['debit'];
												
							$datmp['Gst5b6b']['company_id']     	= $cid; 	
							$datmp['Gst5b6b']['customer_id'] 		= $da['Gst5b6bTmp']['account_code'];	
							$datmp['Gst5b6b']['invoice_no'] 		= $da['Gst5b6bTmp']['description'];	
							$datmp['Gst5b6b']['invoice_date']   	= date("d/m/Y");					
							$datmp['Gst5b6b']['5b']  				= $da_5b;	
							$datmp['Gst5b6b']['6b'] 	 			= $da_6b;	
							$datmp['Gst5b6b']['trade_type'] 		= $da['Gst5b6bTmp']['trade_type'];		
							$datmp['Gst5b6b']['5b_value'] 			= $da['Gst5b6bTmp']['5b_value'];		
							$datmp['Gst5b6b']['6b_value'] 			= $da['Gst5b6bTmp']['6b_value'];	
							$datmp['Gst5b6b']['transaction_date']  	= $da['Gst5b6bTmp']['gstdate'];		
							$datmp['Gst5b6b']['flag']  				= 1;		
							
							
						} else {
							
							
						
							if($da['Gst5b6b_flag']['slug']==0){
								
								$da_5b = number_format($da['Gst5b6bTmp']['debit_gst'], 2, '.', '');
								$da_6b = number_format($da['Gst5b6bTmp']['credit_gst'], 2, '.', '');
								
								if($da_5b>0){
									$datmp['Gst5b6b']['taxcode']  		= "AJS";	
								} else if($da_6b>0){
									$datmp['Gst5b6b']['taxcode']  		= "AJP";	
								}					
								
								$datmp['Gst5b6b']['company_id']     	= $cid; 	
								$datmp['Gst5b6b']['customer_id'] 		= $da['Gst5b6bTmp']['account_code'];	
								$datmp['Gst5b6b']['invoice_no'] 		= $da['Gst5b6bTmp']['description'];	
								$datmp['Gst5b6b']['invoice_date']   	= date("d/m/Y");					
								$datmp['Gst5b6b']['5b']  				= $da_5b;	
								$datmp['Gst5b6b']['6b'] 	 			= $da_6b;	
								$datmp['Gst5b6b']['trade_type'] 		= $da['Gst5b6bTmp']['trade_type'];		
								$datmp['Gst5b6b']['5b_value'] 			= $da['Gst5b6bTmp']['debit'];		
								$datmp['Gst5b6b']['6b_value'] 			= $da['Gst5b6bTmp']['credit'];	
								$datmp['Gst5b6b']['transaction_date']  	= $da['Gst5b6bTmp']['gstdate'];	
								$datmp['Gst5b6b']['flag']  				= 0;		
							
							} else {
							
								$da_5b = number_format($da['Gst5b6bTmp']['credit_gst'], 2, '.', '');
								$da_6b = number_format($da['Gst5b6bTmp']['debit_gst'], 2, '.', '');
								
								if($da_5b>0){
									$datmp['Gst5b6b']['taxcode']  		= "AJS";	
								} else if($da_6b>0){
									$datmp['Gst5b6b']['taxcode']  		= "AJP";	
								}					
								
								$datmp['Gst5b6b']['company_id']     	= $cid; 	
								$datmp['Gst5b6b']['customer_id'] 		= $da['Gst5b6bTmp']['account_code'];	
								$datmp['Gst5b6b']['invoice_no'] 		= $da['Gst5b6bTmp']['description'];	
								$datmp['Gst5b6b']['invoice_date']   	= date("d/m/Y");					
								$datmp['Gst5b6b']['5b']  				= $da_5b;	
								$datmp['Gst5b6b']['6b'] 	 			= $da_6b;	
								$datmp['Gst5b6b']['trade_type'] 		= $da['Gst5b6bTmp']['trade_type'];		
								$datmp['Gst5b6b']['5b_value'] 			= $da['Gst5b6bTmp']['credit'];		
								$datmp['Gst5b6b']['6b_value'] 			= $da['Gst5b6bTmp']['debit'];	
								$datmp['Gst5b6b']['transaction_date']  	= $da['Gst5b6bTmp']['gstdate'];	
								$datmp['Gst5b6b']['flag']  				= 1;		
							
							}
							
							
						}
												
																		
				
				
				//	unset($da['Gst5b6bTmp']['description']); 
					unset($da['Gst5b6bTmp']['gstdate']); 				
					unset($da['Gst5b6bTmp']['debit']); 
					unset($da['Gst5b6bTmp']['credit']);  
					unset($da['Gst5b6bTmp']['ref']);  
					unset($da['Gst5b6bTmp']['account_code']);  
					unset($da['Gst5b6bTmp']['addgst']);  
					unset($da['Gst5b6bTmp']['credit_gst']); 
					unset($da['Gst5b6bTmp']['debit_gst']); 
					
					$gstdata = $da;	
					$gst5b6bdata = $datmp;						
					
				
					$db->query("update gstbaddebt set flag=1 where description='".$da['Gst5b6bTmp']['description']."' and company_id ='".$cid."' ");												
					
				
				
				$db->query("delete from gst5b6btmp");	
			
				//foreach($gstdata as $gt){
				
					$insertqry = $db->query("insert into gst5b6btmp(`trade_type`,`company_id`,`customer_id`,`invoice_no`,`invoice_date`,`5b`,`6b`,`5b_value`,`6b_value`)values('".$da['Gst5b6bTmp']['trade_type']."', '".$da['Gst5b6bTmp']['company_id']."', '".$da['Gst5b6bTmp']['customer_id']."', '".$da['Gst5b6bTmp']['invoice_no']."', '".$da['Gst5b6bTmp']['invoice_date']."', '".$da['Gst5b6bTmp']['5b']."', '".$da['Gst5b6bTmp']['6b']."', '".$da['Gst5b6bTmp']['5b_value']."', '".$da['Gst5b6bTmp']['6b_value']."')");
				
			//	}
			 // gst5b6b	
			
				//foreach($gst5b6bdata as $gt56){
				
				  $insertqry = $db->query("insert into gst5b6b(`trade_type`,`company_id`,`customer_id`,`invoice_no`,`invoice_date`,`5b`,`6b`,`5b_value`,`6b_value`,`transaction_date`,`flag`,`taxcode`)values('".$datmp['Gst5b6b']['trade_type']."', '".$datmp['Gst5b6b']['company_id']."', '".$datmp['Gst5b6b']['customer_id']."', '".$datmp['Gst5b6b']['invoice_no']."', '".$datmp['Gst5b6b']['invoice_date']."', '".$datmp['Gst5b6b']['5b']."', '".$datmp['Gst5b6b']['6b']."', '".$datmp['Gst5b6b']['5b_value']."', '".$datmp['Gst5b6b']['6b_value']."', '".$datmp['Gst5b6b']['transaction_date']."', '".$datmp['Gst5b6b']['flag']."', '".$datmp['Gst5b6b']['taxcode']."')");					
				
			//	} 	
			
				
				// gst output tax
			
						
			
				$inputtaxdata = $db->query("select id from subcodes where description = 'GST-INPUT-TAX-AJP' and company_id='".$cid."' ");
				foreach($inputtaxdata->fetchAll() as $inpt){
					$inputtax_id 			= $inpt['id'];									
				}
				
				
				$b5transdate = date("Y-m-d", strtotime($datmp['Gst5b6b']['transaction_date']));
				$b5dates = date("Y-m-d", strtotime($datmp['Gst5b6b']['invoice_date']));
				
				
				$outputtaxjournaldata = $db->query("insert into journal_entries(`subcode_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`entry_mode`,`Gstinvdate`,`taxcode`) values('".$inputtax_id."','".$cid."','".$b5transdate."','outputtax','".$datmp['Gst5b6b']['invoice_no']."','".$datmp['Gst5b6b']['6b']."','".$datmp['Gst5b6b']['6b']."','sales','".$b5dates."','AJP')");
				
				if(!$outputtaxjournaldata){
					die('Invalid query: ' . mysql_error());
				}		
			
			
						
				
					$i++;
					
				}	
							
			}	
	
						
           							
			header("Location: ?controller=gstbaddebtsalesadjustment&action=index&cid=".$cid."");			
			
        }  
		
		  
		            	
   }



    public function error() {
      require_once('views/gstbaddebtsalesadjustment/error.php');
    }
  }
?>