<?php
  class Post {
    // we define 3 attributes
    // they are public so that we can access them using $post->author directly
    public $id;
    public $author;
    public $content;

    public function __construct($id, $author, $content) {
      $this->id      = $id;
      $this->author  = $author;
      $this->content = $content;
    }

    public static function all() {
      $list = [];
      $db = Db::getInstance();
      $req = $db->query('SELECT * FROM unattended_gl');
		
      // we create a list of Post objects from the database results
      foreach($req->fetchAll() as $post) {
        $list[] = new Post($post['id'], $post['account_code'], $post['description']);
      }

     // return $list;
	 
	$exectime = microtime(); 
	$exectime = explode(" ",$exectime); 
	$exectime = $exectime[1] + $exectime[0]; 
	$starttime = $exectime; 
	  
	 /* $subcodesList = $db->query("select sc.id, sc.description, sc.code from subcodes as sc where sc.company_id ='173' order by sc.code asc ");		
	  $in=0;
	  foreach($subcodesList->fetchAll() as $row) {
		$subcodes[$in]['Subcode']['id'] 			= $row['id']; 		
		$subcodes[$in]['Subcode']['description'] 	= $row['description'];
		$subcodes[$in]['Subcode']['code'] 			= $row['code']; 
	  $in++;
	  }	
	  
	 
	  	
	
	foreach($subcodes as $sc){	
		
		$con = mysqli_connect("localhost","root","@)!%@9179","newaccounts");
		$id = $sc['Subcode']['id'];		
		$data = mysqli_query($con,"CALL generalLedgerForProfitCenter ('173','63','$id','2015-01-01', '2015-07-30')");
		while($row1=mysqli_fetch_array($data)){		
			$row1['code'] = $sc['Subcode']['code'];
			$row1['description'] = $sc['Subcode']['description'];
			$gls[] = $row1;	
		}			
		mysqli_close($con);		
		
	}	*/
		
		$data = $db->query("SELECT Subcode.description, Subcode.code, (select sum(gl.debit) from general_ledgers as gl where gl.date <= DATE('2015-07-03') and gl.subcode_id = Subcode.id ) as debit FROM subcodes AS Subcode LEFT JOIN master_account_codes ON master_account_codes.id = Subcode.master_account_code_id WHERE Subcode.subcode_of = (select sc.id from subcodes as sc where sc.master_account_code_id = (select mac.id from master_account_codes as mac where mac.account_type_id = 13 and mac.company_id=173) limit 1) AND master_account_codes.account_type_id = 13 AND master_account_codes.company_id = 173 GROUP by Subcode.id ORDER by sum(debit) DESC");
		foreach($data->fetchAll() as $row) {			
			$gls[] = $row;	
		}			
		
	  
	  $exectime = microtime(); 
	  $exectime = explode(" ",$exectime); 
	  $exectime = $exectime[1] + $exectime[0]; 
	  $endtime = $exectime; 
	  $totaltime = ($endtime - $starttime); 
	  echo "This page was created in ".$totaltime." seconds";
 
	  
    }

    public static function find($id) {
      $db = Db::getInstance();
      // we make sure $id is an integer
      $id = intval($id);
      $req = $db->prepare('SELECT * FROM posts WHERE id = :id');
      // the query was prepared, now we replace :id with our actual $id value
      $req->execute(array('id' => $id));
      $post = $req->fetch();

      return new Post($post['id'], $post['author'], $post['content']);
    }
  }
?>