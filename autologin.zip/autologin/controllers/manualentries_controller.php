<?php
  class ManualentriesController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    	    
			
		$fromdate = date("Y-m-01");
		$todate = date("Y-m-d");
		$cond ="and YEAR(je.date) = YEAR(CURRENT_DATE()) AND MONTH(je.date) = MONTH(CURRENT_DATE())";
		$invoice_no ="";
		
		if(isset($_POST['submit'])){		
			
			$invoice_no = $_POST['invoice_no'];
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));				
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-01");
				$todate = date("Y-m-d");
			}						
			
			if($invoice_no!="" && $fromdate!="1970-01-01" && $todate!="1970-01-01"){
				$cond = " and je.memo = '".$invoice_no."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' "; 			
			} else if($invoice_no=="" && $fromdate!="1970-01-01" && $todate!="1970-01-01"){
				$cond = " and je.date >= '".$fromdate."' AND je.date <= '".$todate."' "; 			
			} else if($invoice_no!="" && $fromdate=="1970-01-01" && $todate=="1970-01-01"){
				$cond = " and je.memo = '".$invoice_no."'  "; 			
			} else {
				$cond =" and YEAR(je.date) = YEAR(CURRENT_DATE()) AND MONTH(je.date) = MONTH(CURRENT_DATE())";
			}
			
		}
		
		
		$journallist = array();
		$journals = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.entry_mode in('manual')  group by je.memo  order by je.date,je.memo ");	
		foreach($journals->fetchAll() as $jl) {
			$journallist[] = $jl;
		}  	
									
		$purchaseinvoicelistgroup = array();
		$purchaseinvoicegroup = $db->query("select je.memo, je.id from journal_entries as je where je.company_id='".$cid."' and je.entry_mode = 'manual' ".$cond." group by je.memo ");	
		foreach($purchaseinvoicegroup->fetchAll() as $jel) {
			$purchaseinvoicelistgroup[] = $jel;
		}  		
		
		$purchaseinvoicelist = array();
		$purchaseinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code, je.trade_type from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode = 'manual' ".$cond." order by je.date, je.memo  ");	
		foreach($purchaseinvoice->fetchAll() as $je) {
			$purchaseinvoicelist[] = $je;
		}  	
						  
	    require_once('views/manualentries/index.php'); 
	  
    }		
	
		
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
		
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id != '6' order by account_desc asc ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
			
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	
					
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' order by profit_center asc ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
					
		
		if(isset($_POST['save'])){			
						
			$date  				= date("Y-m-d", strtotime($_POST['date']));
			$ref  				= $_POST['ref'];
			$profit_center_id  	= $_POST['profit_center_id'];	
			$invoice_no  		= $_POST['invoice_no'];	
			$gstinvdate         = $date; 		
			$invtype 			= "manual";
						
			$data = $_POST['data'];
			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
				
		
			foreach($data as $dt){
									
				//journal entries  
							
				$pd_subcode_id   			= $dt['subcode_id'];				
				$pd_company_id 				= $cid;
				$pd_date 					= $date;
				$pd_ref 					= $ref;			
				$pd_memo 					= $invoice_no;			
				$pd_debit  					= $dt['debit'];	
				$pd_credit 					= $dt['credit'];

				$remarks 					= $dt['remarks'];	
				
				$pd_entry_mode 				= 'manual';	
				
				$pd_debit  					= number_format($pd_debit, 2, '.', '');	
				$pd_credit 					= number_format($pd_credit, 2, '.', '');		
					
									
				$db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`credit`,`entry_mode`,`status`,`Gstinvdate`,`created_by`,`created_ip`,`created`,`remarks`,`deb_crt_date`) values('".$pd_subcode_id."','".$profit_center_id."','".$pd_company_id."','".$pd_date."','".$pd_ref."','".$invoice_no."','".$pd_debit."','".$pd_credit."','".$pd_entry_mode."','0','".$pd_date."','".$created_by."','".$created_ip."','".$created."','".$remarks."','".$pd_date."')");
																
			}
				
			
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Add";
			$window_name     = "Manual Entries";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");	
				
				
									
			header("Location: ?controller=manualentries&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/manualentries/create.php'); 	   
		}  
	  
    }		
	
	
	// edit
	public function edit() {   			
			
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$id = $_GET['id'];		
			
		$id = str_replace("~","/",$id);
			
			
			
				
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' order by profit_center ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
		$subcodeslist = array();	
		$subcodes = $db->query("select id,description,code from subcodes where company_id = '".$cid."' order by code, description ");
		foreach($subcodes->fetchAll() as $sc) {
			$subcodeslist[] = $sc;
		}  	
			
				
		$journallist = array();
		$journals = $db->query("select jl.id, jl.date, jl.profit_center_id, jl.subcode_id, sc.description, jl.memo as invoice, jl.debit, jl.credit, jl.remarks from journal_entries as jl left join subcodes as sc on sc.id = jl.subcode_id where jl.company_id='".$cid."' and sc.company_id='".$cid."' and jl.memo = '".$id."'  ");	
		foreach($journals->fetchAll() as $jl) {
			$journallist[] = $jl;
		}  	
						  
		if(isset($_POST['save'])){			
			
			$modified_by = $_SESSION['username'];
			$modified_ip = $_SERVER['REMOTE_ADDR'];
			$modified    = date("Y-m-d H:i:s"); 
			
			
			
			$data = $_POST['data'];
						
			foreach($data as $dt){							
								
				$profit_center_id	= $dt['profit_center_id'];	
				$subcode_id	= $dt['subcode_id'];		
				$uid	= $dt['uid'];		
				$debit	= $dt['debit'];		
				$credit	= $dt['credit'];	
$remarks	= $dt['remarks'];								
				
				// update query
				$result = $db->query("update journal_entries set profit_center_id = '".$profit_center_id."', subcode_id = '".$subcode_id."', debit='".$debit."', credit='".$credit."', modified_by='".$modified_by."', modified_ip='".$modified_ip."', modified='".$modified."', remarks='".$remarks."' where company_id = '".$cid."' and memo = '".$id."' and id='".$uid."' ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}				
			}
			
			$created_by 	 = $_SESSION['username'];
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Change";
			$window_name     = "Manual Entries";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
			
			header("Location: ?controller=manualentries&action=index&cid=".$cid."");						
					
		} else {	 
		   require_once('views/manualentries/edit.php'); 	   
		}  
	  
    }		
	
	// edit
	public function delete() {   			
			
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$id = $_GET['id'];		
			
		//$id = str_replace("~","/",$id);
			
		$result = $db->query("delete from journal_entries where company_id = '".$cid."' and memo = '".$id."' and entry_mode='manual' ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}	
			
		header("Location: ?controller=manualentries&action=index&cid=".$cid."");		
				  
		/*if(isset($_POST['save'])){			
			
			$modified_by = $_SESSION['username'];
			$modified_ip = $_SERVER['REMOTE_ADDR'];
			$modified    = date("Y-m-d H:i:s"); 
			
			
			
			$data = $_POST['data'];
						
			foreach($data as $dt){							
								
				$profit_center_id	= $dt['profit_center_id'];	
				$subcode_id	= $dt['subcode_id'];		
				$uid	= $dt['uid'];		
				$debit	= $dt['debit'];		
				$credit	= $dt['credit'];*/								
				
				// update query
				/*$result = $db->query("update journal_entries set profit_center_id = '".$profit_center_id."', subcode_id = '".$subcode_id."', debit='".$debit."', credit='".$credit."', modified_by='".$modified_by."', modified_ip='".$modified_ip."', modified='".$modified."' where company_id = '".$cid."' and memo = '".$id."' and id='".$uid."' ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}				
			}
			
			$created_by 	 = $_SESSION['username'];
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Change";
			$window_name     = "Manual Entries";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
			
			header("Location: ?controller=manualentries&action=index&cid=".$cid."");						
					
		} else {	 
		   require_once('views/manualentries/edit.php'); 	   
		} */ 
	  
    }	
	

    public function error() {
      require_once('views/manualentries/error.php');
    }
  }
?>