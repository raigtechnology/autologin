<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		
	
	$username		= $_GET['username']; 	
	$password		= $_GET['password']; 	

	$userslist = $db->query("SELECT co.company_name, co.id from tbllogin as tbl left join companies as co on co.id = tbl.company_id where tbl.username='".$username."' and tbl.password='".$password."' ");		
		
	?>	
		<select name="company_id" id="getlogins" class="selectbox" required="required"> 		
		<option value="">-- Choose Company --</option>
		<?php 
		$i=0;
		foreach($userslist->fetchAll() as $ur) {
		?>
		
		<option value="<?php echo $ur['id'];?>"><?php echo $ur['company_name'];?></option>
								
		<?php
		$i++;
		}
		?>				
		</select>	
		</tr>			
	</table>
	
