<?php
  class Accounttypes {
   
  }
?>