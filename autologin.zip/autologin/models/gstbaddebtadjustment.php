<?php
  class gstbaddebtadjustment {
   
  }
?>