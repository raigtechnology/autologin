<?php
  class Db {
    private static $instance = NULL;
	private static $instance_sample = NULL;

    private function __construct() {}

    private function __clone() {}
	

    public static function getInstance() {
      if (!isset(self::$instance)) {
        $pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
         self::$instance = new PDO('mysql:host=localhost;dbname=MHosting_autoaccounts', 'raig_autoaccount', '@)!%@9179', $pdo_options);
      }  
      return self::$instance;
    }
	
	public static function getInstance_sample() {
      if (!isset(self::$instance_sample)) {
        $pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
         self::$instance_sample = new PDO('mysql:host=localhost;dbname=MHosting_sample', 'samplecompany', '@)!%@9179', $pdo_options);
      }
      return self::$instance_sample;
    }
	
  }
?>