<?php session_start();
//ob_start();
//error_reporting(E_ALL & ~E_NOTICE);
	$path = getcwd().'/connection.php';	
	if (file_exists($path)) {
		require_once('connection.php');
	}    

	if (isset($_GET['controller']) && isset($_GET['action'])) {
		
		$controller = $_GET['controller'];
		$action     = $_GET['action'];
	
	} else {		
		
		
		if (file_exists($path)) {			
			$controller = 'users';
			$action     = 'index';
		} else {	
		
			$controller = 'install';
			$action     = 'index';
		}	
	}

	if(isset($_SESSION['msg'])){
		$sessionmsg = $_SESSION['msg'];	
	} else {
		$sessionmsg = "";	
	}
	
	
	if(isset($_SESSION['username'])){	
	   
		$db = Db::getInstance();		    
	
					
		if(isset($_GET['cid'])){
			$coid = $_GET['cid'];
		} else {
			$coid = $_SESSION['company_id'];
		}
				
			    
		$company = $db->query('SELECT id,company_name FROM companies where id ="'.$coid.'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
		} 
		$_SESSION['company_name'] = $company_name;

		
	}	    	
/*	
$inactive = 600;

if(isset($_SESSION['username'])){

	$session_life = time() - $_SESSION['timeout']; 
	if($session_life > $inactive) {
	
		if(isset($_SESSION['username']) && isset($_SESSION['password'])){			
			$db = Db::getInstance();
	  		$db->query("delete from user_logs where username = '".$_SESSION['username']."' and password = '".$_SESSION['password']."' and app_type='accounts'  ");		 
		}			
	  
	  unset($_SESSION['username']);
	  unset($_SESSION['password']);	
	
			 header("Location: ?controller=users&action=logout");		
	
	}
}
*/

$document_root = "https://autoaccounts.com/autologin";


	
require_once('views/layout.php');
?>