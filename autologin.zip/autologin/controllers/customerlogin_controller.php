<?php
  class CustomerloginController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}    
				
		$cid = $_GET['cid']; // company_id
		
		$customerslist = array();				
		$customers = $db->query("select com.company_name,tbl.username,tbl.password,ug.customer_code,reg.registered_date from companies as com inner join tbllogin as tbl on tbl.company_id=com.id left join user_group as ug on ug.company_id=com.id inner join registrations as reg on reg.company_id=com.id group by com.company_name asc ");	
		foreach($customers->fetchAll() as $com) {
			$customerslist[] = $com;
		}  		
					
						  
	  require_once('views/customerlogin/index.php'); 
	  
    }	
	


    public function error() {
      require_once('views/accountingyear/error.php');
    }
  }
?>