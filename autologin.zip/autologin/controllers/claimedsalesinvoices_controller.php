<?php
  class ClaimedsalesinvoicesController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
		
		
		$appinvoices = array();
		$invs = $db->query("select distinct(invoice_no) from gst5b6b where company_id ='".$cid."' ");	
		foreach($invs->fetchAll() as $inv) {
			$appinvoices[] 	= $inv['invoice_no'];	
		}				
				
		$id_invs = $appinvoices;
		$apinvs = implode("','", $id_invs);		
						
		$salesinvoicelistgroup = array();
		$salesinvoicegroup = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.entry_mode in('Sales','Deposit Sales') and je.memo in('".$apinvs."') group by je.memo  ");	 // except simplified invoice and reverse charge invoices
		foreach($salesinvoicegroup->fetchAll() as $jel) {
			$salesinvoicelistgroup[] = $jel;
		}  		
			
		$salesinvoicelist = array();
		$salesinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code, je.trade_type from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode in('Sales','Deposit Sales') and je.ref not in('dispose') and je.memo in('".$apinvs."') order by je.date, je.memo ");	// except simplified invoice and reverse charge invoices
		foreach($salesinvoice->fetchAll() as $je) {
			$salesinvoicelist[] = $je;
		}  	
						  
	    require_once('views/claimedsalesinvoices/index.php'); 
	  
    }		
		
		
	
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
		
		
		$company = $db->query("select MixedSupply, inv_prefix from companies where id='".$cid."'  ");	
		foreach($company->fetchAll() as $cm) {
			$supply_type = $cm['MixedSupply'];
			$inv_prefix = $cm['inv_prefix'];
		}  	
		
		if($supply_type=="Y"){
			$type = 'MIX';
			$stype = "Mixed";
		} else if($supply_type=="N"){
			$type = 'TAXABLE';
			$stype = "Standard";
		} 
		
		$_SESSION['type'] = $type;
		
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id != '6' ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		} 	
		
		// banks
		$bankslist = array();
		$banks = $db->query("select bl.bank_name, bk.subcode_id from banks as bk left join bank_lists as bl on bl.id = bk.bank_list_id left join subcodes as sc on sc.id = bk.subcode_id where bk.company_id=".$cid." order by bl.bank_name");	
		foreach($banks->fetchAll() as $bk) {
			$bankslist[] = $bk;
		}  
		
		
		// sales taxcode master		
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select PurTaxCode from purchasecodematch where supplyType = '".$type."' group by PurTaxCode order by PurTaxCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		// purchase taxcode master		
		$purchasetaxcodemasterlist = array();
		$purchasetaxcodemaster = $db->query("select TaxCode,TaxRate,id from purtaxcodemaster order by TaxCode");	
		foreach($purchasetaxcodemaster->fetchAll() as $pm) {
			$purchasetaxcodemasterlist[] = $pm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	
					
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
			
		
		if(isset($_POST['save'])){			
						
			$date  				= date("Y-m-d", strtotime($_POST['date']));
			$ref  				= $_POST['ref'];
			//$profit_center_id  	= $_POST['profit_center_id'];
			$vendor_id  		= $_POST['vendor_id'];
			$invoice_no  		= $_POST['invoice_no'];
			$currency_code  	= $_POST['currency_code'];
			$exchange_rate  	= $_POST['exchange_rate'];
			$purchase_order_no  = $_POST['purchase_order_no'];	
			$totalamount 		= $_POST['totalamt'];	// including gst
			$gst 	 			= $_POST['totalgst'];			
			
					
			$tblinvmasterpurchase = $db->query("select * from tblinvmaster_purchase order by AutoInvoiceID desc limit 1 ");										
			foreach($tblinvmasterpurchase->fetchAll() as $timp) {			
				$AutoInvoiceID = $timp['AutoInvoiceID'];
			}
									
			if($AutoInvoiceID==""){
				$new_autoinvoice_id= $inv_prefix.''.date("MM/yy").''.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);			
			} else {
				$old_autoinvoice_id = $AutoInvoiceID;									
				$currentlastsixdigit = substr($old_autoinvoice_id, -6);		 // last six digit							
				$prefixstring = substr($old_autoinvoice_id, 0, -6);			 // prefix string						
				$newlastsixdigit = str_pad($currentlastsixdigit + 1, 6, 0, STR_PAD_LEFT);						 // new last six digit			
				$new_autoinvoice_id = $prefixstring.''.$newlastsixdigit;	 // new invoice id																																							
			}	
			
						
			// master purchase data start
			$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$vendor_id."' ");
			foreach($subcodes->fetchAll() as $scs){
				$vendorname 	= $scs['description'];
				$subcode_of 	= $scs['subcode_of'];	
				$account_code 	= $scs['code'];			
			}
			
			$newAutoInvoiceID   = $new_autoinvoice_id;
			$InvRef 			= $invoice_no;
			$PORef 				= $purchase_order_no;
			$InvDate 			= date("d/m/Y", strtotime($date));
			$company_id 		= $cid;			
			$VendorName 		= $vendorname;
			$vendorID 			= $vendor_id;
			$Currencycode 		= $currency_code;
			$Currencyrate 		= $exchange_rate;		
			
			
			// for op taxcode
			$TaxCode			= $_POST['data'][0]['matchcode'];
					
			$masterpurchasedata = $db->query("insert into  tblinvmaster_purchase(`AutoInvoiceID`,`InvRef`,`PORef`,`InvDate`,`company_id`,`VendorName`,`Currencycode`,`Currencyrate`,`vendorID`,`TaxCode`) values('".$newAutoInvoiceID."','".$InvRef."','".$PORef."','".$InvDate."','".$company_id."','".$VendorName."','".$Currencycode."','".$Currencyrate."','".$vendorID."','".$TaxCode."')");	
						
			if(!$masterpurchasedata){
				die('Invalid query: ' . mysql_error());
			}				
			// master purchase data end
			
			// journal entries start
			
			$subcode_id   			= $vendor_id;
			//$profit_center_id 		= $profit_center_id;
			$company_id 			= $cid;
			$date 					= date("Y-m-d", strtotime($date));
			$ref 					= $ref;			
			$memo 					= $invoice_no;			
			$credit 				= $totalamount;		
			$gst 					= $gst;		
			$subcode_of 			= $subcode_of;	
			$entry_mode 			= "Purchase";		
		
			if($TaxCode=="IM" || $TaxCode=="IS"){
				$taxcode = "IM";
			} else {
				$taxocde = $PORef;
			}
						
			// taxcode	
			
			foreach($_POST['data'] as $rdt){
				$price += $rdt['quantity'] * $rdt['unit_price'];
			}
								
			$purchasemasterjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`subcode_of`,`entry_mode`,`totalamount`,`currencycode`,`currencyrate`,`taxcode`,`trade_type`) values('".$subcode_id."','','".$company_id."','".$date."','".$ref."','".$memo."','".$credit."','".$gst."','".$subcode_of."','".$entry_mode."','".$price."','".$Currencycode."','".$Currencyrate."','".$taxocde."','Trade Creditors')");
			
			if(!$purchasemasterjournaldata){
				die('Invalid query: ' . mysql_error());
			}	
			// journal entries end
			
			// gst bad debt entries start
			
			$account_code  			= $account_code;	
			$gstdate 				= date("Y-m-d", strtotime($date));		
			$description 			= $invoice_no;			
			$ref 					= $ref;			
			$credit 				= $totalamount;		
			$credit_gst 			= $gst;		
			$trade_type 			= "Trade Creditors";	
			$company_id 			= $cid;
			
			$gstbaddebtdata = $db->query("insert into gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`credit`,`credit_gst`,`trade_type`,`company_id`) values('".$account_code."','".$gstdate."','".$description."','".$ref."','".$credit."','".$credit_gst."','".$trade_type."','".$company_id."')");
			
			if(!$gstbaddebtdata){
				die('Invalid query: ' . mysql_error());
			}	
			// gst bad debt entries end		
					
					
			$data = $_POST['data'];
				
			foreach($data as $dt){
										
				$productdescription = $db->query("select description, subcode_of from subcodes where id = '".$dt['subcode_id']."' and company_id='".$cid."' ");
				foreach($productdescription->fetchAll() as $pds){
					$product_desc 			= $pds['description'];
					$product_subcode_of 	= $pds['subcode_of'];						
				}
				
							
				$autoinvoiceid 			= $newAutoInvoiceID;
				$subcode_id				= $dt['subcode_id'];
				$product_desc 			= $product_desc;
				$quanity 				= $dt['quantity'];
				$unit_price 			= $dt['unit_price'];
				$total_amount 			= $dt['total_amount'];
				$taxcode_purchased 		= $dt['taxcode'];
				$taxcode_matched 		= $dt['matchcode'];
				$gst_amount 			= $dt['gst'];	
				$entry_mode 			= "Purchase";			
				$company_id 			= $cid;	
										
				$totalunitprice			= $quanity * $unit_price;
				
				
				if($total_amount>0){
				
					$productpurchasedata = $db->query("insert into  tblinvproduct_purchase(`AutoInvoiceID`,`ProductDesc`,`Quantity`,`UnitPrice`,`totalunitprice`,`Totalamt`,`TaxCodePurchase`,`TaxCodeMatched`,`GSTamt`,`entry_mode`,`company_id`,`subcode_id`) values('".$autoinvoiceid."','".$product_desc."','".$quanity."','".$unit_price."','".$totalunitprice."','".$total_amount."','".$taxcode_purchased."','".$taxcode_matched."','".$gst_amount."','".$entry_mode."','".$company_id."','".$subcode_id."')");
					
					if(!$productpurchasedata){
						die('Invalid query: ' . mysql_error());
					}	
					
					// journal entries start
			
					$pd_subcode_id   			= $subcode_id;
					$pd_profit_center_id 		= $dt['profit_center_id'];
					$pd_company_id 				= $cid;
					$pd_date 					= date("Y-m-d", strtotime($date));
					$pd_ref 					= $ref;			
					$pd_memo 					= $invoice_no;			
					$pd_debit 					= $total_amount;		
					$pd_gst 					= $gst_amount;		
					$pd_subcode_of 				= $product_subcode_of;	
					$pd_entry_mode 				= "Purchase";		
					
					$productpurchasejournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`subcode_of`,`entry_mode`) values('".$pd_subcode_id."','".$pd_profit_center_id."','".$pd_company_id."','".$pd_date."','".$pd_ref."','".$pd_memo."','".$pd_debit."','".$pd_gst."','".$pd_subcode_of."','".$pd_entry_mode."')");
					
					if(!$productpurchasejournaldata){
						die('Invalid query: ' . mysql_error());
					}	
					// journal entries end
				}
											
			}
						
			header("Location: ?controller=claimedsalesinvoices&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/claimedsalesinvoices/create.php'); 	   
		}  
	  
    }		
	
	
	// filter
	public function filter() {
     	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
	 
	   	
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		} 		
					
		// banks
		$bankslist = array();
		$banks = $db->query("select bl.bank_name, bk.subcode_id from banks as bk left join bank_lists as bl on bl.id = bk.bank_list_id left join subcodes as sc on sc.id = bk.subcode_id where bk.company_id=".$cid." order by bl.bank_name");								
		foreach($banks->fetchAll() as $bk) {
			$bankslist[] = $bk;
		}  
		
		// subcodes for reverse
		$subcodes_reverselist = array();
		$subcodes_reverse = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_desc='CURRENT LIABILITIES' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors')");								
		foreach($subcodes_reverse->fetchAll() as $sc) {
			$subcodes_reverselist[] = $sc;
		}  
		
		// for filter		

       if(isset($_POST['Submit'])){		
	   				
			$date		= $_POST['date'];
	   		$bank_id 	= $_POST['bank_id'];
	  		$customer_id	= $_POST['customer_id'];	  	   						
			
			
			$appinvoices = array();
			$invs = $db->query("select distinct(invoice_no) from gst5b6b where company_id ='".$cid."' ");	
			foreach($invs->fetchAll() as $inv) {
				$appinvoices[] 	= $inv['invoice_no'];	
			}				
					
			$id_invs = $appinvoices;
			$apinvs = implode("','", $id_invs);					
			
										
			$tblinvmastersales = $db->query("select distinct(je.memo), je.date, je.totalamount, je.currencycode, je.currencyrate, je.taxcode from journal_entries as je where je.company_id=".$cid." and je.subcode_id = ".$customer_id." and je.entry_mode not in('Reverse Charge','Simplified','SimplifiedBL','SimplifiedTX') and je.ref not in('dispose') and je.memo in('".$apinvs."') group by je.memo ");					
												
			$i=0;
			$tblinvmastersales2 = array();
			foreach($tblinvmastersales->fetchAll() as $tbl) {			
																		
				$tblinvmastersales1 = $db->query("select distinct(memo), date, sum(totalamount) as totalamount, currencycode, currencyrate, gst, credit from journal_entries where memo='".$tbl['memo']."' and currencyrate>0 and currencycode!='' and company_id='".$cid."'  ");					
				foreach($tblinvmastersales1->fetchAll() as $tbl1) {						
									
					$tblinvmastersales2[] = $tbl1;						
				}	
				$i++;
			}	
				
			 					
			
			$tblpro = array();				
			foreach($tblinvmastersales2 as $mp){
			
				if($mp['totalamount']>0){				
								
												
					$tblproductsales = $db->query("select AutoInvoiceID, sum(totalunitprice) as totalunitprice from tblinvproduct_sales where company_id='".$cid."' and AutoInvoiceID = '".$mp['memo']."' ");					
					
					foreach($tblproductsales->fetchAll() as $tpp) {						
					
						if($tpp['totalunitprice']>0){
							$tblpro[] =  $tpp;		
						}
					}	
				}
				
			}		
		
			$count = count($tblpro);			
						
			
			require_once('views/claimedsalesinvoices/filter.php'); 	 

						
        }  else if(isset($_POST['save'])){		
	   					
			$pay_date = date("Y-m-d", strtotime($_POST['date']));
			
			$customer_id 	= $_POST['customer_id'];
			$bank_id 	= $_POST['bank_id'];			
			
			foreach($_POST['data'] as $dt){											
				
				if($dt['selectedrow']==1){
												
					$invoice_details = $db->query("select memo, ref, profit_center_id, subcode_of, currencyrate from journal_entries where company_id=".$cid." and memo = '".$dt['invoice_no']."' and trade_type='Trade Debtors' order by id asc limit 1 ");								
					foreach($invoice_details->fetchAll() as $ids) {						
						$ref 					= $ids['ref'];
						$profit_center_id 		= $ids['profit_center_id'];
						$subcode_of 			= $ids['subcode_of'];
						$invoice_currencyrate 	= $ids['currencyrate'];
						$invoiceno 				= $ids['memo'];
					}
					
					// for taxcode
					$taxlist = $db->query("select taxcode from journal_entries where company_id=".$cid." and memo = '".$invoiceno."' and gst>0 ");								
					foreach($taxlist->fetchAll() as $tl) {						
						$txcode 				= $tl['taxcode'];
					}
					
											
					$credit_subcode_id		= $customer_id; // debit
					$debit_subcode_id		= $bank_id; // credit
					$memo					= $dt['invoice_no'];
					$profit_center_id 		= $profit_center_id;
					$company_id 			= $cid;
					$ref					= $ref;
					$debit		 			= $dt['rmamount'];
					$credit		 			= $dt['rmamount'];
					$gst		 			= $dt['rmamountgst'];
					$totalamount 			= -abs($dt['currency_amount']);
					$currencyrate 			= $dt['currency_rate'];	
					$currencycode 			= $dt['currency_code'];	
					$subcode_of 			= $subcode_of;						
					$entry_mode 			= "Sales";		
									
					//$sub_total_amount1 	= $totalamount;	
					//$total_amount 		= abs($sub_total_amount1) * $currencyrate; 					
					//$gst					= $total_amount * (6/100);						
						
					//$t_amount = $total_amount + $gst;	
					//$total_amount 			= abs($sub_total_amount1) * $currencyrate; 		
					$t_amount = $credit;	
					$ct_amount = $credit - $gst;
																
					// debit					
					$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`totalamount`,`currencycode`,`currencyrate`,`subcode_of`,`entry_mode`,`gst`,`trade_type`) values ('".$credit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$ct_amount."','".$totalamount."','".$currencycode."','".$currencyrate."','".$subcode_of."','".$entry_mode."','".$gst."','Trade Debtors')");		
														
					//// credit
					$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`,`gst`)values('".$debit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$t_amount."','".$entry_mode."','".$gst."')");	
					
					
					// gst bad debt entries start			
					// master purchase data start
					$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$customer_id."' ");
					foreach($subcodes->fetchAll() as $scs){
						$customername 	= $scs['description'];
						$subcode_of 	= $scs['subcode_of'];	
						$account_code 	= $scs['code'];			
					}					
					
					$gstbaddebtdata = $db->query("insert into gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`credit`,`credit_gst`,`trade_type`,`company_id`) values('".$account_code."','".$pay_date."','".$memo."','".$ref."','".$t_amount."','".$gst."','Trade Debtors','".$company_id."')");
					
					if(!$gstbaddebtdata){
						die('Invalid query: ' . mysql_error());
					}	
					// gst bad debt entries end		
					
					
					$b5date = date("d/m/Y", strtotime($pay_date));
						
					// gst 5b6b data 
					$db->query("insert into gst5b6b(`trade_type`,`company_id`,`customer_id`,`invoice_no`,`invoice_date`,`5b`,`5b_value`,`transaction_date`,`flag`,`taxcode`)values('Trade Debtors', '".$company_id."', '".$account_code."', '".$memo."', '".$b5date."', '".$gst."', '".$t_amount."', '".$b5date."', '0', 'AJS')");		
						
							
													
					// gain or loss calculation
					$invoice_currency_rate 		= $invoice_currencyrate;
					$payment_currency_amount	= $dt['currency_amount'];
								
					$amount_for_find_difference1 = $payment_currency_amount * $invoice_currency_rate; // old value
					$amount_for_find_difference2 = $payment_currency_amount * $currencyrate; // new value
															
					//if($amount_for_find_difference1<$amount_for_find_difference2){					
						$difference = $amount_for_find_difference2 - $amount_for_find_difference1;		 // loss	
						//echo "Loss : ".$loss_difference.'<br>';													
					//} else if($amount_for_find_difference1>$amount_for_find_difference2){					
					//	$difference = $amount_for_find_difference1 - $amount_for_find_difference2;		// gain		
						//echo "Gain : ".$gain_difference.'<br>';
					//} else {
						//echo "There is no difference";
					//}				
					
					
					if($difference==0){		
						$difference=0;
					} else if($difference>0){		
						$difference=$difference;
					} else if($difference<0){		
						$difference=0;
					}
					
								
						$db->query("insert into tbl_es43(`invoice_no`,`invoice_date`,`gst`,`company_id`,`TaxCode`,`transaction_type`)values('".$memo."','".$pay_date."','".$difference."','".$company_id."','ES43','Sales')");	
						
						
						
						$es43_subcodes = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX-ES43' and company_id='".$cid."' ");
						foreach($es43_subcodes->fetchAll() as $es){				
							$es43id 	= $es['id'];			
						}
						
						
						$difference_gst   =  $difference * (6/100);	
						
							
						if($difference<0){
													
							$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`,`taxcode`)values('".$es43id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$difference."','".$entry_mode."','ES43')");	
							
						} else if($difference>0){
							
							$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`,`taxcode`)values('".$es43id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$difference."','".$entry_mode."','ES43')");	
					
						}
						
						
						// gst output tax
			
						$outputtaxdata = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX-AJS' and company_id='".$company_id."' ");
						foreach($outputtaxdata->fetchAll() as $ot){
							$outputtax_id 			= $ot['id'];									
						}
						
						
						$outputtaxjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`entry_mode`,`Gstinvdate`,`taxcode`) values('".$outputtax_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$gst."','".$gst."','".$entry_mode."','".$pay_date."','AJS')");
						
						if(!$outputtaxjournaldata){
							die('Invalid query: ' . mysql_error());
						}		
						
						
						
						
						
				//	}			
												
				} 
			}						
							
			header("Location: ?controller=claimedsalesinvoices&action=index&cid=".$cid."");			
			
        }  else {
			
			require_once('views/claimedsalesinvoices/filter.php'); 	 
			
		}	
		
		  
		            	
   }
	
	

    public function error() {
      require_once('views/claimedsalesinvoices/error.php');
    }
  }
?>