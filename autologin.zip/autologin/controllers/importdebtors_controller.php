<?php
  class ImportdebtorsController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid']; // company id		
		
						  
	  require_once('views/importdebtors/index.php'); 
	  
    }	
	
	public function create() {    
	  
		error_reporting(0);
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
				
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$_GET['cid']."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
	
		if(isset($_POST['submit'])){
		
			$cid 				= $_POST['cid']; 		
			$created_by 		= $_SESSION['username'];
			$created_ip 		= $_SERVER['REMOTE_ADDR'];
			$created    		= date("Y-m-d H:i:s"); 
			$date 				= date("Y-m-d H:i:s");		
			$currentdate 		= date("Y-m-d");
		
				
																					
			if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
				/*echo "<h1>" . "File ". $_FILES['filename']['name'] ." uploaded successfully." . "</h1>";
				echo "<h2>Displaying contents:</h2>";*/
				readfile($_FILES['filename']['tmp_name']);
			}
			
			
				
																						
			$handle = fopen($_FILES['filename']['tmp_name'], "r");
			
			$subcode_of = 0;
			
			$master_account_codes 	= "";
			$subcodes				= "";
			$account_types			= "";
			
				
			while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
				$str[]                    = $data;								
			}	
			fclose($handle);
		
				//echo "<pre>";print_r($str);exit;															
			foreach($str as $key=>$val) {
				foreach($val as $kk=>$v) {
					
				    $ss=explode('~',$v);
				
					$chqdate				= $ss[0];
					$split					= explode('/',$chqdate);
					
					$day					= $split[0];
					$month					= $split[1];
					$year					= $split[2];
					//$chquedate				= date('Y-m-d',strtotime($chqdate));
					$chquedate				= $year.'-'.$month.'-'.$day;
					$pvno					= $ss[1];
					$chqno					= $ss[2];
					$payee					= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[3]));
					$description			= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($ss[4]));
					$debit					= $ss[5];
					$bank1					= $ss[6];
					$subid					= $ss[7];
					//$bank2				    = $ss[7];
					$d1 = $db->query("SELECT id FROM subcodes where code LIKE '%".$subid."%' and company_id='1146' ");			
					
					foreach($d1->fetchAll() as $dd) {
						$subb = $dd['id'];
					
					}
					
					$payee  				= addslashes($payee);
					//vendor issued
					$chequetype				= "Print";
					$description		    = addslashes($description);
					//debtor Received
					 //$chequetype				= "Deposit";
					
					//if($bank1>0){
						$bankid = '0';
						$credit = $bank1;
						$subcode = '3010/0000';
						$subcodeof='52926';
					/*}else if($bank2>0){
						$bankid = '621';
						$bankamt = $bank2;
						$subcode = '3000/0050';
						$subcodeof='225';
					}*/
					//	vendor 		
					
					/*$db->query("insert into tblcheque(company_id,BankID,CheqDate,Payee,Amount,CheqNO,CheqType,Description,PVNO) values ('1', '".$bankid."', '".$chquedate."', '".$payee."', '".$amount."', '".$chqno."', '".$chequetype."', '".$description."', '".$pvno."') ");	
					
					$db->query("insert into unattended_gl(date,company_id,account_code,ref,description,debit,credit,subcode_of,Gstinvdate) values ('".$chquedate."', '1', '4001/P001', 'Chequeout-Credit', '".$chqno."', '0.00', '".$amount."', '227','".$chquedate."') ");	
					
					$db->query("insert into unattended_gl(date,company_id,account_code,ref,description,debit,credit,subcode_of,Gstinvdate) values ('".$chquedate."', '1', '".$subcode."', 'Chequeout-Debit', '".$chqno."', '".$amount."', '0.00', '".$subcodeof."','".$chquedate."') ");	*/
					
					//debtor							
					$db->query("insert into tblcheque(company_id,BankID,CheqDate,Payee,Amount,CheqNO,CheqType,Description,PVNO) values ('1146', '".$bankid."', '".$chquedate."', '".$payee."', '".$debit."', '".$chqno."', '".$chequetype."', '".$description."', '".$pvno."') ");	
					
					$db->query("insert into unattended_gl(date,company_id,account_code,ref,description,debit,credit,subcode_of,Gstinvdate) values ('".$chquedate."', '1146', '".$subid."', 'Chequeout-Debit', '".$chqno."', '".$debit."', '0.00', '".$subb."','".$chquedate."') ");	
					
					$db->query("insert into unattended_gl(date,company_id,account_code,ref,description,debit,credit,subcode_of,Gstinvdate) values ('".$chquedate."', '1146', '".$subcode."', 'Chequeout-Credit', '".$chqno."', '0.00', '".$credit."', '".$subcodeof."','".$chquedate."') ");		
					
				
				}
			
			}	
			//require_once('views/importvendors/index.php');
			header("Location:?controller=importdebtors&action=index&cid=".$cid."");	
	
		}	
			
		//header("Location: ?controller=importvendors&action=index&cid=".$cid."");	 
	     require_once('views/importdebtors/index.php');
    }		
			

    public function error() {
      require_once('views/importdebtors/error.php');
    }
  }
?>