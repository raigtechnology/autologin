<?php
  class ImportjournalentriesController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
		$cid = $_GET['cid']; // company id		
		
						  
	  require_once('views/importjournalentries/index.php'); 
	  
    }	
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		$db = Db::getInstance(); // db connection
			
		$cid = 	$_GET['cid'];
				
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
	
		if(isset($_POST['submit'])){		
			
			if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
				echo "<h1>" . "File ". $_FILES['filename']['name'] ." uploaded successfully." . "</h1>";
				echo "<h2>Displaying contents:</h2>";
				readfile($_FILES['filename']['tmp_name']);
			}
		
			$cid 				= $_POST['cid'];
			
			//Import uploaded file to Database
			$handle = fopen($_FILES['filename']['tmp_name'], "r");
			
			$subcode_of = 0;
			
			while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {				
				
				$journaldate=trim($data[0]);

				if (strpos($journaldate, '/') !== false) {
					list($d1, $m1, $y1) = explode('/', $journaldate);
				} else if (strpos($journaldate, '-') !== false) {
					list($d1, $m1, $y1) = explode('-', $journaldate);
				} else if (strpos($journaldate, '.') !== false) {
					list($d1, $m1, $y1) = explode('.', $journaldate);
				}	
				
				$mk1=mktime(0, 0, 0, $m1, $d1, $y1);					
											
				$journal_date		= date($y1.'-'.$m1.'-'.$d1);		
				
			// accept all the special characters	
				$account_code		= preg_replace('/[^A-Za-z0-9- !@#$%^&*().]/u','', strip_tags($data[1])); // need
				$ref				= preg_replace('/[^A-Za-z0-9- !@#$%^&*().]/u','', strip_tags($data[2])); // need
				$description		= preg_replace('/[^A-Za-z0-9- !@#$%^&*().]/u','', strip_tags($data[3])); // need
				$debit				= $data[4];		
				$credit				= $data[5];		
				$invoice_mode		= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($data[6]));	 // need	
				$gst				= $data[7];		
				$taxcode			= $data[8];	
			
				$gst_date=trim($data[9]);//$dob1='dd/mm/yyyy' format
				
				if (strpos($gst_date, '/') !== false) {
					list($d, $m, $y) = explode('/', $gst_date);
				} else if (strpos($gst_date, '-') !== false) {
					list($d, $m, $y) = explode('-', $gst_date);
				} else if (strpos($gst_date, '.') !== false) {
					list($d, $m, $y) = explode('.', $gst_date);
				} 
							
				$mk2=mktime(0, 0, 0, $m, $d, $y);		
				
				$gstdate			= date($d.'-'.$m.'-'.$y);						
				$total_amount		= $data[10]; 
				$currency_code		= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($data[11]));
				$currency_rate		= $data[12];
				$trade_type			= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($data[13]));	 // need	//need	
				$entry_mode			= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($data[14]));	 // need	//need
				$profit_center_code	= preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($data[15]));	 // need	//need	
							
				$codes = $db->query("SELECT code FROM subcodes WHERE description = '".$account_code."' and company_id = '".$cid."' ");		
				foreach($codes->fetchAll() as $sc) {					
					$code 		= $sc['code'];					
				}			
								
				$profitcenters2 = $db->query("select id from profit_centers where company_id='".$cid."' and profit_center_code='".$profit_center_code."' ");	
				foreach($profitcenters2->fetchAll() as $pc2) {
					$profit_center_id = $pc2['id'];
				} 
				
				$subcode_id=0;
				$codes1 = $db->query("SELECT id FROM subcodes WHERE description = '".$account_code."' ");		
				foreach($codes1->fetchAll() as $sc1) {				
					$subcode_id = $sc1['id'];
				}	
				
				$created_by = $_SESSION['username'];
				$created_ip = $_SERVER['REMOTE_ADDR'];
				$created    = date("Y-m-d H:i:s"); 
				
			
				$db->query("insert into journal_entries(date,company_id,profit_center_id,subcode_id,ref,memo,debit,credit,gst,taxcode,Gstinvdate,totalamount,currencycode,currencyrate,trade_type,entry_mode,created_by,created_ip,created) values ('".$journal_date."', '".$cid."', '".$profit_center_id."', '".$subcode_id."', '".$ref."', '".$description."', '".$debit."', '".$credit."', '".$gst."', '".$taxcode."', '".$gstdate."', '".$total_amount."', '".$currency_code."', '".$currency_rate."', '".$trade_type."', '".$entry_mode."', '".$created_by."', '".$created_ip."', '".$created."') ");
				
														
			}		
				 
			
		
			fclose($handle);
		
			print "Import done";
		
			//view upload form			
			
			header("Location: ?controller=importjournalentries&action=index&cid=".$cid."");	
	
		}	
			
		require_once('views/importjournalentries/create.php'); 	 
	  
    }		
			

    public function error() {
      require_once('views/importjournalentries/error.php');
    }
  }
?>