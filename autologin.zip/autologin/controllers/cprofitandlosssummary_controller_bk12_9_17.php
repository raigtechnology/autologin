<?php
  class CprofitandlosssummaryController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		/**************************************************************/
		$db = Db::getInstance();		 // db connection
		$cid = $_GET['cid'];             // company_id
		$session_id = $_SESSION['company_id'];
		//$consolidated = $_SESSION['consolidated'];
		
		$usergroup = $db->query("select user_group_id,consolidated from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
			$consolidated   = $ug['consolidated'];
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}
		
		// same user group companies
		$clists = array();
		$clist = $db->query("select id from companies where user_group_id = '".$usergroupid."'");	
		foreach($clist->fetchAll() as $cl) {
			$clists[] 	= $cl['id'];	
		}	
		
		if($consolidated==1){					
			$id_nums = $clists;
			$cid1 = implode("','", $id_nums);				
		} else {
			$cid1 = $cid;
		}
		
		/**************************************************************/	 
		
		$todate = date("Y-m-d");	
		
		$monthfromdate = date("Y-m-01");	
		$monthtodate = date("Y-m-t");	
		
		$yearfromdate = date("Y-01-01");	
		$yeartodate = date("Y-m-t");	
				
		
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code from subcodes as sc  where sc.company_id=".$com_id." order by sc.description asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 
		
		/******************* SALES START  ****/
		
		$salessubcodesList = array();		
		$salessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY  sc.id ASC");		
		foreach($salessubcodes->fetchAll() as $ssc) {
			$salessubcodesList[] = $ssc;
		} 		
		
		$salesArray = array();		
		$si=0;
		foreach($salessubcodesList as $scl){
						
			$description = $scl['description'];						
						
			$openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and op.company_id = ".$com_id." and sc.id = '".$scl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($openingbalance->fetchAll() as $op) {
				$op_balance = $op['balance'];
			} 		
						
			$sales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id in ('".$cid1."') AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_yeargibalance->fetchAll() as $sygi) {
				$sales_yearbalance = abs($sygi['balance']);				
			}
			
			$sales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id in ('".$cid1."') AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_monthgibalance->fetchAll() as $smgi) {
				$sales_monthbalance = abs($smgi['balance']);				
			}								
			
			$salesArray[$si]['description'] = $description;
			$salesArray[$si]['yearbalance'] = $op_balance + $sales_yearbalance;
			$salesArray[$si]['monthbalance'] = $op_balance + $sales_monthbalance;
						
			$si++;	
		}
				
		/******************* SALES END  ****/		
				
		/******************* COST OF SALES START  ****/
		
		$costofsalessubcodesList = array();		
		$costofsalessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY  sc.id ASC");		
		foreach($costofsalessubcodes->fetchAll() as $cssc) {
			$costofsalessubcodesList[] = $cssc;
		} 		
		
		$costofsalesArray = array();		
		$csi=0;
		foreach($costofsalessubcodesList as $cscl){
						
			$description = $cscl['description'];					
			
			// opening balance
			$costofsales_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and op.company_id = ".$com_id." and sc.id = '".$cscl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($costofsales_openingbalance->fetchAll() as $csop) {
				$costofsales_op_balance = $csop['balance'];
			} 
			
			$costofsales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id in ('".$cid1."') AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_yeargibalance->fetchAll() as $csygi) {
				$costofsales_yearbalance = $csygi['balance'];
			}
			
			$costofsales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id in ('".$cid1."') AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_monthgibalance->fetchAll() as $csmgi) {
				$costofsales_monthbalance = $csmgi['balance'];				
			}
				
			$costofsalesArray[$csi]['description'] = $description;
			$costofsalesArray[$csi]['yearbalance'] = $costofsales_op_balance + $costofsales_yearbalance;
			$costofsalesArray[$csi]['monthbalance'] = $costofsales_op_balance + $costofsales_monthbalance;
							
			$csi++;
		}		
				
		/******************* COST OF SALES END  ****/		
				
				
		/******************* EXPENSES START  ****/
		
		$expensessubcodesList = array();		
		$expensessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY  sc.id ASC");		
		foreach($expensessubcodes->fetchAll() as $esc) {
			$expensessubcodesList[] = $esc;
		}				 		
		
		$expensesArray = array();		
		$csi=0;
		foreach($expensessubcodesList as $ecl){
						
			$description = $ecl['description'];					
			
			// opening balance
			$expenses_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and op.company_id = ".$com_id." and sc.id = '".$ecl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($expenses_openingbalance->fetchAll() as $eop) {
				$expenses_op_balance = $eop['balance'];
			} 	
			
			
			$expenses_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id in ('".$cid1."') AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_yeargibalance->fetchAll() as $eygi) {
				$expenses_yearbalance = $eygi['balance'];
			}
			
			$expenses_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id in ('".$cid1."') AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_monthgibalance->fetchAll() as $emgi) {			
				$expenses_monthbalance = $emgi['balance'];				
			}							
						
			$expensesArray[$csi]['description'] = $description;
			$expensesArray[$csi]['yearbalance'] = $expenses_op_balance + $expenses_yearbalance;
			$expensesArray[$csi]['monthbalance'] = $expenses_op_balance + $expenses_monthbalance;
			
			$csi++;
		}		
		
	
		
				
		/******************* EXPENSES END  ****/				
		
						  
	  require_once('views/cprofitandlosssummary/index.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/cprofitandlosssummary/error.php');
    }
  }
?>