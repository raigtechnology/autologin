<?php
  class FixedassetopeningbalanceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // company_id
				    
				
		$openingbalancelist = array();
		$opening_balance = $db->query("select op.id, sc.code, op.debit, op.credit, sc.description, pc.profit_center from opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join profit_centers as pc on pc.id = op.profit_center_id where op.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		foreach($opening_balance->fetchAll() as $pc) {
			$openingbalancelist[] = $pc;
		}  	
	
	  require_once('views/fixedassetopeningbalance/index.php'); 
	  
    }		
	
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		// accounting year	
		$accountingyearlist = array();	
		$accountingyear = $db->query("select * from accounting_year where company_id='".$cid."' and status=1 ");	
		foreach($accountingyear->fetchAll() as $ay) {
			
			if(date("Y")==date("Y", strtotime($ay['current_yr_to_date']))){
			
				$current_year_opening_date = $ay['current_yr_from_date'];
				$current_year_cloasing_date = $ay['current_yr_to_date'];
			}	
				$accountingyearlist[] = $ay;
		}  
		
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id = '6' order by account_desc ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// fixed assets
		$fixedassetlist = array();
		$fixedasset = $db->query("select sc.id, sc.description from subcodes as sc left join master_account_codes as mac on mac.id=sc.master_account_code_id  where sc.company_id='".$cid."' and mac.account_type_id='4' and sc.subcode_of=0 order by sc.description asc ");	
		foreach($fixedasset->fetchAll() as $fa) {
			$fixedassetlist[] = $fa;
		}  
		
		// current assets
		$currentassetlist = array();
		$currentasset = $db->query("select sc.id, sc.description from subcodes as sc left join master_account_codes as mac on mac.id=sc.master_account_code_id  where sc.company_id='".$cid."' and mac.account_type_id='13' order by sc.description asc ");	
		foreach($currentasset->fetchAll() as $ca) {
			$currentassetlist[] = $ca;
		}  
		
		// long term liabilities
		$longtermliabilitieslist = array();
		$longtermliabilities = $db->query("select sc.id, sc.description from subcodes as sc left join master_account_codes as mac on mac.id=sc.master_account_code_id  where sc.company_id='".$cid."' and mac.account_type_id='3'  ");	
		foreach($longtermliabilities->fetchAll() as $ltl) {
			$longtermliabilitieslist[] = $ltl;
		}  
		
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		// sales taxcode master		
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select TaxCode,TaxRate,id from salestaxcodemaster order by TaxCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		
		
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	
					
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
					
		
		if(isset($_POST['save'])){			
					
			$date			            = date("Y-m-d");
			$date_of_purchase			= date("Y-m-d", strtotime($_POST['dateofpurchase']));			
			$profit_center_id  			= $_POST['profit_center_id'];
			$document_no  				= $_POST['document_no'];
			$no_of_months  				= $_POST['no_of_months'];
			$fixed_asset_id		  		= $_POST['fixed_asset_id'];			
			$fixed_asset_value  		= $_POST['fixed_asset_value'];
			$depriciation 	 			= $_POST['depriciation'];
			$depriciation_value 	 	= $_POST['depriciation_value'];
			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 			
			
														
			$fixedassets = $db->query("insert into  fixed_assets(`company_id`,`date_of_purchase`,`profit_center_id`,`subcode_id`,`fixed_asset_value`,`depriciation`,`no_of_years`,`depriciation_value`,`created_by`,`created_ip`,`created`) values('".$cid."','".$date_of_purchase."','".$profit_center_id."','".$fixed_asset_id."','".$fixed_asset_value."','".$depriciation."','".$no_of_months."','".$depriciation_value."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$fixedassets){
				die('Invalid query: ' . mysql_error());
			}		
			
						
	/*********************** opening balance *****************************/		
			
			$db->query("insert into opening_balance(`subcode_id`,`profit_center_id`,`company_id`,`debit`,`created_by`,`created_ip`,`created`) values('".$fixed_asset_id."','".$profit_center_id."','".$cid."','".$fixed_asset_value."','".$created_by."','".$created_ip."','".$created."')");
			
			$fixedasset_depreciation = $db->query("select id from subcodes where company_id='".$cid."' and subcode_of='".$fixed_asset_id."' and description LIKE '%depreciation%' ");	
			foreach($fixedasset_depreciation->fetchAll() as $fad) {
				$pd_depreciation_id = $fad['id'];
			}  
						
			$accumulated_depreciation = $depriciation_value * $no_of_months;			
			
			$db->query("insert into opening_balance(`subcode_id`,`profit_center_id`,`company_id`,`credit`,`created_by`,`created_ip`,`created`) values('".$pd_depreciation_id."','".$profit_center_id."','".$cid."','".$accumulated_depreciation."','".$created_by."','".$created_ip."','".$created."')");
			
			
			/**********************************************************  for full depreciation ************************/
			
			$no_of_depreciation1 = $accumulated_depreciation / $depriciation_value; 	
			$no_of_depreciation1 = round($no_of_depreciation1);		
			
			for($l1=0; $l1<$no_of_depreciation1; $l1++){
			
				$depreciation_date1 = date('Y-m-d', strtotime('+'.$l1.' month', strtotime($date_of_purchase)));					
			
				$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`,`created_by`,`created_ip`,`created`) values('".$pd_depreciation_id."','".$profit_center_id."','".$cid."','".$depreciation_date1."','fixed asset depreciation credit suspense','".$document_no."','".$depriciation_value."','fixed asset depreciation','".$created_by."','".$created_ip."','".$created."')");
			
			}
			
			
			$new_fixed_asset_value = $fixed_asset_value - $accumulated_depreciation;
					
			$no_of_depreciation = $new_fixed_asset_value / $depriciation_value; 	
			$no_of_depreciation = round($no_of_depreciation);		
			
			for($l=0; $l<$no_of_depreciation; $l++){
			
				$depreciation_date = date('Y-m-d', strtotime('+'.$l.' month', strtotime($date)));					
			
				$db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`,`created_by`,`created_ip`,`created`) values('".$pd_depreciation_id."','".$profit_center_id."','".$cid."','".$depreciation_date."','fixed asset depreciation credit','".$document_no."','".$depriciation_value."','fixed asset depreciation','".$created_by."','".$created_ip."','".$created."')");
			
			}
			/**************************************************** ***************************************************/	
							
						
			header("Location: ?controller=fixedassetopeningbalance&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/fixedassetopeningbalance/create.php'); 	   
		}  
	  
    }		
	
		

    public function error() {
      require_once('views/fixedassetopeningbalance/error.php');
    }
  }
?>