<?php
  class PosController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    	    
						
		$salesinvoicelistgroup = array();
		$salesinvoicegroup = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.entry_mode ='POSout' group by je.memo ");	
		foreach($salesinvoicegroup->fetchAll() as $jel) {
			$salesinvoicelistgroup[] = $jel;
		}  		
		
		$salesinvoicelist = array();
		$salesinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code,je.trade_type from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode ='POSout'  order by je.date,je.memo");	
		foreach($salesinvoice->fetchAll() as $je) {
			$salesinvoicelist[] = $je;
		}  	
						  
	  require_once('views/pos/index.php'); 
	  
    }		
	

    public function error() {
      require_once('views/pos/error.php');
    }
  }
?>