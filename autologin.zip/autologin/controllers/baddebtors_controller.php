<?php
  class BaddebtorsController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id		    
		
		$company = $db->query('SELECT id,company_name FROM companies where id ="'.$cid.'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
		} 
		
		$todate = date("Y-m-d");		
		
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code, tc.GSTRNo, tc.Business_Regno from subcodes as sc 
								left join master_account_codes as mac on mac.id = sc.master_account_code_id
								left join tblcustomer as tc on tc.Customer_account_code = sc.code							
							 where tc.company_id = '".$cid."' and sc.company_id=".$cid." and mac.company_id=".$cid." and mac.account_type_id='13' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id=".$cid.") group by sc.code order by sc.code asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 			
				
		
					$first_month_start_date = date('Y-m-01', strtotime($todate." -1 month"));
					$first_month_end_date = date('Y-m-t', strtotime($todate." -1 month"));
							
					$first_month = (strtotime($first_month_end_date) - strtotime($first_month_start_date)) / (60 * 60 * 24);		
					$first_month = $first_month + 1;
						
					$second_month_start_date = date('Y-m-01', strtotime($first_month_start_date." -1 month"));
					$second_month_end_date = date('Y-m-t', strtotime($first_month_start_date." -1 month"));
					
					$second_month = (strtotime($second_month_end_date) - strtotime($second_month_start_date)) / (60 * 60 * 24);		
					$second_month = $second_month + 1;
					
					$third_month_start_date = date('Y-m-01', strtotime($second_month_start_date." -1 month"));
					$third_month_end_date = date('Y-m-t', strtotime($second_month_start_date." -1 month"));
					
					$third_month = (strtotime($third_month_end_date) - strtotime($third_month_start_date)) / (60 * 60 * 24);
					$third_month = $third_month + 1;		
					
					$fourth_month_start_date = date('Y-m-01', strtotime($third_month_start_date." -1 month"));
					$fourth_month_end_date = date('Y-m-t', strtotime($third_month_start_date." -1 month"));
					
					$fourth_month = (strtotime($fourth_month_end_date) - strtotime($fourth_month_start_date)) / (60 * 60 * 24);
					$fourth_month = $fourth_month + 1;	
					
					$fifth_month_start_date = date('Y-m-01', strtotime($fourth_month_start_date." -1 month"));
					$fifth_month_end_date = date('Y-m-t', strtotime($fourth_month_start_date." -1 month"));
					
					$fifth_month = (strtotime($fifth_month_end_date) - strtotime($fifth_month_start_date)) / (60 * 60 * 24);
					$fifth_month = $fifth_month + 1;	
					
					$sixth_month_start_date = date('Y-m-01', strtotime($fifth_month_start_date." -1 month"));
					$sixth_month_end_date = date('Y-m-t', strtotime($fifth_month_start_date." -1 month"));
					
					$sixth_month = (strtotime($sixth_month_end_date) - strtotime($sixth_month_start_date)) / (60 * 60 * 24);
					$sixth_month = $sixth_month + 1;	
			
					$seventh_month_start_date = date('Y-m-01', strtotime($sixth_month_start_date." -1 month"));
					$seventh_month_end_date = date('Y-m-t', strtotime($sixth_month_start_date." -1 month"));
				
		
		
		// journal entries
		$journallist1 = array();		
		$journals1 = $db->query("select 
									sc.description,
									sc.id,
									sc.code,								
									je.date,
									je.memo
								from 
									subcodes as sc
									left join journal_entries as je on je.subcode_id = sc.id
									left join master_account_codes as mac on mac.id = sc.master_account_code_id
								where 
									je.company_id=".$cid." and sc.company_id=".$cid." and mac.company_id=".$cid." and mac.account_type_id='13' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors') and date(je.date) BETWEEN date('1111-11-11') and date('".$seventh_month_end_date."') group by je.memo order by sc.description asc");		
		foreach($journals1->fetchAll() as $je) {
			$journallist1[] = $je;
		} 	
			
		
									  
	  require_once('views/baddebtors/index.php'); 
	  
    }		
	
	public function view() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	    
		
		$company = $db->query('SELECT id,company_name FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
		} 
		
		
		$todate = date("Y-m-d");		
		
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code, tc.GSTRNo, tc.Business_Regno from subcodes as sc 								
								left join tblcustomer as tc on tc.Customer_account_code = sc.code								
							 where tc.company_id = '".$cid."' and sc.company_id=".$cid." and sc.id = '".$_GET['subcode']."'  ");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 			
		
	
		// journal entries
		$journallist = array();		
		$journals = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									je.debit,
									je.credit,								
									je.date,
									je.memo
								from 
									subcodes as sc
									left join journal_entries as je on je.subcode_id = sc.id
									left join master_account_codes as mac on mac.id = sc.master_account_code_id
								where 
									je.company_id=".$cid." and sc.company_id=".$cid." and mac.company_id=".$cid." and mac.account_type_id='13' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id=".$cid.") and je.memo = '".$_GET['id']."' order by je.date asc");		
		foreach($journals->fetchAll() as $je) {
			$journallist[] = $je;
		} 	
						
						  
	  require_once('views/baddebtors/view.php'); 
	  
    }		
	

    public function error() {
      require_once('views/baddebtors/error.php');
    }
  }
?>