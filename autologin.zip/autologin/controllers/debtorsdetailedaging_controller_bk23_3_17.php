<?php
  class DebtorsdetailedagingController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	   
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$date = date("Y-m-t");
		
		if(isset($_POST['submit'])){
				
			$date = date("Y-m-d", strtotime($_POST['date']));			
				
			if(empty($date)){
				$date = date("Y-m-d");			
			}				
		
		}	
		
		$debtorslist = array();		
		$debtors = $db->query("select sc.description, sc.id, sc.code from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='13' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");		
		foreach($debtors->fetchAll() as $dt) {
			$debtorslist[] = $dt;
		} 	
		
		$subcodesList1 = $db->query("select id, description from subcodes where company_id=".$cid." order by code ");
		foreach($subcodesList1->fetchAll() as $sl) {
				
			if($sl['description']=="Trade Debtors"){
				$debtor_id = $sl['id'];
			} 
			if($sl['description']=="Trade Creditors"){
				$creditor_id = $sl['id'];
			} 
		
		}  	
						  
						  
	  require_once('views/debtorsdetailedaging/index.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/debtorsdetailedaging/error.php');
    }
  }
?>