<?php
  class RemittanceadviceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='5' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
		
		$date = date("Y-m-t");
		
		 $from_date = date("Y-m-01");	
		 $to_date = date("Y-m-t");	
		
		$subcode_id			= "";
		$profit_center_id	= "";
		$profitcenter 		= "";
		$customername 		= "";
		$accountcode  		= "";
		
		$cond1				= "";
		
		$journallist = array();		
		if(isset($_POST['submit'])){
				
			$date = date("Y-m-d", strtotime($_POST['from_date']));			
				
			$from_date = date("Y-m-01", strtotime($_POST['from_date']));
			$to_date = date("Y-m-t", strtotime($_POST['from_date']));
			
							
			if(empty($date) || $date=="1970-01-01"){
							
				$date = date("Y-m-d");		
				
				 $from_date = date("Y-m-01");	
				 $to_date = date("Y-m-t");	
					
			}		
			
			
					
			$subcode_id = $_POST['customer_id'];
			$profit_center_id = $_POST['profit_center_id'];
			
			
				
			$profit_centers1 = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' and id='".$profit_center_id."' ");	
			foreach($profit_centers1->fetchAll() as $pc1) {
				 $profitcenter = $pc1['profit_center'];
			}  	
			
			$customers1 = $db->query("select sc.description, sc.code from subcodes as sc where company_id='".$cid."' and id='".$subcode_id."' ");	
			foreach($customers1->fetchAll() as $ct1) {
				$customername = $ct1['description'];
				$accountcode = $ct1['code'];
			}  	
			
								
			// journal entries
			
			if($date!="1970-01-01" && $subcode_id!=""){
				$cond1 = "and je.date >= '".$from_date."' AND je.date <= '".$to_date."' and sc.id = ".$subcode_id.""; 
			} else if($date!="1970-01-01" && $subcode_id==""){
				$cond1 = "and je.date >= '".$from_date."' AND je.date <= '".$to_date."'"; 
			}
			
				
			$journals = $db->query("select 
										sc.description,
										sc.id,
										sc.code,
										je.debit,
										je.credit,
										je.date,
										je.memo
									from 
										subcodes as sc
										left join journal_entries as je on je.subcode_id = sc.id
									where 
										je.company_id=".$cid." and sc.company_id='".$cid."' ".$cond1."  order by je.date asc");		
			
			
			
			
			foreach($journals->fetchAll() as $je) {
				$journallist[] = $je;
			} 	
		
					
			
			
		}	
		
		
		
		/******************************************************************************/	
		$cond = "";
		
		if($subcode_id!=""){
			$cond = "and sc.id=".$subcode_id." ";
		}
				
		
		$creditorslist = array();		
		$creditors = $db->query("select sc.description, sc.id, sc.code from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='5' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors' and company_id='".$cid."') ".$cond." order by sc.description asc");		
		foreach($creditors->fetchAll() as $dt) {
			$creditorslist[] = $dt;
		} 	
		
		$subcodesList1 = $db->query("select id, description from subcodes where company_id=".$cid." order by code ");
		foreach($subcodesList1->fetchAll() as $sl) {
				
			if($sl['description']=="Trade Debtors"){
				$debtor_id = $sl['id'];
			} 
			if($sl['description']=="Trade Creditors"){
				$creditor_id = $sl['id'];
			} 
		
		}  	
		/*********************************************************************/  	
		
		
		
		///////////////////////////////////////////
			
		
			
							  
	  require_once('views/remittanceadvice/index.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/remittanceadvice/error.php');
    }
  }
?>
