<?php
  class ApproveduncategorizedglController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();	// db connection	
		$cid = $_GET['cid'];		// company id	    
		
		$fromdate = date("Y-m-01");
		$todate = date("Y-m-d");
		$cond ="";
		$invoice_no ="";
		
		if(isset($_POST['submit'])){		
			
			$invoice_no = $_POST['invoice_no'];
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));				
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-01");
				$todate = date("Y-m-d");
			}					
			
			
			
			if($invoice_no!="" && $fromdate!="1970-01-01" && $todate!="1970-01-01"){
				$cond = " and je.memo = '".$invoice_no."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' "; 			
			} else if($invoice_no=="" && $fromdate!="1970-01-01" && $todate!="1970-01-01"){
				$cond = " and je.date >= '".$fromdate."' AND je.date <= '".$todate."' "; 			
			} else if($invoice_no!="" && $fromdate=="1970-01-01" && $todate=="1970-01-01"){
				$cond = " and je.memo = '".$invoice_no."'  "; 			
			} else {
				$cond ="";
			}
			
		}	
						
		$approveduncategorizedgllistgroup = array();
		$approveduncategorizedglgroup = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.status = '1' ".$cond." group by je.memo ");	
		foreach($approveduncategorizedglgroup->fetchAll() as $jel) {
			$approveduncategorizedgllistgroup[] = $jel;
		}  		
		
		$approveduncategorizedgllist = array();
		$approveduncategorizedgl = $db->query("select mac.account_desc, je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id 
		left join master_account_codes as mac on mac.id= sc.master_account_code_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.status ='1' ".$cond." ");	
		foreach($approveduncategorizedgl->fetchAll() as $je) {
			$approveduncategorizedgllist[] = $je;
		}  	
									  
	  require_once('views/approveduncategorizedgl/index.php'); 
	  
    }		
	
	
	// edit
	public function edit() {   			
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		
		
		$db = Db::getInstance();	// db connection	
		$cid = $_GET['cid'];		// company id	
		
		$id = $_GET['id'];
		
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
				
		$salesinvoicelist = array();
		$salesinvoice = $db->query("select je.id, je.profit_center_id, je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode = 'manual' and je.memo = '".$id."'  ");	
		foreach($salesinvoice->fetchAll() as $je) {
			$salesinvoicelist[] = $je;
		}  	
						  
		if(isset($_POST['save'])){			
			
			$data = $_POST['data'];		
							
			foreach($data as $dt){	
								
				$profit_center_id	= $dt['profit_center_id'];	
				$debit	= $dt['debit'];
				$credit	= $dt['credit'];
				$jeid	= $dt['id'];
				// update query
				$result = $db->query("update journal_entries set profit_center_id = '".$profit_center_id."', debit = '".$debit."', credit = '".$credit."' where company_id = '".$cid."' and memo = '".$id."' and id = '".$jeid."' ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}				
			}
			
			header("Location: ?controller=approveduncategorizedgl&action=index&cid=".$cid."");						
					
		} else {	 
		   require_once('views/approveduncategorizedgl/edit.php'); 	   
		}  
	  
    }		
	
	

    public function error() {
      require_once('views/approveduncategorizedgl/error.php');
    }
  }
?>