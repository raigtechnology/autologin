<?php
  class Stockreports {
   
  }
?>