<?php
  class User {
    // we define 3 attributes
    // they are public so that we can access them using $post->author directly
      
  }
?>