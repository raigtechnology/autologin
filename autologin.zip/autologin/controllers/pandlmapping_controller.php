<?php
  class PandlmappingController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}   
		
		$cid = $_GET['cid'];		// company id	
		
		
		$tacs = $_GET['t'];	
	
		$fromdate = $_GET['fromdate'];	
		$todate = $_GET['todate'];
		
				
		/******************* Current Assets START  ****/
		$master_account_codes1 = $db->query("select id as mid, account_desc from master_account_codes where company_id=".$cid." order by account_code");				
		
		foreach($master_account_codes1->fetchAll() as $maclist) {
			
			if($maclist['account_desc']=="CURRENT ASSETS"){
				$currentassetid = $maclist['mid'];
			} 
			if($maclist['account_desc']=="CURRENT LIABILITIES"){
				$currentliabilitiesid = $maclist['mid'];
			} 
			
		}	
		
		$type = $_GET['type'];
		
		if($type=="outputtax"){
		
			$typeid = $currentliabilitiesid;
			$descript = "GST-OUTPUT-TAX";	
		
		} else if($type=="inputtax"){
		
			$typeid = $currentliabilitiesid;
			$descript = "GST-INPUT-TAX";	
		
		}
			
		
		// for output tax
		$subcodesList = array();		
		$subcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$typeid."'
									and sc.subcode_of in (select id from subcodes where description ='".$descript."')
								order by sc.code asc");	
									
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		}	
				
		// for sales tax codes
		$salestaxlist = array();			
		$salestax = $db->query("select ims.AutoInvoiceID, round((ims.Currencyrate * (ips.GSTAmt)),2) as GSTAmt, ips.taxcode, ips.totalamt from tblinvmaster_sales as ims left join tblinvproduct_sales as ips on ims.AutoInvoiceID = ips.AutoInvoiceID where ims.company_id =".$cid." and STR_TO_DATE(ims.Gstinvdate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and ips.GSTAmt>0 	
		
		union select cnp.InvoiceID as AutoInvoiceID, cnp.GSTAmt as GSTAmt, cnp.TaxCode as taxcode, cnp.Totalamt as totalamt from tblcnproduct_sales as cnp where cnp.Company_ID =".$cid." and STR_TO_DATE(cnp.cndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and cnp.GSTAmt>0 and cnp.type='SALES' 
		
		union select dnp.InvoiceID as AutoInvoiceID, dnp.GSTAmt as GSTAmt, dnp.TaxCode as taxcode, dnp.Totalamt as totalamt from tbldnproduct_sales as dnp where dnp.Company_ID =".$cid." and STR_TO_DATE(dnp.dndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and dnp.GSTAmt>0 and dnp.type='SALES' 
		
		union select ims.AutoInvoiceID, round((ims.Currencyrate * (ips.GSTAmt)),2) as GSTAmt, ips.taxcode, ips.totalamt from tblinvmaster_sales_rcm as ims left join tblinvproduct_sales_rcm as ips on ims.AutoInvoiceID = ips.AutoInvoiceID where ims.company_id =".$cid." and STR_TO_DATE(ims.Gstinvdate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and ips.GSTAmt>0 
		
		 ");
		 
		 
				
		foreach($salestax->fetchAll() as $st) {
			$salestaxlist[] = $st;		
		}	
		
		
		
		$purchasetaxlist = array();			
		/*$purchasetax = $db->query("select imp.InvRef, round((imp.Currencyrate * (ipp.GSTamt)),2) as GSTamt, ipp.TaxCodeMatched, ipp.totalamt from tblinvmaster_purchase as imp left join tblinvproduct_purchase as ipp on imp.AutoInvoiceID = ipp.AutoInvoiceID where imp.company_id =".$cid." and STR_TO_DATE(imp.Gstinvdate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and ipp.GSTamt>0  
		
		union select cnp.InvoiceID as AutoInvoiceID, cnp.GSTAmt as GSTAmt, cnp.TaxCode as taxcode, cnp.Totalamt as totalamt from tblcnproduct_sales as cnp where cnp.Company_ID =".$cid." and STR_TO_DATE(cnp.cndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and cnp.GSTAmt>0 and cnp.type='PURCHASE' 
		
		union select dnp.InvoiceID as AutoInvoiceID, dnp.GSTAmt as GSTAmt, dnp.TaxCode as taxcode, dnp.Totalamt as totalamt from tbldnproduct_sales as dnp where dnp.Company_ID =".$cid." and STR_TO_DATE(dnp.dndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and dnp.GSTAmt>0 and dnp.type='PURCHASE' 
		
		union select imp.InvRef, round((imp.Currencyrate * (ipp.GSTamt)),2) as GSTamt, ipp.TaxCodeMatched, ipp.totalamt from tblinvmaster_purchase_rcm as imp left join tblinvproduct_purchase_rcm as ipp on imp.AutoInvoiceID = ipp.AutoInvoiceID where imp.company_id =".$cid." and STR_TO_DATE(imp.Gstinvdate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and ipp.GSTamt>0
		
		
		");*/
		
		$purchasetax = $db->query("select imp.InvRef as AutoInvoiceID, round((imp.Currencyrate * (ipp.GSTamt)),2) as GSTamt, ipp.TaxCodeMatched, ipp.totalamt from tblinvmaster_purchase as imp left join tblinvproduct_purchase as ipp on imp.AutoInvoiceID = ipp.AutoInvoiceID inner join journal_entries as je ON je.memo=imp.InvRef where imp.company_id =".$cid." and STR_TO_DATE(imp.Gstinvdate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and ipp.GSTamt>0  
		
		union select cnp.InvoiceID as AutoInvoiceID, cnp.GSTAmt as GSTAmt, cnp.TaxCode as taxcode, cnp.Totalamt as totalamt from tblcnproduct_sales as cnp where cnp.Company_ID =".$cid." and STR_TO_DATE(cnp.cndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and cnp.GSTAmt>0 and cnp.type='PURCHASE' 
		
		union select dnp.InvoiceID as AutoInvoiceID, dnp.GSTAmt as GSTAmt, dnp.TaxCode as taxcode, dnp.Totalamt as totalamt from tbldnproduct_sales as dnp where dnp.Company_ID =".$cid." and STR_TO_DATE(dnp.dndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and dnp.GSTAmt>0 and dnp.type='PURCHASE' 
		
		");
		
				
		foreach($purchasetax->fetchAll() as $pt) {
			$purchasetaxlist[] = $pt;		
		}	
		
		
		// creditnote
		$creditnotetaxlist = array();			
		$creditnotetax = $db->query("select cnp.InvoiceID as AutoInvoiceID, cnp.GSTAmt as GSTAmt, cnp.TaxCode as taxcode, cnp.Totalamt as totalamt from tblcnproduct_sales as cnp where cnp.Company_ID =".$cid." and STR_TO_DATE(cnp.cndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and cnp.GSTAmt>0 and cnp.type='PURCHASE'");
				
		foreach($creditnotetax->fetchAll() as $cn) {
			$creditnotetaxlist[] = $cn;		
		}	
		
		// debitnote
		$debitnotetaxlist = array();			
		$debitnotetax = $db->query("select dnp.InvoiceID as AutoInvoiceID, dnp.GSTAmt as GSTAmt, dnp.TaxCode as taxcode, dnp.Totalamt as totalamt from tbldnproduct_sales as dnp where dnp.Company_ID =".$cid." and STR_TO_DATE(dnp.dndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' and dnp.GSTAmt>0 and dnp.type='SALES'");
				
		foreach($debitnotetax->fetchAll() as $dn) {
			$debitnotetaxlist[] = $dn;		
		}	
				
		
		
		
		if($type=="inputtax"){
			
			$cond=" and taxcode='AJP' and invoice_date >= '".date("d/m/Y", strtotime($fromdate))."' AND invoice_date <= '".date("d/m/Y", strtotime($todate))."' ";				
		
			// for ajp & ajs
			$ajp_data = $db->query("select 
										sum(gs.6b) as 6b
									from 									
										gst5b6b as gs
										left join subcodes as sc on sc.code = gs.customer_id
									where 
										gs.company_id=".$cid." and sc.company_id='".$cid."' ".$cond." order by gs.invoice_date asc");						
												
			foreach($ajp_data->fetchAll() as $ajp) {
				$ajp_amount = $ajp['6b'];
			} 		
			
		
		
		} else if($type=="outputtax"){
			
			$cond=" and taxcode='AJS' and invoice_date >= '".date("d/m/Y", strtotime($fromdate))."' AND invoice_date <= '".date("d/m/Y", strtotime($todate))."' ";				
		
			// for ajp & ajs
			$ajs_data = $db->query("select 
										sum(gs.5b) as 5b
									from 									
										gst5b6b as gs
										left join subcodes as sc on sc.code = gs.customer_id
									where 
										gs.company_id=".$cid." and sc.company_id='".$cid."' ".$cond." order by gs.invoice_date asc");						
												
			foreach($ajs_data->fetchAll() as $ajs) {
				$ajs_amount = $ajs['5b'];
			} 		
		
		
		} 
		
		
			
		
		
		
						
		/******************* current assets END  ****/		
		
		
						  
	  require_once('views/pandlmapping/index.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/pandlmapping/error.php');
    }
  }
?>