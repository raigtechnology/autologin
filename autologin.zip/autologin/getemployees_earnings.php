<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		
	
	$branch_id		= $_GET['branch_id']; 	
	$department_id = $_GET['department_id']; 
	$designation_id = $_GET['designation_id']; 
	
	$employees = $db->query("SELECT em.id, em.employee_code, em.full_name, em.date_of_joining, pc.profit_center, dm.department_name, dgm.designation_name FROM employee_master AS em 								
								 LEFT JOIN profit_centers as pc on pc.id = em.branch_id
								 LEFT JOIN department_master as dm on dm.id = em.department_id
								 LEFT JOIN designation_master as dgm on dgm.id = em.designation_id where em.branch_id = '".$branch_id."' and em.department_id = '".$department_id."' and em.designation_id = '".$designation_id."' ");						
	
	

	
	?>			
				<select name="employee_id" class="selectbox" onchange="showleavebalance(this.value)">	
				<option value="">--Select--</option>
				<?php 
				foreach($employees->fetchAll() as $er) {
				?>
				<option value="<?php echo $er['id']; ?>"><?php echo $er['full_name']; ?></option>
			
				<?php
				}
				?>
			</select>
