<?php
  class GiftrulesController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    	    
						
		$salesinvoicelistgroup = array();
		$salesinvoicegroup = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.entry_mode in('Gift') group by je.memo order by je.date,je.memo ");	
		foreach($salesinvoicegroup->fetchAll() as $jel) {
			$salesinvoicelistgroup[] = $jel;
		}  		
		
		$salesinvoicelist = array();
		$salesinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code,je.trade_type from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode in('Gift')  order by je.date,je.memo");	
		foreach($salesinvoice->fetchAll() as $je) {
			$salesinvoicelist[] = $je;
		}  	
						  
	  require_once('views/giftrules/index.php'); 
	  
    }		
	
	
		
	
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' order by account_desc asc ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		// sales taxcode master		
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select TaxCode,TaxRate,id from salestaxcodemaster where TaxCode in ('OS') order by TaxCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		
		
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	
					
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
			
		
		if(isset($_POST['save'])){			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 			
			
						
			$date  				= date("Y-m-d", strtotime($_POST['date']));
			$ref  				= 'Gift';
			$profit_center_id  	= $_POST['profit_center_id'];
			$customer_id  		= $_POST['customer_id'];
			$currency_code  	= $_POST['currency_code'];
			$exchange_rate  	= $_POST['exchange_rate'];
			$purchase_order_no  = $_POST['purchase_order_no'];	
			$totalamount 		= $_POST['totalamt'];	// including gst
			$gst 	 			= $_POST['totalgst'];			
			
						
			$tblinvmastersales = $db->query("select * from tblinvmaster_sales order by AutoInvoiceID desc limit 1 ");										
			foreach($tblinvmastersales->fetchAll() as $tims) {
				$AutoInvoiceID = $tims['AutoInvoiceID'];
			}						
						
			if($AutoInvoiceID==""){
				$new_autoinvoice_id= $inv_prefix.''.date("MM/yy").''.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);			
			} else {
				$old_autoinvoice_id = $AutoInvoiceID;									
				$currentlastsixdigit = substr($old_autoinvoice_id, -6);		 // last six digit							
				$prefixstring = substr($old_autoinvoice_id, 0, -6);			 // prefix string						
				$newlastsixdigit = str_pad($currentlastsixdigit + 1, 6, 0, STR_PAD_LEFT);						 // new last six digit			
				$new_autoinvoice_id = $prefixstring.''.$newlastsixdigit;	 // new invoice id																																							
			}	
									
			// master sales data start
			$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$customer_id."' and company_id='".$cid."' ");
			foreach($subcodes->fetchAll() as $scs){
				$customername 	= $scs['description'];
				$subcode_of 	= $scs['subcode_of'];	
				$account_code 	= $scs['code'];			
			}
			
			
			// customer code
			$customers = $db->query("select AutoCustomerID from tblcustomer where CompanyName = '".$customername."' and company_id='".$cid."' ");
			foreach($customers->fetchAll() as $ct){
				$customerid 	= $ct['AutoCustomerID'];					
			}
			
			
			//$newAutoInvoiceID   = $new_autoinvoice_id;
			$CustPORef			= $purchase_order_no;			
			$InvDate			= date("d/m/Y", strtotime($date));			
			$company_id			= $cid;		
			$VendorName			= $customername;
			$CurrencyCode		= $currency_code;
			$Currencyrate		= $exchange_rate;			
							
			$invmastersales = $db->query("insert into tblinvmaster_sales(`AutoInvoiceID`,`CustPORef`,`InvDate`,`company_id`,`CurrencyCode`,`Currencyrate`,`VendorName`,`customerID`) values('".$new_autoinvoice_id."','".$CustPORef."','".$InvDate."','".$company_id."','".$CurrencyCode."','".$Currencyrate."','".$VendorName."','".$customerid."')");	
			
			if(!$invmastersales){
				die('Invalid query: ' . mysql_error());
			}	
			
			
			
						
			// master purchase data end
			
			// journal entries start
			
			$subcode_id   			= $customer_id;
			$profit_center_id 		= $profit_center_id;
			$company_id 			= $cid;
			$date 					= $date;
			$ref 					= $ref;			
			$memo 					= $new_autoinvoice_id;			
			$debit	 				= $totalamount;		
			$gst 					= $gst;		
			$subcode_of 			= $subcode_of;	
			$entry_mode 			= "Gift";		
			
			$price=0;
			
			foreach($_POST['data'] as $rdt){
				$price += $rdt['quantity'] * $rdt['unit_price'];
			}
			
			
			$mastersalesjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`subcode_of`,`entry_mode`,`totalamount`,`currencycode`,`currencyrate`,`trade_type`,`created_by`,`created_ip`,`created`) values('".$subcode_id."','".$profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_autoinvoice_id."','".$debit."','".$gst."','".$subcode_of."','".$entry_mode."','".$price."','".$CurrencyCode."','".$Currencyrate."','Trade Debtors','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$mastersalesjournaldata){
				die('Invalid query: ' . mysql_error());
			}		
			
			$gamount = $debit-$gst;
			
			
					$giftitems = $db->query("select sum(amount) as amount from gift_rules where subcode_id='".$customer_id."' and company_id='".$cid."' and status='0' and flag='N' and year(date) = year('".$date."') ");										
					foreach($giftitems->fetchAll() as $gi) {
						$gift_amount = $gi['amount'];
					}
					
					$withoutgst_amount = $totalamount-$gst;			
					$for_gstinvdate = $withoutgst_amount + $gift_amount;
					
											
					if($for_gstinvdate>500){
						$db->query("update gift_rules set status='1' where subcode_id='".$customer_id."' and company_id='".$company_id."' ");		
						
						$gamount_new = $gamount * 6/100;	
						
						$db->query("insert into  gift_rules(`subcode_id`,`profit_center_id`,`company_id`,`date`,`description`,`amount`,`taxcode`,`gst`,`status`,`created_by`,`created_ip`,`created`) values('".$subcode_id."','".$profit_center_id."','".$company_id."','".$date."','".$new_autoinvoice_id."','".$gamount."','OS','".$gamount_new."','1','".$created_by."','".$created_ip."','".$created."')");
						
						
						// for gaf and gst 03
						$amt     = $for_gstinvdate;
						$amt_gst = $amt * 6/100;						
						
						$db->query("insert into  gift_rules(`subcode_id`,`profit_center_id`,`company_id`,`date`,`description`,`amount`,`taxcode`,`gst`,`status`,`gstdate`,`flag`,`created_by`,`created_ip`,`created`) values('".$subcode_id."','".$profit_center_id."','".$company_id."','".$date."','".$new_autoinvoice_id."','".$amt."','DS','".$amt_gst."','1','".$date."','Y','".$created_by."','".$created_ip."','".$created."')");
						
							
					} else {
					
						$gamount_new = $gamount * 6/100;	
					
						
						$db->query("insert into  gift_rules(`subcode_id`,`profit_center_id`,`company_id`,`date`,`description`,`amount`,`taxcode`,`gst`,`created_by`,`created_ip`,`created`) values('".$subcode_id."','".$profit_center_id."','".$company_id."','".$date."','".$new_autoinvoice_id."','".$gamount."','OS','".$gamount_new."','".$created_by."','".$created_ip."','".$created."')");
					
					}
			
			
			
			
		
			
					
			
			// for customer id
			$tblcustomer = $db->query("select AutoCustomerID from tblcustomer where CompanyName = (select description from subcodes where company_id ='".$cid."' and id='".$customer_id."' ) and company_id = '".$cid."' ");
			foreach($tblcustomer->fetchAll() as $vd){
				$CustID 	= $vd['AutoCustomerID'];				
			}		
			
			// for cheqwriter
			$tblinvoiceinoutdata = $db->query("insert into tblinvoiceinout(`InvType`,`CustID`,`InvNo`,`InvAmt`,`InvDate`,`DueDate`,`company_id`,`Acc_description`) values('Sales','".$CustID."','".$new_autoinvoice_id."','".$debit."','".$date."','".$date."','".$company_id."','Invoiceout')");
			
			if(!$tblinvoiceinoutdata){
				die('Invalid query: ' . mysql_error());
			}	
			
			// journal entries end
			
			// gst bad debt entries start
			
			$account_code  			= $account_code;	
			$gstdate 				= $date;		
			$description 			= $new_autoinvoice_id;			
			$ref 					= $ref;			
			$debit	 				= $totalamount;		
			$debit_gst	 			= $gst;		
			$trade_type 			= "Trade Debtors";	
			$company_id 			= $cid;
			
			$gstbaddebtdata = $db->query("insert into  gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`debit`,`debit_gst`,`trade_type`,`company_id`,`created_by`,`created_ip`,`created`) values('".$account_code."','".$gstdate."','".$new_autoinvoice_id."','".$ref."','".$debit."','".$debit_gst."','".$trade_type."','".$company_id."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$gstbaddebtdata){
				die('Invalid query: ' . mysql_error());
			}	
			
						
			
			// gst bad debt entries end					
					
			$data = $_POST['data'];
			
							
			foreach($data as $dt){
										
				$productdescription = $db->query("select description, subcode_of from subcodes where id = '".$dt['subcode_id']."' and company_id='".$cid."' ");
				foreach($productdescription->fetchAll() as $pds){
					$product_desc 			= $pds['description'];
					$product_subcode_of 	= $pds['subcode_of'];						
				}
				
							
				//$autoinvoiceid 			= $newAutoInvoiceID;
				$subcode_id				= $dt['subcode_id'];
				$product_desc 			= $product_desc;
				$quanity 				= $dt['quantity'];
				$unit_price 			= $dt['unit_price'];
				$total_amount 			= $dt['total_amount'];
				$taxcode		 		= $dt['taxcode'];				
				$gst_amount 			= $dt['gst'];	
				$gst_eer 				= $dt['gst_err'];	// gst exclude exchange rate			
				$company_id 			= $cid;				
				
				$totalunitprice			= $quanity * $unit_price;
				
				
				$productdescription_pro = $db->query("select Productcode, Misc_code from tblproduct where Productdesc = '".$product_desc."' and company_id='".$cid."' ");
				foreach($productdescription_pro->fetchAll() as $pr){
					$productcode 		= $pr['Productcode'];		
					$Misc_code 			= $pr['Misc_code'];								
				}
				
				
				if($total_amount>0){
				
					$totamt = $total_amount - $gst_eer;
				
					$productsalesdata = $db->query("insert into  tblinvproduct_sales(`AutoInvoiceID`,`Productcode`,`ProductDesc`,`Quantity`,`UnitPrice`,`totalunitprice`,`Totalamt`,`TaxCode`,`GSTAmt`,`company_id`,`Misc_code`) values('".$new_autoinvoice_id."','".$productcode."','".$product_desc."','".$quanity."','".$unit_price."','".$totalunitprice."','".$total_amount."','".$taxcode."','".$gst_eer."','".$company_id."','".$Misc_code."')");
					
					if(!$productsalesdata){
						die('Invalid query: ' . mysql_error());
					}	
					
					// journal entries start
			
					$pd_subcode_id   			= $dt['subcode_id'];
					$pd_profit_center_id 		= $profit_center_id;
					$pd_company_id 				= $cid;
					$pd_date 					= date("Y-m-d", strtotime($date));
					$pd_ref 					= $ref;			
					//$pd_memo 					= $new_autoinvoice_id;		
					$pd_credit 					= $total_amount - $gst_amount;		
					$pd_gst 					= $gst_amount;		
					$pd_subcode_of 				= $product_subcode_of;	
					$pd_entry_mode 				= "Gift";		
					
					$productsalesjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`subcode_of`,`entry_mode`,`taxcode`,`created_by`,`created_ip`,`created`) values('".$pd_subcode_id."','".$pd_profit_center_id."','".$pd_company_id."','".$pd_date."','".$pd_ref."','".$new_autoinvoice_id."','".$pd_credit."','".$pd_gst."','".$pd_subcode_of."','".$pd_entry_mode."','".$taxcode."','".$created_by."','".$created_ip."','".$created."')");
					
					if(!$productsalesjournaldata){
						die('Invalid query: ' . mysql_error());
					}	
					// journal entries end
					
					
					// PROFIT CENTER CODE
					$pcenter = $db->query("select profit_center_code from profit_centers where company_id ='".$cid."' and id='".$profit_center_id."' ");
					foreach($pcenter->fetchAll() as $pc){
						$profit_center_code 	= $pc['profit_center_code'];				
					}		
					
					
					// PROFIT CENTER CODE
					$paccountno = $db->query("select code from subcodes where company_id ='".$cid."' and id='".$pd_subcode_id."' ");
					foreach($paccountno->fetchAll() as $acc){
						$pd_account_code 	= $acc['code'];				
					}	
					
					// for profit center list
					$profitcenterlist = $db->query("insert into profit_centers_list(`company_id`,`pf_center_code`,`pf_invoiceno`,`pf_ispaid`,`Pf_AccNo`) values('".$company_id."','".$profit_center_code."','".$new_autoinvoice_id."','N','".$pd_account_code."')");	
								
					if(!$profitcenterlist){
						die('Invalid query: ' . mysql_error());
					}		
			
					
					
					
					
				}
											
			}
			
				
			// gst output tax
			
			$outputtaxdata = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX' and company_id='".$cid."' ");
			foreach($outputtaxdata->fetchAll() as $ot){
				$outputtax_id 			= $ot['id'];									
			}
			
			if($gst>0){
			
				$outputtaxjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`entry_mode`,`created_by`,`created_ip`,`created`) values('".$outputtax_id."','".$profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_autoinvoice_id."','".$gst."','".$gst."','".$entry_mode."','".$created_by."','".$created_ip."','".$created."')");
				
				if(!$outputtaxjournaldata){
					die('Invalid query: ' . mysql_error());
				}	
				
				
			$suspensedata = $db->query("select id from subcodes where description = 'GST Expenses (Deemed Supply)' and company_id='".$cid."' ");
			foreach($suspensedata->fetchAll() as $st){
				$suspense_id 			= $st['id'];									
			}			
			
			$db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`,`created_by`,`created_ip`,`created`) values('".$suspense_id."','".$profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_autoinvoice_id."','".$gst."','".$entry_mode."','".$created_by."','".$created_ip."','".$created."')");
			
				
			
			}	
			
			// for suspense part 
			$suspense_credit = $debit - $gst;
			
			
			$db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`subcode_of`,`entry_mode`,`totalamount`,`currencycode`,`currencyrate`,`trade_type`,`created_by`,`created_ip`,`created`) values('".$customer_id."','".$profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_autoinvoice_id."','".$debit."','".$subcode_of."','".$entry_mode."','".-abs($suspense_credit)."','".$CurrencyCode."','".$Currencyrate."','Trade Debtors','".$created_by."','".$created_ip."','".$created."')");
			
			
			$db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`subcode_of`,`entry_mode`,`created_by`,`created_ip`,`created`) values('".$subcode_id."','".$profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_autoinvoice_id."','".$suspense_credit."','".$subcode_of."','".$entry_mode."','".$created_by."','".$created_ip."','".$created."')");
			
			
			
		
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Add";
			$window_name     = "Gift Rules";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
						
			header("Location: ?controller=giftrules&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/giftrules/create.php'); 	   
		}  
	  
    }		
	

    public function error() {
      require_once('views/giftrules/error.php');
    }
  }
?>
