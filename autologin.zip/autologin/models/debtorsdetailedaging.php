<?php
  class debtorsdetailedaging {
   
  }
?>