<?php
  class BranchmasterController {
  
	public function index() { 	
	
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		
		// allowancelist
		$branchlist = array();
		$branch = $db->query("SELECT * FROM branch_master where company_id='".$cid."' order by branch_name");		
		foreach($branch->fetchAll() as $el) {
        	$branchlist[] = $el;
     	}	
		
			
		require_once('views/branchmaster/index.php'); 
    }	
	
	
	// create
	public function create() { 	
	
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		
		$cid = $_GET['cid'];
			
		if (isset($_POST['Submit'])) {
		
			$branch_name		= $_POST['branch_name'];			
			$branch_address 	= $_POST['branch_address'];		
			$branch_city 	= $_POST['branch_city'];			
			
			$db->query("insert into branch_master(`company_id`,`branch_name`,`address`,`city`)values('".$cid."','".$branch_name."','".$branch_address."','".$branch_city."')");			
			
			header("Location: ?controller=branchmaster&action=index&cid=".$cid."");	
				
		} else {
			require_once('views/branchmaster/create.php'); 
	   	}		
		  	  	  
    }
	
	
	// edit
	public function edit() { 	
	
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		
		$id = $_GET['id'];
		 $cid = $_GET['cid'];
		// allowancelist
		$branchlist = array();
		$branch = $db->query("SELECT * FROM branch_master where id='".$id."' and company_id='".$cid."' order by branch_name");		
		foreach($branch->fetchAll() as $el) {
        	$branchlist[] = $el;
     	}	
		
		
			
		if (isset($_POST['Submit'])) {
		
			$branch_name		= $_POST['branch_name'];			
			$branch_address 	= $_POST['branch_address'];		
			$branch_city 	    = $_POST['branch_city'];			
		
			$db->query("update branch_master set branch_name='".$branch_name."', address='".$branch_address."', city='".$branch_city."' where id='".$id."' and company_id='".$cid."' ");
			
			header("Location: ?controller=branchmaster&action=index&cid=".$cid."");	
				
		} else {
			require_once('views/branchmaster/edit.php'); 
	   	}		
		  	  	  
    }
	
	
	// delete	
	public function delete() {
		
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
	
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		
		$id = $_GET['id'];	
		$cid = $_GET['cid'];
		$result = $db->query("delete from branch_master where id ='".$id."' ");		
							
		if(!$result){
			die('Invalid query: ' . mysql_error());
		}	
		
      header("Location: ?controller=branchmaster&action=index&cid=".$cid."");		
    }
		

    public function error() {
      require_once('views/branchmaster/error.php');
    }
	
	
	
  }
?>