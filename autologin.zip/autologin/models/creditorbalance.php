<?php
  class creditorbalance {
   
  }
?>