<?php
  class ImportedgoodsController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    	    
						
		$purchaseinvoicelistgroup = array();
		$purchaseinvoicegroup = $db->query("select je.memo, je.ImptDecNo from journal_entries as je where je.company_id='".$cid."' and je.entry_mode = 'Imported Goods' group by je.memo ");	
		foreach($purchaseinvoicegroup->fetchAll() as $jel) {
			$purchaseinvoicelistgroup[] = $jel;
		}  		
		
		$purchaseinvoicelist = array();
		$purchaseinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and je.entry_mode = 'Imported Goods' and  sc.company_id='".$cid."'  ");	
		foreach($purchaseinvoice->fetchAll() as $je) {
			$purchaseinvoicelist[] = $je;
		}  	
						  
	  require_once('views/importedgoods/index.php'); 
	  
    }		
		
	
	

/******************************************************************************************************************************************************************************/
// create
	
	public function edit() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		
		$id = $_GET['id'];		
		
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
				
		$purchaseinvoicelist = array();
		$purchaseinvoice = $db->query("select je.id, je.profit_center_id, je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center, je.taxcode, je.currencycode, je.currencyrate from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode = 'Imported Goods' and je.memo = '".$id."'  ");	
		foreach($purchaseinvoice->fetchAll() as $je) {
			$purchaseinvoicelist[] = $je;
		}  
		
		
		$purchaseinvoicelist1 = array();
		$purchaseinvoice1 = $db->query("select je.subcode_id, je.profit_center_id, je.id, je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center, je.taxcode from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode = 'Imported Goods' and je.memo = '".$id."' and je.trade_type='Trade Creditors' ");	
		foreach($purchaseinvoice1->fetchAll() as $je1) {
			$purchaseinvoicelist1[] = $je1;
		} 	
				
				
		$company = $db->query("select MixedSupply, inv_prefix from companies where id='".$cid."'  ");	
		foreach($company->fetchAll() as $cm) {
			$supply_type = $cm['MixedSupply'];
			$inv_prefix = $cm['inv_prefix'];
		}  	
		
		if($supply_type=="Y"){
			$type = 'MIX';
			$stype = "Mixed";
		} else if($supply_type=="N"){
			$type = 'TAXABLE';
			$stype = "Standard";
		} 
		
		$_SESSION['type'] = $type;
		
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id != '6' order by account_desc ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// vendor
		$vendorslist = array();
		$vendors = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='5' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors') order by sc.description asc");	
		foreach($vendors->fetchAll() as $ct) {
			$vendorslist[] = $ct;
		}  	
		
		// sales taxcode master		
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select PurTaxCode from purchasecodematch where supplyType = '".$type."' group by PurTaxCode order by PurTaxCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		// purchase taxcode master		
		$purchasetaxcodemasterlist = array();
		$purchasetaxcodemaster = $db->query("select TaxCode,TaxRate,id from purtaxcodemaster order by TaxCode");	
		foreach($purchasetaxcodemaster->fetchAll() as $pm) {
			$purchasetaxcodemasterlist[] = $pm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	
					
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
					
		
		if(isset($_POST['save'])){			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
			
								
			$date  				= date("Y-m-d", strtotime($_POST['date']));
			$imptdecno 			= $_POST['k1number'];			
			$vendor_id  		= $_POST['vendor_id'];
			$invoice_no  		= $_POST['invoice_no'];				
			$totalamount 		= $_POST['totalamt'];	// including gst
			$gst 	 			= $_POST['totalgst'];	
			$memo               = $_POST['memo'];
			$paytocustoms       = $_POST['paytocustoms'];
			$totalgst_err       = $_POST['totalgst_err'];
			$currency_rate_new  = $_POST['exchange_rate'];
			
			$original_invoice_no     = $_POST['original_invoice_no'];
			$pro_desc    		= $_POST['pro_desc'];
						
			$invtype = "Purchase";
			
			// for self clearance
			if($invoice_no==""){				
				$invoice_no = $imptdecno;					
			}
			
			
			
			// update im invoice			
				
			$updateqry = $db->query("update journal_entries set taxcode='IM' where taxcode='IMS' and company_id='".$cid."' and memo='".$original_invoice_no."' ");	
						
			if(!$updateqry){
				die('Invalid query: ' . mysql_error());
			}	
			
			$updateqry2 = $db->query("update journal_entries set Gstinvdate='".$date."',  ImptDecNo='".$imptdecno."' where company_id='".$cid."' and memo='".$original_invoice_no."' ");	
						
			if(!$updateqry2){
				die('Invalid query: ' . mysql_error());
			}	
					
			
			$updateqry1 = $db->query("update tblinvmaster_purchase set Gstinvdate='".date("d/m/Y", strtotime($date))."', ImptDecNo='".$imptdecno."' where company_id='".$cid."' and InvRef='".$original_invoice_no."' ");	
						
			if(!$updateqry1){
				die('Invalid query: ' . mysql_error());
			}
			
			// master purchase data start
			
			
			if($vendor_id==0 || $vendor_id==""){
				$new_vendor_id = $_POST['data'][0]['subcode_id'];
				
				$subcodes = $db->query("select sc.description, sc.subcode_of, sc.code, vd.Country_Code from subcodes as sc left join vendor as vd on vd.Vendor_Name=sc.description where sc.id = '".$new_vendor_id."' ");
				foreach($subcodes->fetchAll() as $scs){
					$vendorname 	= $scs['description'];
					$subcode_of 	= $scs['subcode_of'];	
					$account_code 	= $scs['code'];		
					$country 		= $scs['Country_Code'];			
				}
				
			} else {
				
				$subcodes = $db->query("select sc.description, sc.subcode_of, sc.code, vd.Country_Code from subcodes as sc left join vendor as vd on vd.Vendor_Name=sc.description where sc.id = '".$vendor_id."' ");
				foreach($subcodes->fetchAll() as $scs){
					$vendorname 	= $scs['description'];
					$subcode_of 	= $scs['subcode_of'];	
					$account_code 	= $scs['code'];		
					$country 		= $scs['Country_Code'];			
				}
				
			}
			
			
			
			

/**********************forwarding agent ************************************************************************************/			
		if($vendor_id==0 || $vendor_id==""){
					
					$vendorname					= $vendorname.' '.$imptdecno;		
					$business_registration_no	= "";
					$gst_registration_no		= "";	
					$country					= $country;							
					
					$char = substr($vendorname, 0, 1); // first letter from a string						
					
					$subtitle = $db->query("select code, description from subcodes where company_id = '".$cid."' and id ='".$new_vendor_id."'");	
					foreach($subtitle->fetchAll() as $sc) {
						$sub_account_code 	= $sc['code'];					
						$sub_description 	= $sc['description'];			
					}			
					
					// generating account code for vendor from vendor name
					
					$acode = substr($sub_account_code, 0, 4);
	  				$acode = "$acode/$char";					
					
					$subcode_foraccount_code = $db->query("select Vendor_account_code from vendor where company_id = '".$cid."' and Vendor_account_code like '%$acode%'  order by Vendor_ID desc limit 1 ");	
					foreach($subcode_foraccount_code->fetchAll() as $sac) {							
						$code_for_vendor = $sac['Vendor_account_code'];		
					}	
						
					if($code_for_vendor!=""){
						$code2 = substr($code_for_vendor, 6, 8);
					  	$code2++;
					 	$code2 = str_pad($code2, 3, '0', STR_PAD_LEFT);
					  	$acc_code = "$acode$code2";
       				} else {
               			$acc_code = "$acode"."001";   	
					}			
								
					$acc_code = strtoupper($acc_code);						
					// end of generating account code for vendor from vendor name
															
					if($country=="MALAYSIA"){
						$country_type = "LOCAL";
					} else {
						$country_type = "FOREIGN";
					}
					
					
												
					$result = $db->query("insert into vendor(Vendor_Name, Vendor_account_code, company_id, Business_Regno, GSTRNo, Country_Code, CustTradeTYpe) values ('".$vendorname."', '".$acc_code."', '".$cid."', '".$business_registration_no."', '".$gst_registration_no."', '".$country."', '".$country_type."') ");										
					if(!$result){
						die('Invalid query: ' . mysql_error());
					} 
						
					// insert subcodes 
					$result_qry = $db->query("insert into subcodes(master_account_code_id, code, description, subcode_of, company_id, created_by, created_ip, created) values ('".$mac_id_for_title."', '".$acc_code."', '".$vendorname."', '".$getid."', '".$cid."', '".$created_by."', '".$created_ip."', '".$created."') ");										
					if(!$result_qry){
						die('Invalid query: ' . mysql_error());
					} 
											
					$newvendor = $db->query("select id, description from subcodes where company_id = '".$cid."' order by id desc limit 1");	
					foreach($newvendor->fetchAll() as $nv) {
						$vendor_id 	= $nv['id'];							
					}	
	
		}
 
/****************************************************** ********************************************/

			
			
			$tblinvmasterpurchase = $db->query("select * from tblinvmaster_purchase order by AutoInvoiceID desc limit 1 ");										
			foreach($tblinvmasterpurchase->fetchAll() as $timp) {			
				$AutoInvoiceID = $timp['AutoInvoiceID'];
			}
									
			if($AutoInvoiceID==""){
				$new_autoinvoice_id= $inv_prefix.'/'.date("d/M/Y").'/'.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);			
			} else {
				$old_autoinvoice_id = $AutoInvoiceID;									
				$currentlastsixdigit = substr($old_autoinvoice_id, -6);		 // last six digit							
				$prefixstring = substr($old_autoinvoice_id, 0, -6);			 // prefix string						
				$newlastsixdigit = str_pad($currentlastsixdigit + 1, 6, 0, STR_PAD_LEFT);						 // new last six digit			
				$new_autoinvoice_id = $prefixstring.''.$newlastsixdigit;	 // new invoice id																																							
			}	
				
			$tblinvmasterpurchase1 = $db->query("select count(*) as total from tblinvmaster_purchase where InvRef='".$new_autoinvoice_id."' ");										
			foreach($tblinvmasterpurchase1->fetchAll() as $timp1) {			
				$total = $timp1['total'];
			}	
				
			if($total>0){
				$new_invoice_no = $inv_prefix.'/'.date("d/M/Y").'/'.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);	
			} else {
				$new_invoice_no = $invoice_no;
			}	
				
					
			
			
			$tblinvmasterpurchase2 = $db->query("select Currencycode, Currencyrate from tblinvmaster_purchase where InvRef='".$memo."' and company_id='".$cid."' ");										
			foreach($tblinvmasterpurchase2->fetchAll() as $timp2) {			
				$currency_code  	= $timp2['Currencycode'];
				$exchange_rate  	= $timp2['Currencyrate'];		
			}	
			
			
			$newAutoInvoiceID   = $new_autoinvoice_id;
			$InvRef 			= $new_invoice_no;
			$PORef 				= $purchase_order_no;
			$InvDate 			= date("d/m/Y", strtotime($date));
			$company_id 		= $cid;			
			$VendorName 		= $vendorname;
			$vendorID 			= $vendor_id;
						
			$Currencycode 		= 'RM';
			$Currencyrate 		= 1;		
			
			
			// for op taxcode
			$TaxCode			= $_POST['data'][0]['matchcode'];
				
			if($TaxCode=="IMS" || $TaxCode=="ISS"){
				$gstdate ="";
				$entry = "Imported Goods";
				$status = 'im';
				
			} else {
				$gstdate = $InvDate;
				$entry = "Purchase";
				$status = '';
			}	
			
					
			$masterpurchasedata = $db->query("insert into  tblinvmaster_purchase(`AutoInvoiceID`,`InvRef`,`InvDate`,`company_id`,`VendorName`,`Currencycode`,`Currencyrate`,`vendorID`,`TaxCode`,`Gstinvdate`,`ImptDecNo`) values('".$newAutoInvoiceID."','".$InvRef."','".$InvDate."','".$company_id."','".$VendorName."','".$Currencycode."','".$Currencyrate."','".$vendorID."','".$TaxCode."','".$gstdate."','".$imptdecno."')");	
						
			if(!$masterpurchasedata){
				die('Invalid query: ' . mysql_error());
			}				
			// master purchase data end
			
			// journal entries start
			
			$subcode_id   			= $vendor_id;		
			$company_id 			= $cid;
			$date 					= date("Y-m-d", strtotime($date));
			$ref 					= $ref;		
			$credit 				= $totalamount;		
			$gst 					= $gst;		
			$subcode_of 			= $subcode_of;	
			$entry_mode 			= $entry;		
		
			$taxocde = "";			
			// taxcode	
			$price=0;
			
			$ir=0;
			foreach($_POST['data'] as $rdt){		
				$price += $rdt['quantity'] * $rdt['unit_price'];
			$ir++;
			}
			
					
			$pfcenter = $db->query("select id from profit_centers where flag='1' and company_id ='".$cid."' ");
			foreach($pfcenter->fetchAll() as $pf){
				$pfid 	= $pf['id'];				
			}			
							
								
			$purchasemasterjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`subcode_of`,`entry_mode`,`totalamount`,`currencycode`,`currencyrate`,`taxcode`,`trade_type`,`status`,`ImptDecNo`,`Gstinvdate`,`created_by`,`created_ip`,`created`) values('".$subcode_id."','".$pfid."','".$company_id."','".$date."','".$ref."','".$new_invoice_no."','".$paytocustoms."','".$subcode_of."','".$entry_mode."','".$paytocustoms."','".$Currencycode."','".$Currencyrate."','".$taxocde."','Trade Creditors','".$status."','".$imptdecno."','".$date."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$purchasemasterjournaldata){
				die('Invalid query: ' . mysql_error());
			}	
	
			
			// for vendor id
			$tblvendor = $db->query("select Vendor_ID from vendor where Vendor_Name = (select description from subcodes where company_id ='".$cid."' and id='".$vendor_id."' ) and company_id = '".$cid."' ");
			foreach($tblvendor->fetchAll() as $vd){
				$CustID 	= $vd['Vendor_ID'];				
			}			
						
			// for cheqwriter
			$tblinvoiceinoutdata = $db->query("insert into tblinvoiceinout(`InvType`,`CustID`,`InvNo`,`InvAmt`,`InvDate`,`DueDate`,`company_id`,`Acc_description`) values('".$invtype."','".$CustID."','".$new_invoice_no."','".$paytocustoms."','".$date."','".$date."','".$company_id."','Invoicein')");
			
			if(!$tblinvoiceinoutdata){
				die('Invalid query: ' . mysql_error());
			}	
			
			
			// gain or loss part start************************************************************/
			
			$invoiceoriginal = $db->query("select currencyrate from journal_entries where memo='".$original_invoice_no."' and company_id='".$cid."' and trade_type='Trade Creditors' ");
			foreach($invoiceoriginal->fetchAll() as $io){						
				$invoice_currencyrate 	= $io['currencyrate'];						
			}
			
			$invoice_quantity = $_POST['data'][0]['quantity'];
			$invoice_unitprice = $_POST['data'][0]['unit_price'];
					
			$invoice_currency_amount = $invoice_quantity * $invoice_unitprice;
								
			// gain or loss calculation
			$invoice_currency_rate 		= $invoice_currencyrate;
			$payment_currency_amount	= $invoice_currency_amount;
						
			$amount_for_find_difference1 = $payment_currency_amount * $invoice_currencyrate; // old value
			$amount_for_find_difference2 = $payment_currency_amount * $currency_rate_new; // new value
													
			if($amount_for_find_difference1<$amount_for_find_difference2){					
				$difference = $amount_for_find_difference2 - $amount_for_find_difference1;		 // loss	
				//echo "Loss : ".$loss_difference.'<br>';													
			} else if($amount_for_find_difference1>$amount_for_find_difference2){					
				$difference = $amount_for_find_difference1 - $amount_for_find_difference2;		// gain		
				//echo "Gain : ".$gain_difference.'<br>';
			} else {
				//echo "There is no difference";
			}				
									
					
			if($difference>0){					
				$db->query("insert into tbl_es43(`invoice_no`,`invoice_date`,`gst`,`company_id`,`TaxCode`,`transaction_type`,`created_by`,`created_ip`,`created`)values('".$original_invoice_no."','".$date."','".$difference."','".$company_id."','ES43','Purchase','".$created_by."','".$created_ip."','".$created."')");	
			}	
						
			/*****************************************************************gain or loss part end */
			
			// journal entries end
			
			// gst bad debt entries start
			
			$account_code  			= $account_code;	
			$gstdate 				= date("Y-m-d", strtotime($date));		
			//$description 			= $invoice_no;			
			$ref 					= $ref;			
			$credit 				= $totalamount;		
			$credit_gst 			= $gst;		
			$trade_type 			= "Trade Creditors";	
			$company_id 			= $cid;
			
			$gstbaddebtdata = $db->query("insert into gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`credit`,`trade_type`,`company_id`,`created_by`,`created_ip`,`created`) values('".$account_code."','".$gstdate."','".$new_invoice_no."','".$ref."','".$paytocustoms."','".$trade_type."','".$company_id."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$gstbaddebtdata){
				die('Invalid query: ' . mysql_error());
			}	
			// gst bad debt entries end		
					
					
			$data = $_POST['data'];
			
			$in=0;	
			foreach($data as $dt){
										
				$productdescription = $db->query("select description, subcode_of from subcodes where id = '".$dt['subcode_id']."' and company_id='".$cid."' ");
				foreach($productdescription->fetchAll() as $pds){
					$product_desc 			= $pds['description'];
					$product_subcode_of 	= $pds['subcode_of'];						
				}
								
				$subcode_id				= $dt['subcode_id'];
				$product_desc 			= $product_desc;
				$quanity 				= $dt['quantity'];
				$unit_price 			= $dt['unit_price'];
				$total_amount 			= $dt['total_amount'] - $dt['gst_err'];
				$taxcode_purchased 		= $dt['taxcode'];
				$taxcode_matched 		= $dt['matchcode'];
				$gst_amount 			= $dt['gst'];
				$gst_eer 				= $dt['gst_err'];	// gst exclude exchange rate
				$entry_mode 			= "Purchase";			
				$company_id 			= $cid;	
												
				$totalunitprice			= $quanity * $unit_price;
									
				if($totalunitprice>0){
						
					if($in==0){								
						$product_desc = $pro_desc;	
						$quantity = 1;
						$unit_price = $_POST['data'][0]['unit_price'];
										
						$total_amount = $quantity * $unit_price * $currency_rate_new;											
					}
				
					$productpurchasedata = $db->query("insert into  tblinvproduct_purchase(`AutoInvoiceID`,`ProductDesc`,`Quantity`,`UnitPrice`,`totalunitprice`,`Totalamt`,`GSTamt`,`TaxCodePurchase`,`TaxCodeMatched`,`entry_mode`,`company_id`,`subcode_id`,`ImptDecNo`) values('".$newAutoInvoiceID."','".$product_desc."','".$quanity."','".$total_amount."','".$total_amount."','".$total_amount."','".$gst_eer."','".$taxcode_purchased."','".$taxcode_matched."','".$entry_mode."','".$company_id."','".$subcode_id."','".$imptdecno."')");
							
					if(!$productpurchasedata){
						die('Invalid query: ' . mysql_error());
					}	
							
					// journal entries start
					
					$pd_subcode_id   			= $subcode_id;
					$pd_profit_center_id 		= $dt['profit_center_id'];
					$pd_company_id 				= $cid;
					$pd_date 					= date("Y-m-d", strtotime($date));
					$pd_ref 					= $ref;							
					$pd_debit 					= $total_amount;		
					$pd_gst 					= $gst_amount;		
					$pd_subcode_of 				= $product_subcode_of;	
					$pd_entry_mode 				= $entry;		
				
					if($in>0){
							
						$productpurchasejournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`subcode_of`,`entry_mode`,`taxcode`,`status`,`ImptDecNo`,`Gstinvdate`,`created_by`,`created_ip`,`created`) values('".$pd_subcode_id."','".$pd_profit_center_id."','".$pd_company_id."','".$pd_date."','".$pd_ref."','".$new_invoice_no."','".$pd_debit."','".$pd_subcode_of."','".$pd_entry_mode."','".$taxcode_matched."','".$status."','".$imptdecno."','".$pd_date."','".$created_by."','".$created_ip."','".$created."')");
							
						if(!$productpurchasejournaldata){
							die('Invalid query: ' . mysql_error());
						}	
					}		
					// journal entries end
				}
				$in++;	
			}
											
			$inputtaxdata = $db->query("select id from subcodes where description = 'GST-INPUT-TAX' and company_id='".$cid."' ");
			foreach($inputtaxdata->fetchAll() as $ot){
				$inputtax_id 			= $ot['id'];									
			}			
			
			$outputtaxjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`,`Gstinvdate`,`ImptDecNo`,`created_by`,`created_ip`,`created`) values('".$inputtax_id."','".$pd_profit_center_id."','".$company_id."','".$date."','".$ref."','".$new_invoice_no."','".$totalgst_err."','".$entry_mode."','".$date."','".$imptdecno."','".$created_by."','".$created_ip."','".$created."')");
			
			if(!$outputtaxjournaldata){
				die('Invalid query: ' . mysql_error());
			}	
				
						
			header("Location: ?controller=importedgoods&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/importedgoods/edit.php'); 	   
		}  
	  
    }		

/******************************************************************************************************************************************************************************/	
	

    public function error() {
      require_once('views/importedgoods/error.php');
    }
  }
?>