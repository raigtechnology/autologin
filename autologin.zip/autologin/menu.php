<?php
	$tag = $_SESSION['tag'];


?>

<?php
if($tag=="setup"){
?>
<div class="row2">
  <nav id="topnav">
    <ul class="clear">    
      <li><a class="drop" href="#" style="background:#FFFFFF; cursor:default;">Setup :</a></li>   
	  <li><a href="?controller=accountingyear&action=index&cid=<?php echo $cid; ?>">Accounting Year</a></li>    
      <li><a href="?controller=chartofaccounts&action=index&cid=<?php echo $cid; ?>">Chart of Accounts</a></li> 
	  <li><a href="?controller=codedescriptions&action=index&cid=<?php echo $cid; ?>">Code Descriptions</a></li> 
	  <li><a href="?controller=profitcenters&action=index&cid=<?php echo $cid; ?>">Profit Centers</a></li> 
	  <li><a href="#">Opening Balance</a>
	  	<ul>
	  		<li><a href="?controller=openingbalance&action=index&cid=<?php echo $cid; ?>">Opening Balance</a></li> 
			<li><a href="?controller=fixedassets&action=index&cid=<?php echo $cid; ?>">Fixed Asset</a></li> 
			
	  	</ul>
	</li>		
	
	   <li><a href="?controller=forex&action=index&cid=<?php echo $cid; ?>">Foreign Exchange Rates</a></li> 
	   <li><a href="#">Import</a>
	  	<ul>
	  		 <li><a class="drop" href="?controller=importjournalentries&action=index&cid=<?php echo $cid; ?>">Import Journal Entries</a></li> 
			 <li><a class="drop" href="?controller=importchartofaccounts&action=index&cid=<?php echo $cid; ?>">Import Chart of Accounts</a></li>  	
			 <li><a class="drop" href="?controller=importcustomers&action=index&cid=<?php echo $cid; ?>">Import Customers & Vendors</a></li> 
			 <?php if($cid=='1237'){ ?> 	
			 <li><a class="drop" href="?controller=importproduct&action=index&cid=<?php echo $cid; ?>">Import Sales & Payment </a></li>
			 <li><a class="drop" href="?controller=importreturnproduct&action=index&cid=<?php echo $cid; ?>">Import Sales Return & Payment </a></li> 
			 <?php } ?> 
	  	</ul>
	</li>	
	  
	<?php
	if($_SESSION['username']=="krishnaveni"){
	?>
		<li><a href="?controller=customers&action=index&cid=<?php echo $cid; ?>">Customers List</a></li> 
		<li><a href="?controller=customerlogin&action=index&cid=<?php echo $cid; ?>">Customers</a></li> 

	<?php
	}
	?>		
	
	   <li style="text-align:right; float:right;"><a class="drop" href="?controller=companies&action=view&cid=<?php echo $cid; ?>&tag=reports">Reports</a></li> 
	   <li style="text-align:right; float:right;"><a class="drop" href="?controller=companies&action=view&cid=<?php echo $cid; ?>&tag=entries" style="margin-right:8px;">Entries</a></li>	
	    
    </ul>

  </nav>
 
</div>
<?php
} else if($tag=="entries"){
?>
<div class="row2">
  <nav id="topnav">
    <ul class="clear">    
	  <li><a class="drop" href="#" style="background:#FFFFFF;">Entries :</a></li>   
	  <li><a class="drop" href="#">General Ledger</a>
        <ul>
          <li><a href="?controller=uncategorizedgl&action=index&cid=<?php echo $cid; ?>" >Unapproved GL</a></li>
          <li><a href="?controller=approveduncategorizedgl&action=index&cid=<?php echo $cid; ?>" >Approved GL</a></li>         
        </ul>
      </li>
	  <li><a class="drop" href="#">Journal Entries</a>
        <ul>
          <li><a href="?controller=manualentries&action=index&cid=<?php echo $cid; ?>">Manual Entries/Adjustments </a></li>             
        </ul>
      </li>
	  <li><a class="drop" href="#">Sales</a>
        <ul>
           <li><a href="?controller=salesinvoice&action=index&cid=<?php echo $cid; ?>">Invoice Issued</a></li>  
		   <li><a href="?controller=paymentreceived&action=index&cid=<?php echo $cid; ?>">Payment Received</a></li>  		 
		   <li><a href="?controller=giftrules&action=index&cid=<?php echo $cid; ?>">Gift Rules</a></li> 
		   <li><a class="drop" href="#">Deposit Received</a>
			<ul>			 
			  <li><a href="?controller=depositsalesnonrefundable&action=index&cid=<?php echo $cid; ?>">Non-Refundable Deposit</a></li>  			 
			</ul>
		  </li> 
        </ul>
      </li>
	  <li><a class="drop" href="#">Purchase</a>
        <ul>			
			 <li><a href="?controller=purchaseinvoice&action=index&cid=<?php echo $cid; ?>">Invoice Received</a></li>			
			 <li><a href="?controller=simplifiedinvoice&action=index&cid=<?php echo $cid; ?>">Simplified Invoice Received</a></li>  
			 <li><a href="?controller=importedgoods&action=index&cid=<?php echo $cid; ?>">Imported Goods</a></li>	
			 <li><a href="?controller=depositpurchase&action=index&cid=<?php echo $cid; ?>">Deposit Paid</a></li>			  
		</ul>	 
	 </li>	  
	 <li><a href="?controller=budget&action=index&cid=<?php echo $cid; ?>">Budget</a></li>	     
	 <li style="text-align:right; float:right;"><a class="drop" href="?controller=companies&action=view&cid=<?php echo $cid; ?>&tag=reports">Reports</a></li>   
	 <li style="text-align:right; float:right;"><a class="drop" href="?controller=companies&action=view&cid=<?php echo $cid; ?>&tag=setup" style="margin-right:8px;">Setup</a></li>   
	  
    </ul>
  </nav>
</div>
<?php
} else if($tag=="reports"){
?>
<div class="row2">
  <nav id="topnav">
    <ul class="clear">    
	  <li><a class="drop" href="#" style="background:#FFFFFF;">Reports :</a></li>   	  
	  <li><a class="drop" href="#">General Ledgers</a>
        <ul>
          <li><a href="?controller=generalledger&action=index&cid=<?php echo $cid; ?>">General Ledger</a></li>
          <li><a href="?controller=gstgeneralledger&action=index&cid=<?php echo $cid; ?>">General Ledger for GST</a></li>  
 <li><a href="?controller=debtorsledger&action=index&cid=<?php echo $cid; ?>">Debtors Ledger</a></li>   
          <li><a href="?controller=creditorsledger&action=index&cid=<?php echo $cid; ?>">Creditors Ledger</a></li>        
        </ul>
      </li>  
	  <li><a class="drop" href="#">Management Reports</a>
        <ul>
          <li><a href="?controller=balancesheet&action=index&cid=<?php echo $cid; ?>">Balance Sheet</a></li>
          <li><a class="drop" href="#">Profit & Loss</a>
			<ul>
			  <li><a href="?controller=profitandlosssummary&action=index&cid=<?php echo $cid; ?>">Profit & Loss Summary</a></li>
			  
			  <li><a href="?controller=budgetandvariance&action=index&cid=<?php echo $cid; ?>">Budget and Variance</a></li>
			           
			</ul>
		  </li>  
		  <li><a href="?controller=trialbalance&action=index&cid=<?php echo $cid; ?>">Trial Balance</a></li>          
        </ul>
      </li>  
	  <li><a class="drop" href="#">Banking Reports</a>
        <ul>          
          <li><a href="?controller=paymentissued&action=index&cid=<?php echo $cid; ?>">Payment Issued</a></li>
          <li><a href="?controller=receivedpayment&action=index&cid=<?php echo $cid; ?>">Payment Received</a></li>
          <li><a href="?controller=ledgerbalance&action=index&cid=<?php echo $cid; ?>">Cash Flow</a></li>	
	  		   
		  <li><a href="?controller=bankreconciliation&action=index&cid=<?php echo $cid; ?>">Bank Reconciliation</a></li>         
        </ul>
      </li>  
	   <li><a class="drop" href="#">Debtors Report</a>
         <ul>
          <li><a href="?controller=debtorsaging&action=index&cid=<?php echo $cid; ?>">Debtors Aging</a></li>
          <li><a href="?controller=debtorsdetailedaging&action=index&cid=<?php echo $cid; ?>">Debtors Detailed Aging</a></li>
          <li><a href="?controller=overduedebtors&action=index&cid=<?php echo $cid; ?>">Outstanding Debtors</a></li>
          <li><a href="?controller=baddebtors&action=index&cid=<?php echo $cid; ?>">Debtors Report > 6 Months</a></li>
		  <li><a href="?controller=statementofaccount&action=index&cid=<?php echo $cid; ?>">Statement of Accounts</a></li>
        </ul>
      </li>
	   <li><a class="drop" href="#">Creditors Report</a>
        <ul>
          <li><a href="?controller=creditorsaging&action=index&cid=<?php echo $cid; ?>">Creditors Aging</a></li>
          <li><a href="?controller=creditorsdetailedaging&action=index&cid=<?php echo $cid; ?>">Creditors Detailed Aging</a></li>
          <li><a href="?controller=overduecreditors&action=index&cid=<?php echo $cid; ?>">Outstanding Creditors</a></li>
          <li><a href="?controller=badcreditors&action=index&cid=<?php echo $cid; ?>">Creditors Report > 6 Months</a></li> 
		  <li><a href="?controller=remittanceadvice&action=index&cid=<?php echo $cid; ?>">Remittance Advice</a></li>          
        </ul>
      </li>
	  
	   <li><a class="drop" href="#">GST Report</a>
        <ul>
          <li><a href="?controller=gafreport&action=index&cid=<?php echo $cid; ?>">GAF Report</a></li>        
          <li><a href="?controller=gstbaddebtsalesadjustment&action=index&cid=<?php echo $cid; ?>">Bad Debt - Sales (AJS)</a></li>	
		  <li><a href="?controller=gstbaddebtpurchaseadjustment&action=index&cid=<?php echo $cid; ?>">Bad Debt - Purchase (AJP)</a></li>	
		  <li><a href="?controller=gstbaddebtapprovedlist&action=index&cid=<?php echo $cid; ?>">Bad Debt Approved List</a></li>	
		  <li><a href="?controller=claimedsalesinvoices&action=index&cid=<?php echo $cid; ?>">Bad Debt Claimed Invoice List</a></li>	
		</ul>
      </li> 
	   <li><a class="drop" href="#" >Other Reports</a>
        <ul>
          <li><a href="?controller=listofexpenses&action=index&cid=<?php echo $cid; ?>">List of Expenses</a></li>
          <li><a href="?controller=topcustomers&action=index&cid=<?php echo $cid; ?>">Top Customers</a></li>
          <li><a href="?controller=topvendors&action=index&cid=<?php echo $cid; ?>">Top Vendors</a></li> 
		  <li><a href="?controller=projects&action=index&cid=<?php echo $cid; ?>">Job/Reference No.</a></li> 
		  <li><a href="?controller=expirycustomers&action=index&cid=<?php echo $cid; ?>">Expiry Customers</a></li> 
		  <li><a href="?controller=ledgerbalance&action=statement&cid=<?php echo $cid; ?>">Cash Flow Statement</a></li>	   
		   <li><a class="drop" href="#" >BA Charts</a>
        <ul>
        	 <li><a href="?controller=budgetandvariancechart&action=index&cid=<?php echo $cid; ?>">Budget and Variance Chart</a></li> 
        	 <li><a href="?controller=comparisonchart&action=index&cid=<?php echo $cid; ?>">Comparison Chart</a></li> 
        </ul>	 
      </li>
        </ul>
       
	  <li><a href="?controller=audittrail&action=index&cid=<?php echo $cid; ?>">Audit Trail</a></li>
	  <li><a href="?controller=stockreports&action=index&cid=<?php echo $cid; ?>">Inventory</a></li>  
	  <!-- <li><a class="drop" href="#" >Consolidated Reports</a>
        <ul>
          <li><a href="?controller=cbalancesheet&action=index&cid=<?php echo $cid; ?>">Balance Sheet</a></li>
          <li><a href="?controller=cprofitandlosssummary&action=index&cid=<?php echo $cid; ?>">Profit & Loss</a></li>
          <li><a href="?controller=ctrialbalance&action=index&cid=<?php echo $cid; ?>">Trial Balance</a></li> 
        </ul>
      </li> -->       
	  <li style="text-align:right; float:right;"><a class="drop" href="?controller=companies&action=view&cid=<?php echo $cid; ?>&tag=entries">Entries</a></li>   
	  <li style="text-align:right; float:right;"><a class="drop" href="?controller=companies&action=view&cid=<?php echo $cid; ?>&tag=setup" style="margin-right:8px;">Setup</a></li>    </ul>
  </nav>
</div>
<?php
} 
?>