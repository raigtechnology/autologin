<?php
  class Receivedpayment {
   
  }
?>