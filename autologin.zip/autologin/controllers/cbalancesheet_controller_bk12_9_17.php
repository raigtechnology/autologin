<?php
  class CbalancesheetController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		/**************************************************************/
		$db = Db::getInstance();		 // db connection
		$cid = $_GET['cid'];             // company_id
		$session_id = $_SESSION['company_id'];
		//$consolidated = $_SESSION['consolidated'];
		
		$usergroup = $db->query("select user_group_id,consolidated from companies where id = '".$cid."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
			$consolidated   = $ug['consolidated'];
		}	
		
		
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}
		
		// same user group companies
		//echo "select id from companies where user_group_id = '".$usergroupid."'";
		$clists = array();
		$clist = $db->query("select id from companies where user_group_id = '".$usergroupid."'");	
		foreach($clist->fetchAll() as $cl) {
			$clists[] 	= $cl['id'];	
		}	
		//echo "<pre>";print_r($clists);
		if($consolidated==1){					
			$id_nums = $clists;
			$cid1 = implode("','", $id_nums);				
		} else {
			$cid1 = $cid;
		}
		
		//echo "TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT".$cid1;exit;
		/**************************************************************/	
		
		$todate = date("Y-m-d");	
		
		$monthfromdate = date("Y-m-01");	
		$monthtodate = date("Y-m-t");	
		
		$yearfromdate = date("Y-01-01");	
		$yeartodate = date("Y-m-t");
		
		$currentyeardate = date("Y-m-d");	
		$lastyear = date("Y",strtotime("-1 year"));
		$lastyeardate = date($lastyear.'-m-d');
		
		//echo "select sc.description, sc.id, sc.code from subcodes as sc  where sc.company_id=".$com_id." order by sc.description asc";
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code from subcodes as sc  where sc.company_id=".$com_id." order by sc.description asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 
		
		/******************* fixed Assets START  ****/
		
		$fixedassets_subcodesList = array();		
		$fixedassets_subcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 4 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY sc.id ASC");		
		foreach($fixedassets_subcodes->fetchAll() as $fasc) {
			$fixedassets_subcodesList[] = $fasc;
		} 		
		
		$fixedassets_Array = array();		
		$si=0;
		foreach($fixedassets_subcodesList as $fascl){
						
			$description = $fascl['description'];						
						
			$fixedassets_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 4 and op.company_id = ".$com_id." and sc.id = '".$fascl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($fixedassets_openingbalance->fetchAll() as $faop) {
				$fixedassets_op_balance = $faop['balance'];
			} 		
						
			$fixedassets_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$fascl['id']."' and mac.account_type_id = 4 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($fixedassets_currentyeargibalance->fetchAll() as $faygi) {
				$fixedassets_currentyearbalance = $faygi['balance'];				
			}
			
			$fixedassets_lastyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$fascl['id']."' and mac.account_type_id = 4 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($fixedassets_lastyeargibalance->fetchAll() as $famgi) {
				$fixedassets_lastyearbalance = $famgi['balance'];				
			}								
			
			$fixedassets_Array[$si]['description'] = $description;
			$fixedassets_Array[$si]['currentyearbalance'] = $fixedassets_op_balance + $fixedassets_currentyearbalance;
			$fixedassets_Array[$si]['lastyearbalance'] = $fixedassets_op_balance + $fixedassets_lastyearbalance;
						
			$si++;	
		}
				
		/******************* fixed assets END  ****/	
		
		
		/******************* Current Assets START  ****/
		
		$currentassets_subcodesList = array();		
		$currentassets_subcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 13 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY  sc.id ASC");		
		foreach($currentassets_subcodes->fetchAll() as $casc) {
			$currentassets_subcodesList[] = $casc;
		} 		
		
		$currentassets_Array = array();		
		$si=0;
		foreach($currentassets_subcodesList as $cascl){
						
			$description = $cascl['description'];						
						
			$currentassets_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 13 and op.company_id = ".$com_id." and sc.id = '".$cascl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($currentassets_openingbalance->fetchAll() as $caop) {
				$currentassets_op_balance = $caop['balance'];
			} 		
						
			$currentassets_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cascl['id']."' and mac.account_type_id = 13 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($currentassets_currentyeargibalance->fetchAll() as $caygi) {
				$currentassets_currentyearbalance = $caygi['balance'];				
			}
			
			$currentassets_lastyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cascl['id']."' and mac.account_type_id = 13 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($currentassets_lastyeargibalance->fetchAll() as $camgi) {
				$currentassets_lastyearbalance = $camgi['balance'];				
			}								
			
			$currentassets_Array[$si]['description'] = $description;
			$currentassets_Array[$si]['currentyearbalance'] = $currentassets_op_balance + $currentassets_currentyearbalance;
			$currentassets_Array[$si]['lastyearbalance'] = $currentassets_op_balance + $currentassets_lastyearbalance;
						
			$si++;	
		}
				
		/******************* current assets END  ****/		
				
		/******************* current liabilities START  ****/
		
		$currentliabilitiessubcodesList = array();		
		$currentliabilitiessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 5 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY  sc.id ASC");		
		foreach($currentliabilitiessubcodes->fetchAll() as $clsc) {
			$currentliabilitiessubcodesList[] = $clsc;
		} 		
		
		$currentliabilitiesArray = array();		
		$csi=0;
		foreach($currentliabilitiessubcodesList as $clcl){
						
			$description = $clcl['description'];					
			
			// opening balance
			$currentliabilities_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 5 and op.company_id = ".$com_id." and sc.id = '".$clcl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($currentliabilities_openingbalance->fetchAll() as $clop) {
				$currentliabilities_op_balance = $clop['balance'];
			} 
			
			$currentliabilities_currentyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$clcl['id']."' and mac.account_type_id = 5 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($currentliabilities_currentyeargibalance->fetchAll() as $clygi) {
				$currentliabilities_currentyearbalance = $clygi['balance'];
			}
			
			$currentliabilities_lastyeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$clcl['id']."' and mac.account_type_id = 5 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($currentliabilities_lastyeargibalance->fetchAll() as $clmgi) {
				$currentliabilities_lastyearbalance = $clmgi['balance'];				
			}
				
			$currentliabilitiesArray[$csi]['description'] = $description;
			$currentliabilitiesArray[$csi]['currentyearbalance'] = $currentliabilities_op_balance + $currentliabilities_currentyearbalance;
			$currentliabilitiesArray[$csi]['lastyearbalance'] = $currentliabilities_op_balance + $currentliabilities_lastyearbalance;
							
			$csi++;
		}		
				
		/******************* current liabilities END  ****/		
		
		/******************* capital START  ****/
		
		$capital_subcodesList = array();		
		$capital_subcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 2 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY  sc.id ASC");		
		foreach($capital_subcodes->fetchAll() as $csc) {
			$capital_subcodesList[] = $csc;
		}				 		
		
		$capital_Array = array();		
		$csi=0;
		foreach($capital_subcodesList as $ccl){
						
			$description = $ccl['description'];					
			
			// opening balance
			$capital__openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 2 and op.company_id = ".$com_id." and sc.id = '".$ccl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($capital__openingbalance->fetchAll() as $eop) {
				$capital__op_balance = $eop['balance'];
			} 	
			
			
			$capital__yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ccl['id']."' and mac.account_type_id = 2 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($capital__yeargibalance->fetchAll() as $eygi) {
				$capital__yearbalance = $eygi['balance'];
			}
			
			$capital__monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ccl['id']."' and mac.account_type_id = 2 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($capital__monthgibalance->fetchAll() as $emgi) {			
				$capital__monthbalance = $emgi['balance'];				
			}							
						
			$capital_Array[$csi]['description'] = $description;
			$capital_Array[$csi]['currentyearbalance'] = $capital__op_balance + $capital__yearbalance;
			$capital_Array[$csi]['lastyearbalance'] = $capital__op_balance + $capital__monthbalance;
			
			$csi++;
		}		
					
		/******************* capital END  ****/	
		
				
				
		/******************* long term liabilities START  ****/
		
		$longtermliabilities_subcodesList = array();		
		$longtermliabilities_subcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 3 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY  sc.id ASC");		
		foreach($longtermliabilities_subcodes->fetchAll() as $esc) {
			$longtermliabilities_subcodesList[] = $esc;
		}				 		
		
		$longtermliabilities_Array = array();		
		$csi=0;
		foreach($longtermliabilities_subcodesList as $ecl){
						
			$description = $ecl['description'];					
			
			// opening balance
			$longtermliabilities__openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 3 and op.company_id = ".$com_id." and sc.id = '".$ecl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($longtermliabilities__openingbalance->fetchAll() as $eop) {
				$longtermliabilities__op_balance = $eop['balance'];
			} 	
			
			
			$longtermliabilities__yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 3 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($longtermliabilities__yeargibalance->fetchAll() as $eygi) {
				$longtermliabilities__yearbalance = $eygi['balance'];
			}
			
			$longtermliabilities__monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 3 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($longtermliabilities__monthgibalance->fetchAll() as $emgi) {			
				$longtermliabilities__monthbalance = $emgi['balance'];				
			}							
						
			$longtermliabilities_Array[$csi]['description'] = $description;
			$longtermliabilities_Array[$csi]['currentyearbalance'] = $longtermliabilities__op_balance + $longtermliabilities__yearbalance;
			$longtermliabilities_Array[$csi]['lastyearbalance'] = $longtermliabilities__op_balance + $longtermliabilities__monthbalance;
			
			$csi++;
		}		
					
		/******************* long term liabilities END  ****/	
		
		
		/******************* SALES START  ****/
		
		$salessubcodesList = array();		
		$salessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY  sc.id ASC");		
		foreach($salessubcodes->fetchAll() as $ssc) {
			$salessubcodesList[] = $ssc;
		} 		
		
		$salesArray = array();		
		$si=0;
		foreach($salessubcodesList as $scl){
						
			$description = $scl['description'];						
						
			$openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and op.company_id = ".$com_id." and sc.id = '".$scl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($openingbalance->fetchAll() as $op) {
				$op_balance = $op['balance'];
			} 		
						
			$sales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_yeargibalance->fetchAll() as $sygi) {
				$sales_yearbalance = $sygi['balance'];				
			}
			
			$sales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_monthgibalance->fetchAll() as $smgi) {
				$sales_monthbalance = $smgi['balance'];				
			}								
			
			$salesArray[$si]['description'] = $description;
			$salesArray[$si]['yearbalance'] = $op_balance + $sales_yearbalance;
			$salesArray[$si]['monthbalance'] = $op_balance + $sales_monthbalance;
						
			$si++;	
		}
				
		/******************* SALES END  ****/		
				
		/******************* COST OF SALES START  ****/
		
		$costofsalessubcodesList = array();		
		$costofsalessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY  sc.id ASC");		
		foreach($costofsalessubcodes->fetchAll() as $cssc) {
			$costofsalessubcodesList[] = $cssc;
		} 		
		
		$costofsalesArray = array();		
		$csi=0;
		foreach($costofsalessubcodesList as $cscl){
						
			$description = $cscl['description'];					
			
			// opening balance
			$costofsales_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and op.company_id = ".$com_id." and sc.id = '".$cscl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($costofsales_openingbalance->fetchAll() as $csop) {
				$costofsales_op_balance = $csop['balance'];
			} 
			
			$costofsales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_yeargibalance->fetchAll() as $csygi) {
				$costofsales_yearbalance = $csygi['balance'];
			}
			
			$costofsales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_monthgibalance->fetchAll() as $csmgi) {
				$costofsales_monthbalance = $csmgi['balance'];				
			}
				
			$costofsalesArray[$csi]['description'] = $description;
			$costofsalesArray[$csi]['yearbalance'] = $costofsales_op_balance + $costofsales_yearbalance;
			$costofsalesArray[$csi]['monthbalance'] = $costofsales_op_balance + $costofsales_monthbalance;
							
			$csi++;
		}		
				
		/******************* COST OF SALES END  ****/		
				
				
		/******************* EXPENSES START  ****/
		
		$expensessubcodesList = array();		
		$expensessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and sc.company_id = ".$com_id." and mac.company_id=".$com_id." ORDER BY  sc.id ASC");		
		foreach($expensessubcodes->fetchAll() as $esc) {
			$expensessubcodesList[] = $esc;
		}				 		
		
		$expensesArray = array();		
		$csi=0;
		foreach($expensessubcodesList as $ecl){
						
			$description = $ecl['description'];					
			
			// opening balance
			$expenses_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and op.company_id = ".$com_id." and sc.id = '".$ecl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($expenses_openingbalance->fetchAll() as $eop) {
				$expenses_op_balance = $eop['balance'];
			} 	
			
			
			$expenses_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$currentyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_yeargibalance->fetchAll() as $eygi) {
				$expenses_yearbalance = $eygi['balance'];
			}
			
			$expenses_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id in('".$cid1."') AND date(je.date) BETWEEN date('1111-11-11') AND date('".$lastyeardate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_monthgibalance->fetchAll() as $emgi) {			
				$expenses_monthbalance = $emgi['balance'];				
			}							
						
			$expensesArray[$csi]['description'] = $description;
			$expensesArray[$csi]['currentyearbalance'] = $expenses_op_balance + $expenses_yearbalance;
			$expensesArray[$csi]['lastyearbalance'] = $expenses_op_balance + $expenses_monthbalance;
			
			$csi++;
		}		
		
				
		/******************* EXPENSES END  ****/			
		
					
		
						  
	  require_once('views/cbalancesheet/index.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/cbalancesheet/error.php');
    }
  }
?>