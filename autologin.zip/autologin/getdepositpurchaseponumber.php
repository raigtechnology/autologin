<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		
	
	$id = $_GET['value1']; 
	$cid = $_GET['cid'];

	$pomaster = $db->query("select distinct(PoNumber) from deposit_purchase where companyID ='".$cid."' and subcode_id='".$id."' group by PoNumber ");
		
	$pom_sales = array();
	foreach($pomaster as $po){	
		$pom_sales[] = $po;		
	}
	?>	
		<select name="ponumber" id="ponumber" class="selectbox_small" required="required">
			<option value="">-- Choose --</option>					
			<?php
		foreach($pom_sales as $pms) {
		?>
		<option value="<?php echo $pms['PoNumber']; ?>"><?php echo $pms['PoNumber']; ?></option>			
		<?php
		}
		?>
		</select>