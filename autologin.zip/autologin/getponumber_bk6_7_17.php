<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		
	
	// sales taxcode master		
	$salestaxcodemasterlist = array();
	$salestaxcodemaster = $db->query("select TaxCode,TaxRate,id from salestaxcodemaster order by TaxCode");	
	foreach($salestaxcodemaster->fetchAll() as $tm) {
		$salestaxcodemasterlist[] = $tm;
	}  	
	
	// currency
	$currencylist = array();
	$currency = $db->query("select * from currency where company_id='".$_GET['cid']."' ");	
	foreach($currency->fetchAll() as $cy) {
		$currencylist[] = $cy;
	}  	
	
	
	
	$accountname = $_GET['value1']; 

	$pomaster = $db->query("select pms.AutoPurchaseID, pms.CustPORef, pms.CurrencyCode, pms.Currencyrate, qms.CustomerID from tblpomaster_sales as pms left join tblquotemaster_sales as qms on qms.AutoQuoationID = pms.QuoteRef where qms.CustomerID = '".$accountname."' and pms.company_id ='".$_GET['cid']."' and qms.company_id ='".$_GET['cid']."' and pms.flag!=1");
		
	$it=0;
	$pom_sales = array();
	foreach($pomaster as $po){	
	
		$pom_sales[$it]['CurrencyCode'] = $po['CurrencyCode'];
		$pom_sales[$it]['Currencyrate'] = $po['Currencyrate'];
		$pom_sales[$it]['CustPORef'] = $po['CustPORef'];
		
			
			
	$it++;
	}
	
	if($it>0){
	
	?>	
		PO Number&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : <select name="po_number" id="po_number" class="selectbox_medium" onchange="showdeposit(this.value,<?php echo $_GET['cid']; ?>)" required="required">
			<option value="">-- Choose --</option>					
			<?php
		foreach($pom_sales as $pms) {
		?>
		<option value="<?php echo $pms['CustPORef']; ?>"><?php echo $pms['CustPORef']; ?></option>			
		<?php
		}
		?>
		</select>
<?php
	} else {
	
		$custs = $db->query("select CompanyName from tblcustomer where AutoCustomerID = '".$accountname."' and company_id='".$_GET['cid']."' ");
		foreach($custs->fetchAll() as $cs){
			$custname 			= $cs['CompanyName'];									
		}	
	
	
		$custid = $db->query("select id from subcodes where description = '".$custname."' and company_id='".$_GET['cid']."' ");
		foreach($custid->fetchAll() as $ct){
			$cust_subid 			= $ct['id'];									
		}	
	
		$referencelist = array();
		$referencenos = $db->query("select distinct(reference_no) from deposit_sales where reference_no!='' and subcode_id = '".$cust_subid."' ");	
		$r=0;
		foreach($referencenos->fetchAll() as $ref) {
			$referencelist[] = $ref;
		$r++;	
		}  	
	
?>
		<table style="border:hidden;" id="salesinvoice_panel3">			
			<tr>
				<td colspan="6" style="border:none;">
				
					<table style="border:hidden;" id="salesinvoice_panel3">
						<tr>
							<th width="8%" align="center">REFERENCE NO</th>
							<th align="center">DESCRIPTION</th>							
							<th width="8%" align="center">CURRENCY</th>							
							<th width="10%" align="center">EXCHANGE RATE</th>
							<th width="5%" align="center">AMOUNT</th>
							<th width="10%" align="center">TAXCODE</th>															
						</tr>			
						<tr>
						    <td align="center">
							<?php
								if($r>0){ 
							?>						
								<select name="reference" id="reference" class="selectbox_small" required="required" onchange="showreferenceno(this.value)">
									<option value="">-- Choose --</option>
									<option value="new">-- New --</option>
									<?php
									foreach($referencelist as $rl){
									?>
										<option value="<?php echo $rl['reference_no'];?>" ><?php echo $rl['reference_no'];?></option>
									<?php
									}
									?>
								</select>
								<span id="referenceno"></span>
								
							<?php
							} else {
							?>
								<input type="text" name="reference_no" id="reference_no" value="" required="required" />
							<?php
							}
							?>
							
							</td>
							<td><input type="text" name="description" id="description" value="" style="width:450px;" required="required" /></td>	
							<td align="center"><select name="currency_code" id="currency_code" class="selectbox_small" required="required" onchange="showexchangerate(this.value,<?php echo $_SESSION['company_id']; ?>)">
									<?php
									foreach($currencylist as $cl){
									?>
										<option value="<?php echo $cl['currency_code'];?>" <?php if($cl['currency_code']=="RM"){?> selected="selected" <?php } ?>><?php echo $cl['currency_code'];?></option>
									<?php
									}
									?>
								</select></td>
								
							<td align="center"><span id="exchangerate">1.00<input type="hidden" name="exchange_rate" id="exchange_rate" style="text-align:right;" class="textbox_small" required="required" value="1.00" /></span></td>	
							<td align="center">
								<input type="text" name="unit_price"  id="unit_price" class="textbox_small" style="text-align:right;" required="required" />
							</td>							
							<td align="center">
							<select name="taxcode" id="taxcode" class="selectbox_small" required="required" >
								<option value="">-- Choose --</option>
								<?php
								foreach($salestaxcodemasterlist as $stcm){
								?>
									<option value="<?php echo $stcm['TaxCode'];?>"><?php echo $stcm['TaxCode'];?></option>
								<?php
								}
								?>
							</select>
							</td>					
							
								<input type="hidden" name="gst" value="" id="total_gst" class="total" style="text-align:right;"  />
								<input type="hidden" name="gst_err" value="" id="total_gst_err" class="total" style="text-align:right;"  />
								<input type="hidden" name="total_amount" value="" id="total_amount" class="total" style="text-align:right;"  />							
						
								
						</tr>			
				  </table>	
				
				</td>
			</tr>
		</table>
	
	
	
<?php
	} 
?>
