<?php
  class depositpurchase {
   
  }
?>