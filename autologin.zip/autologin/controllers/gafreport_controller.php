<?php
  class GafreportController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	     
						
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code, sc.master_account_code_id, sc.subcode_of from subcodes as sc where sc.company_id=".$cid." order by sc.code asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		}	
		
		// master_account_codes
		$master_account_codes_list = array();		
		$master_account_codes = $db->query("select id as mid, account_desc from master_account_codes where company_id=".$cid." order by account_code");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$master_account_codes_list[] = $mac;
		}	
		
		$companiesList = array();		
		$company = $db->query("select cy.company_name, cy.GST_IdNo, cy.Business_Regno from companies as cy where cy.id=".$cid." ");		
		foreach($company->fetchAll() as $co) {
			$companiesList[] = $co;
		}	
		
				
		///////////////////////////////////////////////////////////
						
						  
	  require_once('views/gafreport/index.php'); 
	  
    }	
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
						
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code, sc.master_account_code_id, sc.subcode_of from subcodes as sc where sc.company_id=".$cid." order by sc.code asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		}	
		
		// master_account_codes
		$master_account_codes_list = array();		
		$master_account_codes = $db->query("select id as mid, account_desc from master_account_codes where company_id=".$cid." order by account_code");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$master_account_codes_list[] = $mac;
		}	
		
		$companiesList = array();		
		$company = $db->query("select cy.company_name, cy.GST_IdNo, cy.Business_Regno from companies as cy where cy.id=".$cid." ");		
		foreach($company->fetchAll() as $co) {
			$companiesList[] = $co;
		}	
		
		$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
		$todate = date("Y-m-d", strtotime($_POST['to_date']));
			
			
		$fromdate_sp = date("d/m/Y", strtotime($_POST['from_date']));
		$todate_sp = date("d/m/Y", strtotime($_POST['to_date']));
		
				
		if(isset($_POST['submit'])){
			
			$debtor_id =0;
			$creditor_id =0;			
			
			// opening balance list
			$i=0;
			foreach($subcodesList as $sc){	
			
				$subcodesListss = $db->query("select getOpeningBalance('".$cid."','".$sc['id']."','0','0','null','1111-11-11','".$todate."') as balance, id from subcodes where id='".$sc['id']."' and company_id = '".$cid."' ");					
			
				foreach($subcodesListss->fetchAll() as $ss) {
					$ssid = $ss['id'];
					$ssbalance = $ss['balance'];
				}
				
				$openingbalancelist[$i]['id'] 	   =  $ssid;
				$openingbalancelist[$i]['balance'] =  $ssbalance;
				
			
			$i++;
			}
			
			// gledgers
			$gledgerslist = array();
			$gledgers = $db->query("select jl.subcode_id from journal_entries as jl where jl.date >= '".$fromdate."' AND jl.date <= '".$todate."' AND jl.company_id='".$cid."' ");		
			foreach($gledgers->fetchAll() as $jl) {
				$gledgerslist[] = $jl;
			}
			
			
			$subcodesList1 = $db->query("select id, description, code, master_account_code_id, subcode_of from subcodes where company_id=".$cid." order by code ");				
			foreach($subcodesList1->fetchAll() as $sclist) {
					
				if($sclist['description']=="Trade Debtors"){
					$debtor_id = $sclist['id'];
				} 
				if($sclist['description']=="Trade Creditors"){
					$creditor_id = $sclist['id'];
				} 
			}
			
					
			
			$master_account_codes1 = $db->query("select id as mid, account_desc from master_account_codes where company_id=".$cid." order by account_code");				
			
			foreach($master_account_codes1->fetchAll() as $maclist) {
				
				if($maclist['account_desc']=="CURRENT ASSETS"){
					$currentassetid = $maclist['mid'];
				} 
				if($maclist['account_desc']=="CURRENT LIABILITIES"){
					$currentliabilitiesid = $maclist['mid'];
				} 
				
			}		
			
			// output tax start 
			$outputtaxlist = array();
			$outputtax = $db->query("select
										je.memo,
										je.ref,
										je.date,
										je.gst
									 from
									 	subcodes as sc
										left join journal_entries as je on sc.id = je.subcode_id
										left join tblinvmaster_sales as ms on ms.AutoInvoiceID = je.memo
									where
										ms.Gstinvdate != '' and je.company_id = '".$cid."' and sc.company_id = '".$cid."' and sc.master_account_code_id = '".$currentliabilitiesid."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' 
			");
			
			foreach($outputtax->fetchAll() as $opt) {
				$outputtaxlist[] = $opt;
			}
			// output tax end
		
			// input tax start 
			$inputtaxlist = array();
			$inputtax = $db->query("select
										je.memo,
										je.ref,
										je.date,
										je.gst
									 from
									 	subcodes as sc
										left join journal_entries as je on sc.id = je.subcode_id
										left join tblinvmaster_purchase as mp on mp.InvRef = je.memo
									where
										mp.Gstinvdate != '' and je.company_id = '".$cid."' and sc.company_id = '".$cid."' and sc.master_account_code_id = '".$currentliabilitiesid."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' 
			");
			
			foreach($inputtax->fetchAll() as $ipt) {
				$inputtaxlist[] = $ipt;
			}
				
					// input tax end
			
			// simplified tx start 
			$simplifiedtxlist = array();
			$simplifiedtx = $db->query("select
										je.memo,
										je.ref,
										je.date,
										je.gst,
										je.entry_mode
									 from
									 	subcodes as sc
										left join journal_entries as je on sc.id = je.subcode_id
									where
										je.Gstinvdate != '' and je.company_id = '".$cid."' and sc.company_id = '".$cid."' and je.entry_mode = 'SimplifiedTX' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' 
			");
			
			foreach($simplifiedtx->fetchAll() as $stx) {
				$simplifiedtxlist[] = $stx;
			}
												
			// input tax end
			
					
			
			// simplified bl start 
			$simplifiedbllist = array();
			$simplifiedbl = $db->query("select
										je.memo,
										je.ref,
										je.date,
										je.gst,
										je.entry_mode
									 from
									 	subcodes as sc
										left join journal_entries as je on sc.id = je.subcode_id
									where
										je.Gstinvdate != '' and  je.company_id = '".$cid."' and sc.company_id = '".$cid."' and je.entry_mode = 'SimplifiedBL' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' 
			");
			
			foreach($simplifiedbl->fetchAll() as $sbl) {
				$simplifiedbllist[] = $sbl;
			}
			// input tax end
			
			// es43  
			$es43txlist = array();
			$es43tx = $db->query("select
										es.invoice_no,
										es.invoice_date,
										es.gst
									 from
									 	tbl_es43 as es									
									where
										es.company_id = '".$cid."' and es.invoice_date >= '".$fromdate."' AND es.invoice_date <= '".$todate."' 
			");			
			
			foreach($es43tx->fetchAll() as $tx) {
				$es43txlist[] = $tx;
			}
			
			
			// default data
			
			$defaultdatalist = array();
			$defaultdata = $db->query("select
										je.memo,
										je.ref,
										je.date,
										je.gst,
										je.debit,
										je.credit,
										je.taxcode,
										je.subcode_id
										
									 from
									 	subcodes as sc
										left join journal_entries as je on sc.id = je.subcode_id
										left join tblinvmaster_purchase as mp on mp.InvRef = je.memo
									where
										mp.Gstinvdate !='' and je.company_id = '".$cid."' and je.company_id = '".$cid."' and sc.company_id = '".$cid."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' and sc.description != 'Affin AW Bank' 
					and sc.description != 'Affin Bank'
					and sc.description != 'Agro Bank'
					and sc.description != 'Al Rajhi Bank'
					and sc.description != 'Alliance Bank'
					and sc.description != 'Ambank'
					and sc.description != 'Bangkok Bank'
					and sc.description != 'Bank Islam'
					and sc.description != 'Bank of Tokyo - Mitsubishi'
					and sc.description != 'Cimb Bank'
					and sc.description != 'Citi Bank'
					and sc.description != 'Deutsche Bank'
					and sc.description != 'EON Bank'
					and sc.description != 'EON Islam'
					and sc.description != 'Hong Leong Bank'
					and sc.description != 'HSBC Bank'
					and sc.description != 'Kuwait Finance House'
					and sc.description != 'Maybank'
					and sc.description != 'MayBank Islam'
					and sc.description != 'Muamalat Bank'
					and sc.description != 'OCBC Bank'
					and sc.description != 'Public Bank'
					and sc.description != 'RHB Bank'
					and sc.description != 'Standard Chartered Bank'
					and sc.description != 'United Overseas Bank'
					and je.entry_mode != 'Deposit Purchase'
			");
			
			foreach($defaultdata->fetchAll() as $dt) {
				$defaultdatalist[] = $dt;
			}
		
			// bank data
			
			$bankdatalist = array();
			$bankdata = $db->query("select
										je.memo,
										je.ref,
										je.date,
										je.gst,
										je.debit,
										je.credit,
										je.taxcode,
										je.subcode_id										
									 from
									 	subcodes as sc
										left join journal_entries as je on sc.id = je.subcode_id
										left join tblinvmaster_purchase as mp on mp.InvRef = je.memo
									where
										(mp.Gstinvdate != '' and je.company_id = '".$cid."'	and je.entry_mode != 'Deposit Purchase' and je.date >= '".$fromdate."'	and je.date <= '".$todate."')	OR (sc.description = 'Affin AW Bank' and sc.description = 'Affin Bank' and sc.description = 'Agro Bank'	and sc.description = 'Al Rajhi Bank' and sc.description = 'Alliance Bank' and sc.description = 'Ambank'	and sc.description = 'Bangkok Bank'	and sc.description = 'Bank Islam' and sc.description = 'Bank of Tokyo - Mitsubishi'	and sc.description = 'Cimb Bank'	and sc.description = 'Citi Bank' and sc.description = 'Deutsche Bank' and sc.description = 'EON Bank' and sc.description = 'EON Islam' and sc.description = 'Hong Leong Bank' and sc.description = 'HSBC Bank' and sc.description = 'Kuwait Finance House' and sc.description = 'Maybank' and sc.description = 'MayBank Islam' and sc.description = 'Muamalat Bank' and sc.description = 'OCBC Bank' and sc.description = 'Public Bank' and sc.description = 'RHB Bank' and sc.description = 'Standard Chartered Bank' and sc.description = 'United Overseas Bank')
									
			");
			
			foreach($bankdata->fetchAll() as $bt) {
				$bankdatalist[] = $bt;
			}
					
			
						
			// for sales
			$masterProductSaleslist = array();
			$masterProductSales = $db->query("select tms.*, tps.TaxCode, tps.GSTAmt from tblinvproduct_sales as tps left join tblinvmaster_sales as tms on tms.AutoInvoiceID = tps.AutoInvoiceID where tps.company_id = ".$cid." ");
			foreach($masterProductSales->fetchAll() as $mps) {
				$masterProductSaleslist[] = $mps;
			}	
				
			// // for purchase
			$masterProductPurchaselist = array();
			$masterProductPurchase = $db->query("select tmp.*, tpp.entry_mode, tpp.TaxCodeMatched, tpp.TaxCodePurchase, tpp.GSTamt, tpp.ImptDecNo from tblinvproduct_purchase as tpp left join tblinvmaster_purchase as tmp on tmp.AutoInvoiceID = tpp.AutoInvoiceID where tmp.company_id = ".$cid."");
			foreach($masterProductPurchase->fetchAll() as $mpp) {
				$masterProductPurchaselist[] = $mpp;
			}			
			
			/////////////////////// Purchase ///////////////////////////			
		//C.ImptDecNo !='' AND	
			 $purchase_query = "select 'P' as Record_Identifier, B.Vendor_Name,B.Business_Regno,A.InvDate as InvDate, A.PORef, A.InvRef,A.ImptDecNo as ImpDecNum, '' as LineNum,C.ProductDesc, round((A.Currencyrate * (C.Quantity*C.UnitPrice)),2) as TotalamtLocal, round((A.Currencyrate * (C.GSTamt)),2) as GSTLocal, C.TaxCodeMatched, A.Currencycode, (C.Quantity*C.UnitPrice) as Totalamt, C.GSTamt from tblinvmaster_purchase A Inner JOIN Vendor B on A.VendorName = B.Vendor_Name AND A.company_id = B.company_id Inner join tblinvproduct_purchase C on A.AutoInvoiceID = C.AutoInvoiceID Where A.company_id = '".$cid."' and STR_TO_DATE(A.InvDate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' "; 				 			
			$purchase_query .= " union select 'P' as Record_Identifier, B.Vendor_Name,B.Business_Regno,A.InvDate as InvDate, '' as PORef, A.InvRef, C.ImptDecNo as ImpDecNum, '' as LineNum,C.ProductDesc, round((A.Currencyrate * (C.Quantity*C.UnitPrice)),2) as TotalamtLocal, C.GSTamt as GSTLocal, C.TaxCodeMatched, A.Currencycode, (C.Quantity*C.UnitPrice) as Totalamt, C.GSTamt from tblinvmaster_purchase_rcm A Inner JOIN Vendor B on A.VendorName = B.Vendor_Name AND A.company_id = B.company_id Inner join tblinvproduct_purchase_rcm C on A.AutoInvoiceID = C.AutoInvoiceID Where A.company_id = '".$cid."' AND A.Gstinvdate BETWEEN '".$fromdate."' AND '".$todate."' "; 		
				
			$purchase_query .= " union select 'P' as Record_Identifier,C.Vendor_Name,C.Business_Regno,A.cndate as InvDate, '' as PORef, A.InvoiceID as InvRef, '' as LineNum,A.ProductDesc,-round((B.Currencyrate * (A.Quantity*A.UnitPrice)),2) as TotalamtLocal, -round(B.Currencyrate * A.GSTAmt,2) as GSTLocal ,A.TaxCode,C.Country_Code, B.Currencycode,(A.Quantity*A.UnitPrice) as LocalTotalamt,A.GSTamt from tblinvmaster_Purchase B inner join tblcnproduct_sales A on A.InvoiceID = B.AutoInvoiceID and B.company_id=A.company_id inner JOIN vendor C on C.Vendor_Name = B.VendorName AND B.company_id = C.company_id Where STR_TO_DATE(A.cndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' AND A.type='PURCHASE' AND B.company_id = '".$cid."' AND B.Gstinvdate != '' "; 	
					
			$purchase_query .= " union select 'P' as Record_Identifier,C.Vendor_Name,C.Business_Regno,A.dndate as InvDate, '' as PORef, A.InvoiceID as InvRef, '' as LineNum,A.ProductDesc,round((B.Currencyrate * (A.Quantity*A.UnitPrice)),2) as TotalamtLocal, round(B.Currencyrate * A.GSTAmt,2) as GSTLocal ,A.TaxCode,C.Country_Code, B.Currencycode,(A.Quantity*A.UnitPrice) as LocalTotalamt,A.GSTamt from tblinvmaster_Purchase B inner join tbldnproduct_sales A  on A.InvoiceID = B.AutoInvoiceID and B.company_id=A.company_id inner JOIN  vendor C on C.Vendor_Name = B.VendorName AND B.company_id = C.company_id where STR_TO_DATE(A.dndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' AND A.type='PURCHASE' AND  B.company_id = '".$cid."' AND B.Gstinvdate != '' ";  
			
			$purchase_query .= " union  select 'P' as Record_Identifier, B.Vendor_Name,B.Business_Regno,A.InvDate, '' as PORef, A.InvRef,C.ImptDecNo as ImpDecNum, '' as LineNum,C.ProductDesc, round((A.Currencyrate * (C.Quantity*C.UnitPrice)),2) as TotalamtLocal, round((A.Currencyrate * (C.GSTamt)),2) as GSTLocal, C.TaxCodeMatched, A.Currencycode, (C.Quantity*C.UnitPrice) as Totalamt, C.GSTamt from tblinvmaster_purchase_rcm A Inner JOIN Vendor B on A.VendorName = B.Vendor_Name AND A.company_id = B.company_id Inner join tblinvproduct_purchase_rcm C on A.AutoInvoiceID = C.AutoInvoiceID and C.idbyinv = A.idbyinv Where A.Gstinvdate !='' AND A.company_id = '".$cid."' and STR_TO_DATE(A.Gstinvdate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' ";				
					
			/*$purchase_query .=" union select 'P' as Record_Identifier, sc.description as Vendor_Name, '' as Business_Regno, DATE_FORMAT(je.date,'%d/%m/%Y') as InvDate, je.memo as InvRef, '' as ImpDecNum, 'R' as LineNum, 'Reverse' as ProductDesc, sum(je.debit) as TotalamtLocal, '0' as GSTLocal, 'OP' as TaxCodeMatched, imp.Currencycode as Currencycode, '0' as Totalamt, '0' as GSTamt
from subcodes as sc 
left join journal_entries as je on je.subcode_id = sc.id
left join tblinvmaster_purchase as imp on imp.InvRef = je.memo
 where je.ref in('Outward TT-Debit') and je.subcode_of = '".$creditor_id."' and je.entry_mode='Reverse Charge' and je.company_id=".$cid." and sc.company_id='".$cid."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' ";*/
									
			$purchasedatalist = array();
			$purchasedata =  $db->query($purchase_query);	
			foreach($purchasedata->fetchAll() as $pd) {
				$purchasedatalist[] = $pd;
			}			
					
							
			$purchasecount = count($purchasedatalist);
			
			/***************************************/
			//	Sales 
			/*****************************************/
				
			$sales_query = "select 'S' as Record_Identifier, B.CompanyName,B.Business_Regno,A.InvDate,A.AutoInvoiceID as InvRef, '' as LineNum,C.ProductDesc, round((A.Currencyrate * (C.Quantity*C.UnitPrice)),2) as TotalamtLocal, round((A.Currencyrate * C.GSTamt),2) as GSTLocal,C.TaxCode,B.Country_Code, A.Currencycode, (C.Quantity*C.UnitPrice) as LocalTotalamt, C.GSTAmt from tblinvmaster_sales A inner JOIN tblcustomer B on B.CompanyName = A.VendorName AND A.company_id = B.company_id inner join tblinvproduct_sales C on A.AutoInvoiceID = C.AutoInvoiceID Where A.Gstinvdate !='' AND  STR_TO_DATE(A.InvDate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' AND A.company_id = ".$cid." ";
												
			 /*$sales_query .= " union select 'S' as Record_Identifier, B.Vendor_Name,B.Business_Regno,C.PayDate as InvDate, C.PoNumber as InvRef, '' as LineNum,D.ProductDesc, (C.Currencyrate * C.deposit_amount) as TotalamtLocal, (C.Currencyrate * C.deposit_gst) as  GSTLocal,C.TaxCode,B.Country_Code, A.Currencycode,C.deposit_amount as LocalTotalamt, C.deposit_gst as GSTamt from tblpomaster_sales A Inner join deposit_sales C on A.CustPORef = C.PoNumber inner join vendor B on  C.company_id = B.company_id Inner join tblpoproduct_sales D on A.AutoPurchaseID = D.AutoPurchaseID Where STR_TO_DATE(C.PayDate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' AND C.company_id = ".$cid." ";	  */
			 
			$sales_query .= " union select 'S' as Record_Identifier, TC.CompanyName as CompanyName, TC.Business_Regno as Business_Regno, C.PayDate as InvDate, C.PoNumber as InvRef, '' as LineNum, PD.Productdesc as ProductDesc, (C.Currencyrate * C.deposit_amount) as TotalamtLocal, (C.Currencyrate * C.deposit_gst) as  GSTLocal,C.TaxCode, TC.Country_Code as Country_Code, A.Currencycode,C.deposit_amount as LocalTotalamt, C.deposit_gst as GSTamt from deposit_sales as C left join tblpomaster_sales as A on A.CustPORef = C.PoNumber left join tblquotemaster_sales as Q on Q.AutoQuoationID = A.QuoteRef left JOIN tblcustomer TC on TC.AutoCustomerID = Q.CustomerID left JOIN tblproduct as PD on PD.Productcode = C.Productcode Where STR_TO_DATE(C.PayDate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' AND C.company_id = ".$cid." AND C.PoNumber!='0' and C.deposit_amount!=0 ";
			
			$sales_query .= " union select 'S' as Record_Identifier, TC.CompanyName as CompanyName, TC.Business_Regno as Business_Regno, C.PayDate as InvDate, C.reference_no as InvRef, '' as LineNum, C.description as ProductDesc, C.deposit_amount as TotalamtLocal, C.deposit_gst as  GSTLocal,C.TaxCode, TC.Country_Code as Country_Code, C.currencycode,C.foreign_amount as LocalTotalamt, C.foreign_gst as GSTamt from deposit_sales as C left join tblpomaster_sales as A on A.CustPORef = C.PoNumber left join tblquotemaster_sales as Q on Q.AutoQuoationID = A.QuoteRef left JOIN subcodes SC on SC.id = C.subcode_id left JOIN tblcustomer TC on TC.Customercode = C.customerid   Where STR_TO_DATE(C.PayDate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' AND C.company_id = ".$cid." AND C.PoNumber='0' and C.deposit_amount!=0 ";															
								
			$sales_query .= " union select 'S' as Record_Identifier,C.CompanyName,C.Business_Regno,A.cndate as InvDate, A.InvoiceID as InvRef, '' as LineNum,A.ProductDesc,(B.Currencyrate * (A.Quantity*A.UnitPrice)) as TotalamtLocal, B.Currencyrate * A.GSTAmt as GSTLocal ,A.TaxCode,C.Country_Code, B.Currencycode,(A.Quantity*A.UnitPrice) as LocalTotalamt,A.GSTamt  from tblinvmaster_sales B inner join tblcnproduct_sales A on A.InvoiceID = B.AutoInvoiceID and B.company_id=A.company_id inner JOIN tblcustomer C on C.CompanyName = B.VendorName AND B.company_id = C.company_id Where (STR_TO_DATE(A.cndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."') AND A.type='SALES' AND B.company_id = ".$cid." ";
			
			$sales_query .= " union select 'S' as Record_Identifier,C.CompanyName,C.Business_Regno,A.dndate as InvDate, A.InvoiceID as InvRef, '' as LineNum,A.ProductDesc,round((B.Currencyrate * (A.Quantity*A.UnitPrice)),2) as TotalamtLocal, round(B.Currencyrate * A.GSTAmt,2) as GSTLocal ,A.TaxCode,C.Country_Code,  B.Currencycode,(A.Quantity*A.UnitPrice) as LocalTotalamt,A.GSTamt from tblinvmaster_sales B inner join tbldnproduct_sales A on A.InvoiceID = B.AutoInvoiceID and B.company_id=A.company_id inner JOIN tblcustomer C on C.CompanyName = B.VendorName AND  B.company_id = C.company_id where (STR_TO_DATE(A.dndate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."') AND A.type='SALES' AND B.company_id= ".$cid." ";  		
			
			$sales_query .= " union select 'S' as Record_Identifier, B.CompanyName,B.Business_Regno,A.DueDate as invdate,A.AutoDOID as InvRef, '' as LineNum,C.ProductDesc, round((A.Currencyrate * (C.Quantity*C.UnitPrice)),2) as TotalamtLocal, round((A.Currencyrate * C.GSTAmt),2) as  GSTLocal,C.TaxCode,B.Country_Code, A.Currencycode, (C.Quantity*C.UnitPrice) as LocalTotalamt, C.GSTAmt from tbldomaster_sales A inner JOIN tblcustomer B on B.CompanyName = A.VendorName AND  A.company_id = B.company_id inner join tbldoproduct_sales C on A.AutoDOID = C.AutoDOID Where (STR_TO_DATE(A.duedate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."') AND  A.company_id = ".$cid." ";
			
			$sales_query .= " union select 'S' as Record_Identifier, B.CompanyName,B.Business_Regno,A.InvDate,A.AutoInvoiceID as InvRef, '' as LineNum,C.ProductDesc, round((A.Currencyrate * (C.Quantity*C.UnitPrice)),2) as TotalamtLocal, round((A.Currencyrate * C.GSTamt),2) as GSTLocal,C.TaxCode,B.Country_Code, A.Currencycode, (C.Quantity*C.UnitPrice) as LocalTotalamt, C.GSTAmt from tblinvmaster_sales_rcm A inner JOIN tblcustomer B on B.CompanyName = A.VendorName AND A.company_id = B.company_id inner join tblinvproduct_sales_rcm C on A.AutoInvoiceID = C.AutoInvoiceID and A.idbyinv = C.idbyinv Where STR_TO_DATE(A.Gstinvdate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."' AND A.company_id = ".$cid." ";
		
			// gift rules			
		
			$sales_query .= " union select 'S' as Record_Identifier, sc.description as CompanyName,tc.Business_Regno as Business_Regno, DATE_FORMAT(gr.date,'%d/%m/%Y') as InvDate, gr.description as InvRef, '' as LineNum,'Gift & Promotion' as ProductDesc, '0' as TotalamtLocal, '0' as GSTLocal, gr.taxcode as TaxCode, tc.Country_Code as Country_Code, 'RM' as Currencycode, gr.amount as LocalTotalamt, gr.gst as GSTAmt from gift_rules as gr left join subcodes as sc on sc.id=gr.subcode_id  left join tblcustomer as tc on tc.CompanyName = sc.description where gr.date BETWEEN '".$fromdate."' AND '".$todate."'";	
				
				
			$salesdatalist = array();
			$salesdata =  $db->query($sales_query);	
			foreach($salesdata->fetchAll() as $sd) {
				$salesdatalist[] = $sd;
			}	
			
				
			
		////////////////////////////////////seperate gl////////////////////
		
		$outputtaxdata = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX' and company_id='".$cid."' ");
		foreach($outputtaxdata->fetchAll() as $ot){
			$outputtax_id 			= $ot['id'];									
		}
		
		$inputtaxdata = $db->query("select id from subcodes where description = 'GST-INPUT-TAX' and company_id='".$cid."' ");
		foreach($inputtaxdata->fetchAll() as $ot){
			$inputtax_id 			= $ot['id'];									
		}
		
		$subcodesList_test = array();		
		$subcodes_test = $db->query("select sc.description, sc.id, sc.code from subcodes as sc  where sc.company_id=".$cid." and sc.id not in (select id from subcodes where subcode_of='".$outputtax_id."') and sc.id not in (select id from subcodes where subcode_of='".$inputtax_id."') order by sc.code, sc.description asc");		
		foreach($subcodes_test->fetchAll() as $sc_test) {
			$subcodesList_test[] = $sc_test;
		}
			
		// journal entries
		$journallist_test = array();		
		$journals_test = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									je.debit,
									je.credit,
									je.date,
									je.memo,
									je.ref,
									je.taxcode
								from 
									subcodes as sc
									left join journal_entries as je on je.subcode_id = sc.id																	
								where 
									je.date !='' and je.company_id=".$cid." and sc.company_id='".$cid."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' order by je.date asc");		
		
		foreach($journals_test->fetchAll() as $je_test) {
			$journallist_test[] = $je_test;
		}
				
		
		
		// for gift customer entry
		$journallist_gift = array();		
		$journals_gift = $db->query("select gr.subcode_id as id, 'L' as record_Identifier, gr.gstdate as gstdate, sc.code as code, 'CURRENT ASSETS' as account_name, 'Gift' as ref, sc.description as description, gr.description as transaction_id, gr.description as sourcedocument_id, 'AR' as source_type, round((gr.amount),2) as debit, '0' as credit  from gift_rules as gr left join subcodes as sc on sc.id=gr.subcode_id  left join tblcustomer as tc on tc.CompanyName = sc.description where gr.gstdate BETWEEN '".$fromdate."' AND '".$todate."'");		
		
		foreach($journals_gift->fetchAll() as $je_gift) {
			$journallist_gift[] = $je_gift;
		}
		
		// for gift expenses entry
		
		$giftexpenses = $db->query("select id from subcodes where code = '9000/1515' and company_id='".$cid."' ");
		foreach($giftexpenses->fetchAll() as $ge){
			$gift_expense_id 			= $ge['id'];									
		}
		
		$journallist_gift_expenses = array();		
		$journals_gift_expenses = $db->query("select '".$gift_expense_id."' as id, 'L' as record_Identifier, gr.gstdate as gstdate, sc.code as code, 'EXPENSES' as account_name, 'Gift' as ref, sc.description as description, gr.description as transaction_id, gr.description as sourcedocument_id, 'AR' as source_type, '0' as debit, round((gr.amount),2) as credit from gift_rules as gr left join subcodes as sc on sc.id=gr.subcode_id  where gr.gstdate BETWEEN '".$fromdate."' AND '".$todate."'");		
		
		foreach($journals_gift_expenses->fetchAll() as $je_gift_expenses) {
			$journallist_gift_expenses[] = $je_gift_expenses;
		}
		
		// for gift output tax entry
		
		$giftoutputtax = $db->query("select id from subcodes where code = '4900/1000' and company_id='".$cid."' ");
		foreach($giftoutputtax->fetchAll() as $gt){
			$gift_outputtax_id 			= $gt['id'];									
		}
		
		$journallist_gift_outputtax = array();		
		$journals_gift_outputtax = $db->query("select '".$gift_outputtax_id."' as id, 'L' as record_Identifier, gr.gstdate as gstdate, sc.code as code, 'CURRENT LIABILITIES' as account_name, 'Gift' as ref, sc.description as description, gr.description as transaction_id, gr.description as sourcedocument_id, 'AR' as source_type, '0' as debit, round((gr.gst),2) as credit from gift_rules as gr left join subcodes as sc on sc.id=gr.subcode_id  where gr.gstdate BETWEEN '".$fromdate."' AND '".$todate."'");		
		
		foreach($journals_gift_outputtax->fetchAll() as $je_gift_outputtax) {
			$journallist_gift_outputtax[] = $je_gift_outputtax;
		}
		
						
		
		// for reversechaarge purchase tally
		$journallist_rev = array();		
		$journals_rev = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									je.debit,
									je.credit,
									je.date,
									je.memo,
									je.ref
								from 
									subcodes as sc
									left join journal_entries as je on je.subcode_id = sc.id																	
								where 
									je.ref in('Outward TT-Debit') and je.subcode_of = '".$creditor_id."' and je.entry_mode='Reverse Charge' and je.company_id=".$cid." and sc.company_id='".$cid."' and je.date >= '".$fromdate."' AND je.date <= '".$todate."' order by je.date asc");		
		
		foreach($journals_rev->fetchAll() as $je_rev) {
			$journallist_rev[] = $je_rev;
		}
		
					
			//////////////////////////////////////end//////////////////////////
			
			
			
			
										
		}
		///////////////////////////////////////////////////////////
						
						  
	  require_once('views/gafreport/create.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/gafreport/error.php');
    }
  }
?>