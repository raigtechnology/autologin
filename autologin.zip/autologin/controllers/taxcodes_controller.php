<?php
  class TaxcodesController {
  
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
								
		$taxcodes = $db->query("select taxcode, taxrate, description from taxcodes order by taxcode asc");	
		foreach($taxcodes->fetchAll() as $scm) {
			$taxcodeslist[] = $scm;
		}	
								  
		require_once('views/taxcodes/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/taxcodes/error.php');
    }
  }
?>
