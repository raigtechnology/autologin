<?php
  class manualentries{
   
  }
?>