<?php
  class PurtaxcodemasterController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
						
		$purchasecodemaster = $db->query("select TaxCode, TaxRate, Description, claimable from purtaxcodemaster order by TaxCode asc");	
		foreach($purchasecodemaster->fetchAll() as $pcm) {
			$purchasecodemasterlist[] = $pcm;
		}		
						  
	  require_once('views/purtaxcodemaster/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/purtaxcodemaster/error.php');
    }
  }
?>
