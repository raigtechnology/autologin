<?php
  class gstgeneralledger {
    
  }
?>