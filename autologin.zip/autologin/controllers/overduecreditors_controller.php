<?php
  class OverduecreditorsController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$cid.'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$date = date("Y-m-t");
		
		if(isset($_POST['submit'])){
				
			$date = date("Y-m-d", strtotime($_POST['date']));			
				
			if(empty($date)){
				$date = date("Y-m-d");			
			}				
		
		}			
		
		/*$debtorsoverduelist = array();	
		$debtorsoverdue = $db->query("CALL duePayment('".$cid."', '' ,'creditor', '1111-11-11', '".$todate."')");		
		foreach($debtorsoverdue->fetchAll() as $dod) {
			$debtorsoverduelist[] = $dod;
		}  */		
		
		$debtorsoverduelist = array();	
		$debtorsoverdue = $db->query("select sc.code as subcode, sc.description as subcode_desc, je.date, DATEDIFF('".$date."', je.date) as oDueDays,
			ROUND(SUM(IFNULL(credit,0)) + IFNULL(getOpeningBalance('".$cid."',sc.id,NULL,NULL,'C','1111-11-11',now()),0)
-SUM(IFNULL(debit,0)) + IFNULL(getOpeningBalance('".$cid."',sc.id,NULL,NULL,'D','1111-11-11',now()),0) 
,2) as balance
		from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors' and company_id='".$cid."') and je.date <= DATE('".$date."') group by sc.id order by sc.description asc");		
		foreach($debtorsoverdue->fetchAll() as $dod) {
			$debtorsoverduelist[] = $dod;
		}  	
		
		
		
		
		
		$count = count($debtorsoverduelist);						
		
						  
	  require_once('views/overduecreditors/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/overduecreditors/error.php');
    }
  }
  

?>
