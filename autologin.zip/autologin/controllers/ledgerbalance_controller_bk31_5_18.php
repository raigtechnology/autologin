<?php
  class LedgerbalanceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$cid.'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 	
		
		$fromdate = date("Y-m-01");
		$todate = date("Y-m-d");
		
		if(isset($_POST['submit'])){
				
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));				
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-01");
				$todate = date("Y-m-d");
			}				
		
		}
		
		// BANK LIST
		$banklist = array();
		$id_array =  array();
		$banks = $db->query("select b.id, b.bank_list_id, bl.bank_name, b.account_number from banks as b left join bank_lists as bl on bl.id = b.bank_list_id where b.company_id='".$cid."' and b.subcode_id>0 group by b.bank_list_id ");	
		foreach($banks->fetchAll() as $bl) {
			$banklist[] = $bl;
			
			$id_array[] = $bl['id'];		
		}
		
		$val = implode(",",$id_array); // for bank id's
		
		$cnt = count($id_array);	
							
		if(isset($_POST['bank_list_id'])){		
			
			$bankid = $_POST['bank_id'];			
			
			$id = $_POST['bank_list_id'];
					
			$banksdata = $db->query("select b.id, bl.bank_name, b.bank_branch, b.account_number from banks as b left join bank_lists as bl on bl.id = b.bank_list_id where b.company_id='".$cid."' and b.id='".$id."' ");	
			foreach($banksdata->fetchAll() as $bd) {
				$bankname = $bd['bank_name'];
				$bankbranch = $bd['bank_branch'];
				$accountnumber = $bd['account_number'];
			}  				
		
			if($id>0){
				 $cond = "and tc.BankID=".$id."  ";
			} else {
				
				if($cnt>0){
					$cond = " and tc.BankID in(".$val.") ";
				} else {
					$cond = "";
				}
								
			}
		} else {
			$id=0;
			
			if($cnt>0){
				$cond = " and tc.BankID in(".$val.") ";
			} else {
				$cond = "";
			}
			
			$bankid=0;			
		}	
		
		// for account number
		$banklist_acc = array();
		$banks_acc = $db->query("select b.id, b.bank_list_id, bl.bank_name, b.account_number from banks as b left join bank_lists as bl on bl.id = b.bank_list_id where b.company_id='".$cid."' and b.bank_list_id='".$bankid."' and b.subcode_id>0 ");	
		foreach($banks_acc->fetchAll() as $ac) {
			$banklist_acc[] = $ac;
		}  	
		
	// first time only			
		$banklist_acc1 = array();
		$banks_acc1 = $db->query("select b.id, b.bank_list_id, bl.bank_name, b.account_number from banks as b left join bank_lists as bl on bl.id = b.bank_list_id where b.company_id='".$cid."' and b.subcode_id>0 ");	
		foreach($banks_acc1->fetchAll() as $ac1) {
			$banklist_acc1[] = $ac1;
		}  	
				
										
		// journal entries
		$tblchequelist = array();		
		$tblcheque = $db->query("select 
									tc.CheqDate,
									tc.CheqNO,
									tc.CheqType,									
									tc.Payee,
									tc.PVNO,
									tc.Description,
									tc.Amount
								from 									
									tblcheque as tc
								where 
									tc.company_id=".$cid." and tc.CheqType!='CManual' and tc.CheqType!='CPrint' and tc.CheqType!='CDeposit' and tc.CheqDate >= '".$fromdate."' AND tc.CheqDate <= '".$todate."' ".$cond." order by tc.CheqDate asc");		
		
						
		foreach($tblcheque->fetchAll() as $je) {
			$tblchequelist[] = $je;
		} 	
		
					
		
		/////  for opeing balance/**********************************************/
		
		
		// opeing balance
				
		if($id>0){
			
			
			$openingbalance=0;
			$opeingbal = $db->query("select Amount from tblledger where company_id=".$cid." and BankID=".$id."  and CheqDate >= '".$fromdate."' AND CheqDate <= '".$todate."' ");		
										
			foreach($opeingbal->fetchAll() as $op) {
				$openingbalance = $op['Amount'];
			} 
			
			
		} else {
		
			$openingbalance=0;
			$opeingbal = $db->query("select sum(Amount) as Amount from tblledger where company_id=".$cid." and CheqDate >= '".$fromdate."' AND CheqDate <= '".$todate."' ");		
										
			foreach($opeingbal->fetchAll() as $op) {
				$openingbalance = $op['Amount'];
			} 
						
		}
					
		
		if($openingbalance>0 || $openingbalance<0){
			$openingbalance = $openingbalance;
			$lastyearbalance = $openingbalance;		
	
		} else {

			$openingbalance1=0;
			
			if($id>0){
				$opeingbal1 = $db->query("select Amount, cheqDate from tblledger where company_id=".$cid." and BankID=".$id." and CheqDate >= '1111-11-11' AND CheqDate <= '".$todate."' ");		
			} else {
				$opeingbal1 = $db->query("select sum(Amount) as Amount, cheqDate from tblledger where company_id=".$cid." and CheqDate >= '1111-11-11' AND CheqDate <= '".$todate."' ");		
			}
			
			
			
						
			foreach($opeingbal1->fetchAll() as $op1) {
				$openingbalance1 = $op1['Amount'];
				$fromdate_op = date("Y-m-d", strtotime($op1['cheqDate']));

			} 
			
			$openingbalance = $openingbalance1;	
	

			$prev_date = date('Y-m-d', strtotime($fromdate .' -1 day'));		
							
			$tblchequelist_forop = array();		
			$tblcheque_forop = $db->query("select 
									tc.CheqDate,
									tc.CheqNO,
									tc.CheqType,									
									tc.Payee,
									tc.PVNO,
									tc.Description,
									tc.Amount
								from 									
									tblcheque as tc
								where 
									tc.company_id=".$cid." and tc.CheqType!='CManual' and tc.CheqType!='CPrint' and tc.CheqType!='CDeposit' and tc.CheqDate >= '".$fromdate_op."' AND tc.CheqDate <= '".$prev_date."' ".$cond." order by tc.CheqDate asc");	
			
			
						
			foreach($tblcheque_forop->fetchAll() as $je_forop) {
				$tblchequelist_forop[] = $je_forop;
			} 		
		

				
		
			$total_forop=0;
			$paid_amount_forop=0;
			$received_amount_forop=0;
			$paidtotal_forop = 0;	
			$receivedtotal_forop = 0;
		
			$i=0;
			foreach($tblchequelist_forop as $tc_forop){
		
					
				$cheqtype_forop = $tc_forop['CheqType'];
					
				if($cheqtype_forop=="Print" || $cheqtype_forop=="Online" || $cheqtype_forop=="Manual" || $cheqtype_forop=="TO" || $cheqtype_forop=="BO"){
					$paid_amount_forop = $tc_forop['Amount'];
				}
									
					
				if($cheqtype_forop=="ODeposit" || $cheqtype_forop=="Deposit" || $cheqtype_forop=="CI" || $cheqtype_forop=="KI" || $cheqtype_forop=="TI" || $cheqtype_forop=="CashinPaid"){
													
					$received_amount_forop = $tc_forop['Amount'];
				}
											
						
				$total_forop += $tc_forop['Amount'];	
				
				$paidtotal_forop += $paid_amount_forop;	
				$receivedtotal_forop += $received_amount_forop;						
							
				$paid_amount_forop=0;
				$received_amount_forop=0;
				
			$i++;
			}	
			//echo $paidtotal_forop1;		
	
	
			$lastyearbalance = $receivedtotal_forop - $paidtotal_forop;
	
			$lastyearbalance = $openingbalance + $lastyearbalance;	
		
			//$balance_forop = $receivedtotal_forop - $paidtotal_forop;
			//$balance_forop = $openingbalance - $paidtotal_forop;
		}

		
		
		
		// last year closing balance
		
		/**************************************************************************************/
		
		
						  
	  require_once('views/ledgerbalance/index.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/ledgerbalance/error.php');
    }
  }
?>