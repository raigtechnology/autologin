<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		
	
	$branch_id		= $_GET['branch_id']; 	
	$department_id = $_GET['department_id']; 
	$designation_id = $_GET['designation_id']; 
	$cid = $_GET['cid'];
	
	$employees = $db->query("SELECT em.id, em.employee_code, em.full_name, em.date_of_joining, pc.profit_center, dm.department_name, dgm.designation_name FROM employee_master AS em								
								 LEFT JOIN profit_centers as pc on pc.id = em.branch_id
								 LEFT JOIN department_master as dm on dm.id = em.department_id
								 LEFT JOIN designation_master as dgm on dgm.id = em.designation_id where em.branch_id = '".$branch_id."' and em.department_id = '".$department_id."' and em.designation_id = '".$designation_id."' and em.company_id='".$cid."' ");						
	
	
	
	?>			
	<table cellpadding="0" cellspacing="0" id="salesinvoice_panel">
			<tr>
				<th width="4%">Select</th>
				<th width="10%">Employee Code</th>
				<th>Employee Full Name</th>
				<th width="10%" align="right">Amount</th>
				<th width="30%">Remark</th>
			</tr>
			<?php
			$i=0;					
			foreach($employees->fetchAll() as $el) {
			?>
			<tr>
				<td><input type="checkbox"  class="checkbox<?php echo $i; ?>" value="1" name="data[<?php echo $i; ?>][chk]" /></td>				
				<td align="left"><input type="hidden" name="data[<?php echo $i; ?>][employee_id]" value="<?php echo $el['id']; ?>" /><?php echo $el['employee_code']; ?></td>
				<td align="left"><?php echo $el['full_name']; ?></td>		
				<td align="left"><input type="text" name="data[<?php echo $i; ?>][increment_amount]" style="text-align:right;width:100%;"/></td>	
				<td align="left"><input type="text" name="data[<?php echo $i; ?>][remark]" style="width:100%;" /></td>					
			</tr>
			<?php
			$i++;
			}	
			?>	
		</table>
	
