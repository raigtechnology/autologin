<?php require_once 'pdf/dompdf_config.inc.php';
 
 
$htmlString = '';
ob_start();
//include('index.html');

$filename = $_POST['filename'];

$htmlString .= ob_get_clean(); 
$htmlString .=$_POST['pdf_data']; 
$dompdf = new DOMPDF();
$dompdf->load_html($htmlString);
$dompdf->render();
$dompdf->stream($filename.".pdf");

?>