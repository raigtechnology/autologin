<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

  class ProfitandlossController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 	
		
		
		$todate = date("Y-m-d");	
		
		$monthfromdate = date("Y-m-01");	
		$monthtodate = date("Y-m-t");	
		
		$yearfromdate = date("Y-01-01");	
		$yeartodate = date("Y-m-t");	
		
		
		if(isset($_POST['submit'])){
		
			$todate = date("Y-m-d");	
		
			$monthfromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$monthtodate = date("Y-m-d", strtotime($_POST['to_date']));;	
			$profit_center_id = $_POST['profit_center_id']; 
			$year = date("Y", strtotime($_POST['from_date']));
			
			$yearfromdate = date($year."-01-01");	
			$yeartodate = date($monthtodate);	
		
			$profitcenter = " AND je.profit_center_id=".$profit_center_id." ";
			
			$profitcenterbudget = " AND b.profit_center_id=".$profit_center_id." ";
		
		}
		
				
				$previousdate = date('Y-m-d', strtotime('-1 day', strtotime($monthfromdate)));  
					
					
					// for gst 					
					$gstbalance = $db->query("SELECT aa.AdjustmentRecovered as balance, aa.TaxCode FROM annualadjustment as aa WHERE aa.company_id = ".$cid." AND STR_TO_DATE(aa.PeriodTo,'%d/%m/%Y') BETWEEN '1111-11-11' AND '".$previousdate."' ");								
								
					foreach($gstbalance->fetchAll() as $gs) {
						 
						 if($gs['TaxCode']=="AJS"){
						 	 $gst_balance1 = -abs($gs['balance']);				
						 } else  if($gs['TaxCode']=="AJP"){
						 	 $gst_balance2 = $gs['balance'];				
						 } 
						 
						 $gsttaxcode = $gs['TaxCode'];
					}	
		
				
		
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code from subcodes as sc  where sc.company_id=".$cid." order by sc.description asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 
		
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
		/******************* SALES START  ****/
		
		$salessubcodesList = array();		
		$salessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($salessubcodes->fetchAll() as $ssc) {
			$salessubcodesList[] = $ssc;
		} 		
		
		$salesArray = array();		
		$si=0;
		foreach($salessubcodesList as $scl){
						
			
						
			$description = $scl['description'];						
						
			$openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 6 and op.company_id = ".$cid." and sc.id = '".$scl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($openingbalance->fetchAll() as $op) {
				$op_balance = $op['balance'];
			} 		
						
			$sales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_yeargibalance->fetchAll() as $sygi) {
				$sales_yearbalance = $sygi['balance'];	
			}
			
			
			$sales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($sales_monthgibalance->fetchAll() as $smgi) {
				$sales_monthbalance = $smgi['balance'];						
			}	
			
			
			$sales_monthbudgetbalance = $db->query("SELECT sum(b.budget_value) as budget from budgets as b left join subcodes as sc on sc.id = b.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE b.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and b.company_id = ".$cid." ".$profitcenterbudget." AND date(b.from_date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY b.subcode_id ASC");		
			foreach($sales_monthbudgetbalance->fetchAll() as $smbi) {			
				 $sales_monthbudget = $smbi['budget'];			
			}	
			
			$sales_yearbudgetbalance = $db->query("SELECT sum(b.budget_value) as budget from budgets as b left join subcodes as sc on sc.id = b.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE b.subcode_id = '".$scl['id']."' and mac.account_type_id = 6 and b.company_id = ".$cid." ".$profitcenterbudget." AND date(b.from_date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY b.subcode_id ASC");		
			foreach($sales_yearbudgetbalance->fetchAll() as $sybi) {			
				 $sales_yearbudget = $sybi['budget'];			
			}	
			
			
													
			
			$salesArray[$si]['description'] = $description;
			$salesArray[$si]['yearbalance'] = $op_balance + $sales_yearbalance;
			$salesArray[$si]['monthbalance'] = $op_balance + $sales_monthbalance;
			$salesArray[$si]['yearbudget'] = $sales_yearbudget;
			$salesArray[$si]['monthbudget'] = $sales_monthbudget;
						
			$si++;	
		}
				
		/******************* SALES END  ****/		
				
		/******************* COST OF SALES START  ****/
		
		$costofsalessubcodesList = array();		
		$costofsalessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($costofsalessubcodes->fetchAll() as $cssc) {
			$costofsalessubcodesList[] = $cssc;
		} 		
		
		$costofsalesArray = array();		
		$csi=0;
		foreach($costofsalessubcodesList as $cscl){
						
			$description = $cscl['description'];					
			
			// opening balance
			$costofsales_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 7 and op.company_id = ".$cid." and sc.id = '".$cscl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($costofsales_openingbalance->fetchAll() as $csop) {
				$costofsales_op_balance = $csop['balance'];
			} 
			
			$costofsales_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_yeargibalance->fetchAll() as $csygi) {
				$costofsales_yearbalance = $csygi['balance'];
			}
			
			$costofsales_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($costofsales_monthgibalance->fetchAll() as $csmgi) {
				$costofsales_monthbalance = $csmgi['balance'];				
			}
			
			
			$costofsales_monthbudgetbalance = $db->query("SELECT sum(b.budget_value) as budget from budgets as b left join subcodes as sc on sc.id = b.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE b.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and b.company_id = ".$cid." ".$profitcenterbudget." AND date(b.from_date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY b.subcode_id ASC");		
			foreach($costofsales_monthbudgetbalance->fetchAll() as $smbi) {			
				$costofsales_monthbudget = $smbi['budget'];			
			}			
						
			
			$costofsales_yearbudgetbalance = $db->query("SELECT sum(b.budget_value) as budget from budgets as b left join subcodes as sc on sc.id = b.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE b.subcode_id = '".$cscl['id']."' and mac.account_type_id = 7 and b.company_id = ".$cid." ".$profitcenterbudget." AND date(b.from_date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY b.subcode_id ASC");		
			foreach($costofsales_yearbudgetbalance->fetchAll() as $sybi) {			
				 $costofsales_yearbudget = $sybi['budget'];			
			}	
						
				
			$costofsalesArray[$csi]['description'] = $description;
			$costofsalesArray[$csi]['yearbalance'] = $costofsales_op_balance + $costofsales_yearbalance;
			$costofsalesArray[$csi]['monthbalance'] = $costofsales_op_balance + $costofsales_monthbalance;
			$costofsalesArray[$csi]['yearbudget'] = $costofsales_yearbudget;
			$costofsalesArray[$csi]['monthbudget'] = $costofsales_monthbudget;
			
							
			$csi++;
		}	
				
				
		/******************* COST OF SALES END  ****/		
				
				
		/******************* EXPENSES START  ****/
		
		$expensessubcodesList = array();		
		$expensessubcodes = $db->query("SELECT sc.id, sc.description FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");		
		foreach($expensessubcodes->fetchAll() as $esc) {
			$expensessubcodesList[] = $esc;
		}				 		
		
		$expensesArray = array();		
		$csi=0;
		foreach($expensessubcodesList as $ecl){
						
			$description = $ecl['description'];					
			
			// opening balance
			$expenses_openingbalance = $db->query("SELECT sum(op.debit)-sum(op.credit) as balance FROM opening_balance as op left join subcodes as sc on sc.id = op.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = 12 and op.company_id = ".$cid." and sc.id = '".$ecl['id']."'  ORDER BY `op`.`subcode_id` ASC");		
			foreach($expenses_openingbalance->fetchAll() as $eop) {
				$expenses_op_balance = $eop['balance'];
			} 	
			
			
			$expenses_yeargibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_yeargibalance->fetchAll() as $eygi) {
				$expenses_yearbalance = $eygi['balance'];
			}
			
			$expenses_monthgibalance = $db->query("SELECT sum(je.debit)-sum(je.credit) as balance, sc.description FROM journal_entries as je left join subcodes as sc on sc.id = je.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE je.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and je.company_id = ".$cid." ".$profitcenter." AND date(je.date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY je.subcode_id ASC");		
			foreach($expenses_monthgibalance->fetchAll() as $emgi) {			
				$expenses_monthbalance = $emgi['balance'];				
			}							
				
			
			$expenses_monthbudgetbalance = $db->query("SELECT sum(b.budget_value) as budget from budgets as b left join subcodes as sc on sc.id = b.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE b.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and b.company_id = ".$cid." ".$profitcenterbudget." AND date(b.from_date) BETWEEN date('".$monthfromdate."') AND date('".$monthtodate."') ORDER BY b.subcode_id ASC");		
			foreach($expenses_monthbudgetbalance->fetchAll() as $smbi) {			
				$expenses_monthbudget = $smbi['budget'];			
			}			
						
			
			$expenses_yearbudgetbalance = $db->query("SELECT sum(b.budget_value) as budget from budgets as b left join subcodes as sc on sc.id = b.subcode_id left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE b.subcode_id = '".$ecl['id']."' and mac.account_type_id = 12 and b.company_id = ".$cid." ".$profitcenterbudget." AND date(b.from_date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ORDER BY b.subcode_id ASC");		
			foreach($expenses_yearbudgetbalance->fetchAll() as $sybi) {			
				 $expenses_yearbudget = $sybi['budget'];			
			}	
				
				
						
			$expensesArray[$csi]['description'] = $description;
			$expensesArray[$csi]['yearbalance'] = $expenses_op_balance + $expenses_yearbalance;
			$expensesArray[$csi]['monthbalance'] = $expenses_op_balance + $expenses_monthbalance;			
			$expensesArray[$csi]['yearbudget'] = $expenses_yearbudget;
			$expensesArray[$csi]['monthbudget'] = $expenses_monthbudget;
			
			
			$csi++;
		}		
			
				
		/******************* EXPENSES END  ****/				
		
		/******************* Current Assets START  ****/
		$master_account_codes1 = $db->query("select id as mid, account_desc from master_account_codes where company_id=".$cid." order by account_code");				
		
		foreach($master_account_codes1->fetchAll() as $maclist) {
			
			if($maclist['account_desc']=="CURRENT ASSETS"){
				$currentassetid = $maclist['mid'];
			} 
			if($maclist['account_desc']=="CURRENT LIABILITIES"){
				$currentliabilitiesid = $maclist['mid'];
			} 
			
		}		
		
		// for output tax
		/*$subcodesList = array();		
		$subcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$currentassetid."'
									and sc.subcode_of in (select id from subcodes where description ='GST-OUTPUT-TAX')
								order by sc.code asc");	
									
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		}	
				
		// for sales tax codes
		$salestaxlist_year = array();
		$salestax_year = $db->query("select je.memo, je.debit, je.credit, je.gst, je.taxcode, je.date from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." and je.taxcode!='' and je.date >= '".$yearfromdate."' AND je.date <= '".$yeartodate."' order by je.memo,je.date ");
		
		foreach($salestax_year->fetchAll() as $st_year) {
			$salestaxlist_year[] = $st_year;
		}		
		
		// month
		$salestaxlist_month = array();
		$salestax_month = $db->query("select je.memo, je.debit, je.credit, je.gst, je.taxcode, je.date from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." and je.taxcode!='' and je.date >= '".$monthfromdate."' AND je.date <= '".$monthtodate."' order by je.memo,je.date ");
		
		foreach($salestax_month->fetchAll() as $st_month) {
			$salestaxlist_month[] = $st_month;
		}		
			
				
		$totgst_year=0;	
		$gst_year=0;	
		$gst_month=0;	
		$totgst_month=0;
		foreach($subcodesList as $sc){					
			
			$description  = $sc['description'];
			$desc = explode("-", $description);
			$tax = $desc[3];			
			
			// year wise				
			foreach($salestaxlist_year as $ta_year){											
				$taxcode_year = $ta_year['taxcode'];
				
				if($tax==$taxcode_year){			
					$gst_year	 = $ta_year['gst'];																		
					$totgst_year += $gst_year;
				}
			}	
			
			// month wise
			foreach($salestaxlist_month as $ta_month){											
				$taxcode_month = $ta_month['taxcode'];
				
				if($tax==$taxcode_month){			
					$gst_month	 = $ta_month['gst'];																		
					$totgst_month += $gst_month;
				}
			}	
			
			
		}
			
		$outputtax_year = $totgst_year;	
		$outputtax_month = $totgst_month;	
				*/
				
		// for output tax
		$subcodesList = array();		
		$subcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$currentassetid."'
									and sc.subcode_of in (select id from subcodes where description ='GST-OUTPUT-TAX')
								order by sc.code asc");	
									
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		}	
				
		// for sales tax codes
		$outputtaxdata = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX' and company_id='".$cid."' ");
		foreach($outputtaxdata->fetchAll() as $ot){
			$outputtax_id 			= $ot['id'];									
		}
		
				
		// for sales tax codes
				
		$salestax_year = $db->query("select sum(credit) as credit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." ".$profitcenter." and je.subcode_id ='".$outputtax_id."' and STR_TO_DATE(je.date,'%Y-%m-%d') BETWEEN '1111-11-11' AND '".$yeartodate."' order by je.memo,je.date ");
				
		foreach($salestax_year->fetchAll() as $st_year) {
			$outputtax_year = $st_year['credit'];
		}	
		
		if($gsttaxcode=="AJS"){
			$outputtax_year = $outputtax_year + $gst_balance1;
		} 
		
				
		// month		
		$salestax_month = $db->query("select sum(credit) as credit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." ".$profitcenter." and je.subcode_id='".$outputtax_id."' and je.date >= '".$monthfromdate."' AND je.date <= '".$monthtodate."' order by je.memo,je.date ");
		
		foreach($salestax_month->fetchAll() as $st_month) {
			$outputtax_month = $st_month['credit'];
		}				
				
				
		/*// for input tax		
		$psubcodesList = array();		
		$psubcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$currentliabilitiesid."'
									and sc.subcode_of in (select id from subcodes where description ='GST-INPUT-TAX')
								order by sc.code asc");	
									
		foreach($psubcodes->fetchAll() as $psc) {
			$psubcodesList[] = $psc;
		}	
				
		// for sales tax codes
		// for purchase tax codes
		$purchasetaxlist_year = array();
		$purchasetax_year = $db->query("select je.memo, je.debit, je.credit, je.gst, je.taxcode, je.date from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." and je.taxcode!='' and je.date >= '".$yearfromdate."' AND je.date <= '".$yeartodate."' order by je.memo,je.date ");
		
		foreach($purchasetax_year->fetchAll() as $pt_year) {
			$purchasetaxlist_year[] = $pt_year;
		}			
		
		// month wise
		$purchasetaxlist_month = array();
		$purchasetax_month = $db->query("select je.memo, je.debit, je.credit, je.gst, je.taxcode, je.date from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  where je.company_id =".$cid." and je.taxcode!='' and je.date >= '".$monthfromdate."' AND je.date <= '".$monthtodate."' order by je.memo,je.date ");
		
		foreach($purchasetax_month->fetchAll() as $pt_month) {
			$purchasetaxlist_month[] = $pt_month;
		}	
						
		$totgst1=0;	
		$totgst1_year=0;	
		$totgst1_month=0;	
		foreach($psubcodesList as $pc){					
			
			$description1  = $pc['description'];
			$desc1 = explode("-", $description1);
			$tax1 = $desc1[3];			
				
			foreach($purchasetaxlist_year as $pa_year){											
				$taxcode1_year = $pa_year['taxcode'];
				
				if($tax1==$taxcode1_year){			
					$gst1_year	 = $pa_year['gst'];																		
					$totgst1_year += $gst1_year;
				}
			}	
			
			// month wise
			foreach($purchasetaxlist_month as $pa_month){											
				$taxcode1_month = $pa_month['taxcode'];
				
				if($tax1==$taxcode1_month){			
					$gst1_month	 = $pa_month['gst'];																		
					$totgst1_month += $gst1_month;
				}
			}	
			
		}
			
		$inputtax_year = $totgst1_year;		
		$inputtax_month = $totgst1_month;		*/
			
		// for input tax		
		$psubcodesList = array();		
		$psubcodes = $db->query("select 
									sc.description,
									sc.id,
									sc.code,
									sc.master_account_code_id,
									sc.subcode_of
								from
									subcodes as sc 
								where 
									sc.company_id=".$cid."
									and sc.master_account_code_id = '".$currentliabilitiesid."'
									and sc.subcode_of in (select id from subcodes where description ='GST-INPUT-TAX')
								order by sc.code asc");	
									
		foreach($psubcodes->fetchAll() as $psc) {
			$psubcodesList[] = $psc;
		}	
				
		// for sales tax codes
		$inputtaxdata = $db->query("select id from subcodes where description = 'GST-INPUT-TAX' and company_id='".$cid."' ");
		foreach($inputtaxdata->fetchAll() as $ot){
			$inputtax_id 			= $ot['id'];									
		}
		
		// for purchase tax codes
		$purchasetax_year = $db->query("select sum(debit) as debit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." ".$profitcenter." and je.subcode_id='".$inputtax_id."' and je.date >= '1111-11-11' AND je.date <= '".$yeartodate."' order by je.memo,je.date ");
		
		foreach($purchasetax_year->fetchAll() as $pt_year) {
			$inputtax_year = $pt_year['debit'];
		}	
		
		if($gsttaxcode=="AJP"){
			$inputtax_year = $inputtax_year + $gst_balance2;
		} 
		
		
		/*$purchasetax_year_bl = $db->query("select sum(gst) as gst from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." and je.taxcode='BL' and je.date >= '1111-11-11' AND je.date <= '".$yeartodate."' order by je.memo,je.date ");
		
		foreach($purchasetax_year_bl->fetchAll() as $pt_year_bl) {
			$inputtax_year_bl = $pt_year_bl['gst'];
		}	*/
				
		
		// month wise		
		$purchasetax_month = $db->query("select sum(debit) as debit from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id where je.company_id =".$cid." ".$profitcenter." and je.subcode_id='".$inputtax_id."' and je.date >= '".$monthfromdate."' AND je.date <= '".$monthtodate."' order by je.memo,je.date ");
		
		foreach($purchasetax_month->fetchAll() as $pt_month) {
			$inputtax_month = $pt_month['debit'];
		}			
						
		/******************* current assets END  ****/		
		
						  
	  require_once('views/profitandloss/index.php'); 
	  
    }		
	

    public function error() {
      require_once('views/profitandloss/error.php');
    }
  }
?>
