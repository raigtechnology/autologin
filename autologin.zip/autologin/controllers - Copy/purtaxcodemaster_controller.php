<?php
  class PurtaxcodemasterController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
						
		$purchasecodemaster = $db->query("select TaxCode, TaxRate, Description, claimable from purtaxcodemaster order by TaxCode asc");	
		foreach($purchasecodemaster->fetchAll() as $pcm) {
			$purchasecodemasterlist[] = $pcm;
		}		
						  
	  require_once('views/purtaxcodemaster/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/purtaxcodemaster/error.php');
    }
  }
?>