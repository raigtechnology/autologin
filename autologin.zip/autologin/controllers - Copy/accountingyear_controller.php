<?php
  class AccountingyearController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
				
		$cid = $_GET['cid']; // companyid
		
		$accountingyearlist = array();				
		$accountingyear = $db->query("select id, ls_yr_closing_date, current_yr_from_date, current_yr_to_date from accounting_year where company_id='".$cid."' ");	
		foreach($accountingyear->fetchAll() as $ay) {
			$accountingyearlist[] = $ay;
		}  		
				
						  
	  require_once('views/accountingyear/index.php'); 
	  
    }	
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // companyid
		
		$aylcd="";		
		$aytoderror="";		
		$aytcderror="";	
		
		$ls_yr_closing_date="";	
		$current_yr_from_date="";	
		$current_yr_to_date="";
		
		
		if(isset($_POST['create'])){
				
			$ls_yr_closing_date		= $_POST['ls_yr_closing_date'];
			$current_yr_from_date	= $_POST['current_yr_from_date'];
			$current_yr_to_date		= $_POST['current_yr_to_date'];		
			
			if($ls_yr_closing_date==""){
				$aylcd = "Please enter last year closing datre";							 						
			} 
			if($current_yr_from_date==""){
				$aytoderror = "Please enter this year opening date ";			 							
			} 
			if($current_yr_to_date==""){
				$aytcderror = "Please enter this year closing date";			 					
			} 
			
			
			if($aylcd!="" || $aytoderror!="" || $aytcderror!="" ){
				require_once('views/accountingyear/create.php'); 	 
			}	
									
			$ls_yr_closing_date 	= date("Y-m-d", strtotime($ls_yr_closing_date));	
			$current_yr_from_date   = date("Y-m-d", strtotime($current_yr_from_date));	
			$current_yr_to_date     = date("Y-m-d", strtotime($current_yr_to_date));	
			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
			
							
			// insert query
			$result = $db->query("insert into accounting_year(company_id, ls_yr_closing_date, current_yr_from_date, current_yr_to_date, created_by, created_ip, created) values ('".$cid."', '".$ls_yr_closing_date."', '".$current_yr_from_date."', '".$current_yr_to_date."', '".$created_by."', '".$created_ip."', '".$created."') ");		
						
			if(!$result){
				die('Invalid query: ' . mysql_error());
			}
			header("Location: ?controller=accountingyear&action=index&cid=".$cid."");		
					
		} else {	 
		   require_once('views/accountingyear/create.php'); 	   
		}  
	  
    }		
	
	public function edit() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();
		
		$id = $_GET['id'];
		$cid = $_GET['cid'];		
				    
		$accountingyearlist = array();		
		$accountingyear = $db->query("select * from accounting_year where id ='".$id."' and company_id='".$cid."' ");	
		foreach($accountingyear->fetchAll() as $ay) {
			$accountingyearlist[] = $ay;
		}  		
		
		$aylcd="";		
		$aytoderror="";		
		$aytcderror="";	
		
		$ls_yr_closing_date="";	
		$current_yr_from_date="";	
		$current_yr_to_date="";
		
		if(isset($_POST['edit'])){
		
			$ls_yr_closing_date		= $_POST['ls_yr_closing_date'];
			$current_yr_from_date	= $_POST['current_yr_from_date'];
			$current_yr_to_date		= $_POST['current_yr_to_date'];		
			
			if($ls_yr_closing_date==""){
				$aylcd = "Please enter last year closing datre";							 						
			} 
			if($current_yr_from_date==""){
				$aytoderror = "Please enter this year opening date ";			 							
			} 
			if($current_yr_to_date==""){
				$aytcderror = "Please enter this year closing date";			 					
			} 
			
			
			if($aylcd!="" || $aytoderror!="" || $aytcderror!="" ){
				require_once('views/accountingyear/create.php'); 	 
			}
			
			$ls_yr_closing_date 	= date("Y-m-d", strtotime($ls_yr_closing_date));	
			$current_yr_from_date   = date("Y-m-d", strtotime($current_yr_from_date));	
			$current_yr_to_date     = date("Y-m-d", strtotime($current_yr_to_date));
			
			
			$modified_by = $_SESSION['username'];
			$modified_ip = $_SERVER['REMOTE_ADDR'];
			$modified    = date("Y-m-d H:i:s"); 
			
						
				// update query
				$result = $db->query("update accounting_year set ls_yr_closing_date = '".date("Y-m-d", strtotime($ls_yr_closing_date))."',  current_yr_from_date = '".$current_yr_from_date."', current_yr_to_date = '".$current_yr_to_date."', modified_by='".$modified_by."', modified_ip='".$modified_ip."', modified='".$modified."' where company_id = '".$cid."' and id ='".$id."' ");		
							
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}
				header("Location: ?controller=accountingyear&action=index");			
					
		} else {	 
		   require_once('views/accountingyear/edit.php'); 	   
		}  
	  
    }	
	
	// delete
	public function delete() {
		
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
	
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // companyid
		
		$id = $_GET['id'];	
		$result = $db->query("delete from accounting_year where company_id = '".$cid."' and id ='".$id."' ");		
							
		if(!$result){
			die('Invalid query: ' . mysql_error());
		}	
		
      header("Location: ?controller=accountingyear&action=index&cid=".$cid." ");		
    }
		

    public function error() {
      require_once('views/accountingyear/error.php');
    }
  }
?>