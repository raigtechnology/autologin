<?php
  class ForexController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid']; // company id
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		}
		
// for currency

		$session_id = $_SESSION['company_id'];		

		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end			
		
		
		
		$currency_source_list =  array();		
		$currency_source = $db->query("select sm.source_name, cure.source_date from currency as cure left join source_master as sm on sm.id = cure.source_id where cure.company_id='".$com_id."' group by cure.source_id");	
		foreach($currency_source->fetchAll() as $csy) {
			$currency_source_list[] = $csy;
		}  
		
	
		
		
		$currencylist =  array();		
		$currency = $db->query("select * from currency where company_id='".$com_id."' ");	
		foreach($currency->fetchAll() as $cy) {
			$currencylist[] = $cy;
		}  		
			//exit;			  
	  require_once('views/forex/index.php'); 
	  
    }	
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid']; // company id
	

// for currency

		$session_id = $_SESSION['company_id'];		

		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end			
	
		
		
		if(isset($_POST['create'])){
		
			$updated_date		= date("Y-m-d", strtotime($_POST['updated_date']));
			$exchange_rate		= $_POST['exchange_rate'];				
			$currency_name		= $_POST['currency_name'];				
			$currency_code		= $_POST['currency_code'];				
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
						
			// insert query
			$result = $db->query("insert into currency(company_id, exchange_rate, updated_date, currency_name, currency_code, created_by, created_ip, created) values ('".$com_id."', '".$exchange_rate."', '".$updated_date."', '".$currency_name."', '".$currency_code."', '".$created_by."', '".$created_ip."', '".$created."') ");		
						
			if(!$result){
				die('Invalid query: ' . mysql_error());
			}
			
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Add";
			$window_name     = "Foreign Exchange Rates";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
			
			header("Location: ?controller=forex&action=index&cid=".$cid."");		
					
		} else {	 
		   require_once('views/forex/create.php'); 	   
		}  
	  
    }		
	
	public function edit() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid']; // company id
		
		$id = $_GET['id'];	    

// for currency

		$session_id = $_SESSION['company_id'];		

		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end			

		
		$currencylist =  array();		
		$currency = $db->query("select * from currency where currency_id ='".$id."' and company_id='".$com_id."' ");	
		foreach($currency->fetchAll() as $cy) {
			$currencylist[] = $cy;
		}  	
				
				
		if(isset($_POST['edit'])){
		
			//$db = Db::getInstance(); // db connection
		
			$updated_date		= date("Y-m-d", strtotime($_POST['updated_date']));
			$exchange_rate		= $_POST['exchange_rate'];
			
			$modified_by = $_SESSION['username'];
			$modified_ip = $_SERVER['REMOTE_ADDR'];
			$modified    = date("Y-m-d H:i:s"); 
					
			// update query
			$result = $db->query("update currency set updated_date = '".$updated_date."',  exchange_rate = '".$exchange_rate."', modified_by='".$modified_by."', modified_ip='".$modified_ip."', modified='".$modified."' where company_id = '".$com_id."' and currency_id ='".$id."' ");		
							
			if(!$result){
				die('Invalid query: ' . mysql_error());
			}
			
			$created_by 	 = $_SESSION['username'];
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Change";
			$window_name     = "Foreign Exchange Rates";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
			
			header("Location: ?controller=forex&action=index&cid=".$cid."");		
		
					
		} else {	 
		   require_once('views/forex/edit.php'); 	   
		}  
	  
    }	
	
	
	public function sourceedit() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid']; // company id		
	
// for currency

		$session_id = $_SESSION['company_id'];		

		
		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end		
	
	
					
		$currency_source_list =  array();		
		$currency_source = $db->query("select cure.source_id, sm.source_name, cure.source_date from currency as cure left join source_master as sm on sm.id = cure.source_id where cure.company_id='".$com_id."' group by cure.source_id");	
		foreach($currency_source->fetchAll() as $csy) {
			$currency_source_list[] = $csy;
		}  
			
		$sourcetypelist =  array();		
		$sourcetype = $db->query("select * from source_master order by id asc");	
		foreach($sourcetype->fetchAll() as $sty) {
			$sourcetypelist[] = $sty;
		}  
			
						
				
		if(isset($_POST['edit'])){
		
			//$db = Db::getInstance(); // db connection
		
			$source_date	= date("Y-m-d", strtotime($_POST['source_date']));
			$source_id		= $_POST['source_id'];
			
			$modified_by = $_SESSION['username'];
			$modified_ip = $_SERVER['REMOTE_ADDR'];
			$modified    = date("Y-m-d H:i:s"); 
					
			// update query
			$result = $db->query("update currency set source_date = '".$source_date."',  source_id = '".$source_id."', modified_by='".$modified_by."', modified_ip='".$modified_ip."', modified='".$modified."' where company_id = '".$com_id."'  ");		
							
			if(!$result){
				die('Invalid query: ' . mysql_error());
			}
			
			$created_by      = $_SESSION['username'];
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Change";
			$window_name     = "Foreign Exchange Rates";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
			
			header("Location: ?controller=forex&action=index&cid=".$cid."");		
		
					
		} else {	 
		   require_once('views/forex/sourceedit.php'); 	   
		}  
	  
    }	
	
	
	
	// delete
	public function delete() {
		
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
	
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid']; // company id
	
// for currency

		$session_id = $_SESSION['company_id'];		

		$usergroup = $db->query("select user_group_id from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}

// end			
		
		
		$id = $_GET['id'];	
		$result = $db->query("delete from currency where company_id = '".$com_id."' and currency_id ='".$id."' ");		
							
		if(!$result){
			die('Invalid query: ' . mysql_error());
		}	
		   
		    $created_by      = $_SESSION['username'];
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Delete";
			$window_name     = "Foreign Exchange Rates";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
		
		
      header("Location: ?controller=forex&action=index&cid=".$cid."");		
    }
		

    public function error() {
      require_once('views/forex/error.php');
    }
  }
?>