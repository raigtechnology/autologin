<?php
  class CompanymasterController {
  
	public function index() { 	
	
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		
		$cid = $_GET['cid'];
		if(isset($_GET['tag'])){
			$_SESSION['tag'] = $_GET['tag'];	
		}
		
		// companylist
		$companylist = array();
		$company = $db->query("SELECT * from companies where id = '".$cid."'  ");		
		foreach($company->fetchAll() as $cy) {
        	$companylist[] = $cy;
     	}	
		
			
		require_once('views/companymaster/index.php'); 
    }	
	
	
	// edit
	public function edit() { 	
	
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		
		$cid = $_GET['cid'];		
		
		
		// branch
		$branchlist = array();
		$branch = $db->query('SELECT * FROM profit_centers order by profit_center asc');		
		foreach($branch->fetchAll() as $br) {
        	$branchlist[] = $br;
     	}	
		
	
		// department
		$departmentlist = array();
		$department = $db->query('SELECT * FROM department_master order by department_name asc');		
		foreach($department->fetchAll() as $dl) {
        	$departmentlist[] = $dl;
     	}
		
		// designation
		$designationlist = array();
		$designation = $db->query('SELECT * FROM designation_master order by designation_name asc');		
		foreach($designation->fetchAll() as $dg) {
        	$designationlist[] = $dg;
     	}
		
		// employee type
		$employeetypelist = array();
		$employeetype = $db->query('SELECT * FROM employee_type_master order by employee_type_name asc');		
		foreach($employeetype->fetchAll() as $et) {
        	$employeetypelist[] = $et;
     	}
	
		if (isset($_POST['Submit'])) {
		
			$company_name		= $_POST['company_name'];
			$company_address	= $_POST['company_address'];
			$city				= $_POST['city'];
			$state				= $_POST['state'];
			$country			= $_POST['country'];
			$postal_code		= $_POST['postal_code'];
			$phone_no			= $_POST['phone_no'];
			$fax_no				= $_POST['fax_no'];
			$email_address		= $_POST['email_address'];
			$website			= $_POST['website'];
			$registration_no	= $_POST['registration_no'];
			$epf_no				= $_POST['epf_no'];
			$tax_no				= $_POST['tax_no'];
			$socso_no			= $_POST['socso_no'];			
			$from_date			= date("Y-m-d", strtotime($_POST['from_date']));
			$to_date			= date("Y-m-d", strtotime($_POST['to_date']));
			$sunday				= $_POST['sunday'];
			$monday				= $_POST['monday'];
			$tuesday			= $_POST['tuesday'];
			$wednesday			= $_POST['wednesday'];
			$thursday			= $_POST['thursday'];
			$friday				= $_POST['friday'];
			$saturday			= $_POST['saturday'];
			$employer_epf		= 0;
			$employee_epf		= 0;
			$gstreg_no			= $_POST['gstreg_no'];
			
			$january	= $_POST['january'];
			$february	= $_POST['february'];
			$march		= $_POST['march'];
			$april		= $_POST['april'];
			$may		= $_POST['may'];
			$june		= $_POST['june'];
			$july		= $_POST['july'];
			$august		= $_POST['august'];
			$september	= $_POST['september'];
			$october	= $_POST['october'];
			$november	= $_POST['november'];
			$december	= $_POST['december'];
			
			$no_of_working_hours= $_POST['no_of_working_hours'];
								
			if(isset($_FILES['image_file'])){
			  $errors= array();
			  $file_name = $_FILES['image_file']['name'];
			  $file_size = $_FILES['image_file']['size'];
			  $file_tmp  = $_FILES['image_file']['tmp_name'];
			  $file_type = $_FILES['image_file']['type'];
			  $file_ext  = strtolower(end(explode('.',$_FILES['image_file']['name'])));
			  
			  $expensions= array("jpeg","jpg","png");
			  
			  if(in_array($file_ext,$expensions)=== false){
				 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
			  }
			  
			  if($file_size > 2097152){
				 $errors[]='File size must be excately 2 MB';
			  }
			  
			  if(empty($errors)==true){
				 move_uploaded_file($file_tmp,"public/img/".$file_name);				
				 $path = "public/img/".$file_name;
			  }else{				 	
				 $path = "";
			  }
		   }
			
			$update = $db->query("update companies set company_image='".$path."', company_name = '".$company_name."', address = '".$company_address."', city = '".$city."', state = '".$state."', Country = '".$country."', pincode = '".$postal_code."', phone_no = '".$phone_no."', fax_no = '".$fax_no."', email_address = '".$email_address."', website = '".$website."', Business_Regno = '".$registration_no."', epf_no = '".$epf_no."', tax_no = '".$tax_no."', socso_no = '".$socso_no."', from_date = '".$from_date."', to_date = '".$to_date."', sunday = '".$sunday."', monday = '".$monday."', tuesday = '".$tuesday."', wednesday = '".$wednesday."', thursday = '".$thursday."', friday = '".$friday."', saturday = '".$saturday."', employer_epf = '".$employer_epf."', employee_epf = '".$employee_epf."', GST_IdNo = '".$gstreg_no."', no_of_working_hours='".$no_of_working_hours."', january='".$january."', february='".$february."', march='".$march."', april='".$april."', may='".$may."', june='".$june."', july='".$july."', august='".$august."', september='".$september."', october='".$october."', november='".$november."', december='".$december."' where id='".$cid."'  ")	;		
			
		
			header("Location: ?controller=companymaster&action=index&cid=".$cid."");	
				
		} else {
			require_once('views/companymaster/edit.php'); 
	   	}		
		  	  	  
    }
	
	
  }
?>
