<?php
  class AccounttypesController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
								
		$accounttypes = $db->query("select code, code_desc from account_types order by code asc");	
		foreach($accounttypes->fetchAll() as $scm) {
			$accounttypeslist[] = $scm;
		}	
								  
		require_once('views/accounttypes/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/accounttypes/error.php');
    }
  }
?>