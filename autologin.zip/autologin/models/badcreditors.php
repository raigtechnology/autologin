<?php
  class badcreditors {
   
  }
?>