<?php
  class TrialbalanceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();	// db connection	
		$cid = $_GET['cid'];		// company id	    
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$todate = date("Y-m-d");		
		
		$trialbalancelist = array();		
		$trialbalance = $db->query("CALL trialBalance('".$cid."', '0' , '0', '".$todate."')");		
		foreach($trialbalance->fetchAll() as $dar) {
			$trialbalancelist[] = $dar;
		}  		
		
		$count = count($trialbalancelist);	
		
						  
	  require_once('views/trialbalance/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/trialbalance/error.php');
    }
  }
  

?>