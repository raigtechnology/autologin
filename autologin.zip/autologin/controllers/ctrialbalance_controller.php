<?php
  class CtrialbalanceController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		/**************************************************************/
		$db = Db::getInstance();		 // db connection
		$cid = $_GET['cid'];             // company_id
		$session_id = $_SESSION['company_id'];
		//$consolidated = $_SESSION['consolidated'];
		
		$usergroup = $db->query("select user_group_id,consolidated from companies where id = '".$session_id."'");	
		foreach($usergroup->fetchAll() as $ug) {
			$usergroupid 	= $ug['user_group_id'];	
			$consolidated   = $ug['consolidated'];
		}	
		
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$usergroupid."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}
		/**************************************************************/	     
		
		$todate = date("Y-m-d");		
		echo "CALL trialBalance('".$cid."', '' , NULL, '".$todate."')";exit;
		$trialbalancelist = array();		
		$trialbalance = $db->query("CALL trialBalance('".$cid."', '' , NULL, '".$todate."')");		
		foreach($trialbalance->fetchAll() as $dar) {
			$trialbalancelist[] = $dar;
		}  	
		//echo "<pre>";print_r($trialbalancelist);exit;
		$count = count($trialbalancelist);	
		
						  
	  require_once('views/ctrialbalance/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/ctrialbalance/error.php');
    }
  }
  

?>