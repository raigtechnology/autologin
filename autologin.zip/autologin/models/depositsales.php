<?php
  class depositsales {
   
  }
?>