<?php
  class PaymentreceivedController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
						
		$salesinvoicelistgroup = array();
		$salesinvoicegroup = $db->query("select je.memo,je.received_entry from journal_entries as je where je.company_id='".$cid."' and je.entry_mode in('Sales','Deposit Sales') group by je.memo  ");	 // except simplified invoice and reverse charge invoices
		foreach($salesinvoicegroup->fetchAll() as $jel) {
			$salesinvoicelistgroup[] = $jel;
		}  		
		
		$salesinvoicelist = array();
		$salesinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code, je.trade_type,je.entry_mode,je.received_entry from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode in('Sales','Deposit Sales') and je.ref not in('dispose') order by je.date, je.memo ");	// except simplified invoice and reverse charge invoices
		foreach($salesinvoice->fetchAll() as $je) {
			$salesinvoicelist[] = $je;
		}  	
						  
	    require_once('views/paymentreceived/index.php'); 
	  
    }		
		
		
	
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
				
		
		// customer
		$customerslist = array();
		$customers = $db->query("select CompanyName, AutoCustomerID from tblcustomer where company_id ='".$cid."' order by CompanyName asc ");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		} 	
		
		// banks
		$bankslist = array();
		$banks = $db->query("select bl.bank_name, bk.subcode_id from banks as bk left join bank_lists as bl on bl.id = bk.bank_list_id left join subcodes as sc on sc.id = bk.subcode_id where bk.company_id=".$cid." order by bl.bank_name");	
		foreach($banks->fetchAll() as $bk) {
			$bankslist[] = $bk;
		}  
		
		
		// banks
		$currentassetslist = array();
		$currentassets = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_desc='CURRENT ASSETS' and sc.description !='Trade Debtors' and sc.subcode_of NOT IN (select id from subcodes where description='Trade Debtors')");								
		foreach($currentassets->fetchAll() as $ca) {
			$currentassetslist[] = $ca;
		}  
		
					 
		require_once('views/paymentreceived/create.php'); 	   
	
	  
    }		
	
	// print
	
	public function printt() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		$invoice = $_GET['id'];      // invoice id	 		
		
		// customer
		$paymentlist = array();
		$payments = $db->query("select je.memo,je.date,je.debit,je.ref,sc.description,je.descripe from journal_entries as je left join subcodes as sc on sc.id=je.subcode_id where je.company_id ='".$cid."' and je.memo = '".$invoice."' and je.debit>0 ");	
		foreach($payments->fetchAll() as $pay) {
			$paymentlist[] = $pay;
		} 
		
		
			 
		require_once('views/paymentreceived/print.php'); 	   
	
	  
    }	
	// filter
	public function filter() {
     	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
	 
	   	
		// customer
		$customerslist = array();
		$customers = $db->query("select CompanyName, AutoCustomerID from tblcustomer where company_id ='".$cid."' order by CompanyName asc ");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		} 		
					
		// banks
		$bankslist = array();
		$banks = $db->query("select bl.bank_name, bk.subcode_id from banks as bk left join bank_lists as bl on bl.id = bk.bank_list_id left join subcodes as sc on sc.id = bk.subcode_id where bk.company_id=".$cid." order by bl.bank_name");								
		foreach($banks->fetchAll() as $bk) {
			$bankslist[] = $bk;
		}  
		
		// banks
		$currentassetslist = array();
		$currentassets = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_desc='CURRENT ASSETS' and sc.description !='Trade Debtors' and sc.subcode_of NOT IN (select id from subcodes where description='Trade Debtors')");								
		foreach($currentassets->fetchAll() as $ca) {
			$currentassetslist[] = $ca;
		}  
		
		
		// subcodes for reverse
		$subcodes_reverselist = array();
		$subcodes_reverse = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_desc='CURRENT LIABILITIES' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors')");								
		foreach($subcodes_reverse->fetchAll() as $sc) {
			$subcodes_reverselist[] = $sc;
		}  
		
		// for filter		

		$cond="";

		$customername="";
	
       if(isset($_POST['Submit'])){		
	   				
			$date			= $_POST['date'];
	   		$bank_id 		= $_POST['bank_id'];
			$asset_id 		= $_POST['asset_id'];
	  		$customer_id	= $_POST['customer_id'];	
			  
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s");   
			   				
			
			if($customer_id!=""){
				$cond = " and AutoCustomerID = '".$customer_id."'";
			} else {
				$customername	= $_POST['customername'];	  	
			
				$cond = " and CompanyName = '".$customername."'";
			}
			
			$tblcustomer = $db->query("select CompanyName, AutoCustomerID  from tblcustomer where company_id=".$cid." ".$cond." ");								
			foreach($tblcustomer->fetchAll() as $tc) {						
				$customername = $tc['CompanyName'];	
				$customer_id = $tc['AutoCustomerID'];				
			}
			
			
			$tblinvoiceinoutlist = array();							
			$tblinvoiceinout = $db->query("select tin.InvNo, tin.InvAmt, tin.AmtPaid, tin.InVDate from tblinvoiceinout as tin where tin.company_id=".$cid." and tin.CustID = '".$customer_id."' and tin.Acc_description = 'Invoiceout' ");				
			foreach($tblinvoiceinout->fetchAll() as $tbl) {			
				$tblinvoiceinoutlist[] = $tbl;
			}	
						
			require_once('views/paymentreceived/filter.php'); 	 
						
        }  else if(isset($_POST['save'])){		
	   					
			$pay_date = date("Y-m-d", strtotime($_POST['date']));
			
			$customerid 	= $_POST['customer_id'];
			
			$tblcustomer1 = $db->query("select CompanyName, AutoCustomerID, Customer_account_code  from tblcustomer where company_id=".$cid." and AutoCustomerID = '".$customerid."' ");								
			foreach($tblcustomer1->fetchAll() as $tc1) {						
				$customercode = $tc1['Customer_account_code'];							
			}
			
			
			$describe 		= $_POST['description'];
			$bank_id 		= $_POST['bank_id'];		
			$asset_id 		= $_POST['asset_id'];		
			
			$tblcustomer = $db->query("select id from subcodes where company_id=".$cid." and code = '".$customercode."' ");								
			foreach($tblcustomer->fetchAll() as $tc) {						
				$customer_id = $tc['id'];				
			}
			
			
			foreach($_POST['data'] as $dt){											
				
				if($dt['selectedrow']==1){
												
					$invoice_details = $db->query("select memo, ref, profit_center_id, subcode_of, currencyrate from journal_entries where company_id=".$cid." and memo = '".$dt['invoice_no']."' and trade_type='Trade Debtors' order by id asc limit 1 ");								
					foreach($invoice_details->fetchAll() as $ids) {						
						$ref 					= $ids['ref'];
						$profit_center_id 		= $ids['profit_center_id'];
						$subcode_of 			= $ids['subcode_of'];
						$invoice_currencyrate 	= $ids['currencyrate'];
						$invoiceno 				= $ids['memo'];
					}
					
					// for taxcode
					$taxlist = $db->query("select taxcode from journal_entries where company_id=".$cid." and memo = '".$invoiceno."' and gst>0 ");								
					foreach($taxlist->fetchAll() as $tl) {						
						$txcode 				= $tl['taxcode'];
					}
					
											
					$credit_subcode_id		= $customer_id; // debit
					
					if($asset_id>0){
						$debit_subcode_id		= $asset_id; // credit
					} else {
						$debit_subcode_id		= $bank_id; // credit
					}
					
					
					$memo					= $dt['invoice_no'];
					$profit_center_id 		= $profit_center_id;
					$company_id 			= $cid;
					$ref					= $dt['voucher_no'];
					$debit		 			= $dt['amount'];
					$credit		 			= $dt['amount'];					
					$totalamount 			= -abs($dt['amount']);
					$currencyrate 			= '1.00';	
					$currencycode 			= 'RM';	
					$subcode_of 			= $subcode_of;						
					$entry_mode 			= "Sales";		
					$receive_mode 			= "Sale";					
					//$sub_total_amount1 	= $totalamount;	
					//$total_amount 		= abs($sub_total_amount1) * $currencyrate; 					
					//$gst					= $total_amount * (6/100);						
						
					//$t_amount = $total_amount + $gst;	
					//$total_amount 			= abs($sub_total_amount1) * $currencyrate; 		
					$t_amount = $credit;	
																
					// debit					
					$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`deb_crt_date`,`ref`,`memo`,`credit`,`totalamount`,`currencycode`,`currencyrate`,`subcode_of`,`entry_mode`,`trade_type`,`created_by`,`created_ip`,`created`,`received_entry`,`descripe`) values ('".$credit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$pay_date."','".$ref."','".$memo."','".$t_amount."','".$totalamount."','".$currencycode."','".$currencyrate."','".$subcode_of."','".$entry_mode."','Trade Debtors','".$created_by."','".$created_ip."','".$created."','".$receive_mode."','".$describe."')");		
														
					//// credit
					$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`deb_crt_date`,`ref`,`memo`,`debit`,`entry_mode`,`taxcode`,`created_by`,`created_ip`,`created`,`received_entry`,`descripe`)values('".$debit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$pay_date."','".$ref."','".$memo."','".$t_amount."','".$entry_mode."','".$txcode."','".$created_by."','".$created_ip."','".$created."','".$receive_mode."','".$describe."')");	
					
					
					// gst bad debt entries start			
					// master purchase data start
					$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$customer_id."' ");
					foreach($subcodes->fetchAll() as $scs){
						$customername 	= $scs['description'];
						$subcode_of 	= $scs['subcode_of'];	
						$account_code 	= $scs['code'];			
					}					
					
					$gstbaddebtdata = $db->query("insert into gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`credit`,`credit_gst`,`trade_type`,`company_id`,`created_by`,`created_ip`,`created`) values('".$account_code."','".$pay_date."','".$memo."','".$ref."','".$t_amount."','".$gst."','Trade Debtors','".$company_id."','".$created_by."','".$created_ip."','".$created."')");
					
					if(!$gstbaddebtdata){
						die('Invalid query: ' . mysql_error());
					}	
					// gst bad debt entries end		
					
					$tblinout = $db->query("select AmtPaid from tblinvoiceinout where InvNo='".$memo."' and company_id='".$company_id."'  ");
					foreach($tblinout->fetchAll() as $tn){
						$AmtPaid 	= $tn['AmtPaid'];							
					}	
					
					$AmtPaid = $AmtPaid + $t_amount;
					
					
					$db->query("update tblinvoiceinout set AmtPaid = '".$AmtPaid."' where InvNo='".$memo."' and company_id='".$company_id."' ");							
													
					// gain or loss calculation
					$invoice_currency_rate 		= $invoice_currencyrate;
					$payment_currency_amount	= $dt['amount'];
								
					$amount_for_find_difference1 = $payment_currency_amount * $invoice_currency_rate; // old value
					$amount_for_find_difference2 = $payment_currency_amount * $currencyrate; // new value
															
					//if($amount_for_find_difference1<$amount_for_find_difference2){					
						$difference = $amount_for_find_difference2 - $amount_for_find_difference1;		 // loss	
						//echo "Loss : ".$loss_difference.'<br>';													
					//} else if($amount_for_find_difference1>$amount_for_find_difference2){					
					//	$difference = $amount_for_find_difference1 - $amount_for_find_difference2;		// gain		
						//echo "Gain : ".$gain_difference.'<br>';
					//} else {
						//echo "There is no difference";
					//}				
					
					
					if($difference==0){		
						$difference=0;
					} else if($difference>0){		
						$difference=$difference;
					} else if($difference<0){		
						$difference=0;
					}
					
								
						$db->query("insert into tbl_es43(`invoice_no`,`invoice_date`,`gst`,`company_id`,`TaxCode`,`transaction_type`)values('".$memo."','".$pay_date."','".$difference."','".$company_id."','ES43','Sales')");	
						
						
						
						$es43_subcodes = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX-ES43' and company_id='".$cid."' ");
						foreach($es43_subcodes->fetchAll() as $es){				
							$es43id 	= $es['id'];			
						}
						
						
						$difference_gst   =  $difference * (6/100);	
						
							
						if($difference<0){
													
							$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`deb_crt_date`,`ref`,`memo`,`credit`,`entry_mode`,`taxcode`,`created_by`,`created_ip`,`created`,`manual_entry`)values('".$es43id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$pay_date."','".$ref."','".$memo."','".$difference."','".$entry_mode."','ES43','".$created_by."','".$created_ip."','".$created."','Sales')");	
							
						} else if($difference>0){
							
							$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`deb_crt_date`,`date`,`ref`,`memo`,`debit`,`entry_mode`,`taxcode`,`created_by`,`created_ip`,`created`,`manual_entry`)values('".$es43id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$pay_date."','".$ref."','".$memo."','".$difference."','".$entry_mode."','ES43','".$created_by."','".$created_ip."','".$created."','Sales')");	
					
						}
						
						
						
				//	}			
												
				} 
			}						
							
			header("Location: ?controller=paymentreceived&action=index&cid=".$cid."");			
			
        }  else {
			
			require_once('views/paymentreceived/filter.php'); 	 
			
		}	
		
		  
		            	
   }
	
	

    public function error() {
      require_once('views/paymentreceived/error.php');
    }
  }
?>