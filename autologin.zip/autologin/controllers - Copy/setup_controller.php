<?php
  class SetupController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();		    
				
		$userflag = $db->query("select flag from tbllogin where company_id='".$_SESSION['company_id']."' and username = '".$_SESSION['username']."' ");	
		foreach($userflag->fetchAll() as $uf) {
			$flag = $uf['flag'];
		}  
	  
	  require_once('views/setup/index.php'); 
	  
    }		

    public function error() {
      require_once('views/setup/error.php');
    }
  }
?>