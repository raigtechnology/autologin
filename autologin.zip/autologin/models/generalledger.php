<?php
  class generalledger {
   
  }
?>