<?php
  class DisposalController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    	    
						
		$salesinvoicelistgroup = array();
		$salesinvoicegroup = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.entry_mode in('Sales') and je.ref in('dispose') group by je.memo order by je.date,je.memo ");	
		foreach($salesinvoicegroup->fetchAll() as $jel) {
			$salesinvoicelistgroup[] = $jel;
		}  		
		
		$salesinvoicelist = array();
		$salesinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code,je.trade_type from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and sc.company_id='".$cid."' and je.entry_mode in('Sales') and je.ref in('dispose') order by je.date,je.memo");	
		foreach($salesinvoice->fetchAll() as $je) {
			$salesinvoicelist[] = $je;
		}  	
						  
	  require_once('views/disposal/index.php'); 
	  
    }		
	
	
	// create and  filter
	
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
		
			
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id != '6' ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		} 	
		
		// banks
		$bankslist = array();
		$banks = $db->query("select bl.bank_name, bk.subcode_id from banks as bk left join bank_lists as bl on bl.id = bk.bank_list_id left join subcodes as sc on sc.id = bk.subcode_id where bk.company_id=".$cid." order by bl.bank_name");	
		foreach($banks->fetchAll() as $bk) {
			$bankslist[] = $bk;
		}  
				
		
					
	   require_once('views/disposal/create.php'); 	   
		
	  
    }		
	
	
	// filter
	public function filter() {
     	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
	 
	   	
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_type_id='13' and mac.company_id='".$cid."' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		} 		
					
		// banks
		$bankslist = array();
		$banks = $db->query("select bl.bank_name, bk.subcode_id from banks as bk left join bank_lists as bl on bl.id = bk.bank_list_id left join subcodes as sc on sc.id = bk.subcode_id where bk.company_id=".$cid." order by bl.bank_name");								
		foreach($banks->fetchAll() as $bk) {
			$bankslist[] = $bk;
		}  
		
		// subcodes for reverse
		$subcodes_reverselist = array();
		$subcodes_reverse = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_desc='CURRENT LIABILITIES' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors')");								
		foreach($subcodes_reverse->fetchAll() as $sc) {
			$subcodes_reverselist[] = $sc;
		}  
		
		// for filter		

       if(isset($_POST['Submit'])){		
	   				
			$date		= $_POST['date'];
	   		$bank_id 	= $_POST['bank_id'];
	  		$customer_id	= $_POST['customer_id'];	  	   						
										
			$tblinvmastersales = $db->query("select distinct(je.memo), je.date, je.totalamount, je.currencycode, je.currencyrate from journal_entries as je where je.company_id=".$cid." and je.subcode_id = ".$customer_id." and je.entry_mode in('Sales') and je.ref in('dispose') group by je.memo ");					
												
			$i=0;
			$tblinvmastersales2 = array();
			foreach($tblinvmastersales->fetchAll() as $tbl) {			
																
				$tblinvmastersales1 = $db->query("select distinct(memo), date, sum(totalamount) as totalamount, currencycode, currencyrate, gst, credit, fixed_asset_id from journal_entries where memo='".$tbl['memo']."' and currencyrate>0 and currencycode!='' and company_id='".$cid."'  ");					
				foreach($tblinvmastersales1->fetchAll() as $tbl1) {						
									
					$tblinvmastersales2[] = $tbl1;						
				}	
				$i++;
			}	
				
						
			$tblpro = array();				
			foreach($tblinvmastersales2 as $mp){
			
				if($mp['totalamount']>0){				
								
												
					$tblproductsales = $db->query("select AutoInvoiceID, sum(totalunitprice) as totalunitprice from tblinvproduct_sales where company_id='".$cid."' and AutoInvoiceID = '".$mp['memo']."' ");					
					
					foreach($tblproductsales->fetchAll() as $tpp) {						
					
						if($tpp['totalunitprice']>0){
							$tblpro[] =  $tpp;		
						}
					}	
				}
				
			}		
		
			$count = count($tblpro);			
						
			
			require_once('views/disposal/filter.php'); 	 
						
        }  else if(isset($_POST['save'])){		
	   					
			$pay_date = date("Y-m-d", strtotime($_POST['date']));
			
			$customer_id 	= $_POST['customer_id'];
			$bank_id 	= $_POST['bank_id'];			
			
			foreach($_POST['data'] as $dt){											
				
				if($dt['selectedrow']==1){
												
					$invoice_details = $db->query("select memo, ref, profit_center_id, subcode_of, currencyrate from journal_entries where company_id=".$cid." and memo = '".$dt['invoice_no']."' and trade_type='Trade Debtors' order by id asc limit 1 ");								
					foreach($invoice_details->fetchAll() as $ids) {						
						$ref 					= $ids['ref'];
						$profit_center_id 		= $ids['profit_center_id'];
						$subcode_of 			= $ids['subcode_of'];
						$invoice_currencyrate 	= $ids['currencyrate'];
						$invoiceno 				= $ids['memo'];
					}
					
					// for taxcode
					$taxlist = $db->query("select taxcode from journal_entries where company_id=".$cid." and memo = '".$invoiceno."' and gst>0 ");								
					foreach($taxlist->fetchAll() as $tl) {						
						$txcode 				= $tl['taxcode'];
					}
					
											
					$credit_subcode_id		= $customer_id; // debit
					$debit_subcode_id		= $bank_id; // credit
					$memo					= $dt['invoice_no'];
					$profit_center_id 		= $profit_center_id;
					$company_id 			= $cid;
					$ref					= $ref;
					$debit		 			= $dt['rmamount'];
					$credit		 			= $dt['rmamount'];
					$gst		 			= $dt['rmamountgst'];
					$totalamount 			= -abs($dt['currency_amount']);
					$currencyrate 			= $dt['currency_rate'];	
					$currencycode 			= $dt['currency_code'];	
					$subcode_of 			= $subcode_of;						
					$entry_mode 			= "Sales";		
					$fixed_asset_id			= $dt['fixed_asset_id'];	
									
					//$sub_total_amount1 	= $totalamount;	
					//$total_amount 		= abs($sub_total_amount1) * $currencyrate; 					
					//$gst					= $total_amount * (6/100);						
						
					//$t_amount = $total_amount + $gst;	
					//$total_amount 			= abs($sub_total_amount1) * $currencyrate; 		
					$t_amount = $credit;	
																
					// debit					
					$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`totalamount`,`currencycode`,`currencyrate`,`subcode_of`,`entry_mode`,`gst`,`trade_type`) values ('".$credit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$t_amount."','".$totalamount."','".$currencycode."','".$currencyrate."','".$subcode_of."','".$entry_mode."','".$gst."','Trade Debtors')");		
														
					//// credit
					$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`,`gst`,`taxcode`)values('".$debit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$t_amount."','".$entry_mode."','".$gst."','".$txcode."')");	
					
					
					// gst bad debt entries start			
					// master purchase data start
					$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$customer_id."' ");
					foreach($subcodes->fetchAll() as $scs){
						$customername 	= $scs['description'];
						$subcode_of 	= $scs['subcode_of'];	
						$account_code 	= $scs['code'];			
					}					
					
					$gstbaddebtdata = $db->query("insert into gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`credit`,`credit_gst`,`trade_type`,`company_id`) values('".$account_code."','".$pay_date."','".$memo."','".$ref."','".$t_amount."','".$gst."','Trade Debtors','".$company_id."')");
					
					if(!$gstbaddebtdata){
						die('Invalid query: ' . mysql_error());
					}	
					// gst bad debt entries end		
					
					
					
					$todate = $pay_date;											
								
					$fixedassets = $db->query("select fa.id, fa.date_of_purchase, fa.depriciation_value, fa.no_of_years,fa.fixed_asset_value, fa.deposit_paid, fa.total_outstanding_amount, fa.interest, fa.total_payable, fa.depriciation, sc.code, pc.profit_center_code from fixed_assets as fa left join subcodes as sc on sc.id = fa.subcode_id  left join profit_centers as pc on pc.id = fa.profit_center_id where fa.company_id='".$cid."' and sc.company_id='".$cid."' and fa.id='".$fixed_asset_id."' order by fa.date_of_purchase");	
					
					foreach($fixedassets->fetchAll() as $fa) {
					
						$fromdate = $fa['date_of_purchase'];
				
				
						$d1 = new DateTime($fromdate);
						$d2 = new DateTime($todate);
						$months = 1;
						
						$d1->add(new \DateInterval('P1M'));
						while ($d1 <= $d2){
							$months ++;
							$d1->add(new \DateInterval('P1M'));
						}
								
						$depriciation_value = $fa['depriciation_value'] * $months; 					
						$fixed_asset_value = $fa['fixed_asset_value'];
					
					}
										
													
					// gain or loss calculation
					$invoice_currency_rate 		= $invoice_currencyrate;
					$payment_currency_amount	= $dt['currency_amount'];
						
											
					$debit_gain_loss = $payment_currency_amount + $depriciation_value;
					$credit_gain_loss = $fixed_asset_value;
					
					$difference = $debit_gain_loss - $credit_gain_loss;
														
					$amount_for_find_difference1 = $difference * $invoice_currency_rate; // old value
					$amount_for_find_difference2 = $difference * $currencyrate; // new value
																					
					//if($amount_for_find_difference1<$amount_for_find_difference2){					
						$difference = $amount_for_find_difference2 - $amount_for_find_difference1;		 // loss	
						//echo "Loss : ".$loss_difference.'<br>';													
					//} else if($amount_for_find_difference1>$amount_for_find_difference2){					
						//$difference = $amount_for_find_difference1 - $amount_for_find_difference2;		// gain		
						//echo "Gain : ".$gain_difference.'<br>';
					//} else {
						//echo "There is no difference";
					//}				
					
					
					
					if($difference==0){		
						$difference=0;
					} else if($difference>0){		
						$difference=$difference;
					} else if($difference<0){		
						$difference=0;
					}
					
					
					//if($difference!=0){					
						$db->query("insert into tbl_es43(`invoice_no`,`invoice_date`,`gst`,`company_id`,`TaxCode`,`transaction_type`)values('".$memo."','".$pay_date."','".$difference."','".$company_id."','ES43','Sales')");	
						
						$es43_subcodes = $db->query("select id from subcodes where description = 'GST-OUTPUT-TAX-ES43' and company_id='".$cid."' ");
						foreach($es43_subcodes->fetchAll() as $es){				
							$es43id 	= $es['id'];			
						}
						
						
						$difference_gst   =  $difference * (6/100);	
						
							
						if($difference<0){
													
							$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`,`taxcode`)values('".$es43id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$difference."','".$entry_mode."','ES43')");	
							
						} else if($difference>0){
							
							$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`,`taxcode`)values('".$es43id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$difference."','".$entry_mode."','ES43')");	
					
						}
						
						
						
					//}			
												
				} 
			}	
			
		$created_by = $_SESSION['username'];
		$created_date    = date("Y-m-d"); 
		$created_time    = date("h:i:s"); 
		$system_name     = "Auto Accounts";
		$action_taken    = "Add";
		$window_name     = "Fixed Asset Disposal";
			
		$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");					
							
			header("Location: ?controller=disposal&action=index&cid=".$cid."");			
			
        }  else {
			
			require_once('views/disposal/filter.php'); 	 
			
		}	
		
		  
		            	
   }
	
	

    public function error() {
      require_once('views/disposal/error.php');
    }
  }
?>
