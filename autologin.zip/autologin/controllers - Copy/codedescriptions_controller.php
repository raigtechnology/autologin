<?php
  class CodedescriptionsController {
  
	public function index() {      
		
		$code="";
		$code_desc="";		
		$code_title="";	
		$account_type_id="";
		$count="";
		$derror="";
			
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
		$cid = $_GET['cid']; // companyid
								
		$accounttypes = $db->query("select code,code_desc from account_types order by code asc");	
		foreach($accounttypes->fetchAll() as $ac) {
			$accounttypeslist[] = $ac;
		}			
		
		if(isset($_GET['code']) && ($_GET['code']!="")){
			$code = $_GET['code'];
		} else {
			$code = "A";
		} 
		
		$codedescriptionslist = array();	
		$codedescriptions = $db->query("select cd.id,cd.description from code_descriptions as cd left join account_types as at on at.id=cd.account_type_id where at.code='".$code."' order by cd.description asc");	
		foreach($codedescriptions->fetchAll() as $scm) {
			$codedescriptionslist[] = $scm;			
		}		
		
		$count = count($codedescriptionslist);			
			
		$accounttypes2 = $db->query("select id,code,code_desc from account_types where code = '".$code."' ");	
		foreach($accounttypes2->fetchAll() as $at) {
			$code_title = $at['code'];
			$code_desc = $at['code_desc'];
			$account_type_id = $at['id'];
		}	
	
		// after submit part start
		
		if(isset($_POST['save'])){
		
			$code				= $_POST['code'];	
			$description		= $_POST['description'];
			$account_type_id	= $_POST['account_type_id'];
			$cid				= $_POST['cid'];
			
			if($description==""){
				$derror = "Please enter description";	
				require_once('views/codedescriptions/index.php'); 							 						
			} 			
						
			$descriptions = $db->query('SELECT count(*) as total FROM code_descriptions WHERE description = "'.$description.'" and account_type_id = "'.$account_type_id.'" ');		
			foreach($descriptions->fetchAll() as $pc) {
				$total = $pc['total'];
			}
			
			if($total>0){
				
				$derror = "Description already exist!";
				require_once('views/codedescriptions/index.php'); 
			
			} else {				
				
				
				$created_by = $_SESSION['username'];
				$created_ip = $_SERVER['REMOTE_ADDR'];
				$created    = date("Y-m-d H:i:s"); 
				
							
				// insert query
				$result = $db->query("insert into code_descriptions(account_type_id,description,created_by,created_ip,created) values ('".$account_type_id."', '".$description."', '".$created_by."', '".$created_ip."', '".$created."') ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}
				header("Location: ?controller=codedescriptions&action=index&code=".$code."&cid=".$cid." ");	
			}
			
					
		} else {	 
		   require_once('views/codedescriptions/index.php'); 	   
		}  		
		// after submit part end	  
    }	
	
	// edit function
	public function edit() {      
		
		$code="";
		$code_desc="";		
		$code_title="";	
		$account_type_id="";
		$count="";
		$derror="";
		$description="";
		$id="";
			
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
		$cid = $_GET['cid']; // companyid
								
		$accounttypes = $db->query("select code,code_desc from account_types order by code asc");	
		foreach($accounttypes->fetchAll() as $ac) {
			$accounttypeslist[] = $ac;
		}			
		
		if(isset($_GET['code']) && ($_GET['code']!="")){
			$code = $_GET['code'];
		} else {
			$code = "A";
		} 
		
		$codedescriptionslist = array();	
		$codedescriptions = $db->query("select cd.id,cd.description from code_descriptions as cd left join account_types as at on at.id=cd.account_type_id where at.code='".$code."' order by cd.description asc");	
		foreach($codedescriptions->fetchAll() as $scm) {
			$codedescriptionslist[] = $scm;			
		}		
		
		$count = count($codedescriptionslist);			
			
		$accounttypes2 = $db->query("select id,code,code_desc from account_types where code = '".$code."' ");	
		foreach($accounttypes2->fetchAll() as $at) {
			$code_title = $at['code'];
			$code_desc = $at['code_desc'];
			$account_type_id = $at['id'];			
		}
	
		if(isset($_GET['id']) && ($_GET['id']!="")){
		
			$description_for_edit = $db->query("select id,description from code_descriptions where id = '".$_GET['id']."' ");	
			foreach($description_for_edit->fetchAll() as $dfe) {
				$description = $dfe['description'];			
				$id = $dfe['id'];			
			}	
	
		}
		// after submit part start
		
		if(isset($_POST['save'])){
		
			$code				= $_POST['code'];	
			$description		= $_POST['description'];
			$account_type_id	= $_POST['account_type_id'];
			$cid				= $_POST['cid'];
			
			if($description==""){
				$derror = "Please enter description";	
				require_once('views/codedescriptions/index.php'); 							 						
			} 			
						
			$descriptions = $db->query('SELECT count(*) as total FROM code_descriptions WHERE description = "'.$description.'" and account_type_id = "'.$account_type_id.'" ');		
			foreach($descriptions->fetchAll() as $pc) {
				$total = $pc['total'];
			}
			
			if($total>0){
				
				$derror = "Description already exist!";
				require_once('views/codedescriptions/edit.php'); 
			
			} else {				
				
				$modified_by = $_SESSION['username'];
				$modified_ip = $_SERVER['REMOTE_ADDR'];
				$modified    = date("Y-m-d H:i:s"); 				
							
				// insert query
				$result = $db->query("update code_descriptions set description = '".$description."', modified_by='".$modified_by."', modified_ip='".$modified_ip."', modified='".$modified."' where id='".$_GET['id']."' ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}
				header("Location: ?controller=codedescriptions&action=index&code=".$code."");	
			}
			
					
		} else {	 
		   require_once('views/codedescriptions/edit.php'); 	   
		}  		
		// after submit part end	  
    }	
	
	
	// delete function
	// delete
	public function delete() {
	
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid']; // companyid
		
		$id = $_GET['id'];		
		$code = $_GET['code'];		
		$result = $db->query("delete from code_descriptions where id ='".$id."' ");		
							
		if(!$result){
			die('Invalid query: ' . mysql_error());
		}	
		
      header("Location: ?controller=codedescriptions&action=index&code=".$code."");	
    }
		

    public function error() {
      require_once('views/codedescriptions/error.php');
    }
  }
?>