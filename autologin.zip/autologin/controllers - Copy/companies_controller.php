<?php
  class CompaniesController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
					
				
		$consolidated=0;
		
		$db = Db::getInstance();				
		$userflag = $db->query("select company_id, user_group_id from tbllogin where username = '".$_SESSION['username']."' and password = '".$_SESSION['password']."' and user_group_id>0 order by id asc limit 1 ");	
		
		foreach($userflag->fetchAll() as $uf) {
			$user_group_id = $uf['user_group_id'];
			$company_id = $uf['company_id'];	
			$_SESSION['company_id'] = $company_id;
		}  		
	
	
		$userflag1 = $db->query("select company_id, user_group_id from tbllogin where username = '".$_SESSION['username']."' and password = '".$_SESSION['password']."' and user_group_id='".$user_group_id."'  ");	
		
		$cid_list =  array();
		foreach($userflag1->fetchAll() as $uf1) {		
			$cid_list[] = $uf1['company_id'];		
		}  

		
		
		$id_nums = $cid_list;
		$cid1 = implode("','", $id_nums);		
		
		
		if(isset($_GET['cid'])){
			$cid = $_GET['cid'];
		} else {				
			$cid =$company_id; 
		}
		
		
		$userflag_view = $db->query("select Autoaccounts from tbllogin where company_id='".$cid."' and username = '".$_SESSION['username']."' ");	
		foreach($userflag_view->fetchAll() as $uf_view) {			
			$_SESSION['accounts']		=  $uf_view['Autoaccounts'];				
		}  		
		
		
		
		if(isset($_GET['tags'])){
			$tags = $_GET['tags'];			
			
			if($tags=="close"){
				
				$db->query("update tbllogin set quicktour = 'completed' where company_id='".$_SESSION['company_id']."' ");	
			}	
		
		} 
				
		$registrations = $db->query("select company_id from registrations where user_group_id = '".$user_group_id."'");	
		foreach($registrations->fetchAll() as $ud) {
			$com_id 	= $ud['company_id'];		
		}
	
		
		$sources = $db->query("select source_date from currency where company_id='".$com_id."' limit 1 ");	
		foreach($sources->fetchAll() as $sc) {
			$source_date = $sc['source_date'];			
		}  	
		
		$date1 = strtotime($source_date);
		$date2 = date("Y-m-d");
		$date2 = strtotime($date2);
		$dateDiff = $date2 - $date1;
		$total_days = floor($dateDiff/(60*60*24));	
		
		
		if($total_days>=90){
		?>
			<script>alert("Update your currency exchange control.");	
		<?php	
			echo 'window.location= "?controller=forex&action=index&cid='.$_SESSION['company_id'].'"';		
			echo '</script>';
		}	
			
			
		$quicktour = $db->query("select quicktour from tbllogin where company_id='".$_SESSION['company_id']."' ");	
		foreach($quicktour->fetchAll() as $qt) {
			$quickt = $qt['quicktour'];			
		} 	
								
		$paginates = $db->query("select id, company_code, company_name, address, state, pincode from companies where status='A' and id in('".$cid1."')  ");			
		foreach($paginates->fetchAll() as $pg) {
			$companieslist[] = $pg;
		}  				
		
		$noofcompanies =  count($companieslist);
		
		if($noofcompanies==1){		
			$company = $db->query("SELECT company_name FROM companies");	
		} else {
			$company = $db->query("SELECT company_name FROM companies where id = '".$cid."' ");	
		}
		
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
		} 	
		
	  
	  require_once('views/companies/index.php'); 
	  
    }		
	
	public function view($code=NULL) {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
				
		$_SESSION['tag'] = $_GET['tag'];
		
		
		$db = Db::getInstance();	
		$cid = $_GET['cid']; // company_id
			    
		$company = $db->query('SELECT id,company_name FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
		} 
		
		
		
		$quicktour = $db->query("select quicktour from tbllogin where company_id='".$_SESSION['company_id']."' ");	
		foreach($quicktour->fetchAll() as $qt) {
			$quickt = $qt['quicktour'];
			
		}  	
			
		
		
		$banks_bk =  array();
		$banks = $db->query("select * from banks where company_id=".$cid." and subcode_id='0' order by bank_branch");	
		foreach($banks->fetchAll() as $bk) {
			$banks_bk[] = $bk;
		}  		
		
		$bankslist_bl =  array();		
		$bankslist = $db->query("select * from bank_lists");				
		foreach($bankslist->fetchAll() as $bl) {
			$bankslist_bl[] = $bl;
		}  		
		
		
		$paginates = $db->query("select id, company_code, company_name, address, state, pincode from companies where status='A' and id='".$cid."' ");		
		foreach($paginates->fetchAll() as $pg) {
			$companieslist[] = $pg;
		}  			
		  
	  require_once('views/companies/view.php'); 
	  
    }		
	
	
	public function edit($code=NULL) {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
		
		$cid = $_GET['cid']; // company_id
		
		$pccerror="";
		$acerror="";
		
		$banks_bk =  array();
		$banks = $db->query("select * from banks where company_id=".$cid." and id='".$_GET['id']."' and subcode_id='0' order by bank_branch");	
		foreach($banks->fetchAll() as $bk) {
			$banks_bk[] = $bk;
		}  		
		
		$bankslist_bl =  array();		
		$bankslist = $db->query("select * from bank_lists");				
		foreach($bankslist->fetchAll() as $bl) {
			$bankslist_bl[] = $bl;
		} 		
			
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$_SESSION['company_id']."' and account_type_id='13' ");			
		foreach($master_account_codes->fetchAll() as $mac) {
			$mastercodes[] = $mac;			
			$macid = $mac['id'];
		}  
		
		$scodes = $db->query("select account_code from master_account_codes where company_id='".$_SESSION['company_id']."' and id='".$macid."' ");			
		foreach($scodes->fetchAll() as $ma) {
			$scode_prefix = $ma['account_code'];			
		}  
				
		$code = substr($scode_prefix, 0, 4);
				
						
		if(isset($_POST['update'])){
						
			$account_code		= $_POST['account_code'];
			$master_account_code_id =  $_POST['master_account_code_id'];
			$description =  $_POST['bank_name'];
									
			if($account_code==""){
				$pccerror = "Please enter account code";							 						
			} 		
			
			if($pccerror!=""){
				require_once('views/companies/edit.php'); 	 
			}			
							
			if($account_code!=""){
								
				$account_code = $code.'/'.$account_code;		
				// insert query
							
				
				$subcodes = $db->query('SELECT count(*) as total FROM subcodes WHERE code = "'.$account_code.'" and company_id = "'.$_SESSION['company_id'].'" ');		
				foreach($subcodes->fetchAll() as $sc) {
					$total = $sc['total'];
				}
				
				if($total>0){
					$pccerror = "Account Code already exist!";
					require_once('views/companies/edit.php'); 
				} else {
					
						$result = $db->query("insert into subcodes(company_id, master_account_code_id, code, description) values ('".$_SESSION['company_id']."', '".$master_account_code_id."', '".$account_code."', '".$description."') ");		
									
						if(!$result){
							die('Invalid query: ' . mysql_error());
						}	
						
						$oid = $db->query("select id from subcodes where company_id='".$_SESSION['company_id']."' and master_account_code_id='".$macid."' order by id desc limit 1 ");			
						foreach($oid->fetchAll() as $od) {
							$lastid = $od['id'];			
						}  
										
						$update = $db->query("update banks set subcode_id='".$lastid."' where id='".$_GET['id']."' and company_id='".$_SESSION['company_id']."' ");		
									
						if(!$update){
							die('Invalid query: ' . mysql_error());
						}	
						
						header("Location: ?controller=companies&action=index");								
				}
								
			}	else {
				require_once('views/companies/edit.php'); 	 
			}
						
			
			
					
		} else {	 
		   require_once('views/companies/edit.php'); 	   
		}  
		
		
			
		  
	  require_once('views/companies/edit.php'); 
	  
    }		
	
	public function startexe(){			
		exec('"C:\Program Files (x86)\RAIG TECHNOLOGIES (M) SDN BHD\CheqWriter 6.0\ChequeWriter.exe"');		
		header("Location: ?controller=companies&action=index");
		exit;						
	}
	

    public function error() {
      require_once('views/companies/error.php');
    }
  }
?>