<?php
  class DepositpurchaseController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
		
		// vendor
		$vendorslist = array();
		$vendors = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='5' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors') order by sc.description asc");	
		foreach($vendors->fetchAll() as $ct) {
			$vendorslist[] = $ct;
		}  	
		
		$cond="";
		$vendor_id=0;
		$ponumber=0;
		
		if(isset($_POST['submit'])){
				
			/*$fromdate = $_POST['from_date'];
			$todate = $_POST['to_date'];				
				
			if(empty($fromdate)){
				$fromdate = date("01/01/Y");
				$todate = date("d/m/Y");
			}*/
			
			$vendor_id = $_POST['vendor_id'];
			$ponumber = $_POST['ponumber'];
			
			if($ponumber!=""){
					$cond=" and dp.subcode_id='".$vendor_id."' and dp.PoNumber='".$ponumber."' ";			
			} else {
				$cond=" and dp.subcode_id='".$vendor_id." '";			
			}
		
		}		
		
			
				
		$pomaster = $db->query("select distinct(PoNumber) from deposit_purchase where company_id ='".$cid."' and subcode_id='".$vendor_id."' group by PoNumber ");
		
		$pom_sales = array();
		foreach($pomaster as $po){	
			$pom_sales[] = $po;		
		}		
		
		
		$depositpurchaselist = array();
		$depositpurchase = $db->query("select dp.PayDate, dp.PoNumber, dp.deposit_amount, dp.deposit_gst from deposit_purchase as dp where dp.company_id='".$cid."' ".$cond." order by dp.PayDate");	
		foreach($depositpurchase->fetchAll() as $dp) {
			$depositpurchaselist[] = $dp;
		}  	
			
						  
	  require_once('views/depositpurchase/index.php'); 
	  
    }		
	
		
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
		
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
		// BANK LIST
		$banklist = array();
		$banks = $db->query("select b.id, bl.bank_name from banks as b left join bank_lists as bl on bl.id = b.bank_list_id where b.company_id='".$cid."' and b.subcode_id>0 ");	
		foreach($banks->fetchAll() as $bl) {
			$banklist[] = $bl;
		}  			
			
		// vendor
		$vendorslist = array();
		$vendors = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='5' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors' and company_id='".$cid."') order by sc.description asc");	
		foreach($vendors->fetchAll() as $vt) {
			$vendorslist[] = $vt;
		}  	
					
		
		if(isset($_POST['save'])){			
			
			// subcodes
			$subcodes = $db->query("select id, subcode_of from subcodes where description = '".$_POST['vendor_id']."' and company_id='".$cid."' ");
			foreach($subcodes->fetchAll() as $scs){
				$subcode_id 	= $scs['id'];	
				$subcode_of 	= $scs['subcode_of'];			
			}
			/****************************************/
			
			// prev deposit
			$depositlist =  $db->query("select amount, deposit_amount, deposit_gst, TotalAmount, GSTAmount from deposit_purchase where PoNumber='".$_POST['po_number']."' and company_id=".$cid." ");
			
			$test = array();
			$inr=0;
			foreach($depositlist->fetchAll() as $dp){				
				$test[$inr]['deposit_amount']	= $dp['deposit_amount'];		
				$test[$inr]['deposit_gst'] = $dp['deposit_gst'];	
				$test[$inr]['TotalAmount']	= $dp['TotalAmount'];
				$test[$inr]['amount'] = $dp['amount'];
				$test[$inr]['GSTAmount'] = $dp['GSTAmount'];	
			$inr++;
			}	
						
			$_POST['vendor_id']	= $subcode_id; 			
			$data = $_POST['data'];		
			
			$dd=0;	
			foreach($data as $dt){	
					
					$it=0;
					foreach($test as $t){
						if($dd==$it){
							$depositamount = $t['deposit_amount'];		
							$depositgst = $t['deposit_gst'];	
							$totalamount = $t['TotalAmount'];
							$amount = $t['amount'];
							$totalgst =$t['GSTAmount'];
						}				
					$it++;	
					}
					
					$pototal				= $dt['pototal'];
					$pogst 					= $dt['pogst'];
					
					$pototal_with_gst 		= $pototal + $pogst;
					$pototal_without_gst 	= $pototal;							
					
																		
					if($depositamount>0){
						$newamount = $amount - $depositamount;
						$totalamount = $totalamount;
					} else {
						$newamount = $dt['amount'];
						$totalamount = $pototal_with_gst;
					}
											
					if($depositgst>0){
						$newgst = $totalgst - $depositgst;
					} else {
						$newgst = $dt['gst'];
					}
									
				 	$tamt =  $totalamount - $dt['deposit_amount'];
					
					$dt['total_amount'] = $tamt;
					
					if($tamt==0){
						$db->query("update tblpomaster_purchase set flag=1 where CustPORef='".$_POST['po_number']."' ");				
					}					
					
					$totalamt = $newamount + $newgst;
											
					$actualdepositamount = ($pototal_without_gst/$pototal_with_gst) * $dt['deposit_amount']; 
					
					$dt['deposit_gst']		 = number_format($dt['deposit_amount'] - $actualdepositamount, 2, '.', '');
					$dt['deposit_amount'] 	 = number_format($actualdepositamount, 2, '.', '');
												
					$dt['amount'] = $newamount;
					$dt['gst'] = $newgst;	
						
					if($dt['currency_rate']==0){
						$dt['currency_rate'] = 1;
					}
							
					$dt['PayDate'] = date("d/m/Y");
				
					
					$PoNumber 			= $_POST['po_number'];
					$Amount 			= $dt['amount'];
					$GSTAmount			= $dt['gst'];
					$TotalAmount		= $dt['total_amount'];	
					$PayDate 			= $dt['PayDate'];
					$company_id			= $cid;					
					$subcode_id			= $subcode_id;
					$deposit_amount		= $dt['deposit_amount'];
					$deposit_gst		= $dt['deposit_gst'];
					$TaxCode			= $dt['TaxCode'];
					$Currencyrate		= $dt['currency_rate'];			
					$Currencycode		= $dt['currency_code'];			
					$profit_center_id	= $_POST['profit_center_id'];
					$bank_id			= $_POST['bank_id'];
					
					
					$depositdata =$db->query("insert into deposit_purchase(`PoNumber`,`Amount`,`GSTAmount`,`TotalAmount`,`PayDate`,`company_id`,`bank_id`,`subcode_id`,`deposit_amount`,`deposit_gst`,`TaxCode`,`Currencyrate`,`created_by`,`created_ip`,`created`) values('".$PoNumber."', '".$Amount."', '".$GSTAmount."', '".$TotalAmount."', '".$PayDate."', '".$company_id."', '".$bank_id."', '".$subcode_id."', '".$deposit_amount."', '".$deposit_gst."', '".$TaxCode."', '".$Currencyrate."','".$created_by."','".$created_ip."','".$created."')"); 
			
					if(!$depositdata){
						die('Invalid query: ' . mysql_error());
					}	
											
					$date = date("Y-m-d");
			
					$debit_credit = $deposit_amount + $deposit_gst;
			
					// credit
					$depositcreditdata =$db->query("insert into journal_entries(`subcode_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`taxcode`,`entry_mode`,`subcode_of`,`profit_center_id`,`totalamount`,`currencycode`,`currencyrate`,`trade_type`,`created_by`,`created_ip`,`created`) values('".$subcode_id."', '".$company_id."', '".$date."', 'Deposit Purchase', '".$PoNumber."', '".$debit_credit."', '".$deposit_gst."', '".$TaxCode."', 'Deposit Purchase', '".$subcode_of."', '".$profit_center_id."', '".-abs($deposit_amount)."', '".$Currencycode."', '".$Currencyrate."', 'Trade Creditors','".$created_by."','".$created_ip."','".$created."')"); 
					
					if(!$depositcreditdata){
						die('Invalid query: ' . mysql_error());
					}
					
					// bank subcode
					$bankssubcodes = $db->query("select subcode_id from banks where id = '".$_POST['bank_id']."' and company_id='".$cid."' ");
					foreach($bankssubcodes->fetchAll() as $bk){
						$bank_subcode_id 	= $bk['subcode_id'];					
					}
									
					
					// debit
					$depositdebitdata =$db->query("insert into journal_entries(`subcode_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`taxcode`,`entry_mode`,`profit_center_id`,`created_by`,`created_ip`,`created`) values('".$bank_subcode_id."', '".$company_id."', '".$date."', 'Deposit Purchase', '".$PoNumber."', '".$debit_credit."', '".$deposit_gst."', '".$TaxCode."', 'Deposit Purchase', '".$profit_center_id."','".$created_by."','".$created_ip."','".$created."')"); 
					
					if(!$depositdebitdata){
						die('Invalid query: ' . mysql_error());
					}	
					
					
					
			$dd++;
			}
			
			$created_by = $_SESSION['username'];
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Add";
			$window_name     = "Deposit Purchase";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
			
			/****************************************/								
			header("Location: ?controller=depositpurchase&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/depositpurchase/create.php'); 	   
		}  
	  
    }		
	

    public function error() {
      require_once('views/depositpurchase/error.php');
    }
  }
?>