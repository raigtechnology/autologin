<?php
  class PurchasecodematchController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
								
		$purchasecodematch = $db->query("select PurTaxCode, MatchCode, supplyType from purchasecodematch order by supplyType asc");	
		foreach($purchasecodematch->fetchAll() as $scm) {
			$purchasecodematchlist[] = $scm;
		}	
								  
		require_once('views/purchasecodematch/index.php'); 
	  
    }	
		

    public function error() {
      require_once('views/purchasecodematch/error.php');
    }
  }
?>
