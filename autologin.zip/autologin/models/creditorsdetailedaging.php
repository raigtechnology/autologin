<?php
  class creditorsdetailedaging {
   
  }
?>