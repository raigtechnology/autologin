<?php session_start();
	
	require_once("connection.php");
	
	$pcbamount = $_GET['pcbamount']; 
	
	if($pcbamount >= '2571'){
	
	?>	

             
              <input name="pcb_amount" type="text" id="pcb_amount" style="width:91%;"/></td>
             
            
	<?php
	} else {
	}
	?>		
		