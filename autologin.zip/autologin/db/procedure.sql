
DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `balance`(IN `companyID` INT, IN `profitCenterID` INT, IN `debtorCreditor` VARCHAR(10), IN `accountTypeCode` CHAR(1), IN `subcodeID` INT, IN `toDate` DATE)
BEGIN

SET @companyID = companyID;


SET @debtorCreditor = debtorCreditor;
IF(@debtorCreditor = '') THEN
SET @debtorCreditor  = NULL;
END if;

SET @accountTypeCode = accountTypeCode;
IF(@accountTypeCode = '') THEN
SET @accountTypeCode  = NULL;
END if;

SET @toDate =toDate;

SET @profitCenterID =profitCenterID;
IF(@profitCenterID = '') THEN
SET @profitCenterID  = NULL;
END if;

SET @subcodeID =subcodeID;
IF(@subcodeID = '') THEN
SET @subcodeID  = NULL;
END if;


SET @whereStmtMonth = ' `ChartOfAccount`.`company_id` = @companyID 
	AND MONTH(GL.date) = MONTH(@toDate)
 	AND YEAR(GL.date) = YEAR(@toDate)';


SET @whereStmtYear = ' `ChartOfAccount`.`company_id` = @companyID
	AND YEAR(GL.date) = YEAR(@toDate)';

SET @balanceStmt = 'ROUND(SUM(monthDebit) - SUM(monthCredit),2) as monthBalance,
	ROUND(SUM(yearDebit) - SUM(yearCredit),2) as yearBalance
';

CALL codeDeclaration('debtorCreditor');

SET @balanceWhereStmt = ' `ChartOfAccount`.`company_id` = @companyID AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeDebtor) AND MasterAccountCode.company_id = @companyID) ';



IF(@debtorCreditor = 'debitor') THEN
SET @whereStmtMonth = CONCAT(@whereStmtMonth,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeDebtor) AND MasterAccountCode.company_id = @companyID)');

SET @whereStmtYear = CONCAT(@whereStmtYear,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeDebtor) AND MasterAccountCode.company_id = @companyID)');

SET @balanceStmt = 'ROUND(SUM(monthDebit) - SUM(monthCredit),2) as monthBalance,
	ROUND(SUM(yearDebit) - SUM(yearCredit),2) as yearBalance
';

SET @balanceWhereStmt = ' `ChartOfAccount`.`company_id` = @companyID AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeDebtor) AND MasterAccountCode.company_id = @companyID) ';


END IF;

IF (@debtorCreditor = 'creditor')
THEN
SET @whereStmtMonth = CONCAT(@whereStmtMonth,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeCreditor)  AND MasterAccountCode.company_id = @companyID)');

SET @whereStmtYear = CONCAT(@whereStmtYear,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeCreditor)  AND MasterAccountCode.company_id = @companyID)');

SET @balanceStmt = 'ROUND(SUM(monthCredit) - SUM(monthDebit),2) as monthBalance,
	ROUND(SUM(yearCredit) - SUM(yearDebit),2) as yearBalance
';

SET @balanceWhereStmt = ' `ChartOfAccount`.`company_id` = @companyID AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeCreditor)  AND MasterAccountCode.company_id = @companyID) ';

END IF;



IF(@accountTypeCode IS NOT NULL) THEN
SET @whereStmtMonth = concat(@whereStmtMonth, ' AND `ChartOfAccount`.`code` = @accountTypeCode ');
SET @whereStmtYear = concat(@whereStmtYear, ' AND `ChartOfAccount`.`code` = @accountTypeCode ');
END if;

IF(@subcodeID IS NOT NULL) THEN
SET @whereStmtMonth = concat(@whereStmtMonth, ' AND `ChartOfAccount`.`subcode_id` = @subcodeID ');
SET @whereStmtYear = concat(@whereStmtYear, ' AND `ChartOfAccount`.`subcode_id` = @subcodeID ');
END if;



IF(@profitCenterID IS NOT NULL) THEN
 SET @whereStmtMonth = concat(@whereStmtMonth, ' AND `GL`.`profit_center_id`= @profitCenterID');
 SET @whereStmtYear = concat(@whereStmtYear, ' AND `GL`.`profit_center_id`= @profitCenterID');
END if;

  CALL balanceGeneric(@whereStmtMonth, @whereStmtYear,@balanceWhereStmt, @debtorCreditor, @companyID, @profitCenterID,NULL);


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `balanceGeneric`(IN `whereStmtMonth` TEXT, IN `whereStmtYear` TEXT, IN `balanceWhereStmt` TEXT, IN `debtorCreditor` VARCHAR(10), IN `companyID` INT, IN `profitCenterID` INT, IN `projectID` INT)
BEGIN

SET @whereStmtMonth = whereStmtMonth;
SET @whereStmtYear = whereStmtYear;

SET @companyID = companyID;
SET @profitCenterID = profitCenterID;
SET @projectID = projectID;

SET @balanceStmt = 'ROUND(SUM(monthCredit) - SUM(monthDebit),2) as monthBalance,
	ROUND(SUM(yearCredit) - SUM(yearDebit),2) as yearBalance';


IF(@debtorCreditor = 'debitor') THEN
SET @balanceStmt = 'ROUND(SUM(monthDebit) - SUM(monthCredit),2) as monthBalance,
	ROUND(SUM(yearDebit) - SUM(yearCredit),2) as yearBalance
';

END IF;

IF (@debtorCreditor = 'creditor')
THEN
SET @balanceStmt = 'ROUND(SUM(monthCredit) - SUM(monthDebit),2) as monthBalance,
	ROUND(SUM(yearCredit) - SUM(yearDebit),2) as yearBalance
';
END IF;

SET @balanceWhereStmt = balanceWhereStmt;
IF(@balanceWhereStmt = '' OR ISNULL(@balanceWhereStmt)) THEN
SET @balanceWhereStmt  = ' ChartOfAccount.company_id = @companyID ';
END if;



SET @stmt = CONCAT('
SELECT `date`,
	`ref`,
	`description`,
	`code`,
    `code_desc`,
    `special_acc`, 
	`subcode_id`,
    `subcode`,
    `subcode_desc`,Debit  as Debit,Credit,
IFNULL(getOpeningBalance(@companyID,subcode_id,@profitCenterID,@projectID,B,1111-11-11,now()),0)  as openingBalance, 
  ROUND(SUM(IFNULL(yearDebit,0)),2) as yearDebit,
  ROUND(SUM(IFNULL(yearCredit,0)),2) as yearCredit,
  ROUND(SUM(IFNULL(monthDebit,0)),2) as monthDebit, 
  ROUND(SUM(IFNULL(monthCredit,0)),2) as monthCredit,
  ROUND(SUM(IFNULL(monthCredit,0)),2) as monthBalance,
  ROUND(SUM(IFNULL(monthCredit,0)),2) as yearBalance

 FROM(

SELECT   
	`date`,
	`ref`,
	`description`,
	`code`,
    `code_desc`,
    `special_acc`, 
	`subcode_id`,
    `subcode`,
    `subcode_desc`,
 ROUND(SUM(IFNULL(yearDebit,0)),2) as Debit,
 ROUND(SUM(IFNULL(yearCredit,0)),2) as Credit,


IF(ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2) >0,ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2),0)
as yearDebit ,


IF(ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2) <0,ABS(ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2)),0)
as yearCredit ,

-- ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2) >0,ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2),0) as yearDebit , 
-- IF(ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2) <0,ABS(ROUND(SUM(IFNULL(yearDebit,0) - IFNULL(yearCredit,0)),2)),0) as yearCredit , 

IF(ROUND(SUM(IFNULL(monthDebit,0) - IFNULL(monthCredit,0)),2) >0,ROUND(SUM(IFNULL(monthDebit,0) - IFNULL(monthCredit,0)),2),0) as monthDebit , 
IF(ROUND(SUM(IFNULL(monthDebit,0) - IFNULL(monthCredit,0)),2) <0,ABS(ROUND(SUM(IFNULL(monthDebit,0) - IFNULL(monthCredit,0)),2)),0)as monthCredit,

-- ROUND(SUM(IFNULL(yearDebit,0)),2) as yearDebit,
-- ROUND(SUM(IFNULL(yearCredit,0)),2) as yearCredit,
-- ROUND(SUM(IFNULL(monthDebit,0)),2) as monthDebit,
-- ROUND(SUM(IFNULL(monthCredit,0)),2) as monthCredit,
',@balanceStmt,'

FROM (

SELECT 
    -- `ChartOfAccount`.`company_id`,
    -- `ChartOfAccount`.`account_code_id`,
	`GL`.`date`,
    `GL`.`ref`,
`GL`.`description`,
    `ChartOfAccount`.`code`,
    `ChartOfAccount`.`code_desc`,
    `ChartOfAccount`.`special_acc`,
    -- `ChartOfAccount`.`account_code`,
    -- `ChartOfAccount`.`account_desc`,
     `ChartOfAccount`.`subcode_id`,
    -- `ChartOfAccount`.`parent`,
    -- `ChartOfAccount`.`subcode_of`,
    `ChartOfAccount`.`subcode`,
    `ChartOfAccount`.`subcode_desc`,
	0 as yearDebit,
	0 as yearCredit,
	ROUND(SUM( IFNULL(debit,0)),2)*count(DISTINCT GL.id)/count(*) as monthDebit , 
	ROUND(SUM( IFNULL(credit,0)),2)*count(DISTINCT GL.id)/count(*) as monthCredit

FROM
    `chart_of_accounts` AS `ChartOfAccount`
	LEFT JOIN subcodes as Subcode ON Subcode.id = `ChartOfAccount`.`subcode_id` 
	LEFT JOIN `general_ledgers` as GL ON `GL`.`subcode_id` = `ChartOfAccount`.`subcode_id` 
WHERE 
   ', @whereStmtMonth ,'

GROUP BY ChartOfAccount.subcode 

UNION SELECT 
    -- `ChartOfAccount`.`company_id`,
    -- `ChartOfAccount`.`account_code_id`,
`GL`.`date`,
    `GL`.`ref`,
`GL`.`description`,
    `ChartOfAccount`.`code`,
    `ChartOfAccount`.`code_desc`,
    `ChartOfAccount`.`special_acc`,
    -- `ChartOfAccount`.`account_code`,
    -- `ChartOfAccount`.`account_desc`,
     `ChartOfAccount`.`subcode_id`,
    -- `ChartOfAccount`.`parent`,
    -- `ChartOfAccount`.`subcode_of`,
    `ChartOfAccount`.`subcode`,
    `ChartOfAccount`.`subcode_desc`,
	-- ROUND(SUM(Distinct IFNULL(debit,0)),2) + IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,@projectID,D,1111-11-11,now()),0) as yearDebit, 
	-- ROUND(SUM(Distinct IFNULL(credit,0)),2)+ IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,@projectID,C,1111-11-11,now()),0) as yearCredit,
	 ROUND(SUM( IFNULL(debit,0)),2)*count(DISTINCT GL.id)/count(*)  as yearDebit, 
	 ROUND(SUM( IFNULL(credit,0)),2)*count(DISTINCT GL.id)/count(*) as yearCredit,
	0 as monthDebit,
	0 as monthCredit
FROM
    `chart_of_accounts` AS `ChartOfAccount`
	LEFT JOIN subcodes as Subcode ON Subcode.id = `ChartOfAccount`.`subcode_id` 
	LEFT JOIN `general_ledgers` as GL ON `GL`.`subcode_id` = `ChartOfAccount`.`subcode_id` 
WHERE
   ', @whereStmtYear ,'
GROUP BY ChartOfAccount.subcode 


UNION SELECT 
    -- `ChartOfAccount`.`company_id`,
    -- `ChartOfAccount`.`account_code_id`,
`GL`.`date`,
    `GL`.`ref`,
`GL`.`description`,
    `ChartOfAccount`.`code`,
    `ChartOfAccount`.`code_desc`,
    `ChartOfAccount`.`special_acc`,
    -- `ChartOfAccount`.`account_code`,
    -- `ChartOfAccount`.`account_desc`,
     `ChartOfAccount`.`subcode_id`,
    -- `ChartOfAccount`.`parent`,
    -- `ChartOfAccount`.`subcode_of`,
    `ChartOfAccount`.`subcode`,
    `ChartOfAccount`.`subcode_desc`,
	-- IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,@projectID,D,1111-11-11,now()),0) as yearDebit, 
	-- IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,@projectID,C,1111-11-11,now()),0) as yearCredit,

	-- IF (`ChartOfAccount`.`subcode_id` IN (SELECT subcode_id FROM Banks WHERE subcode_id ),0,IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,@projectID,B,1111-11-11,now()),0))  as yearDebit,

	-- IF (`ChartOfAccount`.`subcode_id` IN (SELECT subcode_id FROM Banks WHERE subcode_id ),IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,@projectID,B,1111-11-11,now()),0),0)  as yearCredit, 
	IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,@projectID,B,1111-11-11,now()),0) as yearDebit,
	0 as yearCredit,
	0 as monthDebit,
	0 as monthCredit
FROM
    `chart_of_accounts` AS `ChartOfAccount`
	LEFT JOIN subcodes as Subcode ON Subcode.id = `ChartOfAccount`.`subcode_id` 
	LEFT JOIN `general_ledgers` as GL ON `GL`.`subcode_id` = `ChartOfAccount`.`subcode_id` 
WHERE
   ', @balanceWhereStmt  ,'
GROUP BY ChartOfAccount.subcode 

) balanc 

GROUP BY subcode
)balance
WHERE (yearDebit OR yearCredit OR monthDebit OR  monthCredit )

GROUP BY subcode WITH ROLLUP

 ');


PREPARE executeStmt FROM @stmt;

EXECUTE executeStmt;

DEALLOCATE PREPARE executeStmt;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `codeDeclaration`(IN `declareType` VARCHAR(15))
BEGIN

SET @declareType = declareType;
IF(@declareType = '' || isNull(@declareType)) THEN
SET @declareType  = 'code';
END if;

IF(@declareType = 'code')
THEN
SET @salesAdjestment = 'E';
SET @otherIncomes = 'K';
SET @sales = 'E';
SET @costOfGoodsSold = 'N';
SET @expenses = 'I';

SET @fixedAsset = 'B';
SET @currentLiabilities = 'D';
SET @currentAssets = 'M';
SET @costOfSales = 'F';
SET @equity = 'L'; 

END if;

IF(@declareType = 'id')
THEN

SET @capital = 2;
SET @longTermLiabilities = 3;
SET @fixedAsset = 4;
SET @currentLiabilities = 5;
SET @sales = 6;
SET @costOfSales = 7;
SET @otherIncome = 11;
SET @expenses = 12;
SET @currentAssets = 13;
SET @otherAsset = 16;
SET @otherLiabilities = 18;

SET @costOfGoodsSold = 14;
SET @manufacturingAccount = 8;
SET @salesAdjestments = 17;

END if;

IF(@declareType = 'debtorCreditor')
THEN

SET @tradeDebtor = 1;
SET @tradeCreditor = 4;

END if;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `duePayment`(IN `companyID` INT, IN `profitCenterID` INT, IN `debtorCreditor` VARCHAR(10), IN `toDate` DATE, IN `cid` INT)
BEGIN
SET @companyID = companyID;
SET @profitCenterID = profitCenterID;
SET @debtorCreditor = debtorCreditor;
SET @toDate = toDate;

SET @profitCenterID =profitCenterID;
IF(@profitCenterID = '') THEN
SET @profitCenterID  = NULL;
END if;


CALL codeDeclaration('debtorCreditor');

SET @groupStmt = ' GROUP BY ChartOfAccount.subcode_id WITH rollup';

 SET @whereStmt = ' ChartOfAccount.company_id = @companyID
 	AND `GL`.`date` <= DATE(@toDate) ';


IF(@debtorCreditor = 'debitor') THEN
SET @whereStmt = CONCAT(@whereStmt,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE  CodeDesc.id in (@tradeDebtor) AND MasterAccountCode.company_id = @companyID)');

SET @balanceStmt = ' SUM(IFNULL(debit,0)) + IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,NULL,D,1111-11-11,now()),0) 
-  ROUND(SUM(IFNULL(credit,0)) + IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,NULL,C,1111-11-11,now()),0),2)';

END IF;

IF (@debtorCreditor = 'creditor')
THEN
SET @whereStmt = CONCAT(@whereStmt,' AND ChartOfAccount.subcode_of IN (SELECT subcode.id FROM code_descriptions as CodeDesc
		RIGHT JOIN subcodes as subcode ON subcode.description = CodeDesc.description
		LEFT JOIN `master_account_codes` as MasterAccountCode ON MasterAccountCode.id = subcode.master_account_code_id
WHERE CodeDesc.id in (@tradeCreditor)  AND MasterAccountCode.company_id = @companyID)');

SET @balanceStmt = ' ROUND(SUM(IFNULL(credit,0)) + IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,NULL,C,1111-11-11,now()),0)
-SUM(IFNULL(debit,0)) + IFNULL(getOpeningBalance(@companyID,ChartOfAccount.subcode_id,@profitCenterID,NULL,D,1111-11-11,now()),0) 
,2)';

END IF;

IF(@profitCenterID IS NOT NULL) THEN
SET @whereStmt = CONCAT(@whereStmt,' AND GL.profit_center_id = @profitCenterID ');
END IF;



SET @stmt = CONCAT(' SELECT 
     -- `ChartOfAccount`.`company_id`,
    -- `ChartOfAccount`.`account_code_id`,
    `ChartOfAccount`.`code`,
    -- `ChartOfAccount`.`account_code`,
    -- `ChartOfAccount`.`account_desc`,
     `ChartOfAccount`.`subcode_id`,
    -- `ChartOfAccount`.`parent`,
    -- `ChartOfAccount`.`subcode_of`,
    `ChartOfAccount`.`subcode`,
    `ChartOfAccount`.`subcode_desc`,
    `GL`.`date` as inv_date,
    `GL`.`ref`,
	DATEDIFF(@toDate,`GL`.`date`) as oDueDays,
-- 	ROUND(SUM(IFNULL(debit,0)),2) as debit, 
-- 	ROUND(SUM(IFNULL(credit,0)),2) as credit,
',@balanceStmt,'as balance

FROM
    `chart_of_accounts` AS `ChartOfAccount`
	LEFT JOIN `general_ledgers` as GL ON `GL`.`subcode_id` = `ChartOfAccount`.`subcode_id` 
 WHERE ',@whereStmt, @groupStmt ,' 
-- ORDER BY inv_date ');

PREPARE executeStmt FROM @stmt;

EXECUTE executeStmt;

DEALLOCATE PREPARE executeStmt;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `trialBalance`(IN `companyID` INT, IN `profitCenterID` INT, IN `projectID` INT, IN `toDate` DATE)
BEGIN

SET @companyID = companyID;

SET @toDate =toDate;

SET @profitCenterID = profitCenterID;
IF(@profitCenterID = '') THEN
SET @profitCenterID  = NULL;
END if;

SET @projectID = projectID;
IF(@projectID = '') THEN
SET @projectID  = NULL;
END if;

SET @whereStmtMonth = ' ChartOfAccount.company_id = @companyID  -- AND `Subcode`.`subcode_of`=  0  
	-- AND MONTH(GL.date) = MONTH(@toDate)
 	-- AND YEAR(GL.date) = YEAR(@toDate)
	AND DATE(GL.date) BETWEEN FIRST_DAY(@toDate) AND LAST_DAY(@toDate) 
';

SET @whereStmtYear = '    ChartOfAccount.company_id = @companyID  
-- AND `Subcode`.`subcode_of`= 0 AND YEAR(GL.date) = YEAR(@toDate)
AND DATE(GL.date) <= LAST_DAY(@toDate) 
';

IF(@profitCenterID IS NOT NULL) THEN
SET @whereStmtMonth = concat(@whereStmtMonth, ' AND `GL`.`profit_center_id`= @profitCenterID');
SET @whereStmtYear = concat(@whereStmtYear, ' AND `GL`.`profit_center_id`= @profitCenterID');
END if;

IF(@projectID IS NOT NULL) THEN
SET @whereStmtMonth = concat(@whereStmtMonth, ' AND `GL`.`project_id`= @projectID');
SET @whereStmtYear = concat(@whereStmtYear, ' AND `GL`.`project_id`= @projectID');
END if;

CALL balanceGeneric(@whereStmtMonth, @whereStmtYear,NULL,NULL, @companyID, @profitCenterID,@projectID );

END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `FIRST_DAY`(`day` DATE) RETURNS date
BEGIN
  RETURN ADDDATE(LAST_DAY(SUBDATE(day, INTERVAL 1 MONTH)), 1);
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `getOpeningBalance`(`companyID` INT, `subcodeID` INT, `profitCenterID` INT, `projectID` INT, `type` CHAR(1), `fromDate` DATE, `toDate` DATE) RETURNS float
BEGIN  

SET @balance = 0;
SET @debit = 0;
SET @credit = 0;

SET @profitCenterID =  profitCenterID;
SET @fromDate =  fromDate;
SET @toDate =  toDate;

IF(@profitCenterID = '') THEN
SET @profitCenterID  = NULL;
END if;

SET @projectID =  projectID;
IF(@projectID = '') THEN
SET @projectID  = NULL;
END if;


IF(@projectID IS NULL) THEN

IF(@profitCenterID IS NULL) THEN
	SELECT SUM((COALESCE(debit,0) - COALESCE(credit,0))),
	COALESCE(IFNULL(debit,0),0),
	COALESCE(IFNULL(credit,0),0)
	INTO @balance, @debit, @credit
			FROM  opening_balance
			WHERE `opening_balance`.`subcode_id` = subcodeID
			AND `opening_balance`.`company_id` = companyID
			AND `opening_balance`.`opening_date` BETWEEN DATE(fromDate) AND DATE(toDate)		
			;

ELSE
	SELECT SUM((COALESCE(debit,0) - COALESCE(credit,0))),
	COALESCE(IFNULL(debit,0),0),
	COALESCE(IFNULL(credit,0),0)
	INTO @balance, @debit, @credit
			FROM  opening_balance
			WHERE `opening_balance`.`subcode_id` = subcodeID
			AND  `opening_balance`.`profit_center_id` = profitCenterID
			AND `opening_balance`.`company_id` = companyID
			AND `opening_balance`.`opening_date` BETWEEN DATE(fromDate) AND DATE(toDate);
END if;

END if;

if (type = 'D') THEN
RETURN @debit;
END IF;

if (type = 'C') THEN
RETURN @credit;
END IF;

RETURN @balance;

END$$

DELIMITER ;
	