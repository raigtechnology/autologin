<?php
  class ReversechargeController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    	    
						
		$purchaseinvoicelistgroup = array();
		$purchaseinvoicegroup = $db->query("select je.memo from journal_entries as je where je.company_id='".$cid."' and je.taxcode = 'OP' group by je.memo ");	
		foreach($purchaseinvoicegroup->fetchAll() as $jel) {
			$purchaseinvoicelistgroup[] = $jel;
		}  		
		
		$purchaseinvoicelist = array();
		$purchaseinvoice = $db->query("select je.date, je.memo, sc.code, sc.description, je.debit, je.credit, pc.profit_center_code from journal_entries as je left join subcodes as sc on sc.id = je.subcode_id  left join profit_centers as pc on pc.id = je.profit_center_id where je.company_id='".$cid."' and  sc.company_id='".$cid."'  ");	
		foreach($purchaseinvoice->fetchAll() as $je) {
			$purchaseinvoicelist[] = $je;
		}  	
						  
	  require_once('views/reversecharge/index.php'); 
	  
    }		
		
		
	
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
		
		
		$company = $db->query("select MixedSupply, inv_prefix from companies where id='".$cid."'  ");	
		foreach($company->fetchAll() as $cm) {
			$supply_type = $cm['MixedSupply'];
			$inv_prefix = $cm['inv_prefix'];
		}  	
		
		if($supply_type=="Y"){
			$type = 'MIX';
			$stype = "Mixed";
		} else if($supply_type=="N"){
			$type = 'TAXABLE';
			$stype = "Standard";
		} 
		
		$_SESSION['type'] = $type;
		
		
		// account types
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id != '6' ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}  
		
		// vendor
		$vendorslist = array();
		$vendors = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='5' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors') order by sc.description asc");	
		foreach($vendors->fetchAll() as $ct) {
			$vendorslist[] = $ct;
		}  	
		
		// banks
		$bankslist = array();
		$banks = $db->query("select bl.bank_name, bk.subcode_id from banks as bk left join bank_lists as bl on bl.id = bk.bank_list_id left join subcodes as sc on sc.id = bk.subcode_id where bk.company_id=".$cid." order by bl.bank_name");	
		foreach($banks->fetchAll() as $bk) {
			$bankslist[] = $bk;
		}  
		
		
		// sales taxcode master		
		$salestaxcodemasterlist = array();
		$salestaxcodemaster = $db->query("select PurTaxCode from purchasecodematch where supplyType = '".$type."' group by PurTaxCode order by PurTaxCode");	
		foreach($salestaxcodemaster->fetchAll() as $tm) {
			$salestaxcodemasterlist[] = $tm;
		}  	
		
		// purchase taxcode master		
		$purchasetaxcodemasterlist = array();
		$purchasetaxcodemaster = $db->query("select TaxCode,TaxRate,id from purtaxcodemaster order by TaxCode");	
		foreach($purchasetaxcodemaster->fetchAll() as $pm) {
			$purchasetaxcodemasterlist[] = $pm;
		}  	
		
		// tblproduct
		
		$tblproductlist = array();
		$tblproduct = $db->query("select tp.Porductprice, tp.Productdesc, sc.id from tblproduct as tp left join subcodes as sc on sc.description = tp.Productdesc where tp.company_id='".$cid."' and sc.company_id='".$cid."' ");	
		foreach($tblproduct->fetchAll() as $tp) {
			$tblproductlist[] = $tp;
		}  	
					
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
			
		
		if(isset($_POST['save'])){			
						
			$date  				= date("Y-m-d", strtotime($_POST['date']));
			$ref  				= $_POST['ref'];
			//$profit_center_id  	= $_POST['profit_center_id'];
			$vendor_id  		= $_POST['vendor_id'];
			$invoice_no  		= $_POST['invoice_no'];
			$currency_code  	= $_POST['currency_code'];
			$exchange_rate  	= $_POST['exchange_rate'];
			$purchase_order_no  = $_POST['purchase_order_no'];	
			$totalamount 		= $_POST['totalamt'];	// including gst
			$gst 	 			= $_POST['totalgst'];			
			
					
			$tblinvmasterpurchase = $db->query("select * from tblinvmaster_purchase order by AutoInvoiceID desc limit 1 ");										
			foreach($tblinvmasterpurchase->fetchAll() as $timp) {			
				$AutoInvoiceID = $timp['AutoInvoiceID'];
			}
									
			if($AutoInvoiceID==""){
				$new_autoinvoice_id= $inv_prefix.''.date("MM/yy").''.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);			
			} else {
				$old_autoinvoice_id = $AutoInvoiceID;									
				$currentlastsixdigit = substr($old_autoinvoice_id, -6);		 // last six digit							
				$prefixstring = substr($old_autoinvoice_id, 0, -6);			 // prefix string						
				$newlastsixdigit = str_pad($currentlastsixdigit + 1, 6, 0, STR_PAD_LEFT);						 // new last six digit			
				$new_autoinvoice_id = $prefixstring.''.$newlastsixdigit;	 // new invoice id																																							
			}	
			
						
			// master purchase data start
			$subcodes = $db->query("select description, subcode_of, code from subcodes where id = '".$vendor_id."' ");
			foreach($subcodes->fetchAll() as $scs){
				$vendorname 	= $scs['description'];
				$subcode_of 	= $scs['subcode_of'];	
				$account_code 	= $scs['code'];			
			}
			
			$newAutoInvoiceID   = $new_autoinvoice_id;
			$InvRef 			= $invoice_no;
			$PORef 				= $purchase_order_no;
			$InvDate 			= date("d/m/Y", strtotime($date));
			$company_id 		= $cid;			
			$VendorName 		= $vendorname;
			$vendorID 			= $vendor_id;
			$Currencycode 		= $currency_code;
			$Currencyrate 		= $exchange_rate;		
			
			
			// for op taxcode
			$TaxCode			= $_POST['data'][0]['matchcode'];
					
			$masterpurchasedata = $db->query("insert into  tblinvmaster_purchase(`AutoInvoiceID`,`InvRef`,`PORef`,`InvDate`,`company_id`,`VendorName`,`Currencycode`,`Currencyrate`,`vendorID`,`TaxCode`) values('".$newAutoInvoiceID."','".$InvRef."','".$PORef."','".$InvDate."','".$company_id."','".$VendorName."','".$Currencycode."','".$Currencyrate."','".$vendorID."','".$TaxCode."')");	
						
			if(!$masterpurchasedata){
				die('Invalid query: ' . mysql_error());
			}				
			// master purchase data end
			
			// journal entries start
			
			$subcode_id   			= $vendor_id;
			//$profit_center_id 		= $profit_center_id;
			$company_id 			= $cid;
			$date 					= date("Y-m-d", strtotime($date));
			$ref 					= $ref;			
			$memo 					= $invoice_no;			
			$credit 				= $totalamount;		
			$gst 					= $gst;		
			$subcode_of 			= $subcode_of;	
			$entry_mode 			= "Purchase";		
		
			if($TaxCode=="IM" || $TaxCode=="IS"){
				$taxcode = "IM";
			} else {
				$taxocde = $PORef;
			}
						
			// taxcode	
			
			foreach($_POST['data'] as $rdt){
				$price += $rdt['quantity'] * $rdt['unit_price'];
			}
								
			$purchasemasterjournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`subcode_of`,`entry_mode`,`totalamount`,`currencycode`,`currencyrate`,`taxcode`,`trade_type`) values('".$subcode_id."','','".$company_id."','".$date."','".$ref."','".$memo."','".$credit."','".$gst."','".$subcode_of."','".$entry_mode."','".$price."','".$Currencycode."','".$Currencyrate."','".$taxocde."','Trade Creditors')");
			
			if(!$purchasemasterjournaldata){
				die('Invalid query: ' . mysql_error());
			}	
			// journal entries end
			
			// gst bad debt entries start
			
			$account_code  			= $account_code;	
			$gstdate 				= date("Y-m-d", strtotime($date));		
			$description 			= $invoice_no;			
			$ref 					= $ref;			
			$credit 				= $totalamount;		
			$credit_gst 			= $gst;		
			$trade_type 			= "Trade Creditors";	
			$company_id 			= $cid;
			
			$gstbaddebtdata = $db->query("insert into gstbaddebt(`account_code`,`gstdate`,`description`,`ref`,`credit`,`credit_gst`,`trade_type`,`company_id`) values('".$account_code."','".$gstdate."','".$description."','".$ref."','".$credit."','".$credit_gst."','".$trade_type."','".$company_id."')");
			
			if(!$gstbaddebtdata){
				die('Invalid query: ' . mysql_error());
			}	
			// gst bad debt entries end		
					
					
			$data = $_POST['data'];
				
			foreach($data as $dt){
										
				$productdescription = $db->query("select description, subcode_of from subcodes where id = '".$dt['subcode_id']."' and company_id='".$cid."' ");
				foreach($productdescription->fetchAll() as $pds){
					$product_desc 			= $pds['description'];
					$product_subcode_of 	= $pds['subcode_of'];						
				}
				
							
				$autoinvoiceid 			= $newAutoInvoiceID;
				$subcode_id				= $dt['subcode_id'];
				$product_desc 			= $product_desc;
				$quanity 				= $dt['quantity'];
				$unit_price 			= $dt['unit_price'];
				$total_amount 			= $dt['total_amount'];
				$taxcode_purchased 		= $dt['taxcode'];
				$taxcode_matched 		= $dt['matchcode'];
				$gst_amount 			= $dt['gst'];	
				$entry_mode 			= "Purchase";			
				$company_id 			= $cid;	
										
				$totalunitprice			= $quanity * $unit_price;
				
				
				if($total_amount>0){
				
					$productpurchasedata = $db->query("insert into  tblinvproduct_purchase(`AutoInvoiceID`,`ProductDesc`,`Quantity`,`UnitPrice`,`totalunitprice`,`Totalamt`,`TaxCodePurchase`,`TaxCodeMatched`,`GSTamt`,`entry_mode`,`company_id`,`subcode_id`) values('".$autoinvoiceid."','".$product_desc."','".$quanity."','".$unit_price."','".$totalunitprice."','".$total_amount."','".$taxcode_purchased."','".$taxcode_matched."','".$gst_amount."','".$entry_mode."','".$company_id."','".$subcode_id."')");
					
					if(!$productpurchasedata){
						die('Invalid query: ' . mysql_error());
					}	
					
					// journal entries start
			
					$pd_subcode_id   			= $subcode_id;
					$pd_profit_center_id 		= $dt['profit_center_id'];
					$pd_company_id 				= $cid;
					$pd_date 					= date("Y-m-d", strtotime($date));
					$pd_ref 					= $ref;			
					$pd_memo 					= $invoice_no;			
					$pd_debit 					= $total_amount;		
					$pd_gst 					= $gst_amount;		
					$pd_subcode_of 				= $product_subcode_of;	
					$pd_entry_mode 				= "Purchase";		
					
					$productpurchasejournaldata = $db->query("insert into  journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`subcode_of`,`entry_mode`) values('".$pd_subcode_id."','".$pd_profit_center_id."','".$pd_company_id."','".$pd_date."','".$pd_ref."','".$pd_memo."','".$pd_debit."','".$pd_gst."','".$pd_subcode_of."','".$pd_entry_mode."')");
					
					if(!$productpurchasejournaldata){
						die('Invalid query: ' . mysql_error());
					}	
					// journal entries end
				}
											
			}
						
			header("Location: ?controller=reversecharge&action=index&cid=".$cid."");			
					
		} else {	 
		   require_once('views/reversecharge/create.php'); 	   
		}  
	  
    }		
	
	
	// filter
	public function filter() {
     	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];      // company id	    
	 
	   	
		// vendor
		$vendorslist = array();
		$vendors = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='5' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors') order by sc.description asc");	
		foreach($vendors->fetchAll() as $ct) {
			$vendorslist[] = $ct;
		}  	
			
		// banks
		$bankslist = array();
		$banks = $db->query("select bl.bank_name, bk.subcode_id from banks as bk left join bank_lists as bl on bl.id = bk.bank_list_id left join subcodes as sc on sc.id = bk.subcode_id where bk.company_id=".$cid." order by bl.bank_name");								
		foreach($banks->fetchAll() as $bk) {
			$bankslist[] = $bk;
		}  
		
		// subcodes for reverse
		$subcodes_reverselist = array();
		$subcodes_reverse = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.account_desc='CURRENT LIABILITIES' and sc.subcode_of IN (select id from subcodes where description='Trade Creditors')");								
		foreach($subcodes_reverse->fetchAll() as $sc) {
			$subcodes_reverselist[] = $sc;
		}  
		
		// for filter		

       if(isset($_POST['Submit'])){		
	   				
			$date		= $_POST['date'];
	   		$bank_id 	= $_POST['bank_id'];
	  		$vendor_id	= $_POST['vendor_id'];	  	   	
						
			$tblinvmasterpurchase_jl = $db->query("select distinct(je.memo), je.date, je.totalamount, je.currencycode, je.currencyrate from journal_entries as je where je.company_id=".$cid." and je.subcode_id = ".$vendor_id." and je.taxcode = 'OP' group by je.memo");			
												
			$i=0;
			$tblinvmasterpurchase_tb = array();
			foreach($tblinvmasterpurchase_jl->fetchAll() as $tbl) {			
				
				$tblinvmasterpurchase1_jl = $db->query("select distinct(memo), date, sum(totalamount) as totalamount, currencycode, currencyrate from journal_entries  where memo='".$tbl['memo']."' and currencyrate!='' and currencycode!='' ");					
				foreach($tblinvmasterpurchase1_jl->fetchAll() as $tbl1) {						
					if($tbl['totalamount']>0){
						$tblinvmasterpurchase_tb[] = $tbl1;
					}
				}	$i++;
			}								
				
			$cnt = count($tblinvmasterpurchase_tb);	
			$tblinvmasterpurchase2 = array();	
			
			if($cnt>0)	{			
			
				foreach($tblinvmasterpurchase_tb as $tb){
								
					$tblinvmasterpurchase = $db->query("select AutoInvoiceID, InvDate, Currencycode, Currencyrate from tblinvmaster_purchase where company_id=".$cid." and vendorID = ".$vendor_id." and InvRef='".$tb['memo']."' and TaxCode = 'OP' and PORef = 'REV'");		
													
					$i=0;
					foreach($tblinvmasterpurchase->fetchAll() as $tbl) {			
										
						$tblinvproductpurchase = $db->query("select tmp.InvRef, tmp.AutoInvoiceID, sum(tpp.totalunitprice) as totalamount, tmp.currencycode, tmp.currencyrate, tmp.InvDate from tblinvproduct_purchase as tpp left join tblinvmaster_purchase as tmp on tmp.AutoInvoiceID = tpp.AutoInvoiceID where tpp.AutoInvoiceID ='".$tbl['AutoInvoiceID']."' ");					
						foreach($tblinvproductpurchase->fetchAll() as $tbl1) {						
							$tblinvmasterpurchase2[] = $tbl1;
						
						}	$i++;
					}
					
				}		
			
			}				
		
			require_once('views/reversecharge/filter.php'); 	 
						
        }  else if(isset($_POST['save'])){		
	   					
			$pay_date = date("Y-m-d");
			
			$vendor_id 	= $_POST['vendor_id'];
			$bank_id 	= $_POST['bank_id'];
			
			
			foreach($_POST['data'] as $dt){											
				
				if($dt['selectedrow']==1){
												
					/***************************************************************************************/
					
					$newinvoiceentry = $db->query("select tpp.subcode_id, tmp.InvRef, tmp.AutoInvoiceID, tpp.Totalamt, tpp.TaxCodeMatched, tpp.GSTamt, tpp.totalunitprice, tmp.Currencycode, tmp.Currencyrate, tmp.InvDate from tblinvproduct_purchase as tpp left join tblinvmaster_purchase as tmp on tmp.AutoInvoiceID = tpp.AutoInvoiceID where tpp.AutoInvoiceID ='".$dt['AutoInvoiceID']."'");								
					foreach($newinvoiceentry->fetchAll() as $nie) {						
						
						$prev_subcode_id 		= $nie['subcode_id'];
						$prev_profit_center_id	= 0;
						$prev_company_id		= $cid;
						$prev_date 				= $pay_date;
						$prev_ref				= "reverse";
						$prev_memo				= $nie['InvRef'];
						$prev_autoinvoiceid		= $nie['AutoInvoiceID'];
						$prev_amount			= $nie['Totalamt'];						
						$prev_totalamount		= $nie['totalunitprice'];	
						$prev_currencycode		= $nie['Currencycode'];	
						$prev_currencyrate		= $nie['Currencyrate'];	
						$prev_trade_type		= "Trade Creditors";
						$prev_gst				= $nie['GSTamt'];	
						$prev_taxcode			= $nie['TaxCodeMatched'];
						$prev_entry_mode		= "Reverse Charge";
						
						$prev_tot_amount  +=$prev_amount;
						$prev_tot_gst +=$prev_gst;
						
						$prev_totalamount_foriegn += $prev_totalamount;
						
						//debit 
						$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`,`gst`,`taxcode`)values('".$prev_subcode_id."','".$prev_profit_center_id."','".$prev_company_id."','".$prev_date."','".$prev_ref."','".$prev_memo."','".$prev_amount."','".$prev_entry_mode."','".$prev_gst."','".$prev_taxcode."')");	
						
					}
						//// credit
						$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`totalamount`,`currencycode`,`currencyrate`,`subcode_of`,`entry_mode`,`gst`) values ('".$vendor_id."','".$prev_profit_center_id."','".$prev_company_id."','".$prev_date."','".$prev_ref."','".$prev_memo."','".$prev_tot_amount."','".$prev_totalamount_foriegn."','".$prev_currencycode."','".$prev_currencyrate."','".$prev_subcode_of."','".$prev_entry_mode."','".$prev_tot_gst."')");		
					
							
					
					/***************************************************************************************/
										
											
					$debit_subcode_id		= $vendor_id; // debit
					$credit_subcode_id		= $bank_id; // credit
					$memo					= $prev_memo;
					$profit_center_id 		= $profit_center_id;
					$company_id 			= $cid;
					$ref					= "reverse"; // dt
					$debit		 			= $dt['rmamount'];
					$credit		 			= $dt['rmamount'];
					$totalamount 			= -abs($dt['currency_amount']);
					$currencyrate 			= $dt['currency_rate'];	
					$currencycode 			= $dt['currency_code'];	
					$subcode_of 			= $subcode_of;	// dt					
					$entry_mode 			= "Reverse Charge";		
									
					$sub_total_amount1 		= $totalamount;	
					$total_amount 			= abs($sub_total_amount1) * $currencyrate; 					
					$gst					= $total_amount * (6/100);						
						
					$t_amount = $total_amount + $gst;	
																
					// debit					
					$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`totalamount`,`currencycode`,`currencyrate`,`subcode_of`,`entry_mode`,`gst`) values ('".$debit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$t_amount."','".$totalamount."','".$currencycode."','".$currencyrate."','".$subcode_of."','".$entry_mode."','".$gst."')");		
														
					//// credit
					$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`,`gst`,`taxcode`)values('".$credit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$t_amount."','".$entry_mode."','".$gst."','".$prev_taxcode."')");	
							
					// tblinvoice					
					$subcodes = $db->query("select description from subcodes where company_id='".$cid."' and id = '".$vendor_id."'");								
					foreach($subcodes->fetchAll() as $sc) {					
						$vendorname = $ids['description'];
					}
					
					
					$tblinvmps = $db->query("select AutoInvoiceID from tblinvmaster_sales_rcm where company_id = '".$cid."' order by AutoInvoiceID desc limit 1");										
					foreach($tblinvmps->fetchAll() as $mps) {				
						$AutoInvoiceID = $mps['AutoInvoiceID'];
					}
					
					$comp = $db->query("select inv_prefix from companies where id=".$cid."");										
					foreach($comp->fetchAll() as $cs) {				
						$inv_prefix = $cs['inv_prefix'];
					}
																	
										
					if($AutoInvoiceID==""){
						$new_autoinvoice_id= $inv_prefix.'/'.date("My").'/'.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);			
					} else {
						$old_autoinvoice_id = $AutoInvoiceID;									
						$currentlastsixdigit = substr($old_autoinvoice_id, -6);		 // last six digit							
						$prefixstring = substr($old_autoinvoice_id, 0, -6);			 // prefix string						
						$newlastsixdigit = str_pad($currentlastsixdigit + 1, 6, 0, STR_PAD_LEFT);						 // new last six digit			
						$new_autoinvoice_id = $prefixstring.''.$newlastsixdigit;	 // new invoice id																																							
					}							
																		
									
					$InvRef 			= $memo;					
					$InvDate 			= $pay_date;
					$company_id 		= $company_id;			
					$VendorName 		= $vendorname;
					$Currencycode 		= $currencycode;
					$Currencyrate 		= $currencyrate;	
						
					// invoice master purchase dummy data
				//	$db->query("insert into  tblinvmaster_purchase_rcm(`AutoInvoiceID`,`InvRef`,`InvDate`,`company_id`,`VendorName`,`Currencycode`,`Currencyrate`,`Gstinvdate`) values('".$new_autoinvoice_id."','".$InvRef."','".$InvDate."','".$company_id."','".$VendorName."','".$Currencycode."','".$Currencyrate."','".$InvDate."')");
					
					// invoice product purchase dummy data
					$autoinvoiceid 			= $new_autoinvoice_id;
					$subcode_id				= $dt['subcode_id'];
					$product_desc 			= "test product";
					$quanity 				= 1;
					$unit_price 			= $dt['currency_amount'];
					$total_amount 			= $dt['currency_amount'];
					$taxcode_purchased 		= 'SR';
					$taxcode_matched 		= 'TX';				
					$entry_mode 			= "Reverse Charge";
					$company_id 			= $company_id;	
					
					$sub_total_amount 		= $unit_price;	
					$total_amount 			= $sub_total_amount * $Currencyrate; 					
					$gst					= $total_amount * (6/100);	
					
				 //   $db->query("insert into  tblinvproduct_purchase_rcm(`AutoInvoiceID`,`ProductDesc`,`Quantity`,`UnitPrice`,`Totalamt`,`GSTamt`,`TaxCodePurchase`,`TaxCodeMatched`,`entry_mode`,`company_id`) values('".$autoinvoiceid."','".$product_desc."','".$quanity."','".$unit_price."','".$total_amount."','".$gst."','".$taxcode_purchased."','".$taxcode_matched."','".$entry_mode."','".$company_id."')");
					 
					 // purchase journal entries start					 
					 $amount_with_gst = $total_amount + $gst; 
					 
					 // credit					
				//	$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`totalamount`,`subcode_of`,`entry_mode`,`gst`) values ('".$debit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$amount_with_gst."','".$amount_with_gst."','".$subcode_of."','".$entry_mode."','".$gst."')");		
														
					//// debit
				//	$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`entry_mode`,`gst`)values('".$credit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$amount_with_gst."','".$entry_mode."','".$gst."')");	
								 
					 // purchase journal entries end					 
											
					//  invoice master sales dummy data	
														
					$InvDate 			= $pay_date;
					$company_id 		= $company_id;			
					$VendorName 		= $vendorname;
					$CurrencyCode 		= $currencycode;
					$Currencyrate 		= $currencyrate;
					
					$db->query("insert into  tblinvmaster_sales_rcm(`AutoInvoiceID`,`InvDate`,`company_id`,`VendorName`,`CurrencyCode`,`Currencyrate`) values('".$autoinvoiceid."','".$InvDate."','".$company_id."','".$VendorName."','".$CurrencyCode."','".$Currencyrate."')");	
				
					// invoice product sales dummy data
					//$autoinvoiceid 			= $InvRef;
					$subcode_id				= $dt['subcode_id'];
					$product_desc 			= "test product";
					$quanity 				= 1;
					$unit_price 			= $dt['currency_amount'];
					//$total_amount 			= $dt['currency_amount'];					
					$taxcode_matched 		= 'DS';				
					$entry_mode 			= "Reverse Charge";
					$company_id 			= $company_id;		
										
		    		$db->query("insert into tblinvproduct_sales_rcm(`AutoInvoiceID`,`ProductDesc`,`Quantity`,`UnitPrice`,`Totalamt`,`TaxCode`,`company_id`) values('".$autoinvoiceid."','".$product_desc."','".$quanity."','".$unit_price."','".$total_amount."','".$taxcode_matched."','".$company_id."')");
					
					// sales journal entries start
					
				//	 // debit					
					$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`totalamount`,`subcode_of`,`entry_mode`,`gst`) values ('".$debit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$amount_with_gst."','".$amount_with_gst."','".$subcode_of."','Sales','".$gst."')");		
														
					//// credit
					$db->query("insert into journal_entries(`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`entry_mode`,`gst`)values('".$credit_subcode_id."','".$profit_center_id."','".$company_id."','".$pay_date."','".$ref."','".$memo."','".$amount_with_gst."','Sales','".$gst."')");	
					
					// sales journal entries end
								
					// gain or loss calculation
					$prev_currency_rate 		= $prev_currencyrate;
					$payment_currency_amount	= $dt['currency_amount'];
				
					$amount_for_find_difference1 = $payment_currency_amount * $prev_currency_rate; // old value
					$amount_for_find_difference2 = $payment_currency_amount * $currencyrate; // new value
					
					$amount_for_find_difference1 = $amount_for_find_difference1 + $prev_gst; 
					$amount_for_find_difference2 = $amount_for_find_difference2 + $gst;	
					
															
					if($amount_for_find_difference1<$amount_for_find_difference2){					
						$difference = $amount_for_find_difference2 - $amount_for_find_difference1;		 // loss	
						//echo "Loss : ".$loss_difference.'<br>';													
					} else if($amount_for_find_difference1>$amount_for_find_difference2){					
						$difference = $amount_for_find_difference1 - $amount_for_find_difference2;		// gain		
						//echo "Gain : ".$gain_difference.'<br>';
					} else {
						//echo "There is no difference";
					}
					
					if($difference>0){					
						$db->query("insert into tbl_es43(`invoice_no`,`invoice_date`,`gst`,`company_id`,`TaxCode`,`transaction_type`)values('".$memo."','".$pay_date."','".$difference."','".$company_id."','ES43','Reverse Charge')");	
					}								
							
					// tblinv master purchase
					$update_qry1 = $db->query("update tblinvmaster_purchase set Gstinvdate = '".$InvDate."' where company_id = '".$cid."' and InvRef = '".$memo."' ");				
					//tblinv product purchase
					$update_qry2 = $db->query("update tblinvproduct_purchase set TaxCodePurchase = 'SR', TaxCodeMatched = 'TX' where company_id = '".$cid."' and AutoInvoiceID = '".$prev_autoinvoiceid."' ");				
												
				} 
			}	
			
		
							
			header("Location: ?controller=reversecharge&action=index&cid=".$cid."");			
			
        }  else {
			
			require_once('views/reversecharge/filter.php'); 	 
			
		}	
		
		  
		            	
   }
	
	

    public function error() {
      require_once('views/reversecharge/error.php');
    }
  }
?>
