<?php
  class DepositsalesnonrefundableController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		// customer
		$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='13' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		$fromdate = date("01/01/Y");
		$todate = date("d/m/Y");
		
		$cond="";
		$customer_id=0;
		$ponumber=0;
		if(isset($_POST['submit'])){
				
			/*$fromdate = $_POST['from_date'];
			$todate = $_POST['to_date'];				
				
			if(empty($fromdate)){
				$fromdate = date("01/01/Y");
				$todate = date("d/m/Y");
			}*/
			
			$customer_id = $_POST['customer_id'];
			$ponumber = $_POST['ponumber'];
			
			if($ponumber!=""){
					$cond=" and ds.subcode_id='".$customer_id."' and ds.PoNumber='".$ponumber."' ";			
			} else {
				$cond=" and ds.subcode_id='".$customer_id." '";			
			}
		
		}		
		
			
				
		$pomaster = $db->query("select distinct(PoNumber) from deposit_sales where companyID ='".$cid."' and subcode_id='".$customer_id."' group by PoNumber ");
		
		$pom_sales = array();
		foreach($pomaster as $po){	
			$pom_sales[] = $po;		
		}		
		
		//and  STR_TO_DATE(ds.PayDate,'%d/%m/%Y') BETWEEN '".$fromdate."' AND '".$todate."'
							
		$depositsaleslist = array();
		$depositsales = $db->query("select ds.AutoDepositID, ds.cheque_no, ds.reference_no, ds.PayDate, ds.PoNumber, ds.receipt_no, ds.deposit_amount, ds.deposit_gst from deposit_sales as ds where ds.deposit_amount>0 and ds.companyID='".$cid."'  ".$cond." order by ds.PayDate");	
					
		foreach($depositsales->fetchAll() as $ds) {
			$depositsaleslist[] = $ds;
		}  	
		
				
						  
	  require_once('views/depositsalesnonrefundable/index.php'); 
	  
    }		
	
		
	// create
	
	public function create() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();// db connection	
		$cid = $_GET['cid'];      // company id	    
		
		// profit center
		$profitcenterlist = array();
		$profit_centers = $db->query("select id, profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profit_centers->fetchAll() as $pc) {
			$profitcenterlist[] = $pc;
		}  	
		
		// BANK LIST
		$banklist = array();
		$banks = $db->query("select b.id, bl.bank_name,b.bank_branch from banks as b left join bank_lists as bl on bl.id = b.bank_list_id where b.company_id='".$cid."' and b.subcode_id>0 order by bl.bank_name asc ");	
		foreach($banks->fetchAll() as $bl) {
			$banklist[] = $bl;
		}  			
			
		// customer
		/*$customerslist = array();
		$customers = $db->query("select sc.description, sc.id from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id where sc.company_id=".$cid." and mac.company_id='".$cid."' and mac.account_type_id='13' and sc.subcode_of IN (select id from subcodes where description='Trade Debtors' and company_id='".$cid."') order by sc.description asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	*/
		
		
		$customerslist = array();
		$customers = $db->query("select * from tblcustomer where company_id='".$cid."' order by CompanyName asc");	
		foreach($customers->fetchAll() as $ct) {
			$customerslist[] = $ct;
		}  	
		
		$debtors = $db->query("select id from subcodes where description = 'Trade Debtors' and company_id='".$cid."' ");
		foreach($debtors->fetchAll() as $dpt){
			$debtorid 			= $dpt['id'];									
		}	
			
			
		// sales taxcode master		
	$salestaxcodemasterlist = array();
	$salestaxcodemaster = $db->query("select TaxCode,TaxRate,id from salestaxcodemaster order by TaxCode");	
	foreach($salestaxcodemaster->fetchAll() as $tm) {
		$salestaxcodemasterlist[] = $tm;
	}  		
			
			
		
		if(isset($_POST['submit']) && $_POST['submit']=="Save"){			
			
			$depositsales = $db->query("select * from deposit_sales order by receipt_no desc limit 1 ");										
			foreach($depositsales->fetchAll() as $ds) {
				$receipt_no = $ds['receipt_no'];
			}						
						
			if($receipt_no==""){
				$new_receipt_no= 'DP'.str_pad(000000 + 1, 6, 0, STR_PAD_LEFT);			
			} else {
				$old_receipt_no = $receipt_no;									
				$currentlastsixdigit = substr($old_receipt_no, -6);		 // last six digit							
				$prefixstring = substr($old_receipt_no, 0, -6);			 // prefix string						
				$newlastsixdigit = str_pad($currentlastsixdigit + 1, 6, 0, STR_PAD_LEFT);						 // new last six digit			
				$new_receipt_no = $prefixstring.''.$newlastsixdigit;	 // new invoice id																																							
			}	
			
						
			// subcodes
			$tblsc = $db->query("select CompanyName from tblcustomer where AutoCustomerID = '".$_POST['customer_id']."' and company_id='".$cid."' ");
			foreach($tblsc->fetchAll() as $tcs){				
				$customername 	= $tcs['CompanyName'];			
			}			
			
			$subcodes = $db->query("select id, subcode_of from subcodes where description = '".$customername."' and company_id='".$cid."' ");
			foreach($subcodes->fetchAll() as $scs){
				$subcode_id 	= $scs['id'];	
				$subcode_of 	= $scs['subcode_of'];			
			}
			
			
		
			
if($_POST['reference_no']!="" || $_POST['reference']!=""){

	if($_POST['reference']!=""){
		if($_POST['reference']!="new"){
			$referenceno = $_POST['reference'];					
		} else {
			$referenceno = $_POST['reference_no'];
		}
	} else {
		$referenceno = $_POST['reference_no'];
	}	
		
		
		$old_deposit_amount	 = $_POST['total_amount'] - $_POST['gst'];	
			
		$old_deposit_gst 	 = $old_deposit_amount	* 6/100; 
		$deposit_amount 	 = $old_deposit_amount - $old_deposit_gst;
		$deposit_gst 		 = $deposit_amount * 6/100;			
		
		$deposit_amount		 = number_format($deposit_amount, 2, '.', '');						
		$deposit_gst		 = number_format($deposit_gst, 2, '.', '');
		
		

		$PayDate 			= date("d/m/Y");
		$companyID			= $cid;					
		$subcode_id			= $subcode_id;
		
		$deposit_gst		= $_POST['gst'];
		$TaxCode			= $_POST['taxcode'];
		$Currencyrate		= $_POST['exchange_rate'];			
		$Currencycode		= $_POST['currency_code'];			
		$profit_center_id	= $_POST['profit_center_id'];
		$bank_id			= $_POST['bank_id'];
		$cheque_no			= $_POST['cheque_no'];
		$description		= $_POST['description'];	
		
		$old_foreign_amount     = $_POST['unit_price'];
		$old_foreign_gst        = $_POST['gst_err'];
		
		
		$old_foreign_gst   	 = $old_foreign_amount	* 6/100; 
		$foreign_amount 	 = $old_foreign_amount - $old_foreign_gst;
		$foreign_gst 		 = $foreign_amount * 6/100;			
		
		$foreign_amount		 = number_format($foreign_amount, 2, '.', '');						
		$foreign_gst		 = number_format($foreign_gst, 2, '.', '');
				
		
		$depositdata =$db->query("insert into deposit_sales(`receipt_no`,`description`,`cheque_no`,`reference_no`,`PayDate`,`companyID`,`bank_id`,`subcode_id`,`deposit_amount`,`deposit_gst`,`TaxCode`,`Currencyrate`,`currencycode`,`foreign_amount`,`foreign_gst`,`created_by`,`created_ip`,`created`) values('".$new_receipt_no."','".$description."','".$cheque_no."','".$referenceno."', '".$PayDate."', '".$companyID."', '".$bank_id."', '".$subcode_id."', '".$deposit_amount."', '".$deposit_gst."', '".$TaxCode."', '".$Currencyrate."','".$Currencycode."','".$foreign_amount."','".$foreign_gst."', '".$created_by."', '".$created_ip."', '".$created."')"); 
						
		if(!$depositdata){
				die('Invalid query: ' . mysql_error());
		}	

		$cheque_date = date("Y-m-d");

		$db->query("insert into tblcheque(`company_id`,`BankID`,`CheqDate`,`Payee`,`Amount`,`CheqNO`,`CheqType`) values('".$companyID."','".$bank_id."','".$cheque_date."', '".$customername."', '".$_POST['total_amount']."', '".$cheque_no."', 'Deposit')"); 

		$debit_credit = $deposit_amount + $deposit_gst;
					
		// credit
		$depositcreditdata =$db->query("insert into journal_entries(`subcode_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`taxcode`,`entry_mode`,`subcode_of`,`profit_center_id`,`totalamount`,`currencycode`,`currencyrate`,`trade_type`,`created_by`,`created_ip`,`created`) values('".$subcode_id."', '".$companyID."', '".$cheque_date."', 'Deposit Sales', '".$_POST['reference_no']."', '".$debit_credit."', '".$deposit_gst."', '".$TaxCode."', 'Deposit Sales', '".$subcode_of."', '".$profit_center_id."', '".-abs($deposit_amount)."', '".$Currencycode."', '".$Currencyrate."', 'Trade Debtors', '".$created_by."', '".$created_ip."', '".$created."')"); 
		
		if(!$depositcreditdata){
			die('Invalid query: ' . mysql_error());
		}
		
		// bank subcode
		$bankssubcodes = $db->query("select subcode_id from banks where id = '".$_POST['bank_id']."' and company_id='".$cid."' ");
		foreach($bankssubcodes->fetchAll() as $bk){
			$bank_subcode_id 	= $bk['subcode_id'];					
		}
		
	
		// debit
		$depositdebitdata =$db->query("insert into journal_entries(`subcode_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`taxcode`,`entry_mode`,`profit_center_id`,`created_by`,`created_ip`,`created`) values('".$bank_subcode_id."', '".$companyID."', '".$cheque_date."', 'Deposit Sales', '".$_POST['reference_no']."', '".$debit_credit."', '".$deposit_gst."', '".$TaxCode."', 'Deposit Sales', '".$profit_center_id."', '".$created_by."', '".$created_ip."', '".$created."')"); 
		
		if(!$depositdebitdata){
			die('Invalid query: ' . mysql_error());
		}	


		header("Location: ?controller=depositsalesnonrefundable&action=index&cid=".$cid."");	


} else {			
			
/*****************************************************************/
			
										
			// prev deposit
			$depositlist =  $db->query("select amount, gamount, deposit_amount, deposit_gst, TotalAmount, GSTAmount from deposit_sales where PoNumber='".$_POST['po_number']."' and companyID=".$cid." ");
			
			$test = array();
			$inr=0;
			foreach($depositlist->fetchAll() as $dp){				
				$test[$inr]['deposit_amount']	= $dp['deposit_amount'];		
				$test[$inr]['deposit_gst'] = $dp['deposit_gst'];	
				$test[$inr]['TotalAmount']	= $dp['TotalAmount'];
				$test[$inr]['amount'] = $dp['amount'];
				$test[$inr]['GSTAmount'] = $dp['GSTAmount'];	
				$test[$inr]['gamount'] = $dp['gamount'];	
			$inr++;
			}	
						
			//$_POST['customer_id']	= $subcode_id; 
					
	
			$data = $_POST['data'];		
			
				
			$dd=0;	
			foreach($data as $dt){	
					
				
					
					$it=0;
					foreach($test as $t){
						if($dd==$it){
							$depositamount = $t['deposit_amount'];		
							$depositgst = $t['deposit_gst'];	
							$totalamount = $t['TotalAmount'];
							$amount = $t['amount'];
							$gamount = $t['gamount'];
							$totalgst =$t['GSTAmount'];						
						}				
						
						$toamount += $t['deposit_amount'];
						$togstamount += $t['deposit_gst'];
						
					$it++;	
					}
					
					$famount = $amount + $gamount;
					$fgst	 = $toamount + $togstamount;
					
					$final_amount =  $famount - $fgst;
																			
					if($final_amount==$dt['deposit_amount']){
								
							if($gamount>0){	
																					
								$dt['deposit_gst'] = $dt['deposit_amount'] *6/100;  
								
								$dt['deposit_gst']		 = number_format($dt['deposit_gst'], 2, '.', '');
								$dt['deposit_amount'] 	 = number_format($dt['deposit_amount'], 2, '.', '');	
							
							} else {
							
								$dt['deposit_gst']		 = number_format(0, 2, '.', '');
								$dt['deposit_amount'] 	 = number_format($dt['deposit_amount'], 2, '.', '');	
							
							}
							
							$db->query("update tblpomaster_sales set flag=1 where CustPORef='".$_POST['po_number']."' ");				
													
					
					} else {
										
								$pototal				= $dt['pototal'];
								$pogst 					= $dt['pogst'];
								
								$pototal_with_gst 		= $pototal + $pogst;
								$pototal_without_gst 	= $pototal;							
																					
								if($depositamount>0){							
									$newamount = $amount - $depositamount;
									$totalamount = $totalamount;
								} else {
									$newamount = $dt['amount'];
									$totalamount = $pototal_with_gst;
								}
														
								if($depositgst>0){													
									$newgst = $totalgst - $depositgst;
								} else {
									$newgst = $dt['gst'];
								}
														
												
								$tamt =  $totalamount - $dt['deposit_amount'];
								
								$dt['total_amount'] = $tamt;
								
								if($tamt==0){
									$db->query("update tblpomaster_sales set flag=1 where CustPORef='".$_POST['po_number']."' ");				
								}					
								
								$totalamt = $newamount + $newgst;
													
										
																	
								$actualdepositamount = ($pototal_without_gst/$pototal_with_gst) * $dt['deposit_amount']; 
								
								$dt['deposit_gst']		 = number_format($dt['deposit_amount'] - $actualdepositamount, 2, '.', '');
								$dt['deposit_amount'] 	 = number_format($actualdepositamount, 2, '.', '');
															
								$dt['amount'] = $newamount;
								$dt['gst'] = $newgst;					
					
					}
									
					
						
					if($dt['currency_rate']==0){
						$dt['currency_rate'] = 1;
					}
							
					$dt['PayDate'] = date("d/m/Y");
				
					
					$PoNumber 			= $_POST['po_number'];
					$proid 				= $dt['proid'];
					$procode 			= $dt['procode'];
					$Amount 			= $dt['amount'];
					
					
					if($dt['flg']==1){
						$TotalAmount		= -abs($dt['deposit_amount']);	
						$GSTAmount			= -abs($dt['deposit_gst']);
						$gamount=0;
					} else {
						//$TotalAmount		= $dt['total_amount'];	
						$TotalAmount		= $dt['amount'] - $dt['deposit_amount'];
						$GSTAmount			= $dt['gst'] - $dt['deposit_gst'];
						$gamount			= $dt['gst'];
					}
					
					
					$PayDate 			= $dt['PayDate'];
					$companyID			= $cid;					
					$subcode_id			= $subcode_id;
					$deposit_amount		= $dt['deposit_amount'];
					$deposit_gst		= $dt['deposit_gst'];
					$TaxCode			= $dt['TaxCode'];
					$Currencyrate		= $dt['currency_rate'];			
					$Currencycode		= $dt['currency_code'];			
					$profit_center_id	= $_POST['profit_center_id'];
					$bank_id			= $_POST['bank_id'];
					$cheque_no			= $_POST['cheque_no'];
					
					$memo			= $_POST['memo'];					
							
						
					$depositdata =$db->query("insert into deposit_sales(`receipt_no`,`cheque_no`,`PoNumber`,`AutoPurchaseID`,`Productcode`,`Amount`,`gamount`,`GSTAmount`,`TotalAmount`,`PayDate`,`companyID`,`bank_id`,`subcode_id`,`deposit_amount`,`deposit_gst`,`TaxCode`,`Currencyrate`,`created_by`,`created_ip`,`created`) values('".$new_receipt_no."','".$cheque_no."','".$PoNumber."', '".$proid."', '".$procode."', '".$Amount."', '".$gamount."', '".$GSTAmount."', '".$TotalAmount."', '".$PayDate."', '".$companyID."', '".$bank_id."', '".$subcode_id."', '".$deposit_amount."', '".$deposit_gst."', '".$TaxCode."', '".$Currencyrate."', '".$created_by."', '".$created_ip."', '".$created."')"); 
						
					if(!$depositdata){
						die('Invalid query: ' . mysql_error());
					}	
						
						
					$date = date("Y-m-d");
					
					$debit_credit = $deposit_amount + $deposit_gst;
					
					// credit
					$depositcreditdata =$db->query("insert into journal_entries(`subcode_id`,`company_id`,`date`,`ref`,`memo`,`credit`,`gst`,`taxcode`,`entry_mode`,`subcode_of`,`profit_center_id`,`totalamount`,`currencycode`,`currencyrate`,`trade_type`,`created_by`,`created_ip`,`created`) values('".$subcode_id."', '".$companyID."', '".$date."', 'Deposit Sales', '".$PoNumber."', '".$debit_credit."', '".$deposit_gst."', '".$TaxCode."', 'Deposit Sales', '".$subcode_of."', '".$profit_center_id."', '".-abs($deposit_amount)."', '".$Currencycode."', '".$Currencyrate."', 'Trade Debtors', '".$created_by."', '".$created_ip."', '".$created."')"); 
					
					if(!$depositcreditdata){
						die('Invalid query: ' . mysql_error());
					}
					
					// bank subcode
					$bankssubcodes = $db->query("select subcode_id from banks where id = '".$_POST['bank_id']."' and company_id='".$cid."' ");
					foreach($bankssubcodes->fetchAll() as $bk){
						$bank_subcode_id 	= $bk['subcode_id'];					
					}
					
				
					// debit
					$depositdebitdata =$db->query("insert into journal_entries(`subcode_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`gst`,`taxcode`,`entry_mode`,`profit_center_id`,`created_by`,`created_ip`,`created`) values('".$bank_subcode_id."', '".$companyID."', '".$date."', 'Deposit Sales', '".$PoNumber."', '".$debit_credit."', '".$deposit_gst."', '".$TaxCode."', 'Deposit Sales', '".$profit_center_id."', '".$created_by."', '".$created_ip."', '".$created."')"); 
					
					if(!$depositdebitdata){
						die('Invalid query: ' . mysql_error());
					}	
						
			
					
					
					
			$dd++;
			}
/********************************************************************************/		

		header("Location: ?controller=depositsalesnonrefundable&action=index&cid=".$cid."");	
	
}			
			
						
					
					
		} else {	 
		   require_once('views/depositsalesnonrefundable/create.php'); 	   
		}  
	  
    }		
	
// content print
    	public function contentprint() {      
		
			if(!isset($_SESSION['username'])){
				header("Location: ?controller=users&action=index");		
			}		
			
			$db = Db::getInstance();// db connection	
			$cid = $_GET['cid'];      // company id	    
			$id = $_GET['id']; 
			// customer
			
			$companiesdata = $db->query("select * from companies where id='".$cid."'");	
			foreach($companiesdata->fetchAll() as $cd) {
				$company_name = $cd['company_name'];
				$address = $cd['address'];
			}  	
					
						
			$depositsaleslist = array();
			$depositsales = $db->query("select ds.receipt_no, ds.cheque_no, ds.PoNumber, bk.subcode_id, ds.PayDate, sc.description, ds.deposit_amount, ds.deposit_gst from deposit_sales as ds  left join subcodes as sc on sc.id=ds.subcode_id left join banks as bk on bk.id=ds.bank_id where ds.companyID='".$cid."' and ds.AutoDepositID='".$id."' ");							
			foreach($depositsales->fetchAll() as $ds) {
				$depositsaleslist[] = $ds;
				
				$receipt_no = $ds['receipt_no'];
				$paydate = $ds['PayDate'];				
				$payer = $ds['description'];	
				$cheque_no = $ds['cheque_no'];	
				$amount = $ds['deposit_amount'] + $ds['deposit_gst'];
				$ponumber = $ds['PoNumber'];
				
				
				$banks = $db->query("select description from subcodes where company_id='".$cid."' and id='".$ds['subcode_id']."' ");							
				foreach($banks->fetchAll() as $bk) {
				  $bank_name = $bk['description'];
 				}	
				
				
				$productdesc="";
				$pos = $db->query("select ProductDesc from tblpomaster_sales as pms left join tblpoproduct_sales as pps on pps.AutoPurchaseID = pms.AutoPurchaseID where  pms.company_id='".$cid."' and pms.CustPORef='".$ponumber."' ");							
				foreach($pos->fetchAll() as $po) {
				   $productdesc = $po['ProductDesc'];
 				}	
				
					
			}  	
			
				
							  
		  require_once('views/depositsalesnonrefundable/contentprint.php'); 
		  
		}		
	
	
	
		public function error() {
		  require_once('views/depositsalesnonrefundable/error.php');
		}
	  }
?>