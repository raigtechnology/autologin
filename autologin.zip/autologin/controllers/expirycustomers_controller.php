<?php
  class ExpirycustomersController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();		    
				
		$cid = $_GET['cid']; // companyid
		
		$customerlists = array();				
		$customers = $db->query("select * from registrations group by company_name asc");	
		foreach($customers->fetchAll() as $cus) {
			$customerlists[] = $cus;
		}  		
					
						  
	  require_once('views/expirycustomers/index.php'); 
	  
    }	
	

    public function error() {
      require_once('views/expirycustomers/error.php');
    }
  }
?>