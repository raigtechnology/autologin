<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

  class ComparisonchartController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$cid.'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$todate = date("Y-m-d");	
		
		$monthfromdate = date("Y-m-01");	
		$monthtodate = date("Y-m-t");	
		
		$yearfromdate = date("Y-01-01");	
		$yeartodate = date("Y-m-t");	
		
		
		if(isset($_POST['submit'])){
		
			$todate = date("Y-m-d");	
			$profitcenterid1 = $_POST['profit_center_id'];
			$profitlossid1   = $_POST['masteraccount_id'];
			/*$monthfromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$monthtodate = date("Y-m-d", strtotime($_POST['to_date']));;	*/
			$profit_center_id = $_POST['profit_center_id']; 
			
			$profit_count = count($profit_center_id);
			$period = $_POST['period_id'];
			
			if($period=='1'){ //Yearly
				$fromyear = $_POST['from_year'];
				$toyear   = $_POST['to_year'];
				$difference = $toyear-$fromyear;
				$diff_year  = $difference+1;
						
			}else if($period=='2'){ //Halfly
				$fromyear = $_POST['from_year'];
				$toyear   = $_POST['to_year'];
				$halfid   = $_POST['half_id'];
				
				$difference = $toyear-$fromyear;
				$diff_year  = $difference+1;
			
			}else if($period=='3'){ //Quaterly
				$fromyear = $_POST['from_year'];
				$toyear   = $_POST['to_year'];
				$quaterid = $_POST['quater_id'];
				$difference = $toyear-$fromyear;
				$diff_year  = $difference+1;
			
			}else if($period=='4'){ //Monthly
				$fromdate = $_POST['from_date'];
				$todate   = $_POST['to_date'];
			
			}	
		
		}
		
				
		
		$subcodesList = array();		
		$subcodes = $db->query("select sc.description, sc.id, sc.code from subcodes as sc  where sc.company_id=".$cid." order by sc.description asc");		
		foreach($subcodes->fetchAll() as $sc) {
			$subcodesList[] = $sc;
		} 
		
		$profitcenterslist = array();
		$profitcenters = $db->query("select id,profit_center from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
		$masacclist = array();
		$maslist = $db->query("select account_type_id,account_desc from master_account_codes where company_id='".$cid."' ");	
		foreach($maslist->fetchAll() as $ma) {
			$masacclist[] = $ma;
		}

			
		/******************* Profit & LOSS START  ****/
		//6-sales,7-costofsales,12-expanses,11-otherincome,17-salesadjustment
		

		foreach($profitlossid1 as $pl => $v){
		
		$salessubcodes = $db->query("SELECT sc.id FROM subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id WHERE mac.account_type_id = '".$v."' and sc.company_id = ".$cid." and mac.company_id=".$cid." ORDER BY  sc.id ASC");	
		//$salessubcodesList =  array();	
		foreach($salessubcodes->fetchAll() as $ssc) {
			$salessubcodesList[$v][]= $ssc['id'];
			//$subcodesLists[$v] = $ssc['id'];
		} 		
	
		}
		
		foreach ($salessubcodesList as $arr=>$kk) {
			


			$mastersubcodes = $db->query("SELECT account_desc FROM master_account_codes  WHERE account_type_id = '".$arr."' and company_id = ".$cid."");		
			foreach($mastersubcodes->fetchAll() as $mas) {
				$valname[]= $mas['account_desc'];
			} 	

			$totalprofitloss[] = implode("','", $kk);
		
		}
		
		if($period==1){ // Yearly Base Calculation

		   if($profit_count>1 && $diff_year==1){ // Multiple Profit Center, Singl Year Calculation
				$headertype = "Branch";
		   		$yearfromdate = $fromyear."-01-01";
		   		$yeartodate = $fromyear."-12-31";
				
					foreach($profit_center_id as $pcl => $val){
						if($val!=''){			
							$profitcenter = " AND je.profit_center_id=".$val." ";
							$opprofitcenter = " AND op.profit_center_id=".$val." ";
							$buprofitcenter = " AND b.profit_center_id=".$val." ";
							
							$profitcenters = $db->query("select profit_center from profit_centers where id='".$val."' ");	
							foreach($profitcenters->fetchAll() as $pc) {
								$profitcentername = $pc['profit_center'];
							}
					
						}else {	
						    $profitcenter = " ";
							$opprofitcenter = " "; 
							$buprofitcenter=" ";
						}		
						
						foreach($totalprofitloss as $pl => $v){
							
					$op_balance=0;	
					$openingbalance = $db->query("SELECT abs(sum(op.debit)-sum(op.credit)) as balance FROM opening_balance as op  WHERE op.opening_date BETWEEN '".$yearfromdate."' and '".$yeartodate."' and op.company_id = ".$cid." and op.subcode_id IN ('".$v."') ".$opprofitcenter."  GROUP BY op.profit_center_id ");		
					foreach($openingbalance->fetchAll() as $op) {
						$op_balance+= $op['balance'];
					} 		
												
					$mptbalance=0;
					$multiprofit = $db->query("SELECT abs(sum(je.debit)-sum(je.credit)) as balance FROM journal_entries as je WHERE je.subcode_id IN ('".$v."') and  je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$yearfromdate."') AND date('".$yeartodate."') ".$profitcenter." GROUP BY je.profit_center_id ");		
					foreach($multiprofit->fetchAll() as $mpt) {
						$mptbalance   = $mpt['balance'];						
					}	
					
										
					$actulbalance = $op_balance + $mptbalance ;	
					if($actulbalance==''){
						$actulbalance = 0;
					}else{
						$actulbalance = $actulbalance;
					}
					
					$cars[$profitcentername][] = $actulbalance;

					
				
			}	
		}

					foreach ($cars as $aa=>$amount) {
						$totvalue[$aa] = implode(",", $amount);
						
					}
			
		}


		else if($profit_count==1 && $diff_year>1){ // Single Profit Center, Multiple Year Calculation
				$headertype = "Year";
				foreach($profit_center_id as $pcl => $val){
						if($val!=''){			
							$profitcenter = " AND je.profit_center_id=".$val." ";
							$opprofitcenter = " AND op.profit_center_id=".$val." ";
							$buprofitcenter = " AND b.profit_center_id=".$val." ";
							
							$profitcenters = $db->query("select profit_center from profit_centers where id='".$val."' ");	
							foreach($profitcenters->fetchAll() as $pc) {
								$profitcentername = $pc['profit_center'];
							}
					
						}else {	
						    $profitcenter = " ";
							$opprofitcenter = " "; 
							$buprofitcenter=" ";
						}
				}					
				
				$actulbalance = 0;
				$budgetbalance= 0;
				$variance	  = 0;
				$op_balance   = 0;
				$mptbalance	  = 0;
				$mbptbalance  = 0;
				//echo $profitlossid;
				for($i=$fromyear;$i<=$toyear;$i++){

					foreach($totalprofitloss as $pl => $v){
			
					$op_balance=0;
		   		   $openingbalance = $db->query("SELECT abs(sum(op.debit)-sum(op.credit)) as balance FROM opening_balance as op  WHERE YEAR(op.opening_date) ='".$i."' and op.company_id = ".$cid." and op.subcode_id IN ('".$v."') ".$opprofitcenter."  GROUP BY YEAR(op.opening_date) ");		
					foreach($openingbalance->fetchAll() as $op) {
						$op_balance = $op['balance'];
					} 		
									
					$mptbalance=0;
					$multiprofit = $db->query("SELECT abs(sum(je.debit)-sum(je.credit)) as balance FROM journal_entries as je WHERE je.subcode_id IN ('".$v."') and  je.company_id = ".$cid." AND YEAR(je.date)='".$i."' ".$profitcenter." GROUP BY YEAR(je.date) ");		
					foreach($multiprofit->fetchAll() as $mpt) {
						$mptbalance   = $mpt['balance'];						
					}	
					
				
					
					$actulbalance = $op_balance + $mptbalance ;	
					$budgetbalance=	$mbptbalance;
					$variance	  = $budgetbalance-$actulbalance;
					if($budgetbalance==''){
						$budgetbalance = 0;
					}else{
						$budgetbalance = $budgetbalance;
					}
					
					$actulbalance = $op_balance + $mptbalance ;	
					if($actulbalance==''){
						$actulbalance = 0;
					}else{
						$actulbalance = $actulbalance;
					}
					
					$cars[$i][] = $actulbalance;
					
				
				}	

			}

					foreach ($cars as $aa=>$amount) {
						$totvalue[$aa] = implode(",", $amount);
						
					}	
		}
		
		
		else if($profit_count==1 && $diff_year==1){ // Single Profit Center,Single Year and 12 Months Showing
				$headertype = "Months";
				foreach($profit_center_id as $pcl => $val){
						if($val!=''){			
							$profitcenter = " AND je.profit_center_id=".$val." ";
							$opprofitcenter = " AND op.profit_center_id=".$val." ";
							$buprofitcenter = " AND b.profit_center_id=".$val." ";
							
							$profitcenters = $db->query("select profit_center from profit_centers where id='".$val."' ");	
							foreach($profitcenters->fetchAll() as $pc) {
								$profitcentername = $pc['profit_center'];
							}
					
						}else {	
						    $profitcenter = " ";
							$opprofitcenter = " "; 
							$buprofitcenter=" ";
						}
				}					
				$op_balance = 0;
				$mptbalance = 0;
				$mbptbalance= 0;
				$actulbalance = 0;
				$budgetbalance = 0;
				$variance	= 0;
				for($i=1;$i<=12;$i++){
				  foreach($totalprofitloss as $pl => $v){
					$op_balance = 0;
		   		    $openingbalance = $db->query("SELECT abs(sum(op.debit)-sum(op.credit)) as balance FROM opening_balance as op  WHERE YEAR(op.opening_date) ='".$fromyear."' and MONTH(op.opening_date) ='".$i."' and op.company_id = ".$cid." and op.subcode_id IN ('".$v."') ".$opprofitcenter."  GROUP BY MONTH(op.opening_date) ");		
					foreach($openingbalance->fetchAll() as $op) {
						$op_balance = $op['balance'];
					} 		
												
					$mptbalance = 0;
					$multiprofit = $db->query("SELECT abs(sum(je.debit)-sum(je.credit)) as balance FROM journal_entries as je WHERE je.subcode_id IN ('".$v."') and  je.company_id = ".$cid." AND YEAR(je.date)='".$fromyear."' and MONTH(je.date) ='".$i."' ".$profitcenter." GROUP BY MONTH(je.date) ");		
					foreach($multiprofit->fetchAll() as $mpt) {
						$mptbalance   = $mpt['balance'];						
					}	
					
										
					$actulbalance = $op_balance + $mptbalance ;	
					if($actulbalance==''){
						$actulbalance = 0;
					}else{
						$actulbalance = $actulbalance;
					}
					
					
					$monthname = date("F", strtotime(date("Y") ."-". $i ."-01"));
					$monthname = substr($monthname,0,3);
					$cars[$monthname][] = $actulbalance;
					
					
				}	
			 }
			 
			 foreach ($cars as $aa=>$amount) {
						$totvalue[$aa] = implode(",", $amount);
						
			 }
				
		}
		
		
	 }else if($period==2){ // Halfly Calculation
	 
	 	 if($profit_count>1 && $diff_year==1){ // Multiple Profit Center, Singl Year Calculation
				$headertype = "Branch";
		   		$i  = $fromyear;
				
				if($halfid=='1-6'){
						$fromhalf = $i."-01-01";
						$tohalf   = $i."-06-30";
				}else if($halfid=='7-12'){
						$fromhalf = $i."-07-01";
						$tohalf   = $i."-12-31";
				}
					
		   		/*$yeartodate = $fromyear."-12-31";*/
				
					foreach($profit_center_id as $pcl => $val){
						if($val!=''){			
							$profitcenter = " AND je.profit_center_id=".$val." ";
							$opprofitcenter = " AND op.profit_center_id=".$val." ";
							$buprofitcenter = " AND b.profit_center_id=".$val." ";
							
							$profitcenters = $db->query("select profit_center from profit_centers where id='".$val."' ");	
							foreach($profitcenters->fetchAll() as $pc) {
								$profitcentername = $pc['profit_center'];
							}
					
						}else {	
						    $profitcenter = " ";
							$opprofitcenter = " "; 
							$buprofitcenter=" ";
						}		
					foreach($totalprofitloss as $pl => $v){	
					$op_balance=0;	
					$openingbalance = $db->query("SELECT abs(sum(op.debit)-sum(op.credit)) as balance FROM opening_balance as op  WHERE op.opening_date BETWEEN '".$fromhalf."' and '".$tohalf."' and op.company_id = ".$cid." and op.subcode_id IN ('".$v."') ".$opprofitcenter."  GROUP BY op.profit_center_id ");		
					foreach($openingbalance->fetchAll() as $op) {
						$op_balance+= $op['balance'];
					} 		
												
					$mptbalance=0;
					$multiprofit = $db->query("SELECT abs(sum(je.debit)-sum(je.credit)) as balance FROM journal_entries as je WHERE je.subcode_id IN ('".$v."') and  je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$fromhalf."') AND date('".$tohalf."') ".$profitcenter." GROUP BY je.profit_center_id ");		
					foreach($multiprofit->fetchAll() as $mpt) {
						$mptbalance   = $mpt['balance'];						
					}	
					
					
					
					$actulbalance = $op_balance + $mptbalance ;	
					if($actulbalance==''){
						$actulbalance = 0;
					}else{
						$actulbalance = $actulbalance;
					}
					
					
					$cars[$profitcentername][] = $actulbalance;	
					
				
			}
			
		  }	
		  
		  foreach ($cars as $aa=>$amount) {
				$totvalue[$aa] = implode(",", $amount);
						
		 }	

		}
		
	 	  if($profit_count==1 && $diff_year>1){  // single profit center and multiple year 
				$headertype = "Year";
				
				foreach($profit_center_id as $pcl => $val){
						if($val!=''){			
							$profitcenter = " AND je.profit_center_id=".$val." ";
							$opprofitcenter = " AND op.profit_center_id=".$val." ";
							$buprofitcenter = " AND b.profit_center_id=".$val." ";
							
							$profitcenters = $db->query("select profit_center from profit_centers where id='".$val."' ");	
							foreach($profitcenters->fetchAll() as $pc) {
								$profitcentername = $pc['profit_center'];
							}
					
						}else {	
						    $profitcenter = " ";
							$opprofitcenter = " "; 
							$buprofitcenter=" ";
						}
				}		
				
				$actulbalance = 0;
				$budgetbalance= 0;
				$variance	  = 0;
				$op_balance   = 0;
				$mptbalance	  = 0;
				$mbptbalance  = 0;
				//echo $profitlossid;
				for($i=$fromyear;$i<=$toyear;$i++){
					if($halfid=='1-6'){
						$fromhalf = $i."-01-01";
						$tohalf   = $i."-06-30";
					}else if($halfid=='7-12'){
						$fromhalf = $i."-07-01";
						$tohalf   = $i."-12-31";
					}
					
					foreach($totalprofitloss as $pl => $v){	
					$op_balance=0;
		   		   $openingbalance = $db->query("SELECT abs(sum(op.debit)-sum(op.credit)) as balance FROM opening_balance as op  WHERE op.company_id = ".$cid." and op.subcode_id IN ('".$v."') and op.opening_date BETWEEN '".$fromhalf."' and '".$tohalf."' ".$opprofitcenter."  GROUP BY YEAR(op.opening_date) ");		
					foreach($openingbalance->fetchAll() as $op) {
						$op_balance = $op['balance'];
					} 		
											
					$mptbalance=0;
					$multiprofit = $db->query("SELECT abs(sum(je.debit)-sum(je.credit)) as balance FROM journal_entries as je WHERE je.subcode_id IN ('".$v."') and  je.company_id = ".$cid." AND je.date BETWEEN '".$fromhalf."' and '".$tohalf."' ".$profitcenter." GROUP BY YEAR(je.date) ");		
					foreach($multiprofit->fetchAll() as $mpt) {
						$mptbalance   = $mpt['balance'];						
					}	
					
										
					$actulbalance = $op_balance + $mptbalance ;	
					if($actulbalance==''){
						$actulbalance = 0;
					}else{
						$actulbalance = $actulbalance;
					}
					
					
					$cars[$i][] = $actulbalance;	
					
				
				}
			  }
			  	 foreach ($cars as $aa=>$amount) {
					$totvalue[$aa] = implode(",", $amount);
						
				 }			
	 		}

	 }else if($period==3){ // Quaterly Calculation
	 
	 	 if($profit_count>1 && $diff_year==1){ // Multiple Profit Center, Singl Year Calculation
				$headertype = "Branch";
		   		$i  = $fromyear;			
				if($quaterid=='1-3'){
						$fromquater = $i."-01-01";
						$toquater   = $i."-03-31";
				}else if($quaterid=='4-6'){
						$fromquater = $i."-04-01";
						$toquater   = $i."-06-30";
				}else if($quaterid=='7-9'){
						$fromquater = $i."-07-01";
						$toquater   = $i."-09-30";
				}else if($quaterid=='10-12'){
						$fromquater = $i."-10-01";
						$toquater   = $i."-12-31";
				}
				
				
					foreach($profit_center_id as $pcl => $val){
						if($val!=''){			
							$profitcenter = " AND je.profit_center_id=".$val." ";
							$opprofitcenter = " AND op.profit_center_id=".$val." ";
							$buprofitcenter = " AND b.profit_center_id=".$val." ";
							
							$profitcenters = $db->query("select profit_center from profit_centers where id='".$val."' ");	
							foreach($profitcenters->fetchAll() as $pc) {
								$profitcentername = $pc['profit_center'];
							}
					
						}else {	
						    $profitcenter = " ";
							$opprofitcenter = " "; 
							$buprofitcenter=" ";
						}		
					foreach($totalprofitloss as $pl => $v){		
					$op_balance=0;	
					$openingbalance = $db->query("SELECT abs(sum(op.debit)-sum(op.credit)) as balance FROM opening_balance as op  WHERE op.opening_date BETWEEN '".$fromquater."' and '".$toquater."' and op.company_id = ".$cid." and op.subcode_id IN ('".$v."') ".$opprofitcenter."  GROUP BY op.profit_center_id ");		
					foreach($openingbalance->fetchAll() as $op) {
						$op_balance+= $op['balance'];
					} 		
												
					$mptbalance=0;
					$multiprofit = $db->query("SELECT abs(sum(je.debit)-sum(je.credit)) as balance FROM journal_entries as je WHERE je.subcode_id IN ('".$v."') and  je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$fromquater."') AND date('".$toquater."') ".$profitcenter." GROUP BY je.profit_center_id ");		
					foreach($multiprofit->fetchAll() as $mpt) {
						$mptbalance   = $mpt['balance'];						
					}	
					
				
					
					$actulbalance = $op_balance + $mptbalance ;	
					if($actulbalance==''){
						$actulbalance = 0;
					}else{
						$actulbalance = $actulbalance;
					}
					
					
					$cars[$profitcentername][] = $actulbalance;	
					
					
				
			}	
			
			}
			
			foreach ($cars as $aa=>$amount) {
					$totvalue[$aa] = implode(",", $amount);
						
			}

		}
		
	 	  if($profit_count==1 && $diff_year>1){  // single profit center and multiple year 
				$headertype = "Year";
				
				foreach($profit_center_id as $pcl => $val){
						if($val!=''){			
							$profitcenter = " AND je.profit_center_id=".$val." ";
							$opprofitcenter = " AND op.profit_center_id=".$val." ";
							$buprofitcenter = " AND b.profit_center_id=".$val." ";
							
							$profitcenters = $db->query("select profit_center from profit_centers where id='".$val."' ");	
							foreach($profitcenters->fetchAll() as $pc) {
								$profitcentername = $pc['profit_center'];
							}
					
						}else {	
						    $profitcenter = " ";
							$opprofitcenter = " "; 
							$buprofitcenter=" ";
						}
				}		
				
				$actulbalance = 0;
				$budgetbalance= 0;
				$variance	  = 0;
				$op_balance   = 0;
				$mptbalance	  = 0;
				$mbptbalance  = 0;
				//echo $profitlossid;
				for($i=$fromyear;$i<=$toyear;$i++){
					if($quaterid=='1-3'){
						$fromquater = $i."-01-01";
						$toquater   = $i."-03-31";
					}else if($quaterid=='4-6'){
						$fromquater = $i."-04-01";
						$toquater   = $i."-06-30";
					}else if($quaterid=='7-9'){
						$fromquater = $i."-07-01";
						$toquater   = $i."-09-30";
					}else if($quaterid=='10-12'){
						$fromquater = $i."-10-01";
						$toquater   = $i."-12-31";
					}
					foreach($totalprofitloss as $pl => $v){		
					$op_balance=0;
		   		    $openingbalance = $db->query("SELECT abs(sum(op.debit)-sum(op.credit)) as balance FROM opening_balance as op  WHERE op.company_id = ".$cid." and op.subcode_id IN ('".$v."') and op.opening_date BETWEEN '".$fromquater."' and '".$toquater."' ".$opprofitcenter."  GROUP BY YEAR(op.opening_date) ");		
					foreach($openingbalance->fetchAll() as $op) {
						$op_balance = $op['balance'];
					} 		
											
					$mptbalance=0;
					$multiprofit = $db->query("SELECT abs(sum(je.debit)-sum(je.credit)) as balance FROM journal_entries as je WHERE je.subcode_id IN ('".$v."') and  je.company_id = ".$cid." AND je.date BETWEEN '".$fromquater."' and '".$toquater."' ".$profitcenter." GROUP BY YEAR(je.date) ");		
					foreach($multiprofit->fetchAll() as $mpt) {
						$mptbalance   = $mpt['balance'];						
					}	
					
					$actulbalance = $op_balance + $mptbalance ;	
					if($actulbalance==''){
						$actulbalance = 0;
					}else{
						$actulbalance = $actulbalance;
					}
					
					
					$cars[$i][] = $actulbalance;	
					
					
				
				}
				
				}
				
				foreach ($cars as $aa=>$amount) {
					$totvalue[$aa] = implode(",", $amount);
						
			    }
						
	 		}
			
			if($profit_count==1 && $diff_year==1){  // single profit center and sigle year, single quater
				
					$i  = $fromyear;
					if($quaterid=='1-3'){
						$fromquater = $i."-01-01";
						$toquater   = $i."-03-31";
						$hname    = "1st Quater(Jan-Mar)";
					}else if($quaterid=='4-6'){
						$fromquater = $i."-04-01";
						$toquater   = $i."-06-30";
						$hname    = "2nd Quater(Apr-Jun)";
					}else if($quaterid=='7-9'){
						$fromquater = $i."-07-01";
						$toquater   = $i."-09-30";
						$hname    = "3rd Quater(Jul-Sep)";
					}else if($quaterid=='10-12'){
						$fromquater = $i."-10-01";
						$toquater   = $i."-12-31";
						$hname    = "4th Quater(Oct-Dec)";
					}
				
				$headertype = $hname;
					
				foreach($profit_center_id as $pcl => $val){
						if($val!=''){			
							$profitcenter = " AND je.profit_center_id=".$val." ";
							$opprofitcenter = " AND op.profit_center_id=".$val." ";
							$buprofitcenter = " AND b.profit_center_id=".$val." ";
							
							$profitcenters = $db->query("select profit_center from profit_centers where id='".$val."' ");	
							foreach($profitcenters->fetchAll() as $pc) {
								$profitcentername = $pc['profit_center'];
							}
					
						}else {	
						    $profitcenter = " ";
							$opprofitcenter = " "; 
							$buprofitcenter=" ";
						}
				}		
				
				$actulbalance = 0;
				$budgetbalance= 0;
				$variance	  = 0;
				$op_balance   = 0;
				$mptbalance	  = 0;
				$mbptbalance  = 0;
				
				   foreach($totalprofitloss as $pl => $v){		
				   $op_balance=0;
		   		   $openingbalance = $db->query("SELECT abs(sum(op.debit)-sum(op.credit)) as balance FROM opening_balance as op  WHERE op.company_id = ".$cid." and op.subcode_id IN ('".$v."') and op.opening_date BETWEEN '".$fromquater."' and '".$toquater."' ".$opprofitcenter."  GROUP BY YEAR(op.opening_date) ");		
					foreach($openingbalance->fetchAll() as $op) {
						$op_balance = $op['balance'];
					} 		
											
					$mptbalance=0;
					$multiprofit = $db->query("SELECT abs(sum(je.debit)-sum(je.credit)) as balance FROM journal_entries as je WHERE je.subcode_id IN ('".$v."') and  je.company_id = ".$cid." AND je.date BETWEEN '".$fromquater."' and '".$toquater."' ".$profitcenter." GROUP BY YEAR(je.date) ");		
					foreach($multiprofit->fetchAll() as $mpt) {
						$mptbalance   = $mpt['balance'];						
					}	
					
						
					
					$actulbalance = $op_balance + $mptbalance ;	
					if($actulbalance==''){
						$actulbalance = 0;
					}else{
						$actulbalance = $actulbalance;
					}
					
					
					$cars[$i][] = $actulbalance;	
					
					
					
			
			
			}
			}
			
			foreach ($cars as $aa=>$amount) {
					$totvalue[$aa] = implode(",", $amount);
						
			}
	 
	 }else if($period==4){ // Monthly Calculation
	 		if($profit_count>=1){ // Multiple Profit Center, Singl Year Calculation
				$headertype = "Branch";
		   		
				$fromdate = date('Y-m-d',strtotime($fromdate));
				$todate = date('Y-m-d',strtotime($todate));
				
					foreach($profit_center_id as $pcl => $val){
						if($val!=''){			
							$profitcenter = " AND je.profit_center_id=".$val." ";
							$opprofitcenter = " AND op.profit_center_id=".$val." ";
							$buprofitcenter = " AND b.profit_center_id=".$val." ";
							
							$profitcenters = $db->query("select profit_center from profit_centers where id='".$val."' ");	
							foreach($profitcenters->fetchAll() as $pc) {
								$profitcentername = $pc['profit_center'];
							}
					
						}else {	
						    $profitcenter = " ";
							$opprofitcenter = " "; 
							$buprofitcenter=" ";
						}		
					foreach($totalprofitloss as $pl => $v){			
					$op_balance=0;	
					$openingbalance = $db->query("SELECT abs(sum(op.debit)-sum(op.credit)) as balance FROM opening_balance as op  WHERE op.opening_date BETWEEN '".$fromdate."' and '".$todate."' and op.company_id = ".$cid." and op.subcode_id IN ('".$v."') ".$opprofitcenter."  GROUP BY op.profit_center_id ");		
					foreach($openingbalance->fetchAll() as $op) {
						$op_balance+= $op['balance'];
					} 		
												
					$mptbalance=0;
					$multiprofit = $db->query("SELECT abs(sum(je.debit)-sum(je.credit)) as balance FROM journal_entries as je WHERE je.subcode_id IN ('".$v."') and  je.company_id = ".$cid." AND date(je.date) BETWEEN date('".$fromdate."') AND date('".$todate."') ".$profitcenter." GROUP BY je.profit_center_id ");		
					foreach($multiprofit->fetchAll() as $mpt) {
						$mptbalance   = $mpt['balance'];						
					}	
					
					
					
					$actulbalance = $op_balance + $mptbalance ;	
					$budgetbalance=	$mbptbalance;
					$variance	  = $budgetbalance-$actulbalance;
					if($budgetbalance==''){
						$budgetbalance = 0;
					}else{
						$budgetbalance = $budgetbalance;
					}
					
					$actulbalance = $op_balance + $mptbalance ;	
					if($actulbalance==''){
						$actulbalance = 0;
					}else{
						$actulbalance = $actulbalance;
					}
					
					
					$cars[$profitcentername][] = $actulbalance;	
						
					
				
			}	

		}
		}	
		
		foreach ($cars as $aa=>$amount) {
					$totvalue[$aa] = implode(",", $amount);
						
		}		

	 
	 }
						  
	  require_once('views/comparisonchart/index.php'); 
	  
    }	
	
	
	public function view() {
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
	
		$company_name = $_SESSION['company_name'];
		if($company_name=="SAMPLE COMPANY"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
	
		
		$masteraccountcodeslist = array();
		$master_account_codes = $db->query("select id, account_type_id, account_desc from master_account_codes where company_id='".$cid."' and account_type_id in('4','7','12') ");	
		foreach($master_account_codes->fetchAll() as $mac) {
			$masteraccountcodeslist[] = $mac;
		}
		
		if(isset($_POST['submit'])){		
			
			$from_date = date("d-m-Y", strtotime($_POST['from_date']));
		
		}  
	
	
      require_once('views/comparisonchart/view.php');
    }
		
	

    public function error() {
      require_once('views/comparisonchart/error.php');
    }
	
	// Defining function

/*function GetBal($coid,array  $subcode,$pc1,$year1){
$op_balance=0;
  $openingbalance = $db->query("SELECT abs(sum(op.debit)-sum(op.credit)) as balance FROM opening_balance as op  WHERE YEAR(op.opening_date) ='".$year1."' and op.company_id = ".$coid." and op.subcode_id IN (".$subcode.") ".$pc1."  GROUP BY YEAR(op.opening_date) ");	
 foreach($openingbalance->fetchAll() as $op) 
 { $op_balance = $op['balance'];} 
 
    return $op_balance;
}*/


  }
?>