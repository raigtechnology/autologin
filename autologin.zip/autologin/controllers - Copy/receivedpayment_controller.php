<?php
  class ReceivedpaymentController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$db = Db::getInstance();	// db connection	
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		} 
		
		$fromdate = date("Y-m-01");
		$todate = date("Y-m-d");
		
		if(isset($_POST['submit'])){
				
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));				
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-01");
				$todate = date("Y-m-d");
			}				
		
		}
		
		// BANK LIST
		$banklist = array();
		$banks = $db->query("select b.id, b.bank_list_id, bl.bank_name, b.account_number from banks as b left join bank_lists as bl on bl.id = b.bank_list_id where b.company_id='".$cid."' and b.subcode_id>0 group by b.bank_list_id ");	
		foreach($banks->fetchAll() as $bl) {
			$banklist[] = $bl;
		}  	
		
		// for account number
		$banklist_acc = array();
		$banks_acc = $db->query("select b.id, b.bank_list_id, bl.bank_name, b.account_number from banks as b left join bank_lists as bl on bl.id = b.bank_list_id where b.company_id='".$cid."' and b.subcode_id>0 ");	
		foreach($banks_acc->fetchAll() as $ac) {
			$banklist_acc[] = $ac;
		}  	
		
		
				
		if(isset($_POST['bank_list_id'])){		
			
			$bankid = $_POST['bank_id'];
			$type = $_POST['type'];
			
			$id = $_POST['bank_list_id'];
					
			$banksdata = $db->query("select b.id, bl.bank_name, b.bank_branch, b.account_number from banks as b left join bank_lists as bl on bl.id = b.bank_list_id where b.company_id='".$cid."' and b.id='".$id."' ");	
			foreach($banksdata->fetchAll() as $bd) {
				$bankname = $bd['bank_name'];
				$bankbranch = $bd['bank_branch'];
				$accountnumber = $bd['account_number'];
			}  				
		
		} else {
			$id=0;
			$cond="";
			$bankid=0;
			$type="";
		}	
		
		if($type!=""){			
			$cond = "and tc.BankID=".$id." and tc.CheqType='".$type."' ";		
		} else {
			if($bankid>0){				
				$cond = "and tc.BankID=".$id." and tc.CheqType IN('ODeposit','Deposit','KI','CDeposit','TI') ";
			} else {
				$cond = "and tc.CheqType IN('ODeposit','Deposit','KI','CDeposit','TI') ";
			}
		
			
			
		}
		
				
		// journal entries
		$tblchequelist = array();		
		$tblcheque = $db->query("select 
									tc.CheqDate,
									tc.CheqNO,
									tc.CheqType,									
									tc.Payee,
									tc.PVNO,
									tc.Description,
									tc.Amount
								from 									
									tblcheque as tc
								where 
									tc.company_id=".$cid." and tc.CheqDate >= '".$fromdate."' AND tc.CheqDate <= '".$todate."' ".$cond." order by tc.CheqDate asc");		
		
				
				
		foreach($tblcheque->fetchAll() as $je) {
			$tblchequelist[] = $je;
		} 	
		
						  
	  require_once('views/receivedpayment/index.php'); 
	  
    }		
	
	
	

    public function error() {
      require_once('views/receivedpayment/error.php');
    }
  }
?>