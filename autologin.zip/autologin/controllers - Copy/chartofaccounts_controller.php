<?php
  class ChartofaccountsController {
  
	public function index() {      
					
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		
		$db = Db::getInstance();		 // db connection
		$cid = $_GET['cid'];             // company_id
		
		$company = $db->query('SELECT id,company_name,address,state,pincode  FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
			$company_address = $com['address'];
			$company_state = $com['state'];
			$company_pincode = $com['pincode'];
		}	  
		
		$code				= "";
		$count				= "";
		$description		= "";
		$account_code		= "";
		$getid				= "";
		$sub_account_code	= "";
		$sub_description	= "";		
		$getcode			= "";
		$getid				= "";
		$gettype			= "";
		
		
		if(isset($_GET['code'])){
			$getcode 	= $_GET['code'];
		}
		
		if(isset($_GET['id'])){
			$getid 		= $_GET['id'];	
		} else {
			$getid = 0;
		}			
			
		if(isset($_GET['type'])){
			$gettype 	= $_GET['type'];
		}
				
		
		
		
		if($getcode!=""){
		
			$code = $getcode;
		
			if($getid!=""){	
									
				$cond = " and ac.code = '".$code."' and subcode_of = '".$getid."' ";
				
				// for main subcode title, account code
				$subtitle = array();	
				$subtitle = $db->query("select code, description from subcodes where company_id = '".$cid."' and id ='".$getid."'");	
				foreach($subtitle->fetchAll() as $sc) {
					$sub_account_code 	= $sc['code'];					
					$sub_description 	= $sc['description'];			
				}				
				
			} else {
				$cond = " and ac.code = '".$code."' and subcode_of = '0' ";	
			}
						
			// for main subcode title, account code
			$master_account_codes = $db->query("select mac.account_code, mac.account_desc from master_account_codes as mac left join account_types as ac on ac.id = mac.account_type_id where mac.company_id = '".$cid."' and ac.code ='".$code."'");	
			foreach($master_account_codes->fetchAll() as $ms) {
				$account_code 	= $ms['account_code'];					
				$description 	= $ms['account_desc'];			
			}
			
		} else {
			$cond = "";
		}	
		
		$accounttypes = array();	 								
		$accounttypes = $db->query("select code,code_desc from account_types order by code asc");	
		foreach($accounttypes->fetchAll() as $ac) {
			$accounttypeslist[] = $ac;
		}			
		
		
		$subcodeslist = array();	
		$subcodes = $db->query("select sc.id, sc.code, sc.description, ac.code_desc, ac.code as code_type from subcodes as sc left join master_account_codes as mac on mac.id = sc.master_account_code_id left join account_types as ac on ac.id = mac.account_type_id where sc.company_id = '".$cid."' and mac.company_id = '".$cid."' ".$cond." order by sc.code asc");	
		foreach($subcodes->fetchAll() as $scm) {
			$subcodeslist[] = $scm;			
		}	
		
		$count = count($subcodeslist);
				
		require_once('views/chartofaccounts/index.php'); 	   
    }	
	
	// create new subcode
	
	public function create() {      
		
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		
		$db = Db::getInstance();		 // db connection
		$cid = $_GET['cid'];             // company_id		
		
		$acerror					= "";		
		$derror						= "";	
		$verror						= "";		
		$brerror					= "";	
		$grerror					= "";	
		$cerror						= "";			
		$account_code				= "";
		$description				= "";
		$acc_prefix					= "";
		$master_account_code_id		= "";
		$subcode_of					= "";
		$ac_id						= "";		
		$code						= "";			
		$getcode					= "";
		$getid						= "";
		$gettype					= "";	
		$vendor_name				= "";
		$customer_name				= "";
		$business_registration_no	= "";
		$gst_registration_no		= "";
		$country					= "";
		$sub_account_code			= "";
		$sub_description			= "";
		$char						= "";
		$acode						= "";	
		$code_for_vendor			= "";	
		$code2						= "";	
		$acc_code					= "";
		$customer_code				= "";
		$subcode_description_for_title	= "";
		$subcode_for_title				= "";
		$account_code_for_title			= "";
		$description_for_title			= "";
		
		if(isset($_GET['code'])){
			$getcode 	= $_GET['code'];
		}
		
		if(isset($_GET['tag'])){
			$gettag 	= $_GET['tag'];
		} else {
			$gettag 	= "";
		}		
		
		
		if(isset($_GET['id'])){
			$getid 		= $_GET['id'];
			
			// for main subcode title, account code
			$subtitle = array();
			$subtitle = $db->query("select code, description from subcodes where company_id = '".$cid."' and id ='".$getid."'");	
			foreach($subtitle->fetchAll() as $sc) {
				$sub_account_code 	= $sc['code'];					
				$sub_description 	= $sc['description'];			
			}	
			
		}
		if(isset($_GET['type'])){
			$gettype 	= $_GET['type'];
			
			$countrieslist = array();
			$countries = $db->query("select name, nicename from country order by nicename asc");	
			foreach($countries->fetchAll() as $cl) {
				$countrieslist[] = $cl;
			}			
			
		}	
				
		
		if($getcode!=""){
			$code = $getcode;	
			// for main subcode title, account code
			
			if($getid>0){
				$cond = "and sc.id = '".$getid."'";
			} else{
				$cond = "";
			}
			
			
			$master_account_codes = $db->query("select ac.id, mac.id as macid, mac.account_code, mac.account_desc, sc.description, sc.code from master_account_codes as mac
			 left join subcodes as sc on sc.master_account_code_id = mac.id 	
			 left join account_types as ac on ac.id = mac.account_type_id where mac.company_id = '".$cid."' and ac.code ='".$code."'  ".$cond." ");	
			foreach($master_account_codes->fetchAll() as $ms) {
				$account_code_for_title 	= $ms['account_code'];					
				$description_for_title 		= $ms['account_desc'];	
				$mac_id_for_title 			= $ms['macid'];		
				$ac_id_for_title 			= $ms['id'];	
				$subcode_description_for_title 	= $ms['description'];
				$subcode_for_title 				= $ms['code'];
			}		
		} else {
			$code = "";
		}			
		 
		$accounttypeslist = array();	
		$accounttypes = $db->query("select code,code_desc from account_types order by code asc");	
		foreach($accounttypes->fetchAll() as $ac) {
			$accounttypeslist[] = $ac;
		}
								
		$codedescriptionslist = array();	
		$listofcodes = array();
		$codedescriptions = $db->query("select cd.description from code_descriptions as cd left join account_types as at on at.id=cd.account_type_id where at.code='".$code."' order by cd.description asc");	
		foreach($codedescriptions->fetchAll() as $scm) {
			$codedescriptionslist[] = $scm;	
			$listofcodes[] =$scm;		
		}	
		
		foreach($listofcodes as $lc){
			$codelist[] = $lc['description'];
		}
		
		
		if(isset($getid)){
			$subcode_of = $getid;
		} 
		
		$account_code				= "";
		$account_code1				= "";
		$account_code2				= "";
		
						
		if(isset($_POST['create'])){			
			
			$created_by = $_SESSION['username'];
			$created_ip = $_SERVER['REMOTE_ADDR'];
			$created    = date("Y-m-d H:i:s"); 
			
			
			
			/************************ vendor part start *****************************************/		
		
			if($gettype=="vendor"){ 
					
					$vendor_name				= $_POST['vendor_name'];		
					$business_registration_no	= $_POST['business_registration_no'];
					$gst_registration_no		= $_POST['gst_registration_no'];	
					$country					= $_POST['country'];						
					
					if($vendor_name==""){
						$verror = "Please enter vendor name";							 						
					} 
					if($business_registration_no==""){
						$brerror = "Please enter business registration no";			 							
					} 
					
					if($gst_registration_no==""){
						$grerror = "Please enter GST Registration no ";			 							
					} 
					
					if($country==""){
						$cerror = "Please select country";			 							
					} 
					
					$char = substr($vendor_name, 0, 1); // first letter from a string						
					
					if (preg_match('/[\'^�$%&*()}{@#~?><>,|=_+�-]/', $char)){
						$verror = "First Letter cannot be special characters";
					}
					
									
					if($verror!="" || $brerror!="" || $grerror!="" || $cerror!=""){
						require_once('views/chartofaccounts/create.php'); 	 
					}	
					
					// generating account code for vendor from vendor name
					
					$acode = substr($sub_account_code, 0, 4);
	  				$acode = "$acode/$char";					
					
					$subcode_foraccount_code = $db->query("select Vendor_account_code from vendor where company_id = '".$cid."' and Vendor_account_code like '%$acode%'  order by Vendor_ID desc limit 1 ");	
					foreach($subcode_foraccount_code->fetchAll() as $sac) {							
						$code_for_vendor = $sac['Vendor_account_code'];		
					}	
						
					if($code_for_vendor!=""){
						$code2 = substr($code_for_vendor, 6, 8);
					  	$code2++;
					 	$code2 = str_pad($code2, 3, '0', STR_PAD_LEFT);
					  	$acc_code = "$acode$code2";
       				} else {
               			$acc_code = "$acode"."001";   	
					}			
								
					$acc_code = strtoupper($acc_code);						
					// end of generating account code for vendor from vendor name
					
					if($vendor_name!=""){			
						
						$vendors_company = $db->query('SELECT count(*) as total FROM vendor WHERE Vendor_Name = "'.$vendor_name.'" and company_id = "'.$cid.'" ');		
						foreach($vendors_company->fetchAll() as $vv) {
							$totalv = $vv['total'];
						}
					
						if($totalv>0){
							$verror = "Vendor name already exist!";							
						} 					
					}
								
					
					if($business_registration_no!=""){			
						
						$vendors_business = $db->query('SELECT count(*) as total FROM vendor WHERE Business_Regno = "'.$business_registration_no.'" and company_id = "'.$cid.'" ');		
						foreach($vendors_business->fetchAll() as $vb) {
							$totalb = $vb['total'];
						}
					
						if($totalb>0){
							$brerror = "Business registration number already exist!";							
						} 					
					}
					
					if($gst_registration_no!=""){			
						
						$vendors_gst = $db->query('SELECT count(*) as total FROM vendor WHERE GSTRNo = "'.$gst_registration_no.'" and company_id = "'.$cid.'" ');		
						foreach($vendors_gst->fetchAll() as $vg) {
							$totalg = $vg['total'];
						}
					
						if($totalg>0){
							$grerror = "GST registration number already exist!";							
						} 					
					}
					
					if($country=="MALAYSIA"){
						$country_type = "LOCAL";
					} else {
						$country_type = "FOREIGN";
					}
					
					
					if($brerror!="" || $grerror!="" || $verror!=""){
						require_once('views/chartofaccounts/create.php'); 	 
					} else {
												
						$result = $db->query("insert into vendor(Vendor_Name, Vendor_account_code, company_id, Business_Regno, GSTRNo, Country_Code, CustTradeTYpe) values ('".$vendor_name."', '".$acc_code."', '".$cid."', '".$business_registration_no."', '".$gst_registration_no."', '".$country."', '".$country_type."') ");										
						if(!$result){
								die('Invalid query: ' . mysql_error());
						} 
						
						// insert subcodes 
						$result_qry = $db->query("insert into subcodes(master_account_code_id, code, description, subcode_of, company_id,created_by,created_ip,created) values ('".$mac_id_for_title."', '".$acc_code."', '".$vendor_name."', '".$getid."', '".$cid."', '".$created_by."', '".$created_ip."', '".$created."') ");										
						if(!$result_qry){
								die('Invalid query: ' . mysql_error());
						} 
						
						header("Location: ?controller=chartofaccounts&action=index&cid=".$cid."&code=".$getcode."&id=".$getid."");		
												
					}
						
								
				/************************ vendor part end *****************************************/	
			} else if($gettype=="customer"){ 
					
					$customer_name				= $_POST['customer_name'];		
					$business_registration_no	= $_POST['business_registration_no'];
					$gst_registration_no		= $_POST['gst_registration_no'];	
					$country					= $_POST['country'];						
					
					if($customer_name==""){
						$verror = "Please enter customer name";							 						
					} 
					if($business_registration_no==""){
						$brerror = "Please enter business registration no";			 							
					} 
					
					if($gst_registration_no==""){
						$grerror = "Please enter GST Registration no ";			 							
					} 
					
					if($country==""){
						$cerror = "Please select country";			 							
					} 
					
					$char = substr($customer_name, 0, 1); // first letter from a string						
					
					if (preg_match('/[\'^�$%&*()}{@#~?><>,|=_+�-]/', $char)){
						$verror = "First Letter cannot be special characters";
					}
														
					if($verror!="" || $brerror!="" || $grerror!="" || $cerror!=""){
						require_once('views/chartofaccounts/create.php'); 	 
					}	
				
					// generating autocustomer id
					
					$subcode_for_autocustomerid = $db->query("select AutoCustomerID from tblcustomer order by AutoCustomerID desc limit 1 ");	
					foreach($subcode_for_autocustomerid->fetchAll() as $aui) {							
						$tblcustomer_autocustomerid = $aui['AutoCustomerID'];		
					}	
						
					if($tblcustomer_autocustomerid!=""){
						$customercode = substr($tblcustomer_autocustomerid, 1, 7);
					  	$customercode++;
					 	$customercode = str_pad($customercode, 7, '0', STR_PAD_LEFT);
					  	$customercode = "C".$customercode;
					  
       				} else {
               			$customercode = "C0000001";   	
					}			
								
				   $customercode = strtoupper($customercode);	
			
					// generating autocustomer id end
				
				
					// generating account code for vendor from vendor name					
					$acode = substr($sub_account_code, 0, 4);
	  				$acode = "$acode/$char";					
														
					$subcode_foraccount_code = $db->query("select Customer_account_code from tblcustomer where company_id = '".$cid."' and Customer_account_code like '%$acode%'  order by AutoCustomerID desc limit 1 ");	
					foreach($subcode_foraccount_code->fetchAll() as $sac) {							
						$code_for_customer = $sac['Customer_account_code'];		
					}	
						
					if($code_for_customer!=""){
						$code2 = substr($code_for_customer, 6, 8);
					  	$code2++;
					 	$code2 = str_pad($code2, 3, '0', STR_PAD_LEFT);
					  	$acc_code = "$acode$code2";
       				} else {
               			$acc_code = "$acode"."001";   	
					}			
								
					$acc_code = strtoupper($acc_code);						
					// end of generating account code for vendor from vendor name
					
					if($customer_name!=""){			
						
						$customers_company = $db->query('SELECT count(*) as total FROM tblcustomer WHERE CompanyName = "'.$customer_name.'" and company_id = "'.$cid.'" ');		
						foreach($customers_company->fetchAll() as $vv) {
							$totalv = $vv['total'];
						}
					
						if($totalv>0){
							$verror = "Customer name already exist!";							
						} 					
					}
								
					
					if($business_registration_no!=""){			
						
						$customers_business = $db->query('SELECT count(*) as total FROM tblcustomer WHERE Business_Regno = "'.$business_registration_no.'" and company_id = "'.$cid.'" ');		
						foreach($customers_business->fetchAll() as $vb) {
							$totalb = $vb['total'];
						}
					
						if($totalb>0){
							$brerror = "Business registration number already exist!";							
						} 					
					}
					
					if($gst_registration_no!=""){			
						
						$customers_gst = $db->query('SELECT count(*) as total FROM tblcustomer WHERE GSTRNo = "'.$gst_registration_no.'" and company_id = "'.$cid.'" ');		
						foreach($customers_gst->fetchAll() as $vg) {
							$totalg = $vg['total'];
						}
					
						if($totalg>0){
							$grerror = "GST registration number already exist!";							
						} 					
					}
					
					if($country=="MALAYSIA"){
						$country_type = "LOCAL";
					} else {
						$country_type = "FOREIGN";
					}
					
					if($brerror!="" || $grerror!="" || $verror!=""){
						require_once('views/chartofaccounts/create.php'); 	 
					} else {
										
						$result = $db->query("insert into tblcustomer(AutoCustomerID, Customercode, CompanyName, Customer_account_code, company_id, Business_Regno, GSTRNo, Country_code, Status, CustTradeTYpe) values ('".$customercode."', '".$customercode."', '".$customer_name."', '".$acc_code."', '".$cid."', '".$business_registration_no."', '".$gst_registration_no."', '".$country."', 'A', '".$country_type."') ");										
						if(!$result){
								die('Invalid query: ' . mysql_error());
						} 
						
						// insert subcodes 
						$result_qry = $db->query("insert into subcodes(master_account_code_id, code, description, subcode_of, company_id,created_by,created_ip,created) values ('".$mac_id_for_title."', '".$acc_code."', '".$customer_name."', '".$getid."', '".$cid."', '".$created_by."', '".$created_ip."', '".$created."') ");										
						if(!$result_qry){
								die('Invalid query: ' . mysql_error());
						} 
						
						
					
						
						if($gettag=="min"){
						?>
							<script>window.close();
							 window.location.reload(); </script>
						<?php								
						} else {
							header("Location: ?controller=chartofaccounts&action=index&cid=".$cid."&code=".$getcode."&id=".$getid."");		
						}						
					}
							
				/************************ customer part end *****************************************/		
											
			} else { 
					
					
					
					
					$acc_prefix					= $_POST['acc_prefix'];		
					$account_code				= $_POST['account_code'];
					$account_code1				= $_POST['account_code1'];
					$account_code2				= $_POST['account_code2'];
					$description				= $_POST['description'];	
					$master_account_code_id		= $_POST['mac_id'];	
					$ac_id						= $_POST['ac_id'];	
					
					
					if($description==""){
						$derror = "Please enter description";			 							
					} 
					
					
					if($account_code1!="" || $account_code2!=""){						
					
						if($account_code1==""){
							$acerror = "Please enter account code";							 						
						} else if($account_code2==""){
							$acerror = "Please enter account code";			
						}
						
						
						if(!is_numeric($account_code1)){								
							$acerror = "enter only numbers";			
						} else if(!is_numeric($account_code2)){								
							$acerror = "enter only numbers";			
						} 						
					
						$account_code = $acc_prefix.''.$account_code1.'/'.$account_code2;					
				
					} else {
						
						if($account_code==""){
							$acerror = "Please enter account code";							 						
						} 
						if(!is_numeric($account_code)){								
							$acerror = "enter only numbers";			
						}						
							
						$account_code = $acc_prefix.''.$account_code;
					}
					
					
					
					
							
							
					if($acerror!="" || $derror!=""){
						require_once('views/chartofaccounts/create.php'); 	 
					} else {
													
							
												
							if($account_code!=""){	
												
								$subcodes = $db->query('SELECT count(*) as total FROM subcodes WHERE code = "'.$account_code.'" and company_id = "'.$cid.'" ');		
								foreach($subcodes->fetchAll() as $sc) {
									$total = $sc['total'];
								}
							
								if($total>0){
									$acerror = "Account Code already exist!";
									require_once('views/chartofaccounts/create.php'); 
								} else {
																					
									// for code_description
									$codeslist = $db->query('SELECT count(*) as cdtotal, ac.id FROM code_descriptions as cd left join account_types as ac on ac.id = cd.account_type_id WHERE cd.description = "'.$description.'" and ac.code ="'.$getcode.'" ');		
									foreach($codeslist->fetchAll() as $cl) {						
										$cdtotal = $cl['cdtotal'];
									}
													
									if($cdtotal==0){
										
										$result = $db->query("insert into code_descriptions(account_type_id, description) values ('".$ac_id."', '".$description."') ");										
										if(!$result){
											die('Invalid query: ' . mysql_error());
										}
									} 					
										
										
									 $master_account_codes = $db->query("select account_type_id from master_account_codes where company_id='".$cid."' and id='".$master_account_code_id."' order by account_code");				
									foreach($master_account_codes->fetchAll() as $mc) {						
										$account_type_id = $mc['account_type_id'];
									}
										
									if($account_type_id=="3" || $account_type_id=="5" || $account_type_id=="4" || $account_type_id=="7" || $account_type_id=="12" || $account_type_id=="13"){				
										$flag = 1;										
									
									} else {
										$flag = 0;												
									}	
										
																		
														
									// insert query
									$result = $db->query("insert into subcodes(company_id, code, description, master_account_code_id, subcode_of, flag,created_by,created_ip,created) values ('".$cid."', '".$account_code."', '".$description."', '".$master_account_code_id."', '".$subcode_of."', '".$flag."', '".$created_by."', '".$created_ip."', '".$created."') ");	
									
									
									$subcode_for_depre = $db->query("select id from subcodes order by id desc limit 1 ");	
									foreach($subcode_for_depre->fetchAll() as $dp) {							
										$dp_subcode_of = $dp['id'];		
									}
										
									
									if($getcode=='B'){
																		
										$account_code_dep = $account_code.'A';
										$description_dep = $description.' - Depreciation';	
										
										$db->query("insert into subcodes(company_id, code, description, master_account_code_id, subcode_of, flag,created_by,created_ip,created) values ('".$cid."', '".$account_code_dep."', '".$description_dep."', '".$master_account_code_id."', '".$dp_subcode_of."', '".$flag."', '".$created_by."', '".$created_ip."', '".$created."') ");
										
										
										$account_code_dis = $account_code.'B';
										$description_dis = $description.' - Disposal';	
										
										$db->query("insert into subcodes(company_id, code, description, master_account_code_id, subcode_of, flag,created_by,created_ip,created) values ('".$cid."', '".$account_code_dis."', '".$description_dis."', '".$master_account_code_id."', '".$dp_subcode_of."', '".$flag."', '".$created_by."', '".$created_ip."', '".$created."') ");
									
									}
									
									
									
												
									if(!$result){
										die('Invalid query: ' . mysql_error());
									}
									header("Location: ?controller=chartofaccounts&action=index&cid=".$cid."&code=".$getcode."&id=".$getid."");			
									
								}				
							}	
					}		
				/************************ other part end *****************************************/							
			} 
			
					
		} else {	 
		   require_once('views/chartofaccounts/create.php'); 	
		}  				
		   
    }	
	
	// edit chart of accounts
	
	public function edit() {      
									
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
		
		$db = Db::getInstance();		 // db connection
		$cid = $_GET['cid'];             // company_id
		
		
		$code						= "";		
		$getid						= "";
		$description_for_title		= "";
		$account_code_for_title		= "";
		$derror						= "";
		$gettype					= "";
		$verror						= "";
		$brerror					= "";
		$grerror					= "";
		$cerror						= "";
		$vendor_id					= "";
		$tid						= "";
		$ptid						= "";
				
		if(isset($_GET['id'])){
			$getid 		= $_GET['id'];
			
			// for main subcode title, account code
			$subtitle = array();
			$subtitle = $db->query("select code, description from subcodes where company_id = '".$cid."' and id ='".$getid."'");	
			foreach($subtitle->fetchAll() as $sc) {
				$sub_account_code = $sc['code'];					
				$sub_description = $sc['description'];			
			}	
			
		}		
		
		// vendors
		$vendorlist = array();	
		$vendors = $db->query("select v.Vendor_ID, v.Vendor_Name, v.Business_Regno, v.GSTRNo, v.Country_Code from vendor  as v left join subcodes as sc on v.Vendor_account_code = sc.code where v.company_id = '".$cid."' and sc.id='".$getid."'");	
		foreach($vendors->fetchAll() as $scm) {
			$vendorlist[] = $scm;			
		}	
		
		// customers
		$customerlist = array();	
		$customers = $db->query("select c.AutoCustomerID, c.CompanyName, c.Business_Regno, c.GSTRNo from tblcustomer as c left join subcodes as sc on c.Customer_account_code = sc.code where c.company_id = '".$cid."' and sc.id='".$getid."'");	
		foreach($customers->fetchAll() as $cm) {
			$customerlist[] = $cm;			
		}	
		
			
		$subcodeslist = array();	
		$subcodes = $db->query("select id, code, description from subcodes where company_id = '".$cid."' and id='".$getid."'");	
		foreach($subcodes->fetchAll() as $scm) {
			$subcodeslist[] = $scm;			
		}		
			
		if(isset($_GET['type'])){
			$gettype 	= $_GET['type'];
			
			$countrieslist = array();
			$countries = $db->query("select name, nicename from country order by nicename asc");	
			foreach($countries->fetchAll() as $cl) {
				$countrieslist[] = $cl;
			}			
			
		}		
		
		if(isset($_GET['tid'])){
			$tid 	= $_GET['tid'];
		}
		
		if(isset($_GET['code'])){
			$getcode 	= $_GET['code'];
		}
			
		if($getcode!=""){
			$code = $getcode;	
			// for main subcode title, account code
			$master_account_codes = $db->query("select ac.id, mac.id as macid, mac.account_code, mac.account_desc from master_account_codes as mac left join account_types as ac on ac.id = mac.account_type_id where mac.company_id = '".$cid."' and ac.code ='".$code."'");	
			foreach($master_account_codes->fetchAll() as $ms) {
				$account_code_for_title = $ms['account_code'];					
				$description_for_title = $ms['account_desc'];	
				$mac_id_for_title = $ms['macid'];		
				$ac_id_for_title = $ms['id'];		
			}		
		} else {
			$code = "";
		}		
			
						
		if(isset($_POST['update'])){			
												
			if($gettype=="vendor"){   // vendor part starts
			
				$vendor_name				= $_POST['vendor_name'];	
				$business_registration_no	= $_POST['business_registration_no'];
				$gst_registration_no		= $_POST['gst_registration_no'];
				$vendor_id					= $_POST['vendor_id'];
				$ptid						= $_POST['tid'];
						
				
				if($vendor_name!=""){			
						
						$vendors_company = $db->query('SELECT count(*) as total FROM vendor WHERE Vendor_Name = "'.$vendor_name.'" and company_id = "'.$cid.'" and Vendor_ID !="'.$vendor_id.'" ');		
						foreach($vendors_company->fetchAll() as $vv) {
							$totalv = $vv['total'];
						}
					
						if($totalv>0){
							$verror = "Vendor name already exist!";							
						} 					
					}
								
					
					if($business_registration_no!=""){			
						
						$vendors_business = $db->query('SELECT count(*) as total FROM vendor WHERE Business_Regno = "'.$business_registration_no.'" and company_id = "'.$cid.'" and Vendor_ID !="'.$vendor_id.'" ');		
						foreach($vendors_business->fetchAll() as $vb) {
							$totalb = $vb['total'];
						}
					
						if($totalb>0){
							$brerror = "Business registration number already exist!";							
						} 					
					}
					
					if($gst_registration_no!=""){			
						
						$vendors_gst = $db->query('SELECT count(*) as total FROM vendor WHERE GSTRNo = "'.$gst_registration_no.'" and company_id = "'.$cid.'" and Vendor_ID !="'.$vendor_id.'" ');		
						foreach($vendors_gst->fetchAll() as $vg) {
							$totalg = $vg['total'];
						}
					
						if($totalg>0){
							$grerror = "GST registration number already exist!";							
						} 					
					}
					
					if($brerror!="" || $grerror!="" || $verror!=""){
						require_once('views/chartofaccounts/edit.php'); 	 
					} else {
												
						// update query
						$result = $db->query("update vendor set Vendor_Name = '".$vendor_name."', Business_Regno = '".$business_registration_no."', GSTRNo = '".$gst_registration_no."' where Vendor_ID ='".$vendor_id."' and company_id = '".$cid."' ");						
						if(!$result){
							die('Invalid query: ' . mysql_error());
						}							
						
						// insert subcodes 
						$result_qry = $db->query("update subcodes set description = '".$vendor_name."' where id ='".$getid."' and company_id = '".$cid."'");										
						if(!$result_qry){
								die('Invalid query: ' . mysql_error());
						} 
						
						header("Location: ?controller=chartofaccounts&action=index&cid=".$cid."&code=".$getcode."&id=".$ptid."");		
												
					}
									
			} else if($gettype=="customer"){   // customer part starts
			
				$customer_name				= $_POST['customer_name'];	
				$business_registration_no	= $_POST['business_registration_no'];
				$gst_registration_no		= $_POST['gst_registration_no'];
				$AutoCustomerID				= $_POST['AutoCustomerID'];
				$ptid						= $_POST['tid'];		
				
				if($customer_name!=""){			
						
					$customers_company = $db->query('SELECT count(*) as total FROM tblcustomer WHERE CompanyName = "'.$customer_name.'" and company_id = "'.$cid.'" and AutoCustomerID != "'.$AutoCustomerID.'" ');		
					foreach($customers_company->fetchAll() as $vv) {
						$totalv = $vv['total'];
					}
				
					if($totalv>0){
						$verror = "Customer name already exist!";							
					} 					
				}
							
				
				if($business_registration_no!=""){			
					
					$customers_business = $db->query('SELECT count(*) as total FROM tblcustomer WHERE Business_Regno = "'.$business_registration_no.'" and company_id = "'.$cid.'" and AutoCustomerID != "'.$AutoCustomerID.'" ');		
					foreach($customers_business->fetchAll() as $vb) {
						$totalb = $vb['total'];
					}
				
					if($totalb>0){
						$brerror = "Business registration number already exist!";							
					} 					
				}
				
				if($gst_registration_no!=""){			
					
					$customers_gst = $db->query('SELECT count(*) as total FROM tblcustomer WHERE GSTRNo = "'.$gst_registration_no.'" and company_id = "'.$cid.'" and AutoCustomerID != "'.$AutoCustomerID.'" ');		
					foreach($customers_gst->fetchAll() as $vg) {
						$totalg = $vg['total'];
					}
				
					if($totalg>0){
						$grerror = "GST registration number already exist!";							
					} 					
				}
				
				if($brerror!="" || $grerror!="" || $verror!=""){
					require_once('views/chartofaccounts/edit.php'); 	 
				} else {
												
						// update query
						$result = $db->query("update tblcustomer set CompanyName = '".$customer_name."', Business_Regno = '".$business_registration_no."', GSTRNo = '".$gst_registration_no."' where AutoCustomerID ='".$AutoCustomerID."' and company_id = '".$cid."' ");						
						if(!$result){
							die('Invalid query: ' . mysql_error());
						}							
						
						// insert subcodes 
						$result_qry = $db->query("update subcodes set description = '".$customer_name."' where id ='".$getid."' and company_id = '".$cid."'");										
						if(!$result_qry){
								die('Invalid query: ' . mysql_error());
						} 
						
						header("Location: ?controller=chartofaccounts&action=index&cid=".$cid."&code=".$getcode."&id=".$ptid."");		
												
					}
						// end of customer part
				
			} else { // other part 
				
				$description				= $_POST['description'];									
				if($description==""){
					$derror = "Please enter description ";			 							
				} 									
				if($derror!=""){
					require_once('views/chartofaccounts/edit.php'); 	 
				}
				// update query
				$result = $db->query("update subcodes set description = '".$description."' where id ='".$getid."' ");						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}
				header("Location: ?controller=chartofaccounts&action=index&cid=".$cid."&code=".$getcode."");	
				
			}			
					
		} else {	 
		   require_once('views/chartofaccounts/edit.php'); 	
		}  	
				
		   
    }	
	
	
	// delete chart of accounts
	public function delete() {
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}
			
		$db = Db::getInstance();		 // db connection
		$cid = $_GET['cid'];             // company_id
		
		if(isset($_GET['code'])){
			$getcode 	= $_GET['code'];
		}
		
		if(isset($_GET['type'])){
			$gettype 	= $_GET['type'];
		}
		
		if(isset($_GET['id'])){
			$getid 		= $_GET['id'];		
			
			// banks
			$banks = $db->query('SELECT count(*) as total FROM banks WHERE subcode_id = "'.$getid.'" and company_id = "'.$cid.'" ');		
			foreach($banks->fetchAll() as $bk) {
				$bk_total = $bk['total'];
			}	
			
			// budgets
			$budgets = $db->query('SELECT count(*) as total FROM budgets WHERE subcode_id = "'.$getid.'" and company_id = "'.$cid.'" ');		
			foreach($budgets->fetchAll() as $bt) {
				$bt_total = $bt['total'];
			}	
			
			// deposit purchase
			$deposit_purchase = $db->query('SELECT count(*) as total FROM deposit_purchase WHERE subcode_id = "'.$getid.'" and companyID = "'.$cid.'" ');		
			foreach($deposit_purchase->fetchAll() as $dp) {
				$dp_total = $dp['total'];
			}	
			
			// deposit sales
			$deposit_sales = $db->query('SELECT count(*) as total FROM deposit_sales WHERE subcode_id = "'.$getid.'" and companyID = "'.$cid.'" ');		
			foreach($deposit_sales->fetchAll() as $ds) {
				$ds_total = $ds['total'];
			}	
			
			// fised assets
			$fixedassets = $db->query('SELECT count(*) as total FROM fixed_assets WHERE subcode_id = "'.$getid.'" and company_id = "'.$cid.'" ');		
			foreach($fixedassets->fetchAll() as $ft) {
				$ft_total = $ft['total'];
			}	
			
			// fised assets gl
			$fixedassetsgl = $db->query('SELECT count(*) as total FROM fixed_asset_gl WHERE subcode_id = "'.$getid.'" and company_id = "'.$cid.'" ');		
			foreach($fixedassetsgl->fetchAll() as $ftg) {
				$ftg_total = $ftg['total'];
			}	
									
			// journal_entries
			$journalentries = $db->query('SELECT count(*) as total FROM journal_entries WHERE subcode_id = "'.$getid.'" and company_id = "'.$cid.'" ');		
			foreach($journalentries->fetchAll() as $je) {
				$je_total = $je['total'];
			}	
			
			// opening balance
			$opening_balance = $db->query('SELECT count(*) as total FROM opening_balance WHERE subcode_id = "'.$getid.'" and company_id = "'.$cid.'" ');		
			foreach($opening_balance->fetchAll() as $ob) {
				$ob_total = $ob['total'];
			}
			
			// unattended gl
			$unattended_gl = $db->query('SELECT count(*) as total FROM unattended_gl WHERE subcode_of = "'.$getid.'" and company_id = "'.$cid.'" ');		
			foreach($unattended_gl->fetchAll() as $ugl) {
				$ugl_total = $ugl['total'];
			}	
			
			// tblproduct gl
			$tblproduct = $db->query('SELECT count(*) as total FROM tblproduct WHERE subcode_of = "'.$getid.'" and company_id = "'.$cid.'" ');		
			foreach($tblproduct->fetchAll() as $tpd) {
				$tpd_total = $tpd['total'];
			}				
			
		}
				
		if($bk_total>0 || $bt_total>0 || $bk_total>0 || $dp_total>0 || $ds_total>0 || $ft_total>0 || $ftg_total>0 || $je_total>0 || $ob_total>0 || $ugl_total>0 || $tpd_total>0){
		?>
		
			<div align="center" style="background:#FFFFFF; padding:10px;">
				<span style="color:#FF0000;">The Subcode already in use!. Sorry you cannot delete. please contact system administrator</span>
				<p><a href="javascript: history.go(-1);" style="color: #0033FF; text-decoration:underline;">BACK</a></p>
			</div>
		<?php
			
		} else {	
		
			
		
		
			$result = $db->query("delete from subcodes where company_id = '".$cid."' and id ='".$getid."' ");		
								
			if(!$result){
				die('Invalid query: ' . mysql_error());
			}	
			
			if(isset($_GET['tid'])){
				$tid 	= $_GET['tid'];
				header("Location: ?controller=chartofaccounts&action=index&cid=".$cid."&code=".$getcode."&id=".$tid."");	
			} else {		
				header("Location: ?controller=chartofaccounts&action=index&cid=".$cid."&code=".$getcode."");	
			}
		
		}			
	     
    }
	
	
	public function excels() {
	
		
		header('Content-Type: application/force-download');
		header('Content-disposition: attachment; filename=chartofaccounts.xls');
		// Fix for crappy IE bug in download.
		header("Pragma: ");
		header("Cache-Control: ");
		echo $_REQUEST['datatodisplay'];
		
	     
    }
	
			

    public function error() {
      require_once('views/codedescriptions/error.php');
    }
  }
?>