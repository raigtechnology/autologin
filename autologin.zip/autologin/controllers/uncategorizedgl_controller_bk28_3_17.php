<?php
  class UncategorizedglController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		    
		$fromdate = date("Y-m-01");
		$todate = date("Y-m-d");
		$cond ="";
		$invoice_no ="";
		
		if(isset($_POST['submit'])){		
			
			$invoice_no = $_POST['invoice_no'];
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));				
				
			if(empty($fromdate)){
				$fromdate = date("Y-m-01");
				$todate = date("Y-m-d");
			}					
			
			
			
			if($invoice_no!="" && $fromdate!="1970-01-01" && $todate!="1970-01-01"){
				$cond = " and ugl.description = '".$invoice_no."' and ugl.date >= '".$fromdate."' AND ugl.date <= '".$todate."' "; 			
			} else if($invoice_no=="" && $fromdate!="1970-01-01" && $todate!="1970-01-01"){
				$cond = " and ugl.date >= '".$fromdate."' AND ugl.date <= '".$todate."' "; 			
			} else if($invoice_no!="" && $fromdate=="1970-01-01" && $todate=="1970-01-01"){
				$cond = " and ugl.description = '".$invoice_no."'  "; 			
			} else {
				$cond ="";
			}
			
		}
		
						
		$uncategorizedgllistgroup = array();
		$uncategorizedglgroup = $db->query("select ugl.description from unattended_gl as ugl where ugl.company_id='".$cid."' and ugl.status=0 and ugl.flag=0 ".$cond."  group by ugl.description order by ugl.date desc ");	
		foreach($uncategorizedglgroup->fetchAll() as $ugl) {
			$uncategorizedgllistgroup[] = $ugl;
		}  		
		
		$uncategorizedgllist = array();
		$uncategorizedgl = $db->query("select ugl.date, ugl.profit_center_code, ugl.account_code, mac.account_desc, sc.description, ugl.description as invoice, ugl.debit, ugl.credit from unattended_gl as ugl left join subcodes as sc on sc.code = ugl.account_code 
		left join master_account_codes as mac on mac.id= sc.master_account_code_id 		
		where ugl.company_id='".$cid."' and sc.company_id='".$cid."' and ugl.status=0 and ugl.flag=0 ".$cond."   order by ugl.date desc ");	
		foreach($uncategorizedgl->fetchAll() as $ugl) {
			$uncategorizedgllist[] = $ugl;
		}  	
						  
	  require_once('views/uncategorizedgl/index.php'); 
	  
    }		
	
	
	// edit
	public function edit() {   			
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$id = $_GET['id'];		
				
		$profitcenterslist = array();
		$profitcenters = $db->query("select * from profit_centers where company_id='".$cid."' ");	
		foreach($profitcenters->fetchAll() as $pc) {
			$profitcenterslist[] = $pc;
		}  	
		
		$subcodeslist = array();	
		$subcodes = $db->query("select id,description,code from subcodes where company_id = '".$cid."' order by code, description ");
		foreach($subcodes->fetchAll() as $sc) {
			$subcodeslist[] = $sc;
		}  	
			
				
		$uncategorizedgllist = array();
		$uncategorizedgl = $db->query("select ugl.id, ugl.date, ugl.profit_center_code, ugl.account_code, sc.description, ugl.description as invoice, ugl.debit, ugl.credit from unattended_gl as ugl left join subcodes as sc on sc.code = ugl.account_code where ugl.company_id='".$cid."' and sc.company_id='".$cid."' and ugl.description = '".$id."'  ");	
		foreach($uncategorizedgl->fetchAll() as $ugl) {
			$uncategorizedgllist[] = $ugl;
		}  	
						  
		if(isset($_POST['save'])){			
			
			$data = $_POST['data'];
						
			foreach($data as $dt){							
								
				$profit_center_code	= $dt['profit_center_code'];	
				$account_code	= $dt['account_code'];		
				$uid	= $dt['uid'];								
				
				$modified_by = $_SESSION['username'];
				$modified_ip = $_SERVER['REMOTE_ADDR'];
				$modified    = date("Y-m-d H:i:s"); 
				
				// update query
				$result = $db->query("update unattended_gl set profit_center_code = '".$profit_center_code."', account_code = '".$account_code."', modified_by='".$modified_by."', modified_ip='".$modified_ip."', modified='".$modified."' where company_id = '".$cid."' and description = '".$id."' and id='".$uid."' ");		
						
				if(!$result){
					die('Invalid query: ' . mysql_error());
				}				
			}
			
			
			$created_by 	 = $_SESSION['username'];
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Change";
			$window_name     = "Unapproved GL";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
			
			
			header("Location: ?controller=uncategorizedgl&action=index&cid=".$cid."");						
					
		} else {	 
		   require_once('views/uncategorizedgl/edit.php'); 	   
		}  
	  
    }		
	
	
	// single validation
	// edit
	public function validate() {   			
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		$id     = $_GET['id'];
		
		if($id!=""){
			$condit = " and ugl.description = '".$id."'";
		} else {
			$condit = "";
		}		
				
		
			
		$uncategorizedgllist = array();
		$uncategorizedgl = $db->query("select												
											ugl.company_id,
											sc.subcode_of as subcode_of,
											sc.id as subcode_id,
											ugl.debit,
											ugl.credit,	
											ugl.ref,	
											ugl.date,
											ugl.description as memo,
											ugl.gst,
											ugl.Invoice_Mode,
											ugl.jobrefno,
											ugl.profit_center_code,
											ugl.entry_mode,
											ugl.totalamount,
											ugl.currencycode,
											ugl.currencyrate,
											ugl.trade_type,
											ugl.Gstinvdate,
											ugl.taxcode
										from 
											unattended_gl as ugl 
											left join subcodes as sc on sc.code = ugl.account_code																		
										where 
											ugl.company_id='".$cid."' and sc.company_id='".$cid."' ".$condit." and ugl.status = 0 ");	
		foreach($uncategorizedgl->fetchAll() as $ugl) {
			$uncategorizedgllist[] = $ugl;
		}  
					
		
		// Unique Array for return
		$arrayRewrite = array();
		// Array with the md5 hashes
		$arrayHashes = array();
		foreach($uncategorizedgllist as $key => $item) {
			
			$subcodeofarray1 = $db->query("select subcode_of from subcodes where company_id = '".$cid."' and id = '".$item['subcode_id']."' ");
								
			foreach($subcodeofarray1->fetchAll() as $sof1) {
				$subcode_of_1 = $sof1['subcode_of'];
			}  
			
			$subcodeofarray2 = $db->query("select description from subcodes where company_id = '".$cid."' and id = '".$subcode_of_1."' ");
								
			foreach($subcodeofarray2->fetchAll() as $sof2) {
				$subcode_of_2 = $sof2['description'];
			}  
		
			if($subcode_of_2=="Trade Debtors" || $subcode_of_2=="Trade Creditors"){							
				
				$preserveKeys="";	
				// Serialize the current element and create a md5 hash
				$hash = md5(serialize($item['ref']));
				// If the md5 didn't come up yet, add the element to
				// to arrayRewrite, otherwise drop it
				if (!isset($arrayHashes[$hash])) {
					// Save the current element hash
					$arrayHashes[$hash] = $hash;
					// Add element to the unique Array
					if ($preserveKeys) {
						$arrayRewrite[$key] = $item;
					} else {
						$arrayRewrite[] = $item;
					}
				}
			}		
		}
		
		//////////////////////////////////////////////////////////////////
		
			
				$i=0;				
				$paid_gst=0;	
				$tax_amount=0;	
								
				foreach($arrayRewrite as $val){	
					
					$subcode_id 		= $val['subcode_id'];
					$ref 				= $val['memo'];
					$reference 			= $val['ref'];
				    $paid_debit 		= $val['debit'];
					$paid_credit 		= $val['credit'];
					$paid_gst 			= $val['gst'];
					$paid_date 			= $val['date'];					
					$autoinvoiceid 		= $val['memo'];
					$invoice_mode 		= $val['Invoice_Mode'];
					$Gstinvdate 		= $val['Gstinvdate'];
					$profit_center_code	= $val['profit_center_code'];
														
					if($invoice_mode=="Invoicein"){						
						
						$invproductpurchase1 = $db->query("select AutoInvoiceID, Currencyrate from tblinvmaster_purchase where company_id = '".$cid."' and InvRef = '".$autoinvoiceid."' ");		
						foreach($invproductpurchase1->fetchAll() as $ipp1) {
							$invoiceid = $ipp1['AutoInvoiceID'];
							$xchangerate = $ipp1['Currencyrate'];
						}  
																													
						$invproductpurchaselist = array();
						$invproductpurchase = $db->query("select AutoInvoiceID, Productcode, ProductDesc, Quantity, UnitPrice, Totalamt, TaxCodeMatched, GSTamt from tblinvproduct_purchase where company_id = '".$cid."' and AutoInvoiceID = '".$invoiceid."' ");
								
						foreach($invproductpurchase->fetchAll() as $ipp) {
							$invproductpurchaselist[] = $ipp;
						}  
											
						
						$sum = array();

						foreach ($invproductpurchaselist as $item) {
							if (!isset($sum[$item['AutoInvoiceID']])) $sum[$item['AutoInvoiceID']] = 0;
							$sum[$item['AutoInvoiceID']] += $item['GSTamt'] * $xchangerate;
						}	
						
						$inv=0;	
						$bltax="";																								
						foreach($invproductpurchaselist as $iss){
							
							$issgst = $iss['GSTamt'] * $xchangerate;
						
							foreach($sum as $k=>$val){
								if($k==$iss['AutoInvoiceID']){	
									$purchase_gstamt = $val;
									$taxcodepurchase = $iss['TaxCodeMatched']; 
									if($taxcodepurchase=="BL"){
										$taxcodepurchase = $taxcodepurchase;
										$bltax = "BL";
										$blgst += $issgst; 
									} else{
										$taxcodepurchase="";
									}
							
									if($bltax=="BL"){
										$taxcodepurchase = "BL";
									}	
									
									$tax_arr[$i]['taxcode']=$taxcodepurchase; // for taxcode
								}	
							}										
																										
						}	
																																				
					  $paid_gst = $purchase_gstamt;
					
					
					} else if($invoice_mode=="Invoiceout"){	
						
						$invproductsales1 = $db->query("select AutoInvoiceID, Currencyrate from tblinvmaster_sales where company_id = '".$cid."' and AutoInvoiceID = '".$autoinvoiceid."' ");		
						foreach($invproductsales1->fetchAll() as $ips1) {
							$invoiceid = $ips1['AutoInvoiceID'];
							$xchangerate = $ips1['Currencyrate'];
						}  
						
						
						$invproductsaleslist = array();
						$invproductsales = $db->query("select AutoInvoiceID, Productcode, ProductDesc, Quantity, UnitPrice, Totalamt, TaxCode, GSTAmt from tblinvproduct_sales where company_id = '".$cid."' and AutoInvoiceID = '".$invoiceid."' ");
								
						foreach($invproductsales->fetchAll() as $ips) {
							$invproductsaleslist[] = $ips;
						}  
						
						
						$sum = array();

						foreach ($invproductsaleslist as $item) {
							if (!isset($sum[$item['AutoInvoiceID']])) $sum[$item['AutoInvoiceID']] = 0;
							$sum[$item['AutoInvoiceID']] += $item['GSTAmt'] * $xchangerate;
						}	
						
						$inv=0;	
						$bltax="";																								
						foreach($invproductsaleslist as $iss){
							
							$issgst = $iss['GSTAmt'] * $xchangerate;
							
							foreach($sum as $k=>$val){
								if($k==$iss['AutoInvoiceID']){	
									$sales_gstamt = $val;
									$taxcodepurchase = $iss['TaxCode']; 
									if($taxcodepurchase=="BL"){
										$taxcodepurchase = $taxcodepurchase;
										$bltax = "BL";
										$blgst += $issgst; 
									} else{
										$taxcodepurchase="";
									}
							
									if($bltax=="BL"){
										$taxcodepurchase = "BL";
									}	
									
									$tax_arr[$i]['taxcode']=$taxcodepurchase; // for taxcode
								}	
							}										
																										
						}	
																																				
					  $paid_gst = $sales_gstamt;			
					}
					
					$subcodesList1 = $db->query("select id, description, code, master_account_code_id, subcode_of from subcodes where company_id=".$cid." order by code ");
					foreach($subcodesList1->fetchAll() as $sl) {
							
						if($sl['description']=="Trade Debtors"){
							$debtor_id = $sl['id'];
						} 
						if($sl['description']=="Trade Creditors"){
							$creditor_id = $sl['id'];
						} 
					
					}  
					
					
					$totaljournals = $db->query("select sum(debit) as ctotal from journal_entries where company_id=".$cid." and memo = '".$ref."' and subcode_of = '".$creditor_id."' ");
					foreach($subcodesList1->fetchAll() as $tj) {
						$total_debit = $tj['ctotal']; // for 180 days calculation	
					}
												
					$journallist = array();
					$journals = $db->query("select * from journal_entries where company_id=".$cid." and memo = '".$ref."' and ref != 'deposit sales' and ref != 'deposit purchase'");
					foreach($journals->fetchAll() as $jls) {
						$journallist[] = $jls; 	
					}
						
					$cnt=0;					
					foreach($journallist as $key=>$jl){					
						
						 if($cnt==0){					 
						
							 $now 		= strtotime($paid_date);; // or your date as well
							 $your_date = strtotime($jl['date']);
							 $datediff 	= $now - $your_date;
							 $above180 	= floor($datediff/(60*60*24));	
								
							 $date 		= $jl['date'];	
							 $debit 	= $jl['debit'];	
							 $credit 	= $jl['credit'];	
							 $gst 		= $jl['gst'];
								
							 $invoice_date 	= $date;
							 $invoice_gst 	= $gst;													
							
							$invoice_debit  = $debit;								 
							$invoice_credit = $credit;	
																			
						}							 
						$cnt++;								 						
					}		
					
					$subcode = $db->query("select id, code, description, subcode_of from subcodes where company_id = '".$cid."' and id = '".$subcode_id."' ");
					
					$sub_code = array();			
					foreach($subcode->fetchAll() as $so) {
						$subcode_of = $so['subcode_of'];
						$sub_code[] = $so;						
					}  
					
					foreach($sub_code as $scode){
						
						$id = $scode['id'];
						$account_code = $scode['code'];						
																										
						if($subcode_of==$debtor_id && $id==$subcode_id){							
								
							// output tax	// payment in 																
							if($paid_credit>0){								
								
								if($invoice_debit>0){
									$tax_amount = ($paid_credit/$invoice_debit)*($invoice_gst);
								} else {
									$tax_amount = $paid_gst;
								}
						
							} else if($paid_debit>0){
								$tax_amount = $paid_gst;
							}
								
							
						} else if($subcode_of==$creditor_id && $id==$subcode_id){
																		
							// input tax 
							if($above180>180){	// above 180 days					
							
								if($paid_debit>0){
									
									if($invoice_credit>0){
										$tax_amount = ($paid_debit/$invoice_credit)*($invoice_gst);
									} else {
										$tax_amount = $paid_gst;
									}
								
								} else if($paid_credit>0){
									$tax_amount = $paid_gst;
								}
								
							} else { // less than 180days
															
								if($paid_debit>0){								
																	
									if($invoice_credit>0){																		
										$tax_amount = ($paid_debit/$invoice_credit)*($invoice_gst);
									} else {
										$tax_amount = $paid_gst;		
									}																		
									
								} else if($paid_credit>0){
									$tax_amount = $paid_gst;
								}
								
							}
						
						} else{
							$tax_amount = $paid_gst;	
						}				
				
					}
					
					if($tax_amount==""){
						$tax_amount =0;			  
				  	}
				  
									
				  	$tax_arr[$i]['invoiceid']	=	$autoinvoiceid;
				  	$tax_arr[$i]['gst']			=	$tax_amount;
				  	$tax_arr[$i]['reference']	=	$reference;			
										
				 						
				 $i++;					
					
				}		
		//////////////////////////////////////////////////////////////////
				
				
		/****************************************************************/
				$in=0;						
				foreach($uncategorizedgllist as $da){					
										
					/*foreach($tax_arr as $ar){																		
						
						if($da['ref']==$ar['reference']){					
							$uncategorizedgllist[$in]['taxcode']=$ar['taxcode'];						
						} else {
							$uncategorizedgllist[$in]['taxcode']="";
						}						
										
					}*/
					//$uncategorizedgllist[$in]['entry_mode']="manual";
					
									
					$scodeid = $db->query("select subcode_of from subcodes where company_id='".$cid."' and id = '".$uncategorizedgllist[$in]['subcode_id']."' ");
											
					foreach($scodeid->fetchAll() as $sd) {
						$sidvalue = $sd['subcode_of'];								
					}
					
					$uncategorizedgllist[$in]['subcode_of'] = $sidvalue;	
								
				$in++;
				}
				
				
				$created_by = $_SESSION['username'];
				$created_ip = $_SERVER['REMOTE_ADDR'];
				$created    = date("Y-m-d H:i:s"); 
				
				
				
				
				
													
				$ir=0;
				foreach($uncategorizedgllist as $gda){			
					
					$profitcentercode = $db->query("select id from profit_centers where company_id='".$cid."' and profit_center_code = '".$gda['profit_center_code']."' ");											
					foreach($profitcentercode->fetchAll() as $pcc) {
						$profit_center_id = $pcc['id'];								
					}			
					
					
					$subcode_id			= $gda['subcode_id'];
					$profit_center_id 	= $profit_center_id;
					$company_id 		= $cid;
					$date 				= $gda['date'];
					$ref				= $gda['ref'];
					$memo				= $gda['memo'];
					$debit				= $gda['debit'];
					$credit				= $gda['credit'];	
					$gst 				= $gda['gst'];
					$subcode_of			= $gda['subcode_of'];
					$entry_mode			= $gda['entry_mode'];	
					$jobrefno			= $gda['jobrefno'];	
					
					$totalamount		= $gda['totalamount'];	
					$currencycode		= $gda['currencycode'];	
					$currencyrate		= $gda['currencyrate'];	
					$trade_type			= $gda['trade_type'];	
					$taxcode			= $gda['taxcode'];	
					
					$status				= 1;	
														
					
					$journalentrydata = $db->query("insert into journal_entries(`jobrefno`,`subcode_id`,`profit_center_id`,`company_id`,`date`,`ref`,`memo`,`debit`,`credit`,`gst`,`subcode_of`,`entry_mode`,`status`,`totalamount`,`currencycode`,`currencyrate`,`trade_type`,`taxcode`,`Gstinvdate`,`created_by`,`created_ip`,`created`) values('".$jobrefno."','".$subcode_id."', '".$profit_center_id."', '".$company_id."', '".$date."', '".$ref."', '".$memo."', '".$debit."', '".$credit."', '".$gst."', '".$subcode_of."', '".$entry_mode."','".$status."','".$totalamount."','".$currencycode."','".$currencyrate."','".$trade_type."','".$taxcode."','".$Gstinvdate."','".$created_by."','".$created_ip."','".$created."')"); 
			
					if(!$journalentrydata){
						die('Invalid query: ' . mysql_error());
					}	
					
					$updateqry = $db->query("update unattended_gl set status='1' where status='0' and description='".$memo."'  and company_id = '".$cid."' ");
				
					if(!$updateqry){
						die('Invalid query: ' . mysql_error());
					}
					
					if($gda['subcode_of']>0){					
					
						$tradetype = $db->query("select description from subcodes where company_id='".$cid."' and id = '".$gda['subcode_of']."' ");
												
						foreach($tradetype->fetchAll() as $tt){					
							$tradedesc = $tt['description'];											
						}
											
						
						if(($gda['memo']!="" && $tradedesc=="Trade Debtors") || ($gda['memo']!="" && $tradedesc=="Trade Creditors")){
								
							$traders = $db->query("select code, subcode_of from subcodes where company_id='".$cid."' and id = '".$gda['subcode_id']."' ");
												
							foreach($traders->fetchAll() as $tr){					
								$subcodeidvalue = $tr['subcode_of'];	
								$subcodeiddescription = $tr['code'];				
							}
							
							$tradevalue = $db->query("select description from subcodes where company_id='".$cid."' and id= '".$subcodeidvalue."' ");
						
							foreach($tradevalue->fetchAll() as $td){					
								$trader = $td['description'];					
							}	
							
									
							$baddebt_trade_type 	= $trader;						
							$baddebt_account_code 	= $subcodeiddescription;
							$baddebt_description 	= $gda['memo'];
							$baddebt_ref 			= $gda['ref'];
							$baddebt_gstdate		= $gda['date'];
							$baddebt_debit			= $gda['debit'];
							$baddebt_credit 		= $gda['credit'];
							$baddebt_company_id 	= $cid;						
							
							if($baddebt_debit>0){
								$baddebt_debit_gst = $gda['gst'];
							}
							if($credit>0){
								$baddebt_credit_gst = $gda['gst'];
							}
							
							$baddebtdata =$db->query("insert into gstbaddebt(`trade_type`,`account_code`,`description`,`ref`,`gstdate`,`debit`,`credit`,`company_id`,`debit_gst`,`credit_gst`,`created_by`,`created_ip`,`created`) values('".$baddebt_trade_type."', '".$baddebt_account_code."', '".$baddebt_description."', '".$baddebt_ref."', '".$baddebt_gstdate."', '".$baddebt_debit."', '".$baddebt_credit."', '".$baddebt_company_id."', '".$baddebt_debit_gst."', '".$baddebt_credit_gst."','".$created_by."','".$created_ip."','".$created."')"); 
			
							if(!$baddebtdata){
								die('Invalid query: ' . mysql_error());
							}									
							
							$ir++;
						}	
				
					}
				}	
				
				
				
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Add";
			$window_name     = "Unapproved GL";
				
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");
				
				
				
				header("Location: ?controller=uncategorizedgl&action=index&cid=".$cid."");		
		/****************************************************************/
	
		
	  
    }	
	
// delete
	public function delete() {
		
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}	
	
		$db = Db::getInstance(); // db connection
		$cid = $_GET['cid'];		// company id	
		
		$id = $_GET['id'];	
		$result = $db->query("update unattended_gl set flag='1' where company_id = '".$cid."' and description ='".$id."' ");				
		if(!$result){
			die('Invalid query: ' . mysql_error());
		}	
		
		    $created_by = $_SESSION['username'];
			$created_date    = date("Y-m-d"); 
			$created_time    = date("h:i:s"); 
			$system_name     = "Auto Accounts";
			$action_taken    = "Delete";
			$window_name     = "Accounting Year";
			
			$db->query("insert into audittrial(system_name, company_id, rec_date, rec_time, User_name, Action_taken, Window_name) values ('".$system_name."', '".$cid."', '".$created_date."', '".$created_time."', '".$created_by."', '".$action_taken."', '".$window_name."') ");	
		
		
      header("Location: ?controller=uncategorizedgl&action=index&cid=".$cid." ");		
    }

    public function error() {
      require_once('views/uncategorizedgl/error.php');
    }
  }
?>