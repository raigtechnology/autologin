<?php
  class GstbaddebtapprovedlistController {
  
	public function index() {      
	
		if(!isset($_SESSION['username'])){
			header("Location: ?controller=users&action=index");		
		}		
		
		$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}  
		$cid = $_GET['cid'];		// company id	
		
		$company = $db->query('SELECT id,company_name FROM companies where id ="'.$_SESSION['company_id'].'" ');	    
		foreach($company->fetchAll() as $com) {
			$company_name = $com['company_name'];
		} 
		
		$fromdate = date("Y-01-01");
		$todate = date("Y-m-d");
		
		if(isset($_POST['submit'])){
				
			$fromdate = date("Y-m-d", strtotime($_POST['from_date']));
			$todate = date("Y-m-d", strtotime($_POST['to_date']));				
				
			if(empty($fromdate)){
				$fromdate = date("Y-01-01");
				$todate = date("Y-m-d");
			}	
			
			
			$type = $_POST['type'];
				
			if($type=="Recovery"){
				$cond=" and taxcode='AJP' and invoice_date >= '".date("d/m/Y", strtotime($fromdate))."' AND invoice_date <= '".date("d/m/Y", strtotime($todate))."' ";				
			} else if($type=="Relief"){
				$cond=" and taxcode='AJS' and invoice_date >= '".date("d/m/Y", strtotime($fromdate))."' AND invoice_date <= '".date("d/m/Y", strtotime($todate))."' ";				
			} else {
				$cond=" and invoice_date >= '".date("d/m/Y", strtotime($fromdate))."' AND invoice_date <= '".date("d/m/Y", strtotime($todate))."' ";			
			}
		
		
		} else {
			$type="";
			$cond="";
		}
				
						
		// journal entries
		$tblbaddebtlist = array();		
		$tblbaddebt = $db->query("select 
									gs.invoice_no, gs.invoice_date, gs.5b_value, gs.6b_value, gs.5b, gs.6b, sc.description
								from 									
									gst5b6b as gs
									left join subcodes as sc on sc.code = gs.customer_id
								where 
									gs.company_id=".$cid." and sc.company_id='".$cid."' ".$cond." order by gs.invoice_date asc");		
				
											
		foreach($tblbaddebt->fetchAll() as $je) {
			$tblbaddebtlist[] = $je;
		} 			
	
						  
	  require_once('views/gstbaddebtapprovedlist/index.php'); 
	  
    }		
		

    public function error() {
      require_once('views/gstbaddebtapprovedlist/error.php');
    }
  }
?>
