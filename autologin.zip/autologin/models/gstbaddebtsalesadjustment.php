<?php
  class gstbaddebtsalesadjustment {
   
  }
?>