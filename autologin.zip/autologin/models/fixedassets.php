<?php
  class Fixedassets{
   
  }
?>