<?php
  class Companymaster {
   
  }
?>