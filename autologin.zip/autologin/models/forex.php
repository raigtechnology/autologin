<?php
  class Forex{
   
  }
?>