<?php
  class Disposal {
   
  }
?>