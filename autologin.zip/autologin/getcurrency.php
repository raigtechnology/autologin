<?php session_start();
	
	require_once("connection.php");
	$company_name = $_SESSION['company_name'];
		if($company_name=="ASIA PACIFIC MARINE(SAMPLE COMPANY)"){
			$db = Db::getInstance_sample();	
		} else {
			$db = Db::getInstance();	
		}		 
	
	$currencycode = "RM";
	$currencyrate = "1.00";
		
	$currencycodelist = $db->query("select CurrencyCode, Currencyrate from tblinvmaster_sales where AutoInvoiceID = '".$_GET['value1']."' and company_id ='".$_SESSION['company_id']."'  ");	
	foreach($currencycodelist->fetchAll() as $cur) {
		$currencycode = $cur['CurrencyCode'];
		$currencyrate = $cur['Currencyrate'];
	}		
	?>	
	<table style="border:hidden;" id="paymentsreceived_panel">		
	<tr>
		<td width="7%">Currency</td>
		<td width="18%">: 
			<select name="currency_code" id="currency_code"  class="selectbox_small" required="required" disabled="disabled">				
				<option value="RM" <?php if($currencycode=="RM"){?> selected="selected" <?php }?>>RM</option>
				<option value="USD" <?php if($currencycode=="USD"){?> selected="selected" <?php }?>>USD</option>
				<option value="EUR" <?php if($currencycode=="EUR"){?> selected="selected" <?php }?>>EUR</option>
			</select>					
		</td>		
		<td width="9%">Exchange Rate</td>
		<td width="16%">: <input type="text" name="exchange_rate" id="exchange_rate" style="text-align:right;" class="textbox_small" required="required" value="<?php echo $currencyrate; ?>" /></td>		
		<td width="50%"></td>
	</tr>
	</table>
